
	

function logVisitCount(){

			var counts = localStorage.getItem('visit_count');
			if (counts) {
            		localStorage.setItem('visit_count',visit_count);        
                } else {
                    localStorage.setItem('visit_count', 1);
                    }
                document.getElementById("visit_count").innerHTML = "Hey, you are visiting for  : " + localStorage.getItem('count') + " time(s).";
            } 

function httpGetStationsList(theUrl)
{	

    var xmlHttp = new XMLHttpRequest();
	// making a Asynchronous request, let other views load.
    
    xmlHttp.open( "GET", theUrl, true ); 
    xmlHttp.onload = function(e){
    	if(xmlHttp.status == 200)
    	{
    	var data = xmlHttp.responseText;
		var json = JSON.parse(data);
	
		var station = json.stations.station;
		for(var i=0;i< station.length; i++)
		{

			var select = document.getElementById("src");
			select.options[select.options.length] = new Option(  station[i].name,  station[i].abbr);

			var select2 = document.getElementById("dest");
			select2.options[select2.options.length] = new Option(  station[i].name,  station[i].abbr);
	  
		}
    	
    	}

    }

    xmlHttp.send( null );
   
			
}
	

	

function httpGet(theUrl)
{	
	var xmlHttp = new XMLHttpRequest();
	// Synchronous request. Since now only table has to be loaded whose data comes from url
	 // it makes sense to just asynchrous request. 
    xmlHttp.open( "GET", theUrl, false );
    xmlHttp.send( null );
	debug(data);
	// console.log(data)
	var json = JSON.parse(data);
	var trips = json.schedule.request.trip;
	var table = document.getElementById("myTable");
	table.innerHTML = "";
	
	var row = table.insertRow(table.rows.length);
  	var origin = row.insertCell(0);
   	var destination = row.insertCell(1);
 	var origTime = row.insertCell(2);
 	var destTime = row.insertCell(3);
 		
	origin.innerHTML = "Origin";
	destination.innerHTML = "Destination";
	origTime.innerHTML =  "Arrival Time";
    destTime.innerHTML = "Departure time";
    
	for(var i=0;i< trips.length; i++)
	{
	var thisTrip = trips[i]; 
	
		var row = table.insertRow(table.rows.length);
	    var origin = row.insertCell(0);
	    var destination = row.insertCell(1);
	    var origTime = row.insertCell(2);
	    var destTime = row.insertCell(3);
	
	
	origin.innerHTML = thisTrip["@attributes"].origin;
	destination.innerHTML = thisTrip["@attributes"].destination;
	origTime.innerHTML = thisTrip["@attributes"].origTimeMin;
    destTime.innerHTML = thisTrip["@attributes"].destTimeMin;
	}
	
		
}
	
function routes()
{
	var table = document.getElementById("myTable");
	table.innerHTML = "";
	
	
	var srcSelect = document.getElementById("src");
	var desSelect = document.getElementById("dest");

	var srcStation = srcSelect.options[srcSelect.selectedIndex].value;
	var destStation = desSelect.options[desSelect.selectedIndex].value;

	if (srcStation == destStation )
	{
		document.getElementById("selection").innerHTML = "Looks like you don't need a train, you are at your destination already 😎. On the other hand you can try selecting different Source and Destination.";
		return;
	}
	httpGet("http://bart.showmeeapp.com/trips.php?srcStation="+srcStation+"&destStation="+destStation); 
}

