	
function getParameterByName(name,url){
	name = name.replace(/[\[\]]/g, "\\$&");
		var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
			results = regex.exec(url);
		if (!results) return null;
		if (!results[2]) return '';
		return decodeURIComponent(results[2].replace(/\+/g, " "));
}
		
function logVisitCount()
	{

			var counts = localStorage.getItem('visit_count');
			if (counts) {
                    localStorage.setItem('visit_count', counts);
                } else {
                    localStorage.setItem('visit_count', 1);
                    Log.d("WTF","MLS");
                    }
                document.getElementById("visit_count").innerHTML = "Hey, you are visiting for  : " + localStorage.getItem('count') + " time(s).";
	} 


	
	
	function httpGet(theUrl)
	{	

	var lat;
    var lng;
	
		var xmlHttp = new XMLHttpRequest();
		xmlHttp.open( "GET", theUrl, false ); 
		xmlHttp.send( null );
		var data = xmlHttp.responseText;
		var json = JSON.parse(data);
		var station = json.stations.station;
		
		document.getElementById("head").innerHTML = station.name;
		document.getElementById("stationAddress").innerHTML = station.address;
		document.getElementById("stationCity").innerHTML = station.city + ", "+ station.state + " " + station.zipcode ;
		
		lat = station.gtfs_latitude;
		lng=	station.gtfs_longitude;
		var mapProp= {
			center:new google.maps.LatLng(lat,lng),
			zoom:16,
			};
		var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
	}

