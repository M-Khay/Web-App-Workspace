<?php
    header("Access-Control-Allow-Origin: *");
	
	$srcStation = $_GET['srcStation'];
	$destStation= $_GET['destStation'];
	    //  the srcStation and desStation has the source and destination address using those we call the bart api to get the list of trains on that route.
	$xml = file_get_contents("http://api.bart.gov/api/sched.aspx?cmd=depart&orig=" . $srcStation . "&dest=" . $destStation . "&date=now&key=MW9S-E7SL-26DU-VV8V&b=0&a=4&l=1");
    
    // Basic string manupalation functions to replace white space in form of new line, tabs etc
	$fileContents = str_replace(array("\n", "\r", "\t"), '', $xml);

	// trim function to remove the empty space.
    $fileContents = trim(str_replace('"', "'", $fileContents));
    $simpleXml = simplexml_load_string($fileContents);

    // converting xml to json using standard inbuilt library.
    $json = json_encode($simpleXml);
    
    print_r($json);

?>