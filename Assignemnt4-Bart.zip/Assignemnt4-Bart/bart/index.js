function visitCount(){
        $(document).ready(function (){
		
		// Functio to store and retrive user visit in web storage.

            if(typeof(Storage) !== "undefined") {

                var counts = localStorage.getItem('visit_count');
                if (counts) {
                    localStorage.setItem('visit_count', Number(counts) + 1);
                } else {
                    localStorage.setItem('visit_count', 1);
                }
                document.getElementById("visit_count").innerHTML = "Hey,this is your: " + localStorage.getItem('count') + " visit. Keep Comming.";
            }

        });
	
    }