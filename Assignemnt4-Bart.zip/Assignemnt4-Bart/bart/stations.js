	
function logVisitCount(){

			var counts = localStorage.getItem('visit_count');
			if (counts) {
                    
                } else {
                    localStorage.setItem('visit_count', 1);
                    }
                document.getElementById("visit").innerHTML = "Hey, you are visiting for  : " + localStorage.getItem('count') + " time(s).";
             
	}

function httpGet(theUrl)
{

		
    var xmlHttp = new XMLHttpRequest();
	// making a Asynchronous request, let other views load.

    xmlHttp.open( "GET", theUrl, true ); 
    xmlHttp.onload = function(e){
    	if(xmlHttp.status==200){

    var data = xmlHttp.responseText;
	var json = JSON.parse(data);
	
	var station = json.stations.station;
	
	var totalStations = Object.keys(station).length;
	
	for(var i=0;i< station.length; i++)
	{
		var listElement = document.createElement('li');

		var a = document.createElement('a');
		a.innerHTML = station[i].name+ ", "+station[i].city;
		a.setAttribute('href',"station.html?orig="+ station[i].abbr );
		a.href = "station.html?orig="+ station[i].abbr ; 
		
		listElement.appendChild(a);
		document.getElementById('station_list').appendChild(listElement);
	  
	}
    }
    }
    
	
	  xmlHttp.send( null );	
}


	

