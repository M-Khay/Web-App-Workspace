from django.conf import settings
from django.db.models import Count, Avg, Max, Min, StdDev, Q, F
from api.utils import KM_DISTANCE_FILTER, unique
from api import tasks
from django.contrib.gis.measure import D
from django.utils import timezone
from datetime import datetime, timedelta, date
from itertools import groupby
import whatsgoodly.models
import redis
import socket
import json
import os

is_development = os.environ.get('env') == 'vagrant'

BREAKDOWN_RESPONSE_INTERVAL = 5000
MIN_SAMPLE_SIZE = 0 if is_development else 20
MIN_SAMPLE_SIZE_FRIENDS = 0 if is_development else 5
MIN_SIGNIFICANCE = 0.0 if is_development else 0.136 # 2nd std dev
FRIDAY = 4
cache = redis.StrictRedis(host='localhost', port=6379, db=0)

# MAIN
# Add all tasks here to be run periodically by
# the analytics instance, e.g. on Response save
# NOTE: Don't run queries here and don't queue tasks
# with every call to this method
# since Response saves happen too frequently!
def periodic_tasks(response_id=None):
    from whatsgoodly.models import Response, Feed
    
    if response_id and response_id % BREAKDOWN_RESPONSE_INTERVAL == 0:
        # Run Response-periodic tasks
        
        poll_ids = list(Response.objects.filter(
                pk__lte=response_id, pk__gt=response_id-BREAKDOWN_RESPONSE_INTERVAL
            ).values('poll_instance__poll_id').annotate(
                count=Count('poll_instance__poll_id')
                # total=Max('poll_instance__poll__breakdowns__total')
            ).filter(
                # Recompute high-velocity polls
                Q(count__gte=MIN_SAMPLE_SIZE_FRIENDS) |
                Q(poll_instance__feed__guaranteed_breakdowns=True)
                # also recompute significant changes in My Feeds feeds
                # Q(total__range=[MIN_SAMPLE_SIZE/2, MIN_SAMPLE_SIZE], poll_instance__feed__category__in=Feed.REALTIME_BREAKDOWNS) 
            ).values_list('poll_instance__poll_id', flat=True).distinct())

        if poll_ids:
            tasks.recompute_breakdowns.delay(poll_ids)
            # tasks.update_relationships.delay(poll_ids[:1], min_response_id=response_id-BREAKDOWN_RESPONSE_INTERVAL)

    if is_analytics_instance():
        # Run time-periodic tasks

        today = datetime.now().date()
        this_month = date(today.year, today.month, 1)

        if str(today) != cache.get('WG.last_day_logged'):
            # First for the day!
            cache.set('WG.last_day_logged', str(today))
            tasks.log_engagement_metrics.delay(yesterday=True)
            # Index all breakdowns in elasticsearch
            # tasks.elasticsearch_index_breakdowns.delay()

            if today.weekday() == FRIDAY:
                tasks.school_polls_of_the_week.delay()

        if str(this_month) != cache.get('WG.last_month_logged'):
            # First for the month!
            cache.set('WG.last_month_logged', str(this_month))
            tasks.log_engagement_metrics.delay(last_month=True)

def grouped_responses(response_queryset, sql_group_function,
                      group_label_key='date', group_label_column='created_date'):
    '''
    Groups Response objects by `sql_group_function`, labeling groups by
    their minimum `group_label_column`
    '''
    from whatsgoodly.models import Response

    get_group_label = lambda x: x[group_label_key]

    counted = response_queryset.annotate(g=sql_group_function).values(
            'g', 'response'
        ).order_by().annotate(
            # Grouped by date and option choice
            **{
              group_label_key: Min(group_label_column),
              'count': Count('pk'),
              'options': Min('poll_instance__poll__options')
            }
        ).values(
            group_label_key, 'g', 'response', 'count', 'options'
        )

    # Group by g
    grouped = groupby(counted.order_by('g', group_label_key), key=lambda x: x['g'])

    stats = []
    for g, iterator in grouped:
        values = list(iterator)
        group_label = values[0][group_label_key]
        options = json.loads(values[0]['options'])
        totals = [
            next( (a['count'] for a in values
                  if a['response'] == i), 0 )
            for i in range(len(options))
        ]
        stats.append({
            group_label_key: group_label,
            "totals": totals,
            "options": options
        })

    # Sort by group label
    return sorted(stats, key=get_group_label)    

def moving_average_field(feed_id, field_name='vote_aggregate', min_date=None, poll_location=None, poll_community_id=None, filters=None):
    from whatsgoodly.models import PollInstance
    # Default to two weeks ago
    min_date = min_date or (timezone.now() - timedelta(days=14))
    queryset = PollInstance.objects.undeleted().filter(
            feed_id=feed_id,
            created_date__gte=min_date
        )
    if poll_location:
        queryset = queryset.filter(
            location__distance_lte=(poll_location, D(km=KM_DISTANCE_FILTER))
        )
    if poll_community_id:
        queryset = queryset.filter(
            community_id=poll_community_id
        )
    if filters:
        queryset = queryset.filter(**filters)

    stats = queryset.aggregate(avg=Avg(field_name), stddev=StdDev(field_name))

    return (stats['avg'] or 1, stats['stddev'] or 0)

# Use this with related_model = Comment or Response
# Optimized for speed
def moving_average(feed_id, related_model, min_date=None, poll_location=None, filters=None):
    # Default to two weeks ago
    min_date = min_date or (timezone.now() - timedelta(days=14))
    queryset = related_model.objects.all()
    if poll_location:
        queryset = queryset.filter(
                poll_instance__location__distance_lte=(poll_location, D(km=KM_DISTANCE_FILTER))
            )
    if filters:
        queryset = queryset.filter(**filters)

    avg = queryset.filter(
            poll_instance__feed_id=feed_id,
            poll_instance__created_date__gte=min_date,
            poll_instance__deleted=False,
            poll_instance__poll__deleted=False
        ).values('poll_instance_id')\
        .annotate(count=Count('poll_instance_id'))\
        .aggregate(avg=Avg('count'))['avg']

    return avg or 1

def campus_users_by_gender(university):
    counts = whatsgoodly.models.User.objects.filter(university=university)\
        .values('gender')\
        .annotate(count=Count('gender'))\
        .values('gender', 'count')\
        .order_by('gender')

    male = next((c['count'] for c in counts if c.get('gender') == 0), 0)
    female = next((c['count'] for c in counts if c.get('gender') == 1), 0)
    not_chosen = next((c['count'] for c in counts if c.get('gender') == -1), 0)
    return (male, female, not_chosen)

def device_breakdowns(poll):
    # Copy constants here in case running from migration
    PollBreakdown = whatsgoodly.models.PollBreakdown
    MOBILE, WEB, GENDER, UNIVERSITY, SEGMENT = range(5)
    breakdowns = []
    num_options = len(json.loads(poll.options))

    mobile_stats = whatsgoodly.models.Response.objects.filter(
            poll_instance__poll_id=poll.id,
            referrer__isnull=True
        ).values('response').annotate(
            count=Count('user', distinct=True)
        ).values('response', 'count')

    web_stats = whatsgoodly.models.Response.objects.filter(
            poll_instance__poll_id=poll.id,
            referrer__isnull=False
        ).values('response').annotate(
            count=Count('user', distinct=True)
        ).values('response', 'count')

    breakdowns = []

    for btype, stats in [(MOBILE, mobile_stats), (WEB, web_stats)]:
        counts = [
            next( (s['count'] for s in stats if s['response'] == i), 0 )
            for i in range(num_options)
        ]
        breakdowns.append(
            PollBreakdown(
                poll_id=poll.id,
                breakdown_type=btype,
                json=json.dumps(counts),
                total=sum(counts)
            )
        )
    return breakdowns

def gender_breakdowns(poll, control=None):
    PollBreakdown = whatsgoodly.models.PollBreakdown
    Poll = whatsgoodly.models.Poll

    if poll.gender != Poll.GENDERS.ALL:
        # Don't do gendered polls
        return []

    # Copy constants here in case running from migration
    MOBILE, WEB, GENDER, UNIVERSITY, SEGMENT = range(5)
    breakdowns = []
    num_options = len(json.loads(poll.options))

    # Gender votes
    stats = whatsgoodly.models.Response.objects.filter(
            poll_instance__poll_id=poll.id,
            user__gender__gte=0
        ).values('user__gender', 'response').annotate(
            count=Count('user', distinct=True)
        ).values('user__gender', 'response', 'count')

    grouped = groupby(stats.order_by('user__gender'), key=lambda x: x['user__gender'])

    breakdowns = []
    control = control or PollBreakdown.objects.get(
            breakdown_type=PollBreakdown.TYPES.MOBILE,
            poll=poll
        )

    for gender, iterator in grouped:
        values = list(iterator)
        counts_for_gender = [
            next( (s['count'] for s in values if s['response'] == i), 0 )
            for i in range(num_options)
        ]
        breakdowns.append(
            PollBreakdown(
                poll_id=poll.id,
                breakdown_type=GENDER,
                gender=gender,
                json=json.dumps(counts_for_gender),
                total=sum(counts_for_gender)
            )
        )

    for breakdown in breakdowns:
        breakdown.significance = calc_significance(breakdown, control)

    return breakdowns

def university_breakdowns(poll, control=None):
    # Copy constants here in case running from migration
    PollBreakdown = whatsgoodly.models.PollBreakdown
    Response = whatsgoodly.models.Response
    MOBILE, WEB, GENDER, UNIVERSITY, SEGMENT = range(5)
    breakdowns = []
    control = control or PollBreakdown.objects.get(
            breakdown_type=PollBreakdown.TYPES.MOBILE,
            poll=poll
        )
    num_options = len(json.loads(poll.options))

    poll_responses = Response.objects.filter(poll_instance__poll_id=poll.id)

    # Only check significant universities
    significant_uni_ids = poll_responses.filter(
            user__university__isnull=False,
        ).values('user__university_id').annotate(
            count=Count('user__university_id')
        ).filter(
            count__gte=MIN_SAMPLE_SIZE
        ).values('user__university_id')

    stats = poll_responses.filter(
            user__university_id__in=significant_uni_ids
        ).values('user__university_id', 'response').annotate(
            count=Count('user', distinct=True)
        ).values('user__university_id', 'response', 'count')

    grouped = groupby(stats.order_by('user__university_id'), key=lambda x: x['user__university_id'])

    for university_id, iterator in grouped:
        values = list(iterator)
        counts_for_uni = [
            next( (s['count'] for s in values if s['response'] == i), 0 )
            for i in range(num_options)
        ]
        breakdowns.append(
            PollBreakdown(
                poll_id=poll.id,
                breakdown_type=UNIVERSITY,
                university_id=university_id,
                json=json.dumps(counts_for_uni),
                total=sum(counts_for_uni)
            )
        )

    for breakdown in breakdowns:
        breakdown.significance = calc_significance(breakdown, control)

    return breakdowns

def segment_breakdowns(poll, control=None):
    # Copy constants here in case running from migration
    PollBreakdown = whatsgoodly.models.PollBreakdown
    Response = whatsgoodly.models.Response
    Segmenter = whatsgoodly.models.Segmenter
    MOBILE, WEB, GENDER, UNIVERSITY, SEGMENT = range(5)
    breakdowns = []
    control = control or PollBreakdown.objects.get(
            breakdown_type=PollBreakdown.TYPES.MOBILE,
            poll=poll
        )
    num_options = len(json.loads(poll.options))

    poll_responses = Response.objects.filter(poll_instance__poll_id=poll.id)

    # Only check significant segmenters
    significant_segmenters = Response.objects.filter(
            poll_instance__poll__segmenter__isnull=False,
            user__in=poll_responses.values('user')
        ).values('poll_instance__poll__segmenter').annotate(
            count=Count('poll_instance__poll__segmenter')
        ).filter(
            Q(count__gte=F('poll_instance__poll__segmenter__min_votes_for_breakdown'))
        ).values('poll_instance__poll__segmenter')

    # Iterate over significant segmenters
    for seg in Segmenter.objects.filter(
            id__in=significant_segmenters
        ).exclude(pk=poll.id):

        num_seg_options = len(json.loads(seg.options))
        # Iterate over segment options
        for option in range(num_seg_options):
            segment_responses = Response.objects.filter(
                    poll_instance__poll__segmenter=seg,
                    response=option
                )

            option_stats = poll_responses.filter(
                    user__in=segment_responses.values('user')
                ).values('response').annotate(
                    count=Count('user', distinct=True)
                ).values('response', 'count')
            
            counts_for_option = [
                next( (s['count'] for s in option_stats if s['response'] == i), 0 )
                for i in range(num_options)
            ]
            breakdowns.append(
                PollBreakdown(
                    poll_id=poll.id,
                    breakdown_type=SEGMENT,
                    segmenter_id=seg.id,
                    segment_option=option,
                    json=json.dumps(counts_for_option),
                    total=sum(counts_for_option)
                )
            )

    for breakdown in breakdowns:
        breakdown.significance = calc_significance(breakdown, control)

    return breakdowns

def friend_breakdown(poll, user, control=None):
    # Copy constants here in case running from migration
    PollBreakdown = whatsgoodly.models.PollBreakdown
    Response = whatsgoodly.models.Response
    MOBILE, WEB, GENDER, UNIVERSITY, SEGMENT = range(5)
    control = control or PollBreakdown.objects.get(
            breakdown_type=PollBreakdown.TYPES.MOBILE,
            poll=poll
        )
    num_options = len(json.loads(poll.options))

    friend_numbers = Friendship.objects.filter(user=user).values_list('friend_phone_number', flat=True)

    stats = Response.objects.filter(
            poll_instance__poll_id=poll.id,
            user__phone_number__in=friend_numbers
        ).values('response').annotate(
            count=Count('user', distinct=True)
        ).values('response', 'count')

    counts_for_friends = [
        next( (s['count'] for s in stats if s['response'] == i), 0 )
        for i in range(num_options)
    ]
    breakdown = PollBreakdown(
            poll_id=poll.id,
            breakdown_type=MOBILE, # TODO special type
            json=json.dumps(counts_for_friends),
            total=sum(counts_for_friends)
        )
    breakdown.significance = calc_significance(breakdown, control)

    return breakdown

# Get the maximum percent difference between 
# a poll breakdown and a control breakdown (e.g. for MOBILE)
def calc_significance(poll_breakdown, control):
    opt_counts = json.loads(poll_breakdown.json)
    total = sum(opt_counts)
    control_counts = json.loads(control.json)
    control_total = sum(control_counts)
    percent_diffs = sorted(
            ( abs( o/float(total or 1) - c/float(control_total or 1) )
              for o,c in zip(opt_counts, control_counts) ),
            reverse=True
        )
    if len(percent_diffs) > 0:
        return percent_diffs[0]
    print "Warning, got no diffs between {0} and {1}".format(poll_breakdown, control)
    return 0

def is_analytics_instance():
    host = socket.gethostbyname(socket.gethostname())
    return host == settings.ANALYTICS_INSTANCE_IP
