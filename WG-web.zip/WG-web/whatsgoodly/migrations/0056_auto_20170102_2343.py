# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0055_auto_20170102_2055'),
    ]

    operations = [
        migrations.AddField(
            model_name='survey',
            name='account',
            field=models.ForeignKey(blank=True, to='whatsgoodly.Account', null=True),
        ),
        migrations.AlterField(
            model_name='pollinstance',
            name='poll',
            field=models.ForeignKey(related_name='instances', to='whatsgoodly.Poll'),
        ),
    ]
