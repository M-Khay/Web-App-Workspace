# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0059_auto_20170106_0105'),
    ]

    operations = [
        migrations.AddField(
            model_name='feed',
            name='allow_option_photos',
            field=models.BooleanField(default=False),
        ),
        migrations.AlterField(
            model_name='pollinstance',
            name='promotion',
            field=models.IntegerField(default=0, db_index=True, choices=[(0, b'None'), (1, b'Accelerated'), (2, b'Hot'), (3, b'Globalled'), (4, b'Sponsored'), (5, b'Pinned'), (6, b'Poll of the Week')]),
        ),
    ]
