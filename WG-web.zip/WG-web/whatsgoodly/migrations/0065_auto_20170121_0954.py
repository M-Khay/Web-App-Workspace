# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import whatsgoodly.managers


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0064_auto_20170121_0849'),
    ]

    operations = [
        migrations.AlterModelManagers(
            name='pollinstance',
            managers=[
                ('objects', whatsgoodly.managers.PollInstanceManager()),
                ('sponsored', whatsgoodly.managers.SponsoredPollInstanceManager()),
            ],
        ),
        migrations.AlterModelManagers(
            name='segmenterinstance',
            managers=[
                ('objects', whatsgoodly.managers.SegmenterInstanceManager()),
            ],
        ),
        migrations.AlterModelManagers(
            name='user',
            managers=[
                ('objects', whatsgoodly.managers.UserManager()),
            ],
        ),
    ]
