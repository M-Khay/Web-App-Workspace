# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0072_auto_20170131_0432'),
    ]

    operations = [
        migrations.AddField(
            model_name='account',
            name='is_public',
            field=models.BooleanField(default=False),
        ),
    ]
