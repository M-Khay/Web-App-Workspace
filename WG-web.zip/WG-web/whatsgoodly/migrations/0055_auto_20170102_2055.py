# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0054_auto_20161221_2035'),
    ]

    operations = [
        migrations.AlterField(
            model_name='notification',
            name='notification_type',
            field=models.IntegerField(default=0, choices=[(0, b'From Whatsgoodly'), (1, b'Poll Results'), (2, b'Audience Boost'), (3, b'Reply'), (4, b'Popular Comment'), (5, b'Claim Your Coins!'), (6, b'Top Poll'), (7, b'Favorite Poll'), (8, b'Referral Joined'), (9, b'Tag Accepted'), (10, b"You've Been Tagged"), (11, b'Pinned Poll'), (12, b'Fire Poll'), (13, b'New Friend'), (14, b'Friend Poll'), (15, b'US National Poll'), (16, b'Significant Filter Notice'), (17, b"You've Been Mentioned")]),
        ),
    ]
