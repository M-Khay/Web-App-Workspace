# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0050_es_breakdowns'),
    ]

    operations = [
        migrations.AddField(
            model_name='account',
            name='subscribed_breakdowns',
            field=models.ManyToManyField(related_name='subscribed_accounts', to='whatsgoodly.Segmenter', blank=True),
        ),
        migrations.AddField(
            model_name='account',
            name='subscribed_tags',
            field=models.ManyToManyField(to='whatsgoodly.PollTag', blank=True),
        ),
    ]
