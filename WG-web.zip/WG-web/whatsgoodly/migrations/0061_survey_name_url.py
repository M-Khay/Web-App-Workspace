# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0060_auto_20170110_0205'),
    ]

    operations = [
        migrations.AddField(
            model_name='survey',
            name='name_url',
            field=models.CharField(db_index=True, max_length=180, null=True, blank=True),
        ),
    ]
