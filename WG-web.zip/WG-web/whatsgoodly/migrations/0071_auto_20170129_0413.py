# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0070_auto_20170127_0100'),
    ]

    operations = [
        migrations.CreateModel(
            name='NotificationCampaign',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('name', models.CharField(max_length=180)),
                ('notification_type', models.IntegerField(default=0, choices=[(-1, b'From SVB'), (0, b'From Whatsgoodly'), (1, b'Poll Results'), (2, b'Audience Boost'), (3, b'Reply'), (4, b'Popular Comment'), (5, b'Claim Your Coins!'), (6, b'Top Poll'), (7, b'Favorite Poll'), (8, b'Referral Joined'), (9, b'Tag Accepted'), (10, b"You've Been Tagged"), (11, b'Pinned Poll'), (12, b'Fire Poll'), (13, b'New Friend'), (14, b'Friend Poll'), (15, b'US National Poll'), (16, b'Significant Filter Notice'), (17, b"You've Been Mentioned"), (18, b'Poll of the Week'), (19, b'Trump Tracker')])),
                ('customization', models.IntegerField(default=0, choices=[(0, b'None'), (1, b'University as prefix'), (2, b'University as suffix')])),
                ('response_filter', models.CharField(max_length=255, blank=True)),
                ('user_filter', models.CharField(max_length=255, blank=True)),
                ('active_in_last_days', models.IntegerField(default=0)),
                ('account', models.ForeignKey(blank=True, to='whatsgoodly.Account', null=True)),
                ('determining_poll', models.ForeignKey(blank=True, to='whatsgoodly.Poll', null=True)),
            ],
            options={
                'abstract': False,
            },
        ),
        migrations.AlterField(
            model_name='notification',
            name='notification_type',
            field=models.IntegerField(default=0, choices=[(-1, b'From SVB'), (0, b'From Whatsgoodly'), (1, b'Poll Results'), (2, b'Audience Boost'), (3, b'Reply'), (4, b'Popular Comment'), (5, b'Claim Your Coins!'), (6, b'Top Poll'), (7, b'Favorite Poll'), (8, b'Referral Joined'), (9, b'Tag Accepted'), (10, b"You've Been Tagged"), (11, b'Pinned Poll'), (12, b'Fire Poll'), (13, b'New Friend'), (14, b'Friend Poll'), (15, b'US National Poll'), (16, b'Significant Filter Notice'), (17, b"You've Been Mentioned"), (18, b'Poll of the Week'), (19, b'Trump Tracker')]),
        ),
        migrations.AlterField(
            model_name='survey',
            name='timeline_setting',
            field=models.IntegerField(default=0, choices=[(0, b'None'), (1, b'Daily'), (2, b'Weekly'), (3, b'Monthly')]),
        ),
        migrations.AddField(
            model_name='notification',
            name='campaign',
            field=models.ForeignKey(blank=True, to='whatsgoodly.NotificationCampaign', null=True),
        ),
    ]
