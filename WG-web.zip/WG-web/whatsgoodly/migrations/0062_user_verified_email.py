# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models

def add_verified_email(apps, schema_editor):
    User = apps.get_model('whatsgoodly', 'User')

    User.objects.filter(
        verified_university=True,
        email__contains="@"
    ).update(
        verified_email=True
    )

def undo_add_verified_email(apps, schema_editor):
    pass

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0061_survey_name_url'),
    ]

    operations = [
        migrations.AddField(
            model_name='user',
            name='verified_email',
            field=models.BooleanField(default=False),
        ),

        migrations.RunPython(add_verified_email, reverse_code=undo_add_verified_email),
    ]
