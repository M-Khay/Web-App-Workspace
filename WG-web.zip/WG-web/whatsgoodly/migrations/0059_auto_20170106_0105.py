# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from whatsgoodly import analytics

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0058_auto_20170106_0046'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='segmenter',
            name='min_votes_per_option',
        ),
        migrations.AddField(
            model_name='segmenter',
            name='min_votes_for_breakdown',
            field=models.IntegerField(default=analytics.MIN_SAMPLE_SIZE),
        ),
    ]
