# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0074_survey_description'),
    ]

    operations = [
        migrations.AddField(
            model_name='university',
            name='population_size',
            field=models.IntegerField(default=0),
        ),
    ]
