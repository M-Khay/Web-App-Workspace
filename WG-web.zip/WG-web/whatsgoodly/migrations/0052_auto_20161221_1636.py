# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0051_auto_20161213_1406'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='account',
            options={'ordering': ('name_short',)},
        ),
        migrations.AlterModelOptions(
            name='polltag',
            options={'ordering': ('label_lower',)},
        ),
        migrations.AlterModelOptions(
            name='university',
            options={'ordering': ('name',)},
        ),
        migrations.RenameField(
            model_name='account',
            old_name='name',
            new_name='name_short',
        ),
        migrations.AlterField(
            model_name='university',
            name='name',
            field=models.CharField(unique=True, max_length=180, db_index=True),
        ),
        migrations.AlterIndexTogether(
            name='university',
            index_together=set([]),
        ),
    ]
