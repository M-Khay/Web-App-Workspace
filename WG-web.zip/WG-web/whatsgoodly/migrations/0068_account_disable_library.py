# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0067_poll_question_picture_url'),
    ]

    operations = [
        migrations.AddField(
            model_name='account',
            name='disable_library',
            field=models.BooleanField(default=False),
        ),
    ]
