# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0066_feed_guaranteed_breakdowns'),
    ]

    operations = [
        migrations.AddField(
            model_name='poll',
            name='question_picture_url',
            field=models.URLField(default=None, null=True, blank=True),
        ),
    ]
