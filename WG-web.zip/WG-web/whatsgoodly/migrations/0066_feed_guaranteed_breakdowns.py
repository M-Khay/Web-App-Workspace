# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0065_auto_20170121_0954'),
    ]

    operations = [
        migrations.AddField(
            model_name='feed',
            name='guaranteed_breakdowns',
            field=models.BooleanField(default=False),
        ),
    ]
