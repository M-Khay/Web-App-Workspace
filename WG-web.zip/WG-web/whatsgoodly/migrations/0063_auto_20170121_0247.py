# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.contrib.gis.db.models.fields
from whatsgoodly.utils import non_atomic_migration

BATCHSIZE = 5000

@non_atomic_migration
def add_locations_to_responses(apps, schema_editor):
    Feed = apps.get_model('whatsgoodly', 'Feed')
    PollInstance = apps.get_model('whatsgoodly', 'PollInstance')

    local_feed = Feed.objects.get(category=0)

    max_pk = PollInstance.objects.aggregate(models.Max('pk'))['pk__max']

    for offset in range(0, max_pk+1, BATCHSIZE):
        # print "OFFSET {}".format(offset)
        # Only do non-campus polls, because users may have teleported
        # to campus to respond to campus polls
        for pi in PollInstance.objects.filter(
                community__isnull=True, feed=local_feed,
                pk__gte=offset,
                pk__lt=offset+BATCHSIZE
            ):
            pi.response_set.update(location=pi.location)

def undo_add_locations_to_responses(apps, schema_editor):
    pass

def clear_userrels(apps, schema_editor):
    UserRelationship = apps.get_model('whatsgoodly', 'UserRelationship')

    UserRelationship.objects.all().delete()

def undo_clear_userrels(apps, schema_editor):
    pass


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0062_user_verified_email'),
    ]

    operations = [
        migrations.RunPython(clear_userrels, reverse_code=undo_clear_userrels),

        migrations.AlterUniqueTogether(
            name='userrelationship',
            unique_together=set([]),
        ),
        migrations.AlterIndexTogether(
            name='userrelationship',
            index_together=set([]),
        ),

        migrations.AlterField(
            model_name='response',
            name='poll_instance',
            field=models.ForeignKey(to='whatsgoodly.PollInstance', db_index=False),
        ),
        migrations.AddField(
            model_name='response',
            name='location',
            field=django.contrib.gis.db.models.fields.PointField(srid=4326, null=True, blank=True),
        ),

        migrations.RunPython(add_locations_to_responses, reverse_code=undo_add_locations_to_responses),
    ]
