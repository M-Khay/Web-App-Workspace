# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.contrib.gis.db.models.fields
import django.db.models.manager
import django.contrib.auth.models
import django.utils.timezone
from django.conf import settings
import django.core.validators
import whatsgoodly.managers


class Migration(migrations.Migration):

    dependencies = [
        ('auth', '0006_require_contenttypes_0002'),
    ]

    operations = [
        migrations.CreateModel(
            name='User',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('password', models.CharField(max_length=128, verbose_name='password')),
                ('last_login', models.DateTimeField(null=True, verbose_name='last login', blank=True)),
                ('is_superuser', models.BooleanField(default=False, help_text='Designates that this user has all permissions without explicitly assigning them.', verbose_name='superuser status')),
                ('username', models.CharField(error_messages={'unique': 'A user with that username already exists.'}, max_length=30, validators=[django.core.validators.RegexValidator('^[\\w.@+-]+$', 'Enter a valid username. This value may contain only letters, numbers and @/./+/-/_ characters.', 'invalid')], help_text='Required. 30 characters or fewer. Letters, digits and @/./+/-/_ only.', unique=True, verbose_name='username')),
                ('first_name', models.CharField(max_length=30, verbose_name='first name', blank=True)),
                ('last_name', models.CharField(max_length=30, verbose_name='last name', blank=True)),
                ('email', models.EmailField(max_length=254, verbose_name='email address', blank=True)),
                ('is_staff', models.BooleanField(default=False, help_text='Designates whether the user can log into this admin site.', verbose_name='staff status')),
                ('is_active', models.BooleanField(default=True, help_text='Designates whether this user should be treated as active. Unselect this instead of deleting accounts.', verbose_name='active')),
                ('date_joined', models.DateTimeField(default=django.utils.timezone.now, verbose_name='date joined')),
                ('gender', models.IntegerField(default=-1, choices=[(-1, b'Not chosen'), (0, b'Male'), (1, b'Female')])),
                ('notification_count', models.IntegerField(default=0)),
                ('karma', models.IntegerField(default=0)),
                ('credits', models.IntegerField(default=0)),
                ('phone_number', models.CharField(db_index=True, max_length=15, null=True, blank=True)),
                ('verified_phone_number', models.BooleanField(default=False)),
                ('full_name', models.CharField(max_length=180, null=True, blank=True)),
                ('verified_university', models.BooleanField(default=False)),
                ('verification_token', models.CharField(max_length=10, null=True, blank=True)),
                ('ip_address', models.GenericIPAddressField(default=None, null=True, blank=True)),
                ('last_user_agent', models.CharField(max_length=256, null=True, blank=True)),
                ('posting_suspended', models.BooleanField(default=False)),
                ('denied_push_notifications', models.BooleanField(default=False)),
                ('ios_apns_token', models.CharField(max_length=255, null=True, blank=True)),
                ('gcm_token', models.CharField(max_length=255, null=True, blank=True)),
                ('aws_sns_arn_endpoint', models.CharField(max_length=255, null=True, blank=True)),
                ('app_session', models.BooleanField(default=False)),
                ('web_session', models.BooleanField(default=False)),
                ('created_date', models.DateTimeField(auto_now_add=True, null=True)),
                ('modified_date', models.DateTimeField(auto_now=True, null=True)),
            ],
            options={
                'abstract': False,
                'verbose_name': 'user',
                'verbose_name_plural': 'users',
            },
            managers=[
                ('objects', django.contrib.auth.models.UserManager()),
                # ('reachable', whatsgoodly.managers.ReachableUserManager()),
            ],
        ),
        migrations.CreateModel(
            name='Account',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('name', models.CharField(unique=True, max_length=180)),
            ],
            options={
                'abstract': False,
            },
        ),
        migrations.CreateModel(
            name='Announcement',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('user_filter', models.PositiveSmallIntegerField(default=0, choices=[(0, b'None'), (1, b'iOS'), (2, b'Android')])),
                ('message', models.CharField(max_length=300)),
                ('show_invite_button', models.BooleanField(default=False)),
                ('active', models.BooleanField(default=False)),
                ('location', django.contrib.gis.db.models.fields.PointField(srid=4326, null=True, blank=True)),
                ('image_url', models.URLField(null=True, blank=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
            ],
            options={
                'ordering': ('-active', '-id'),
            },
        ),
        migrations.CreateModel(
            name='Comment',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('text', models.CharField(max_length=255)),
                ('vote_aggregate', models.IntegerField(default=0, db_index=True)),
                ('user_karma_on_create', models.IntegerField(default=0)),
                ('censor_level', models.IntegerField(default=0, choices=[(0, b'None'), (1, b'Auto-Deleted'), (2, b'Language'), (3, b'Names')])),
                ('deleted', models.BooleanField(default=False)),
                ('deleted_by_creator', models.BooleanField(default=False)),
                ('verified', models.BooleanField(default=False)),
                ('rejected', models.BooleanField(default=False)),
                ('ip_address', models.GenericIPAddressField(default=None, null=True, blank=True)),
            ],
            options={
                'abstract': False,
            },
        ),
        migrations.CreateModel(
            name='CommentVote',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('vote', models.IntegerField()),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('comment', models.ForeignKey(to='whatsgoodly.Comment')),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='Favorite',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='Feed',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=180)),
                ('active', models.BooleanField(default=False)),
                ('start_date', models.DateTimeField(null=True, blank=True)),
                ('end_date', models.DateTimeField(null=True, blank=True)),
                ('promotion_day', models.IntegerField(default=0, choices=[(0, b'None'), (1, b'Sunday'), (2, b'Monday'), (3, b'Tuesday'), (4, b'Wednesday'), (5, b'Thursday'), (6, b'Friday'), (7, b'Saturday')])),
                ('created_date', models.DateTimeField(auto_now_add=True, null=True)),
                ('modified_date', models.DateTimeField(auto_now=True, null=True)),
                ('category', models.IntegerField(default=4, db_index=True, choices=[(0, b'Local'), (1, b'Global'), (2, b'Featured'), (3, b'My Feeds Featured'), (4, b'Campus Scene'), (5, b'Campus'), (6, b'Peek')])),
                ('level', models.IntegerField(default=4, choices=[(0, b'High School'), (1, b'College'), (2, b'Post College'), (3, b'All in School'), (4, b'All Ages')])),
                ('image_source', models.URLField(null=True, blank=True)),
                ('approve_posts', models.BooleanField(default=False)),
                ('allow_audio', models.BooleanField(default=False)),
                ('allow_photos', models.BooleanField(default=False)),
                ('location', django.contrib.gis.db.models.fields.PointField(srid=4326, null=True, blank=True)),
            ],
            options={
                'ordering': ('-active', 'category', '-id'),
            },
        ),
        migrations.CreateModel(
            name='FeedCondition',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('response_filter', models.CharField(default=None, max_length=255, null=True, blank=True)),
                ('user_filter', models.CharField(default=None, max_length=255, null=True, blank=True)),
            ],
            options={
                'abstract': False,
            },
        ),
        migrations.CreateModel(
            name='FeedPreference',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('rank', models.IntegerField(default=0)),
                ('disabled', models.BooleanField(default=False)),
                ('created_date', models.DateTimeField(auto_now_add=True, null=True)),
                ('modified_date', models.DateTimeField(auto_now=True, null=True)),
                ('feed', models.ForeignKey(to='whatsgoodly.Feed')),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='Friendship',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('friend_name', models.CharField(max_length=180, null=True, blank=True)),
                ('friend_phone_number', models.CharField(max_length=15)),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='Group',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('title', models.CharField(unique=True, max_length=255)),
            ],
            options={
                'ordering': ('title',),
            },
        ),
        migrations.CreateModel(
            name='LocalChannel',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=255)),
                ('active', models.BooleanField(default=False)),
                ('location', django.contrib.gis.db.models.fields.PointField(srid=4326)),
                ('created_date', models.DateTimeField(auto_now_add=True, null=True)),
                ('modified_date', models.DateTimeField(auto_now=True, null=True)),
                ('user', models.ForeignKey(blank=True, to=settings.AUTH_USER_MODEL, null=True)),
            ],
        ),
        migrations.CreateModel(
            name='Mention',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('handle', models.CharField(max_length=255)),
                ('gender', models.IntegerField()),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('comment', models.ForeignKey(to='whatsgoodly.Comment')),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='Notification',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('title', models.CharField(max_length=180)),
                ('body', models.CharField(max_length=180, null=True, blank=True)),
                ('is_read', models.BooleanField(default=False)),
                ('opened_from_push', models.BooleanField(default=False)),
                ('make_poll', models.BooleanField(default=False)),
                ('notification_type', models.IntegerField(default=0, choices=[(0, b'From Whatsgoodly'), (1, b'Poll Results'), (2, b'Globalled'), (3, b'Reply'), (4, b'Popular Comment'), (5, b'Claim Your Coins!'), (6, b'Top Poll'), (7, b'Favorite Poll'), (8, b'Referral Joined'), (9, b'Tag Accepted'), (10, b"You've Been Tagged"), (11, b'Pinned Poll'), (12, b'Fire Poll'), (13, b'New Friend'), (14, b'Friend Poll'), (15, b'US National Poll')])),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('feed', models.ForeignKey(blank=True, to='whatsgoodly.Feed', null=True)),
            ],
        ),
        migrations.CreateModel(
            name='PeekFeed',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(unique=True, max_length=180)),
                ('name_short', models.CharField(max_length=180)),
                ('active', models.BooleanField(default=False)),
                ('location', django.contrib.gis.db.models.fields.PointField(srid=4326, blank=True)),
                ('image_source', models.URLField(null=True, blank=True)),
            ],
            options={
                'ordering': ('-active', '-id'),
            },
        ),
        migrations.CreateModel(
            name='PhoneBan',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('aws_sns_arn_endpoint', models.CharField(db_index=True, max_length=255, null=True, blank=True)),
                ('ios_apns_token', models.CharField(db_index=True, max_length=255, null=True, blank=True)),
                ('gcm_token', models.CharField(db_index=True, max_length=255, null=True, blank=True)),
                ('user', models.ForeignKey(blank=True, to=settings.AUTH_USER_MODEL, null=True)),
            ],
            options={
                'abstract': False,
            },
        ),
        migrations.CreateModel(
            name='Poll',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('gender', models.IntegerField(default=2, db_index=True, choices=[(0, b'Guys'), (1, b'Girls'), (2, b'All')])),
                ('question', models.CharField(max_length=180)),
                ('options', models.TextField()),
                ('randomize_options', models.BooleanField(default=False)),
                ('audio_options', models.TextField(default=None, null=True, blank=True)),
                ('recycle_count', models.IntegerField(default=0)),
                ('censor_level', models.IntegerField(default=0, db_index=True, choices=[(0, b'None'), (1, b'Auto-Deleted'), (2, b'Language'), (3, b'Names')])),
                ('verified', models.BooleanField(default=False)),
                ('deleted', models.BooleanField(default=False)),
            ],
        ),
        migrations.CreateModel(
            name='PollArchetype',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('age_level', models.IntegerField(default=4, choices=[(0, b'High School'), (1, b'College'), (2, b'Post College'), (3, b'All in School'), (4, b'All Ages')])),
                ('campus_level', models.IntegerField(default=0, choices=[(0, b'All'), (1, b'Early'), (2, b'Established')])),
                ('question', models.CharField(max_length=180)),
                ('options', models.TextField()),
                ('disabled', models.BooleanField(default=False)),
                ('created_date', models.DateTimeField(auto_now_add=True, null=True)),
                ('modified_date', models.DateTimeField(auto_now=True, null=True)),
            ],
        ),
        migrations.CreateModel(
            name='PollBreakdown',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('breakdown_type', models.IntegerField(default=0, choices=[(0, b'Mobile'), (1, b'Web'), (2, b'Gender'), (3, b'University'), (4, b'Segment')])),
                ('promotion', models.IntegerField(default=0, choices=[(0, b'None'), (1, b'Disparity'), (2, b'Pinned')])),
                ('gender', models.IntegerField(default=-1, choices=[(-1, b'Not chosen'), (0, b'Male'), (1, b'Female')])),
                ('segment_option', models.IntegerField(default=-1)),
                ('json', models.TextField()),
                ('total', models.IntegerField(default=0)),
                ('significance', models.FloatField(default=0.0)),
            ],
            options={
                'ordering': ('breakdown_type',),
            },
        ),
        migrations.CreateModel(
            name='PollBreakdownPreference',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('breakdown_type', models.IntegerField(default=0, choices=[(0, b'Mobile'), (1, b'Web'), (2, b'Gender'), (3, b'University'), (4, b'Segment')])),
                ('gender', models.IntegerField(default=-1, choices=[(-1, b'Not chosen'), (0, b'Male'), (1, b'Female')])),
                ('segment_option', models.IntegerField(default=-1)),
                ('disabled', models.BooleanField(default=False)),
            ],
            options={
                'ordering': ('breakdown_type',),
            },
        ),
        migrations.CreateModel(
            name='PollBreakdownUnlock',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='PollCondition',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('response_filter', models.CharField(max_length=255)),
            ],
            options={
                'abstract': False,
            },
        ),
        migrations.CreateModel(
            name='PollInstance',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('promotion', models.IntegerField(default=0, db_index=True, choices=[(0, b'None'), (1, b'Accelerated'), (2, b'Hot'), (3, b'Globalled'), (4, b'Sponsored'), (5, b'Pinned')])),
                ('every_nth_user', models.IntegerField(default=1)),
                ('vote_counts', models.TextField()),
                ('user_karma_on_create', models.IntegerField(default=0)),
                ('ip_address', models.GenericIPAddressField(default=None, null=True, blank=True)),
                ('location', django.contrib.gis.db.models.fields.PointField(srid=4326, null=True, blank=True)),
                ('banner', models.CharField(default=None, max_length=180, null=True, blank=True)),
                ('vote_weight', models.FloatField(default=0)),
                ('vote_aggregate', models.IntegerField(default=0)),
                ('favorite_count', models.IntegerField(default=0)),
                ('comment_count', models.IntegerField(default=0)),
                ('tag_count', models.IntegerField(default=0)),
                ('verified', models.BooleanField(default=False)),
                ('auto_verified', models.BooleanField(default=False)),
                ('deleted', models.BooleanField(default=False)),
                ('rejected', models.BooleanField(default=False)),
                ('deleted_by_admin', models.BooleanField(default=False)),
                ('deleted_by_creator', models.BooleanField(default=False)),
                ('created_date', models.DateTimeField(auto_now_add=True, db_index=True)),
                ('modified_date', models.DateTimeField(auto_now=True, db_index=True)),
            ],
            managers=[
                ('objects', django.db.models.manager.Manager()),
                ('polls', whatsgoodly.managers.PollInstanceManager()),
                ('sponsored', whatsgoodly.managers.SponsoredPollInstanceManager()),
            ],
        ),
        migrations.CreateModel(
            name='PollInstanceRemoval',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('is_downvote', models.BooleanField(default=False)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='PollTag',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('label_lower', models.CharField(unique=True, max_length=180, db_index=True)),
                ('flag_terms', models.TextField(default=None, null=True, blank=True)),
                ('parent', models.ForeignKey(blank=True, to='whatsgoodly.PollTag', null=True)),
            ],
            options={
                'abstract': False,
            },
        ),
        migrations.CreateModel(
            name='PushSubscription',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('disabled', models.BooleanField(default=False)),
                ('created_date', models.DateTimeField(auto_now_add=True, null=True)),
                ('modified_date', models.DateTimeField(auto_now=True, null=True)),
            ],
        ),
        migrations.CreateModel(
            name='Referrer',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('host', models.URLField(unique=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='Report',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('report_type', models.IntegerField(default=3, choices=[(0, b'This targets someone'), (1, b'This is offensive'), (2, b'This is spam'), (3, b'Other'), (4, b'This is no longer relevant')])),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('comment', models.ForeignKey(blank=True, to='whatsgoodly.Comment', null=True)),
            ],
        ),
        migrations.CreateModel(
            name='Response',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('response', models.IntegerField()),
                ('referring_url', models.URLField(null=True, blank=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='SearchQuery',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('query', models.TextField(db_index=True)),
                ('count', models.IntegerField(default=0)),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'abstract': False,
            },
        ),
        migrations.CreateModel(
            name='Survey',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('name', models.CharField(max_length=180)),
            ],
            options={
                'abstract': False,
            },
        ),
        migrations.CreateModel(
            name='Tag',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('accepted', models.BooleanField(default=False)),
                ('ignored', models.BooleanField(default=False)),
                ('saw_response', models.BooleanField(default=False)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('friendship', models.ForeignKey(to='whatsgoodly.Friendship')),
            ],
        ),
        migrations.CreateModel(
            name='University',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('level', models.IntegerField(default=0, choices=[(0, b'College'), (1, b'High School'), (2, b'Middle School'), (3, b'Grad School')])),
                ('name', models.CharField(unique=True, max_length=180)),
                ('name_short', models.CharField(max_length=180)),
                ('location', django.contrib.gis.db.models.fields.PointField(srid=4326)),
                ('radius', models.FloatField(default=2.0)),
                ('email_domain', models.CharField(max_length=180)),
                ('public', models.BooleanField(default=False)),
                ('fraternities', models.TextField(null=True, blank=True)),
                ('sororities', models.TextField(null=True, blank=True)),
                ('created_date', models.DateTimeField(auto_now_add=True, null=True)),
                ('modified_date', models.DateTimeField(auto_now=True, null=True)),
                ('primary_color', models.CharField(default=None, max_length=7, null=True, blank=True)),
                ('local_feeds', models.ManyToManyField(to='whatsgoodly.Feed', blank=True)),
            ],
        ),
        migrations.CreateModel(
            name='UserMerger',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('ip_address', models.GenericIPAddressField(default=None, null=True, blank=True)),
                ('merged_user', models.ForeignKey(related_name='merged_into', to=settings.AUTH_USER_MODEL)),
                ('user', models.ForeignKey(related_name='merged', to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='UserRelationship',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('response_count', models.IntegerField(default=0)),
                ('favorite_count', models.IntegerField(default=0)),
                ('removal_count', models.IntegerField(default=0)),
                ('is_friend', models.BooleanField(default=False)),
                ('left', models.ForeignKey(related_name='forward_relationships', to=settings.AUTH_USER_MODEL)),
                ('right', models.ForeignKey(related_name='backward_relationships', to=settings.AUTH_USER_MODEL)),
            ],
            managers=[
                ('objects', django.db.models.manager.Manager()),
                ('edges', whatsgoodly.managers.EdgeManager()),
            ],
        ),
        migrations.CreateModel(
            name='Segmenter',
            fields=[
                ('poll_ptr', models.OneToOneField(parent_link=True, auto_created=True, primary_key=True, serialize=False, to='whatsgoodly.Poll')),
                ('segment_type', models.IntegerField(default=0, db_index=True, choices=[(0, b'Custom'), (1, b'Age'), (4, b'Greek Life'), (5, b'Politics'), (6, b'Race'), (7, b'GPA'), (8, b'Community Service'), (9, b'Leadership'), (10, b'Employment'), (11, b'Degree Type'), (12, b'Techy Major'), (13, b'Fuzzy Major'), (14, b'Socio-economic'), (15, b'Student Debt'), (16, b'Computer'), (17, b'Virgin'), (18, b'Graduation Year')])),
                ('option_labels', models.TextField(default=None, null=True, blank=True)),
                ('option_hex_colors', models.TextField(default=None, null=True, blank=True)),
                ('option_indices_excluded_from_breakdowns', models.TextField(default=None, null=True, blank=True)),
            ],
            options={
                'abstract': False,
            },
            bases=('whatsgoodly.poll',),
        ),
        migrations.CreateModel(
            name='SegmenterInstance',
            fields=[
                ('pollinstance_ptr', models.OneToOneField(parent_link=True, auto_created=True, primary_key=True, serialize=False, to='whatsgoodly.PollInstance')),
                ('segmenter', models.ForeignKey(to='whatsgoodly.Segmenter')),
            ],
            bases=('whatsgoodly.pollinstance',),
            managers=[
                ('objects', django.db.models.manager.Manager()),
                ('segmenters', whatsgoodly.managers.SegmenterInstanceManager()),
            ],
        ),
        migrations.AddField(
            model_name='tag',
            name='poll_instance',
            field=models.ForeignKey(to='whatsgoodly.PollInstance'),
        ),
        migrations.AddField(
            model_name='survey',
            name='polls',
            field=models.ManyToManyField(to='whatsgoodly.Poll', blank=True),
        ),
        migrations.AddField(
            model_name='survey',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name='response',
            name='poll_instance',
            field=models.ForeignKey(to='whatsgoodly.PollInstance'),
        ),
        migrations.AddField(
            model_name='response',
            name='referrer',
            field=models.ForeignKey(blank=True, to='whatsgoodly.Referrer', null=True),
        ),
        migrations.AddField(
            model_name='response',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name='report',
            name='poll_instance',
            field=models.ForeignKey(blank=True, to='whatsgoodly.PollInstance', null=True),
        ),
        migrations.AddField(
            model_name='report',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name='pushsubscription',
            name='poll_instance',
            field=models.ForeignKey(blank=True, to='whatsgoodly.PollInstance', null=True),
        ),
        migrations.AddField(
            model_name='pushsubscription',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name='pollinstanceremoval',
            name='poll_instance',
            field=models.ForeignKey(to='whatsgoodly.PollInstance'),
        ),
        migrations.AddField(
            model_name='pollinstanceremoval',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name='pollinstance',
            name='community',
            field=models.ForeignKey(blank=True, to='whatsgoodly.University', null=True),
        ),
        migrations.AddField(
            model_name='pollinstance',
            name='feed',
            field=models.ForeignKey(related_name='poll_instances', to='whatsgoodly.Feed'),
        ),
        migrations.AddField(
            model_name='pollinstance',
            name='poll',
            field=models.ForeignKey(to='whatsgoodly.Poll'),
        ),
        migrations.AddField(
            model_name='pollinstance',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name='pollinstance',
            name='verified_by',
            field=models.ForeignKey(related_name='poll_instances_verified', blank=True, to=settings.AUTH_USER_MODEL, null=True),
        ),
        migrations.AddField(
            model_name='pollcondition',
            name='dependent_poll',
            field=models.ForeignKey(related_name='conditions', to='whatsgoodly.Poll'),
        ),
        migrations.AddField(
            model_name='pollcondition',
            name='determining_poll',
            field=models.ForeignKey(related_name='dependent_conditions', to='whatsgoodly.Poll'),
        ),
        migrations.AddField(
            model_name='pollbreakdownunlock',
            name='poll',
            field=models.ForeignKey(to='whatsgoodly.Poll'),
        ),
        migrations.AddField(
            model_name='pollbreakdownunlock',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name='pollbreakdownpreference',
            name='university',
            field=models.ForeignKey(blank=True, to='whatsgoodly.University', null=True),
        ),
        migrations.AddField(
            model_name='pollbreakdownpreference',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name='pollbreakdown',
            name='poll',
            field=models.ForeignKey(related_name='breakdowns', to='whatsgoodly.Poll'),
        ),
        migrations.AddField(
            model_name='pollbreakdown',
            name='university',
            field=models.ForeignKey(blank=True, to='whatsgoodly.University', null=True),
        ),
        migrations.AlterIndexTogether(
            name='pollarchetype',
            index_together=set([('age_level', 'campus_level')]),
        ),
        migrations.AddField(
            model_name='poll',
            name='archetype',
            field=models.ForeignKey(blank=True, to='whatsgoodly.PollArchetype', null=True),
        ),
        migrations.AddField(
            model_name='poll',
            name='tags',
            field=models.ManyToManyField(to='whatsgoodly.PollTag', blank=True),
        ),
        migrations.AddField(
            model_name='poll',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name='peekfeed',
            name='university',
            field=models.ForeignKey(blank=True, to='whatsgoodly.University', null=True),
        ),
        migrations.AddField(
            model_name='notification',
            name='poll_instance',
            field=models.ForeignKey(blank=True, to='whatsgoodly.PollInstance', null=True),
        ),
        migrations.AddField(
            model_name='notification',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name='group',
            name='universities',
            field=models.ManyToManyField(to='whatsgoodly.University'),
        ),
        migrations.AddField(
            model_name='feedcondition',
            name='determining_poll',
            field=models.ForeignKey(blank=True, to='whatsgoodly.Poll', null=True),
        ),
        migrations.AddField(
            model_name='feedcondition',
            name='feed',
            field=models.ForeignKey(to='whatsgoodly.Feed'),
        ),
        migrations.AddField(
            model_name='favorite',
            name='poll_instance',
            field=models.ForeignKey(to='whatsgoodly.PollInstance'),
        ),
        migrations.AddField(
            model_name='favorite',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name='comment',
            name='poll_instance',
            field=models.ForeignKey(to='whatsgoodly.PollInstance'),
        ),
        migrations.AddField(
            model_name='comment',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name='announcement',
            name='feed',
            field=models.ForeignKey(blank=True, to='whatsgoodly.Feed', null=True),
        ),
        migrations.AddField(
            model_name='announcement',
            name='university',
            field=models.ForeignKey(blank=True, to='whatsgoodly.University', null=True),
        ),
        migrations.AddField(
            model_name='user',
            name='account',
            field=models.ForeignKey(blank=True, to='whatsgoodly.Account', null=True),
        ),
        migrations.AddField(
            model_name='user',
            name='groups',
            field=models.ManyToManyField(related_query_name='user', related_name='user_set', to='auth.Group', blank=True, help_text='The groups this user belongs to. A user will get all permissions granted to each of their groups.', verbose_name='groups'),
        ),
        migrations.AddField(
            model_name='user',
            name='university',
            field=models.ForeignKey(blank=True, to='whatsgoodly.University', null=True),
        ),
        migrations.AddField(
            model_name='user',
            name='user_permissions',
            field=models.ManyToManyField(related_query_name='user', related_name='user_set', to='auth.Permission', blank=True, help_text='Specific permissions for this user.', verbose_name='user permissions'),
        ),
        migrations.AlterUniqueTogether(
            name='userrelationship',
            unique_together=set([('left', 'right')]),
        ),
        migrations.AlterIndexTogether(
            name='userrelationship',
            index_together=set([('left', 'right'), ('response_count', 'favorite_count', 'removal_count', 'is_friend')]),
        ),
        migrations.AlterUniqueTogether(
            name='usermerger',
            unique_together=set([('user', 'merged_user')]),
        ),
        migrations.AlterIndexTogether(
            name='usermerger',
            index_together=set([('user', 'merged_user')]),
        ),
        migrations.AlterIndexTogether(
            name='university',
            index_together=set([('name', 'name_short')]),
        ),
        migrations.AlterUniqueTogether(
            name='tag',
            unique_together=set([('friendship', 'poll_instance')]),
        ),
        migrations.AlterIndexTogether(
            name='tag',
            index_together=set([('poll_instance', 'friendship')]),
        ),
        migrations.AddField(
            model_name='survey',
            name='allowed_breakdowns',
            field=models.ManyToManyField(related_name='segmented_surveys', to='whatsgoodly.Segmenter', blank=True),
        ),
        migrations.AlterIndexTogether(
            name='response',
            index_together=set([('poll_instance', 'user')]),
        ),
        migrations.AlterUniqueTogether(
            name='pushsubscription',
            unique_together=set([('user', 'poll_instance')]),
        ),
        migrations.AlterIndexTogether(
            name='pushsubscription',
            index_together=set([('user', 'poll_instance')]),
        ),
        migrations.AlterIndexTogether(
            name='pollinstanceremoval',
            index_together=set([('poll_instance', 'user')]),
        ),
        migrations.AlterIndexTogether(
            name='pollinstance',
            index_together=set([('vote_weight', 'vote_aggregate', 'favorite_count', 'comment_count', 'tag_count')]),
        ),
        migrations.AlterUniqueTogether(
            name='pollbreakdownunlock',
            unique_together=set([('user', 'poll')]),
        ),
        migrations.AlterIndexTogether(
            name='pollbreakdownunlock',
            index_together=set([('user', 'poll')]),
        ),
        migrations.AddField(
            model_name='pollbreakdownpreference',
            name='segmenter',
            field=models.ForeignKey(blank=True, to='whatsgoodly.Segmenter', null=True),
        ),
        migrations.AddField(
            model_name='pollbreakdown',
            name='segmenter',
            field=models.ForeignKey(blank=True, to='whatsgoodly.Segmenter', null=True),
        ),
        migrations.AlterIndexTogether(
            name='poll',
            index_together=set([('question', 'options')]),
        ),
        migrations.AlterUniqueTogether(
            name='friendship',
            unique_together=set([('user', 'friend_phone_number')]),
        ),
        migrations.AlterIndexTogether(
            name='friendship',
            index_together=set([('user', 'friend_phone_number')]),
        ),
        migrations.AlterUniqueTogether(
            name='feedpreference',
            unique_together=set([('user', 'feed')]),
        ),
        migrations.AlterIndexTogether(
            name='feedpreference',
            index_together=set([('user', 'feed')]),
        ),
        migrations.AddField(
            model_name='feed',
            name='allowed_breakdowns',
            field=models.ManyToManyField(to='whatsgoodly.Segmenter', blank=True),
        ),
        migrations.AlterIndexTogether(
            name='favorite',
            index_together=set([('poll_instance', 'user')]),
        ),
        migrations.AlterIndexTogether(
            name='commentvote',
            index_together=set([('comment', 'user')]),
        ),
        migrations.AlterUniqueTogether(
            name='pollbreakdownpreference',
            unique_together=set([('user', 'breakdown_type', 'gender', 'segmenter', 'university', 'segment_option')]),
        ),
        migrations.AlterIndexTogether(
            name='pollbreakdownpreference',
            index_together=set([('user', 'breakdown_type', 'gender', 'segmenter', 'university', 'segment_option')]),
        ),
        migrations.AlterUniqueTogether(
            name='pollbreakdown',
            unique_together=set([('poll', 'breakdown_type', 'gender', 'university', 'segmenter', 'segment_option')]),
        ),
        migrations.AlterIndexTogether(
            name='pollbreakdown',
            index_together=set([('poll', 'breakdown_type', 'gender', 'university', 'segmenter', 'segment_option')]),
        ),
        migrations.AlterUniqueTogether(
            name='feed',
            unique_together=set([('name', 'level')]),
        ),
    ]
