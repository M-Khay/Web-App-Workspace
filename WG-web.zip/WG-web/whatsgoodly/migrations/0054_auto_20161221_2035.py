# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0053_auto_20161221_1639'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='account',
            options={'ordering': ('name_url',)},
        ),
        migrations.RenameField(
            model_name='account',
            old_name='name_short',
            new_name='name_url',
        ),
        migrations.AlterField(
            model_name='account',
            name='name',
            field=models.CharField(default='TODO', max_length=180),
            preserve_default=False,
        ),
    ]
