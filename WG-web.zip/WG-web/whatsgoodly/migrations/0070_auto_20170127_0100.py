# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0069_university_state'),
    ]

    operations = [
        migrations.AddField(
            model_name='survey',
            name='map_setting',
            field=models.IntegerField(default=0, choices=[(0, b'None')]),
        ),
        migrations.AddField(
            model_name='survey',
            name='timeline_setting',
            field=models.IntegerField(default=0, choices=[(0, b'None'), (1, b'One-to-One option mapping')]),
        ),
    ]
