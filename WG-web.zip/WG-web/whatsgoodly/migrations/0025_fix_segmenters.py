# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from whatsgoodly import segmentations
import json

def fix_segmentations(apps, schema_editor):
    Segmenter = apps.get_model('whatsgoodly', 'Segmenter')
    SegmenterInstance = apps.get_model('whatsgoodly', 'SegmenterInstance')

    for ident, spec in segmentations.IDENTIFIERS:
        if ident == 0:
            continue
        
        if ident == segmentations.SchoolYear.ID:
            try:
                seg = Segmenter.objects.get(question=segmentations.SchoolYear.QUESTION)
                seg.segment_type = segmentations.SchoolYear.ID
            except Segmenter.DoesNotExist:
                seg = SegmenterInstance.objects.create_segmenter(ident)

        else:
            try:
                seg = Segmenter.objects.get(segment_type=ident)
            except Segmenter.DoesNotExist:
                seg = SegmenterInstance.objects.create_segmenter(ident)

        if seg.segment_type == segmentations.Leadership.ID:
            seg.exclude_breakdowns = True

        if seg.segment_type == segmentations.SocioEconomic.ID:
            seg.question = spec.QUESTION
            seg.options = json.dumps([val for k, val in spec.CHOICES])
            seg.option_labels = json.dumps([val for k, val in spec.OPTION_LABELS])
            SegmenterInstance.objects.filter(
                    segmenter=seg, university__isnull=False
                ).delete()

        if getattr(spec, 'EXCLUDE_FROM_LOCAL', False) == False:
            SegmenterInstance.objects.create_missing_campus_instances(seg)

        seg.save()

def undo_fix_segmentations(apps, schema_editor):
    pass


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0024_initial_credits'),
    ]

    operations = [
        migrations.AddField(
            model_name='segmenter',
            name='exclude_breakdowns',
            field=models.BooleanField(default=False),
        ),

        migrations.RunPython(fix_segmentations, reverse_code=undo_fix_segmentations),
    ]
