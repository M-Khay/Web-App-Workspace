# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0056_auto_20170102_2343'),
    ]

    operations = [
        migrations.AddField(
            model_name='feedcondition',
            name='allowed_users',
            field=models.ManyToManyField(to=settings.AUTH_USER_MODEL, blank=True),
        ),
    ]
