# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0052_auto_20161221_1636'),
    ]

    operations = [
        migrations.AddField(
            model_name='account',
            name='name',
            field=models.CharField(max_length=180, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='account',
            name='name_short',
            field=models.CharField(unique=True, max_length=180, db_index=True),
        ),
    ]
