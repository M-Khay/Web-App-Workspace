# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0063_auto_20170121_0247'),
    ]

    operations = [
        migrations.RenameField(
            model_name='pollinstance',
            old_name='every_nth_user',
            new_name='user_modulus',
        ),
        migrations.AddField(
            model_name='pollinstance',
            name='user_modulus_remainder',
            field=models.IntegerField(default=0),
        ),
        migrations.AlterField(
            model_name='friendship',
            name='friend_phone_number',
            field=models.CharField(max_length=15, db_index=True),
        ),
        migrations.AlterIndexTogether(
            name='friendship',
            index_together=set([]),
        ),
        migrations.AlterIndexTogether(
            name='poll',
            index_together=set([]),
        ),
    ]
