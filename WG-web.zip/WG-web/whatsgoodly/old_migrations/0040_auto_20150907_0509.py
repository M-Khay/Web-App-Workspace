# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0039_auto_20150905_1840'),
    ]

    operations = [
        migrations.CreateModel(
            name='PollInstanceMetadata',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('checkout_time', models.DateTimeField(null=True, blank=True)),
                ('monitor_deleted', models.BooleanField(default=False)),
                ('monitor_verified', models.BooleanField(default=False)),
            ],
        ),
        migrations.AddField(
            model_name='pollinstance',
            name='verified',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='pollinstancemetadata',
            name='poll_instance',
            field=models.ForeignKey(to='whatsgoodly.PollInstance'),
        ),
    ]
