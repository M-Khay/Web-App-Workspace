# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0068_auto_20160417_2201'),
    ]

    operations = [
        migrations.AddField(
            model_name='tag',
            name='accepted',
            field=models.BooleanField(default=False),
        ),
        migrations.AlterField(
            model_name='phoneban',
            name='aws_sns_arn_endpoint',
            field=models.CharField(db_index=True, max_length=255, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='user',
            name='phone_number',
            field=models.CharField(db_index=True, max_length=15, null=True, blank=True),
        ),
        migrations.AlterIndexTogether(
            name='commentvote',
            index_together=set([('comment', 'user')]),
        ),
        migrations.AlterIndexTogether(
            name='pollinstancevote',
            index_together=set([('poll_instance', 'user')]),
        ),
        migrations.AlterIndexTogether(
            name='tag',
            index_together=set([('poll_instance', 'phone_number')]),
        ),
    ]
