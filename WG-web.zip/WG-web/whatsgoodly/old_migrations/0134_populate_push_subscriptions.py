# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from datetime import datetime, timedelta
import django.contrib.auth.models
import whatsgoodly.managers

def add_push_subscriptions(apps, schema_editor):
    PushSubscription = apps.get_model('whatsgoodly', 'PushSubscription')
    Comment = apps.get_model('whatsgoodly', 'Comment')
    PollInstance = apps.get_model('whatsgoodly', 'PollInstance')
    User = apps.get_model('whatsgoodly', 'User')
    cutoff_date = datetime.now().date() - timedelta(100)
    # 104,608 users
    users_with_push = User.objects.reachable()
    # ~100,000 comments
    comments = Comment.objects.filter(
            user__in=users_with_push,
            poll_instance__created_date__gte=cutoff_date
        ).exclude(
            user=models.F('poll_instance__user')
        ).distinct('user', 'poll_instance')
    # ~50,000 polls
    polls = PollInstance.objects.filter(
            user__in=users_with_push,
            created_date__gte=cutoff_date
        )

    subs = []
    for comment in comments:
        subs.append(PushSubscription(
                user_id=comment.user_id,
                poll_instance_id=comment.poll_instance_id
            )
        )
    for poll in polls:
        subs.append(PushSubscription(
                user_id=poll.user_id,
                poll_instance_id=poll.id
            )
        )

    # Delete existing subscriptions to prevent `get` from
    # returning more than one result if some were added
    # during migration
    PushSubscription.objects.all().delete()
    PushSubscription.objects.bulk_create(subs, batch_size=5000)


def undo_add_push_subscriptions(apps, schema_editor):
    pass


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0133_push_subscriptions_and_uniques'),
    ]

    operations = [
        migrations.AlterModelManagers(
            name='user',
            managers=[
                ('objects', django.contrib.auth.models.UserManager()),
                ('reachable', whatsgoodly.managers.UserManager()),
            ],
        ),
        migrations.RunPython(add_push_subscriptions, reverse_code=undo_add_push_subscriptions),
    ]
