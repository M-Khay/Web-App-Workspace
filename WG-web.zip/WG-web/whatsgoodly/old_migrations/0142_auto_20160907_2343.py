# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0141_segmenter_polls_part2'),
    ]

    operations = [
    
        migrations.RemoveField(
            model_name='segmenterinstance',
            name='segment_type',
        ),

        # Index segment_type now
        migrations.AlterField(
            model_name='segmenter',
            name='segment_type',
            field=models.IntegerField(default=0, db_index=True, choices=[(0, b'None'), (1, b'Age'), (4, b'Greek Life'), (5, b'Politics'), (6, b'Race'), (7, b'GPA'), (8, b'Community Service'), (9, b'Leadership'), (10, b'Employment'), (11, b'Degree Type'), (12, b'Techy Major'), (13, b'Fuzzy Major'), (14, b'Socio-economic'), (15, b'Student Debt')]),
        ),

        # Force segmenter_ids to be required now
        migrations.AlterField(
            model_name='segmenterinstance',
            name='segmenter',
            field=models.ForeignKey(to='whatsgoodly.Segmenter'),
        ),
    ]
