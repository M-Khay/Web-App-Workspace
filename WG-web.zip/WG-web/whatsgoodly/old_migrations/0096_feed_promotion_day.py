# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0095_auto_20160619_0526'),
    ]

    operations = [
        migrations.AddField(
            model_name='feed',
            name='promotion_day',
            field=models.IntegerField(default=0, choices=[(0, b'None'), (1, b'Sunday'), (2, b'Monday'), (3, b'Tuesday'), (4, b'Wednesday'), (5, b'Thursday'), (6, b'Friday'), (7, b'Saturday')]),
        ),
    ]
