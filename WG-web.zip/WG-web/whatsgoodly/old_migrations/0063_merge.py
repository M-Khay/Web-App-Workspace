# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0062_auto_20160323_1647'),
        ('whatsgoodly', '0062_auto_20160331_2120'),
    ]

    operations = [
    ]
