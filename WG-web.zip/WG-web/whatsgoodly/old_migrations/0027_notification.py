# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0026_auto_20150717_0656'),
    ]

    operations = [
        migrations.CreateModel(
            name='Notification',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('title', models.CharField(max_length=180)),
                ('body', models.CharField(max_length=180)),
                ('is_popup', models.BooleanField(default=False)),
                ('notification_type', models.IntegerField(default=4, choices=[(0, b'Poll'), (1, b'Global'), (2, b'Reply'), (3, b'Comment vote'), (4, b'Other')])),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('poll', models.ForeignKey(blank=True, to='whatsgoodly.Poll', null=True)),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
    ]
