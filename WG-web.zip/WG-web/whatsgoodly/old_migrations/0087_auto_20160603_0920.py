# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0086_auto_20160531_2302'),
    ]

    operations = [
        migrations.CreateModel(
            name='SegmentationPollInstance',
            fields=[
            ],
            options={
                'ordering': ['segment_type'],
                'proxy': True,
            },
            bases=('whatsgoodly.pollinstance',),
        ),
        migrations.AddField(
            model_name='pollinstance',
            name='segment_type',
            field=models.IntegerField(default=0, choices=[(0, b'None'), (1, b'Age'), (2, b'Gender'), (3, b'Push Notifications Preference'), (4, b'Location Preference')]),
        ),
        migrations.AlterField(
            model_name='feed',
            name='level',
            field=models.IntegerField(default=1, choices=[(0, b'High School'), (1, b'College'), (2, b'Post College'), (3, b'All in School'), (4, b'All Ages')]),
        ),
    ]
