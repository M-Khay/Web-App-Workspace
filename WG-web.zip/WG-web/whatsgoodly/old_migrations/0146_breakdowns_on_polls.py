# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0145_auto_20160910_0225'),
    ]

    operations = [
        migrations.CreateModel(
            name='PollBreakdown',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('gender', models.IntegerField(default=-1, choices=[(-1, b'Not chosen'), (0, b'Male'), (1, b'Female')])),
                ('segment_option', models.IntegerField(default=-1)),
                ('breakdown_type', models.IntegerField(default=0, choices=[(0, b'Mobile'), (1, b'Web'), (2, b'Gender'), (3, b'University'), (4, b'Segment')])),
                ('json', models.TextField()),
                ('total', models.IntegerField(default=0)),
                ('significance', models.FloatField(default=0.0)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('poll', models.ForeignKey(related_name='breakdowns', to='whatsgoodly.Poll')),
                ('segmenter', models.ForeignKey(blank=True, to='whatsgoodly.Segmenter', null=True)),
                ('university', models.ForeignKey(blank=True, to='whatsgoodly.University', null=True)),
            ],
        ),
        migrations.AddField(
            model_name='pollinstance',
            name='vote_counts',
            field=models.TextField(default=None, null=True, blank=True),
        ),
        migrations.AlterUniqueTogether(
            name='pollbreakdown',
            unique_together=set([('poll', 'breakdown_type', 'gender', 'university', 'segmenter', 'segment_option')]),
        ),
        migrations.AlterIndexTogether(
            name='pollbreakdown',
            index_together=set([('poll', 'breakdown_type', 'gender', 'university', 'segmenter', 'segment_option')]),
        ),
        migrations.AlterModelOptions(
            name='pollbreakdown',
            options={'ordering': ('breakdown_type',)},
        ),
        migrations.AlterModelOptions(
            name='responsebreakdown',
            options={'ordering': ('breakdown_type',)},
        ),
        migrations.AlterField(
            model_name='responsebreakdown',
            name='poll_instance',
            field=models.ForeignKey(to='whatsgoodly.PollInstance'),
        ),
    ]
