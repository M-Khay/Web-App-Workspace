# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations

def set_segmenters(apps, schema_editor):
    PollInstance = apps.get_model('whatsgoodly', 'PollInstance')
    PollInstance.objects.exclude(poll__segment_type=0).update(is_segmenter=True)

def remove_segmenters(apps, schema_editor):
    pass

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0099_auto_20160630_1243'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='pollinstance',
            name='promoted',
        ),
        migrations.AddField(
            model_name='pollinstance',
            name='is_segmenter',
            field=models.BooleanField(default=False, db_index=True),
        ),
        migrations.RunPython(set_segmenters, reverse_code=remove_segmenters),
    ]
