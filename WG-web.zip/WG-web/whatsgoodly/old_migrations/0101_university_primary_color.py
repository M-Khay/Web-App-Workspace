# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0100_auto_20160630_1328'),
    ]

    operations = [
        migrations.AddField(
            model_name='university',
            name='primary_color',
            field=models.CharField(max_length=7, null=True),
        ),
    ]
