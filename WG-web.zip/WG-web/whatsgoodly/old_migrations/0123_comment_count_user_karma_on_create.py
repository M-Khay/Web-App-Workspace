# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models

# Part 2 of the migration is in 0124. Needed to split
# them due to deadlocks between comment and pollinstance,
# caused (I think) by the signals.py fn
# that changes the poll instance when a comment is created 

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0122_local_feeds_scenes'),
    ]

    operations = [
        migrations.RenameField(
            model_name='university',
            old_name='feeds',
            new_name='local_feeds',
        ),
        migrations.AddField(
            model_name='comment',
            name='user_karma_on_create',
            field=models.IntegerField(default=0),
        ),
    ]
