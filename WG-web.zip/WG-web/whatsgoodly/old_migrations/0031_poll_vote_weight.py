# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0030_user_gcm_token'),
    ]

    operations = [
        migrations.AddField(
            model_name='poll',
            name='vote_weight',
            field=models.FloatField(default=0),
            preserve_default=True,
        ),
    ]
