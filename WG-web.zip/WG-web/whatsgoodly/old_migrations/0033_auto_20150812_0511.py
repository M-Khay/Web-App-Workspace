# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations

def placeholder(apps, schema_editor):
    pass

def migrate_poll_data(apps, schema_editor):
    Poll = apps.get_model("whatsgoodly", "Poll")
    PollInstance = apps.get_model("whatsgoodly", "PollInstance")
    Feed = apps.get_model("whatsgoodly", "Feed")

    local = Feed(name="Local", active=True, start_date=None, end_date=None, category=0)
    local.save()

    globl = Feed(name="Global", active=True, start_date=None, end_date=None, category=1)
    globl.save()

    print "[DEBUG] Starting PollInstance script..."
    bulk_list = []
    for p in Poll.objects.all().order_by('id'):
        if p.id % 5000 == 0:
            print "[DEBUG] creating PI for Poll ID: ", p.id
        user = p.user
        option_counts = p.option_counts
        location = p.location
        ip_address = p.ip_address
        comment_count = p.comment_count
        favorite_count = p.favorite_count
        promoted = p.promoted
        banner = p.banner
        deleted = p.deleted
        vote_weight = p.vote_weight
        created_date = p.created_date
        modified_date = p.modified_date
        if p.universal:
            feed = globl
        else:
            feed = local
        p_instance = PollInstance(id=p.id, user=user, poll=p, feed=feed, option_counts=option_counts,
            location=location, ip_address=ip_address, comment_count=comment_count, favorite_count=favorite_count, banner=banner, 
            promoted=promoted, deleted=deleted, vote_weight=vote_weight, created_date=created_date, modified_date=modified_date)

        bulk_list.append(p_instance)
        if len(bulk_list) > 200:
            PollInstance.objects.bulk_create(bulk_list)
            bulk_list = []
    if len(bulk_list) > 0:
        PollInstance.objects.bulk_create(bulk_list)
    print "[DEBUG] Finished PollInstance script..."

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0032_auto_20150812_0501'),
    ]

    operations = [
        migrations.RunPython(migrate_poll_data, reverse_code=placeholder)
    ]
