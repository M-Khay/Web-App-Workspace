# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0077_auto_20160428_0404'),
    ]

    operations = [
        migrations.AddField(
            model_name='tag',
            name='saw_response',
            field=models.BooleanField(default=False),
        ),
    ]
