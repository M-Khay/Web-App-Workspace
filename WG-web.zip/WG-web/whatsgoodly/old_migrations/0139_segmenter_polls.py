# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.db.models.manager
import whatsgoodly.managers

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0138_responsebreakdown_total'),
    ]

    operations = [
        migrations.RenameModel(
            old_name='Segmenter',
            new_name='SegmenterInstance',
        ),
        migrations.AddField(
            model_name='segmenterinstance',
            name='university',
            field=models.ForeignKey(blank=True, to='whatsgoodly.University', null=True),
        ),
        migrations.AlterModelManagers(
            name='segmenterinstance',
            managers=[
                ('objects', django.db.models.manager.Manager()),
                ('segmenters', whatsgoodly.managers.SegmenterInstanceManager()),
            ],
        ),
    ]
