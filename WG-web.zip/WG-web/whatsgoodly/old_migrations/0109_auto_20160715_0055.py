# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0108_auto_20160714_0803'),
    ]

    operations = [
        migrations.AlterUniqueTogether(
            name='usermerger',
            unique_together=set([('user', 'merged_user')]),
        ),
    ]
