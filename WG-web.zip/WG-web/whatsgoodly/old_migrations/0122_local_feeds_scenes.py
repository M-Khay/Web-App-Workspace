# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0121_notification_opened_from_push_and_friend_poll'),
    ]

    operations = [
        migrations.AddField(
            model_name='university',
            name='feeds',
            field=models.ManyToManyField(to='whatsgoodly.Feed'),
        ),
        migrations.AlterField(
            model_name='feed',
            name='category',
            field=models.IntegerField(default=0, db_index=True, choices=[(0, b'Local'), (1, b'Global'), (2, b'Global Scene'), (3, b'Private'), (4, b'Local Scene')]),
        ),
    ]
