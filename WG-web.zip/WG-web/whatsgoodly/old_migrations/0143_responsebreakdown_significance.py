# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0142_auto_20160907_2343'),
    ]

    operations = [
        migrations.AddField(
            model_name='responsebreakdown',
            name='significance',
            field=models.FloatField(default=0.0),
        ),
    ]
