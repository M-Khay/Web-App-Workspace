# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from whatsgoodly import analytics
from whatsgoodly.utils import non_atomic_migration
import json

BATCHSIZE = 1000

@non_atomic_migration
def add_breakdowns(apps, schema_editor):
    MOBILE, WEB, GUYS, GIRLS, UNIVERSITY = range(5)
    PollInstance = apps.get_model('whatsgoodly', 'PollInstance')
    ResponseBreakdown = apps.get_model('whatsgoodly', 'ResponseBreakdown')

    max_pk = PollInstance.objects.aggregate(models.Max('pk'))['pk__max']
    if not max_pk:
        return
        
    for offset in range(0, max_pk+1, BATCHSIZE):
        done = ResponseBreakdown.objects.filter(
                breakdown_type__in=[GUYS, GIRLS],
                poll_instance_id__gte=offset,
                poll_instance_id__lt=offset+BATCHSIZE
            ).values('poll_instance_id')
        batch = PollInstance.objects.filter(
                        pk__gte=offset, pk__lt=offset+BATCHSIZE
                    ).exclude(
                        pk__in=done
                    ).select_related('poll')
        if batch.exists():
            print "offset {0} - count {1}".format(offset, batch.count())
            for pi in batch:
                analytics.reset_gender_breakdowns(pi)
                analytics.reset_university_breakdowns(pi)

def undo_add_breakdowns(apps, schema_editor):
    pass

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0136_response_breakdowns'),
    ]

    operations = [
        migrations.AlterUniqueTogether(
            name='responsebreakdown',
            unique_together=set([('poll_instance', 'breakdown_type', 'university')]),
        ),

        migrations.RunPython(add_breakdowns, reverse_code=undo_add_breakdowns),
    ]
