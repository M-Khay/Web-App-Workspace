# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations

def set_deleted(apps, schema_editor):
    Comment = apps.get_model('whatsgoodly', 'Comment')
    Comment.objects.filter(deleted=True).update(deleted_by_creator=True)

def undo_set_deleted(apps, schema_editor):
    pass

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0104_phoneban_user'),
    ]

    operations = [
        migrations.AddField(
            model_name='comment',
            name='deleted_by_creator',
            field=models.BooleanField(default=False),
        ),

        migrations.RunPython(set_deleted, reverse_code=undo_set_deleted),
    ]
