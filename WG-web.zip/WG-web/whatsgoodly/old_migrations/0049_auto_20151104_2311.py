# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0048_user_posting_suspended'),
    ]

    operations = [
        migrations.CreateModel(
            name='PollInstanceVote',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('vote', models.IntegerField()),
                ('created_date', models.DateTimeField(auto_now_add=True)),
            ],
        ),
        migrations.AddField(
            model_name='pollinstance',
            name='vote_aggregate',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='pollinstancevote',
            name='poll_instance',
            field=models.ForeignKey(to='whatsgoodly.PollInstance'),
        ),
        migrations.AddField(
            model_name='pollinstancevote',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
        ),
    ]
