# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0063_merge'),
    ]

    operations = [
        migrations.AddField(
            model_name='feed',
            name='level',
            field=models.IntegerField(default=1, choices=[(0, b'High School'), (1, b'College'), (2, b'Post College')]),
        ),
    ]
