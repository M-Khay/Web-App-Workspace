# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings
import django.contrib.gis.db.models.fields


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0132_auto_20160827_0138'),
    ]

    operations = [
        migrations.CreateModel(
            name='PushSubscription',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('disabled', models.BooleanField(default=False)),
                ('created_date', models.DateTimeField(auto_now_add=True, null=True)),
                ('modified_date', models.DateTimeField(auto_now=True, null=True)),
                ('poll_instance', models.ForeignKey(to='whatsgoodly.PollInstance')),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.AlterField(
            model_name='group',
            name='title',
            field=models.CharField(unique=True, max_length=255),
        ),
        # REMOVED; PROD HAD CONFLICTING PEEK FEEDS
        # migrations.AlterField(
        #     model_name='peekfeed',
        #     name='location',
        #     field=django.contrib.gis.db.models.fields.PointField(srid=4326, unique=True, blank=True),
        # ),
        migrations.AlterField(
            model_name='peekfeed',
            name='name',
            field=models.CharField(unique=True, max_length=180),
        ),
        migrations.AlterField(
            model_name='university',
            name='name',
            field=models.CharField(unique=True, max_length=180),
        ),
        migrations.AlterUniqueTogether(
            name='feed',
            unique_together=set([('name', 'level')]),
        ),
        migrations.AlterUniqueTogether(
            name='pushsubscription',
            unique_together=set([('user', 'poll_instance')]),
        ),
        migrations.AlterIndexTogether(
            name='pushsubscription',
            index_together=set([('user', 'poll_instance')]),
        ),
    ]
