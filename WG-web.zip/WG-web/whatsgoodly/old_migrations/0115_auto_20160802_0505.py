# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0114_user_verified_phone_number'),
    ]

    operations = [
        migrations.AlterField(
            model_name='announcement',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name='comment',
            name='vote_aggregate',
            field=models.IntegerField(default=0),
        ),
        migrations.AlterField(
            model_name='commentvote',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name='feed',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True, null=True),
        ),
        migrations.AlterField(
            model_name='friendship',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name='localchannel',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True, null=True),
        ),
        migrations.AlterField(
            model_name='mention',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name='notification',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name='phoneban',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name='poll',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name='pollinstance',
            name='vote_aggregate',
            field=models.IntegerField(default=0),
        ),
        migrations.AlterField(
            model_name='pollinstanceremoval',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name='pollinstancevote',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name='referrer',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name='report',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name='tag',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name='university',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True, null=True),
        ),
        migrations.AlterField(
            model_name='user',
            name='app_session',
            field=models.BooleanField(default=False),
        ),
        migrations.AlterField(
            model_name='user',
            name='web_session',
            field=models.BooleanField(default=False),
        ),
        migrations.AlterField(
            model_name='usermerger',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True),
        ),
        migrations.AlterIndexTogether(
            name='pollinstance',
            index_together=set([('vote_weight', 'vote_aggregate', 'favorite_count')]),
        ),
    ]
