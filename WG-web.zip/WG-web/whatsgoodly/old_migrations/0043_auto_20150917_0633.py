# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations

def placeholder(apps, schema_editor):
    pass

def set_university_public(apps, schema_editor):
    University = apps.get_model('whatsgoodly', 'University')
    University.objects.all().update(public=True)

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0042_auto_20150907_0355'),
    ]

    operations = [
        migrations.AddField(
            model_name='university',
            name='fraternities',
            field=models.TextField(null=True, blank=True),
        ),
        migrations.AddField(
            model_name='university',
            name='public',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='university',
            name='sororities',
            field=models.TextField(null=True, blank=True),
        ),
        migrations.RunPython(set_university_public, reverse_code=placeholder)
    ]
