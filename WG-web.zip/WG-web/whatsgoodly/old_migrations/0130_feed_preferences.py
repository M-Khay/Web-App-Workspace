# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0129_auto_20160822_0607'),
    ]

    operations = [
        migrations.CreateModel(
            name='FeedPreference',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('rank', models.IntegerField(default=0)),
                ('disabled', models.BooleanField(default=False)),
                ('feed', models.ForeignKey(to='whatsgoodly.Feed')),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.AlterUniqueTogether(
            name='feedpreference',
            unique_together=set([('user', 'feed')]),
        ),
        migrations.AlterIndexTogether(
            name='feedpreference',
            index_together=set([('user', 'feed')]),
        ),
    ]
