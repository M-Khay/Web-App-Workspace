# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0072_auto_20160422_0805'),
    ]

    operations = [
        migrations.AlterField(
            model_name='notification',
            name='notification_type',
            field=models.IntegerField(default=0, choices=[(0, b'Other'), (1, b'25 votes'), (2, b'Global'), (3, b'Reply'), (4, b'Comment vote'), (5, b'100 votes'), (6, b'Top tab'), (7, b'5 favorites'), (8, b'Branch Install'), (9, b'Tag Accepted'), (10, b'Tag Requested')]),
        ),
    ]
