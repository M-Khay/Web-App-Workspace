# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0115_auto_20160802_0505'),
    ]

    operations = [
        migrations.AlterIndexTogether(
            name='pollinstance',
            index_together=set([('vote_weight', 'vote_aggregate', 'favorite_count', 'created_date')]),
        ),
    ]
