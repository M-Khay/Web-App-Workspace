# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0102_auto_20160703_0527'),
    ]

    operations = [
        migrations.AlterField(
            model_name='poll',
            name='gender',
            field=models.IntegerField(default=2, db_index=True, choices=[(0, b'Guys'), (1, b'Girls'), (2, b'All')]),
        ),
    ]
