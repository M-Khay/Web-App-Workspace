# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0078_auto_20160429_2207'),
    ]

    operations = [
        migrations.AddField(
            model_name='feed',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True, null=True),
        ),
        migrations.AddField(
            model_name='feed',
            name='modified_date',
            field=models.DateTimeField(auto_now=True, null=True),
        ),
    ]
