# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0092_pollinstance_deleted_by_creator'),
    ]

    operations = [
        migrations.RenameField(
            model_name='localchannel',
            old_name='user_id',
            new_name='user_ident',
        ),
    ]
