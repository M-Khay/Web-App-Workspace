# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models

def convert_seg_polls(apps, schema_editor):
    PollInstance = apps.get_model('whatsgoodly', 'PollInstance')
    Segmenter = apps.get_model('whatsgoodly', 'Segmenter')
    for pi in PollInstance.objects.filter(is_segmenter=True):
        seg = Segmenter(
            pollinstance_ptr=pi, segment_type=pi.poll.segment_type
        )
        seg.save_base(raw=True)

def undo_convert_seg_polls(apps, schema_editor):
    PollInstance = apps.get_model('whatsgoodly', 'PollInstance')
    PollInstance.objects.filter(segmenter__isnull=False)\
        .update(
            is_segmenter=True,
            poll__segment_type=models.F('segment_type')
        )

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0125_auto_20160818_0349'),
    ]

    operations = [
        migrations.CreateModel(
            name='PollCondition',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('response_filter', models.CharField(max_length=255)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='Segmenter',
            fields=[
                ('pollinstance_ptr', models.OneToOneField(parent_link=True, auto_created=True, primary_key=True, serialize=False, to='whatsgoodly.PollInstance')),
                ('segment_type', models.IntegerField(default=0, db_index=True, choices=[(0, b'None'), (1, b'Age'), (3, b'Greek Life'), (4, b'Politics'), (5, b'Race'), (6, b'GPA'), (7, b'Community Service'), (8, b'Leadership'), (9, b'Employment'), (10, b'Degree Type'), (11, b'Techy Major'), (12, b'Fuzzy Major'), (14, b'Socio-economic'), (15, b'Student Debt')])),
            ],
            bases=('whatsgoodly.pollinstance',),
        ),

        migrations.RunPython(convert_seg_polls, reverse_code=undo_convert_seg_polls),

        migrations.RemoveField(
            model_name='poll',
            name='segment_type',
        ),
        migrations.RemoveField(
            model_name='pollinstance',
            name='is_segmenter',
        ),
        migrations.AddField(
            model_name='pollcondition',
            name='dependent_poll',
            field=models.ForeignKey(related_name='conditions', to='whatsgoodly.Poll'),
        ),
        migrations.AddField(
            model_name='pollcondition',
            name='determining_poll',
            field=models.ForeignKey(related_name='dependent_conditions', to='whatsgoodly.Poll'),
        ),
    ]
