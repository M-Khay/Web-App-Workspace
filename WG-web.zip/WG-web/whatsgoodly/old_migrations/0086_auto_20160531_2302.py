# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0085_auto_20160531_1056'),
    ]

    operations = [
        migrations.AddField(
            model_name='pollinstance',
            name='promotion',
            field=models.IntegerField(default=0, choices=[(0, b'None'), (1, b'Accelerated'), (2, b'Hot'), (3, b'Globalled')]),
        ),
    ]
