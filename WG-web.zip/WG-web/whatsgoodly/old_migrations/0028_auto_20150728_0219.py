# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0027_notification'),
    ]

    operations = [
        migrations.AddField(
            model_name='poll',
            name='has_been_top',
            field=models.BooleanField(default=False),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='notification',
            name='notification_type',
            field=models.IntegerField(default=6, choices=[(0, b'25 votes'), (1, b'Global'), (2, b'Reply'), (3, b'Comment vote'), (4, b'100 votes'), (5, b'Top tab'), (6, b'Other')]),
            preserve_default=True,
        ),
    ]
