# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0139_segmenter_polls'),
    ]

    operations = [
        migrations.CreateModel(
            name='Segmenter',
            fields=[
                ('poll_ptr', models.OneToOneField(parent_link=True, auto_created=True, primary_key=True, serialize=False, to='whatsgoodly.Poll')),
                # Index set to false to fix django bug
                # Later set to true in 0141
                # see https://code.djangoproject.com/ticket/23577
                ('segment_type', models.IntegerField(default=0, db_index=False, choices=[(0, b'None'), (1, b'Age'), (4, b'Greek Life'), (5, b'Politics'), (6, b'Race'), (7, b'GPA'), (8, b'Community Service'), (9, b'Leadership'), (10, b'Employment'), (11, b'Degree Type'), (12, b'Techy Major'), (13, b'Fuzzy Major'), (14, b'Socio-economic'), (15, b'Student Debt')])),
            ],
            bases=('whatsgoodly.poll',),
        ),
        migrations.AddField(
            model_name='segmenterinstance',
            name='segmenter',
            field=models.ForeignKey(blank=True, to='whatsgoodly.Segmenter', null=True),
        ),
        migrations.RemoveField(
            model_name='poll',
            name='deleted_by_admin',
        ),
        migrations.AddField(
            model_name='peekfeed',
            name='image_source',
            field=models.URLField(null=True, blank=True),
        ),
    ]
