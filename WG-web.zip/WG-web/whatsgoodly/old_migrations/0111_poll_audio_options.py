# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0110_pollinstance_option_counts_web'),
    ]

    operations = [
        migrations.AddField(
            model_name='poll',
            name='audio_options',
            field=models.TextField(default=None, null=True, blank=True),
        ),
    ]
