# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0020_poll_promoted'),
    ]

    operations = [
        migrations.AlterIndexTogether(
            name='favorite',
            index_together=set([('poll', 'user')]),
        ),
        migrations.AlterIndexTogether(
            name='response',
            index_together=set([('poll', 'user')]),
        ),
    ]
