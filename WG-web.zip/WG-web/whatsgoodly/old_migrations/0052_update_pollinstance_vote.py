# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0050_auto_20151110_0341'),
    ]

    operations = [
        migrations.RunSQL("UPDATE whatsgoodly_pollinstance SET vote_aggregate = 0"),
    ]