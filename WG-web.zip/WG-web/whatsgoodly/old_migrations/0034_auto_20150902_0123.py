# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0033_auto_20150812_0511'),
    ]

    operations = [
        migrations.RenameField('Favorite', 'poll', 'poll_instance'),
        migrations.RenameField('Response', 'poll', 'poll_instance'),
        migrations.RenameField('Comment', 'poll', 'poll_instance'),
        migrations.RenameField('Report', 'poll', 'poll_instance'),
        migrations.RenameField('Notification', 'poll', 'poll_instance'),
        migrations.AlterField(
            model_name='favorite',
            name='poll_instance',
            field=models.ForeignKey(to='whatsgoodly.PollInstance'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='response',
            name='poll_instance',
            field=models.ForeignKey(to='whatsgoodly.PollInstance'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='comment',
            name='poll_instance',
            field=models.ForeignKey(to='whatsgoodly.PollInstance'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='report',
            name='poll_instance',
            field=models.ForeignKey(blank=True, to='whatsgoodly.PollInstance', null=True),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='notification',
            name='poll_instance',
            field=models.ForeignKey(blank=True, to='whatsgoodly.PollInstance', null=True),
            preserve_default=True,
        ),
        migrations.RunSQL("SELECT setval('whatsgoodly_pollinstance_id_seq', (SELECT MAX(id) FROM whatsgoodly_pollinstance));")
    ]
