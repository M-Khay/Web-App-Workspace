# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0101_university_primary_color'),
    ]

    operations = [
        migrations.AlterField(
            model_name='comment',
            name='vote_aggregate',
            field=models.IntegerField(default=0, db_index=True),
        ),
        migrations.AlterField(
            model_name='poll',
            name='options',
            field=models.TextField(db_index=True),
        ),
        migrations.AlterField(
            model_name='poll',
            name='question',
            field=models.CharField(max_length=180, db_index=True),
        ),
        migrations.AlterField(
            model_name='pollinstance',
            name='vote_aggregate',
            field=models.IntegerField(default=0, db_index=True),
        ),
    ]
