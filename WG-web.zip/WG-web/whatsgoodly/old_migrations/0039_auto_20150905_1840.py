# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0038_auto_20150905_0505'),
    ]

    operations = [
	    migrations.RunSQL("UPDATE whatsgoodly_pollinstance instance SET created_date=poll.created_date FROM whatsgoodly_poll poll WHERE instance.id=poll.id")
    ]
