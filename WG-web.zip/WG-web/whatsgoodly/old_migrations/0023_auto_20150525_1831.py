# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0022_auto_20150514_1754'),
    ]

    operations = [
        migrations.AddField(
            model_name='comment',
            name='verified',
            field=models.BooleanField(default=False),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='report',
            name='comment',
            field=models.ForeignKey(blank=True, to='whatsgoodly.Comment', null=True),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='report',
            name='poll',
            field=models.ForeignKey(blank=True, to='whatsgoodly.Poll', null=True),
            preserve_default=True,
        ),
    ]
