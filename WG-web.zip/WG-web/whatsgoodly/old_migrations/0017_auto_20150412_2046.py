# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import django.contrib.gis.db.models.fields


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0016_poll_banner'),
    ]

    operations = [
        migrations.CreateModel(
            name='University',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=180)),
                ('name_short', models.CharField(max_length=180)),
                ('location', django.contrib.gis.db.models.fields.PointField(srid=4326)),
                ('radius', models.IntegerField(default=9)),
                ('email_domain', models.CharField(max_length=180)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='user',
            name='university',
            field=models.ForeignKey(blank=True, to='whatsgoodly.University', null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='user',
            name='verification_token',
            field=models.CharField(max_length=10, null=True, blank=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='user',
            name='verified_university',
            field=models.BooleanField(default=False),
            preserve_default=True,
        ),
    ]
