# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0037_peekfeed'),
    ]

    operations = [
        migrations.CreateModel(
            name='Recycle',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
            ],
        ),
        migrations.AddField(
            model_name='pollinstance',
            name='is_recycled',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='pollinstance',
            name='recycle_count',
            field=models.IntegerField(default=0),
        ),
        migrations.AlterField(
            model_name='poll',
            name='gender',
            field=models.IntegerField(default=2, choices=[(0, b'Guys'), (1, b'Girls'), (2, b'All')]),
        ),
        migrations.AddField(
            model_name='recycle',
            name='copy_poll',
            field=models.ForeignKey(related_name='copy_poll', to='whatsgoodly.PollInstance'),
        ),
        migrations.AddField(
            model_name='recycle',
            name='poll_instance',
            field=models.ForeignKey(to='whatsgoodly.PollInstance'),
        ),
        migrations.AddField(
            model_name='recycle',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
        ),
    ]
