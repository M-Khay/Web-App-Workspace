# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0091_auto_20160612_0720'),
    ]

    operations = [
        migrations.AddField(
            model_name='pollinstance',
            name='deleted_by_creator',
            field=models.BooleanField(default=False),
        ),
    ]
