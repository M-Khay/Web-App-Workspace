# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.contrib.auth.models
import whatsgoodly.managers
import django.contrib.gis.db.models.fields


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0134_populate_push_subscriptions'),
    ]

    operations = [
        migrations.AlterModelManagers(
            name='user',
            managers=[
                ('objects', django.contrib.auth.models.UserManager()),
                ('reachable', whatsgoodly.managers.UserManager()),
            ],
        ),
        migrations.AlterField(
            model_name='peekfeed',
            name='location',
            field=django.contrib.gis.db.models.fields.PointField(srid=4326, blank=True),
        ),
        migrations.AlterField(
            model_name='pushsubscription',
            name='poll_instance',
            field=models.ForeignKey(blank=True, to='whatsgoodly.PollInstance', null=True),
        ),
        migrations.AlterUniqueTogether(
            name='pushsubscription',
            unique_together=set([]),
        ),
    ]
