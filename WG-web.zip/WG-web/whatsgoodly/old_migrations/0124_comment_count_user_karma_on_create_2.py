# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models

# Part 2 of the migration. Part 1 is in 0123. Needed to split
# them due to deadlocks between comment and pollinstance,
# caused (I think) by the signals.py fn
# that changes the poll instance when a comment is created

def add_comment_count(apps, schema_editor):
    PollInstance = apps.get_model('whatsgoodly', 'PollInstance')
    RawSQL = models.expressions.RawSQL
    PollInstance.objects.all()\
        .update(comment_count=RawSQL("""
            SELECT COUNT(*)
            FROM whatsgoodly_comment
            WHERE whatsgoodly_comment.poll_instance_id = whatsgoodly_pollinstance.id
            AND whatsgoodly_comment.deleted=FALSE
            """, []
        )
    )
    pass

def undo_add_comment_count(apps, schema_editor):
    pass

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0123_comment_count_user_karma_on_create'),
    ]

    operations = [
        migrations.AddField(
            model_name='pollinstance',
            name='comment_count',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='pollinstance',
            name='user_karma_on_create',
            field=models.IntegerField(default=0),
        ),
        migrations.AlterField(
            model_name='pollinstance',
            name='modified_date',
            field=models.DateTimeField(auto_now=True, db_index=True),
        ),
        migrations.AlterIndexTogether(
            name='pollinstance',
            index_together=set([('vote_weight', 'vote_aggregate', 'favorite_count', 'comment_count')]),
        ),

        migrations.RunPython(add_comment_count, reverse_code=undo_add_comment_count),
    ]
