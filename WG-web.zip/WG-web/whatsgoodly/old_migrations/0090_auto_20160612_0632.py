# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations

def move_segment_type_to_poll(apps, schema_editor):
    # TODO fix deadlock here by moving to new migration
    # http://pankrat.github.io/2015/django-migrations-without-downtimes/
    # PollInstance = apps.get_model('whatsgoodly', 'PollInstance')
    # for pi in PollInstance.objects.exclude(segment_type=0):
    #     poll = pi.poll
    #     poll.segment_type = pi.segment_type
    #     poll.save()
    pass

def move_segment_type_to_poll_instance(apps, schema_editor):
    # PollInstance = apps.get_model('whatsgoodly', 'PollInstance')
    # for pi in PollInstance.objects.exclude(poll__segment_type=0):
    #     pi.segment_type = pi.poll.segment_type
    #     pi.save()
    pass

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0089_auto_20160610_0807'),
    ]

    operations = [
        migrations.DeleteModel(
            name='SegmentationPollInstance',
        ),
        migrations.AddField(
            model_name='poll',
            name='segment_type',
            field=models.IntegerField(default=0, choices=[(0, b'None'), (1, b'Age'), (2, b'Gender'), (3, b'Push Notifications Preference'), (4, b'Location Preference')]),
        ),

        migrations.RunPython(move_segment_type_to_poll, reverse_code=move_segment_type_to_poll_instance),

        migrations.RemoveField(
            model_name='pollinstance',
            name='segment_type',
        ),
    ]
