# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0067_auto_20160415_2057'),
    ]

    operations = [
        migrations.AlterIndexTogether(
            name='tag',
            index_together=set([('poll_instance', 'user')]),
        ),
    ]
