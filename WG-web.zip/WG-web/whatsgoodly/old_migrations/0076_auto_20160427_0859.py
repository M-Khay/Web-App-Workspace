# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0075_auto_20160427_0750'),
    ]

    operations = [
        migrations.AddField(
            model_name='announcement',
            name='image_url',
            field=models.URLField(null=True, blank=True),
        ),
    ]
