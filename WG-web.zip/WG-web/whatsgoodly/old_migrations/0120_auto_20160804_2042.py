# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0119_auto_20160802_0615'),
    ]

    operations = [
        migrations.AlterField(
            model_name='pollinstance',
            name='promotion',
            field=models.IntegerField(default=0, db_index=True, choices=[(0, b'None'), (1, b'Accelerated'), (2, b'Hot'), (3, b'Globalled'), (4, b'Sponsored'), (5, b'Pinned')]),
        ),
    ]
