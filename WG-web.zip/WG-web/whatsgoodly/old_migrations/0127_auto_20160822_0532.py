# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.db.models.manager
from django.conf import settings
import whatsgoodly.managers


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0126_auto_20160821_0305'),
    ]

    operations = [
        migrations.AlterModelManagers(
            name='pollinstance',
            managers=[
                ('objects', django.db.models.manager.Manager()),
                ('polls', whatsgoodly.managers.PollInstanceManager()),
                ('sponsored', whatsgoodly.managers.SponsoredPollInstanceManager()),
            ],
        ),
        migrations.AlterModelManagers(
            name='segmenter',
            managers=[
                ('objects', whatsgoodly.managers.SegmenterInstanceManager()),
            ],
        ),
        migrations.AddField(
            model_name='pollinstance',
            name='verified_by',
            field=models.ForeignKey(related_name='poll_instances_verified', blank=True, to=settings.AUTH_USER_MODEL, null=True),
        ),
    ]
