# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations

def remove_private_feed(apps, schema_editor):
    Feed = apps.get_model('whatsgoodly', 'Feed')
    private = Feed.objects.get(category=Feed.MY_FEATURED)
    private.delete()

def add_private_feed(apps, schema_editor):
    Feed = apps.get_model('whatsgoodly', 'Feed')
    private = Feed(name="Private", active=True, start_date=None, end_date=None, category=3)
    private.save()

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0079_auto_20160502_0907'),
    ]

    operations = [
        migrations.AlterField(
            model_name='feed',
            name='category',
            field=models.IntegerField(default=0, choices=[(0, b'Local'), (1, b'Global'), (2, b'Feature'), (3, b'Private')]),
        ),
        migrations.RunPython(add_private_feed, reverse_code=remove_private_feed),
    ]
