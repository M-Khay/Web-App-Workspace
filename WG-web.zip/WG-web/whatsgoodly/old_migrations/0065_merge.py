# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0064_auto_20160412_0837'),
        ('whatsgoodly', '0064_auto_20160412_1806'),
    ]

    operations = [
    ]
