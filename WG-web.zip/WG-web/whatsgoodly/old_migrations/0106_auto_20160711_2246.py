# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations

def set_app_session(apps, schema_editor):
    User = apps.get_model('whatsgoodly', 'User')
    User.objects.all().update(app_session=True)

def undo_set_app_session(apps, schema_editor):
    pass

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0105_comment_deleted_by_creator'),
    ]

    operations = [
        migrations.AddField(
            model_name='user',
            name='app_session',
            field=models.BooleanField(default=False, db_index=True),
        ),
        migrations.AddField(
            model_name='user',
            name='web_session',
            field=models.BooleanField(default=False, db_index=True),
        ),

        migrations.RunPython(set_app_session, reverse_code=undo_set_app_session),
    ]
