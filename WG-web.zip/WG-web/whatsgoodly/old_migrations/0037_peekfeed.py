# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import django.contrib.gis.db.models.fields


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0036_auto_20150827_0654'),
    ]

    operations = [
        migrations.CreateModel(
            name='PeekFeed',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=180)),
                ('name_short', models.CharField(max_length=180)),
                ('active', models.BooleanField(default=False)),
                ('location', django.contrib.gis.db.models.fields.PointField(srid=4326, blank=True)),
                ('university', models.ForeignKey(blank=True, to='whatsgoodly.University', null=True)),
            ],
        ),
    ]
