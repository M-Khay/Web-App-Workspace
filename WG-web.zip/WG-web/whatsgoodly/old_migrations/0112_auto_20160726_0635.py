# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0111_poll_audio_options'),
    ]

    operations = [
        migrations.AddField(
            model_name='feed',
            name='allow_audio',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='feed',
            name='allow_photos',
            field=models.BooleanField(default=False),
        ),
    ]
