# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0011_auto_20150312_0727'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='poll',
            name='featured',
        ),
        migrations.AddField(
            model_name='poll',
            name='universal',
            field=models.BooleanField(default=False),
            preserve_default=True,
        ),
    ]
