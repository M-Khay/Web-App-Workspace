# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0053_auto_20151112_1836'),
    ]

    operations = [
        migrations.AddField(
            model_name='feed',
            name='approve_posts',
            field=models.BooleanField(default=False),
        ),
    ]
