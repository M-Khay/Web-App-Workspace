# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models

def add_segmenter_polls(apps, schema_editor):
    SegmenterInstance = apps.get_model('whatsgoodly', 'SegmenterInstance')
    Segmenter = apps.get_model('whatsgoodly', 'Segmenter')
    Feed = apps.get_model('whatsgoodly', 'Feed')
    University = apps.get_model('whatsgoodly', 'University')
    for seg_instance in SegmenterInstance.objects.all():
        seg = Segmenter(
            poll_ptr=seg_instance.poll, segment_type=seg_instance.segment_type
        )
        seg.save_base(raw=True)
        seg_instance.segmenter = seg
        seg_instance.save()
        # Make local instances
        local_feed = Feed.objects.get(category=0)
        university_ids = University.objects.values_list('id', flat=True)
        local_instances = [
            SegmenterInstance.objects.create(
                    user_id=seg_instance.user_id, segmenter=seg,
                    poll=seg.poll_ptr,
                    feed=local_feed, university_id=u_id,
                    ip_address=seg_instance.ip_address,
                    verified=seg_instance.verified)
            for u_id in university_ids
        ]


def undo_add_segmenter_polls(apps, schema_editor):
    SegmenterInstance = apps.get_model('whatsgoodly', 'SegmenterInstance')
    SegmenterInstance.objects.all()\
        .update(
            segment_type=models.F('segmenter__segment_type'),
            location=models.F('university__location')
        )

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0140_auto_20160907_2302'),
    ]

    operations = [
        # SCRIPT for previous migration's setup
        migrations.RunPython(add_segmenter_polls, reverse_code=undo_add_segmenter_polls),
    ]
