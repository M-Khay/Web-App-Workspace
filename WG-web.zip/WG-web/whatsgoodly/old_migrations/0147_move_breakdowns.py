# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models, transaction
from whatsgoodly import analytics
from whatsgoodly.celery import app as celery_app
from whatsgoodly.utils import non_atomic_migration
import celery
from api import tasks

import json

BATCHSIZE = 1000

@non_atomic_migration
def move(apps, schema_editor):
    MOBILE, WEB, GENDER, UNIVERSITY, SEGMENT = range(5)
    Poll = apps.get_model('whatsgoodly', 'Poll')
    PollInstance = apps.get_model('whatsgoodly', 'PollInstance')
    ResponseBreakdown = apps.get_model('whatsgoodly', 'ResponseBreakdown')

    max_pk = Poll.objects.aggregate(models.Max('pk'))['pk__max']
    if not max_pk:
        return
        
    for offset in range(0, max_pk+1, BATCHSIZE):
        batch = PollInstance.objects.filter(
                        poll_id__gte=offset, poll_id__lt=offset+BATCHSIZE,
                        vote_counts__isnull=True
                    )
        if not batch.exists():
            continue
            
        print "\nBatch {0}".format(offset)

        # Queue celery task to compute breakdowns
        poll_ids = list(batch.values_list('poll_id', flat=True).distinct())
        tasks.recompute_breakdowns.delay(poll_ids)

        # COMPUTE POLL INSTANCE VOTE COUNTS
        for pi in batch:
            counts = pi.responsebreakdown_set.filter(breakdown_type=0).first()
            if counts:
                pi.vote_counts = counts.json
            else:
                num_options = len(json.loads(pi.poll.options))
                default_counts = [0] * num_options
                pi.vote_counts = json.dumps(default_counts)
            pi.save()

            # Gender and University breakdowns, with significance calculated
            # devices = analytics.device_breakdowns(poll)
            # control = [dev for dev in devices if dev.breakdown_type == MOBILE][0]
            # genders = analytics.gender_breakdowns(poll, control)
            # universities = analytics.university_breakdowns(poll, control)
            # segments = analytics.segment_breakdowns(poll, control)

            # breakdowns += devices + genders + universities + segments

        # Bulk create!
        # print "\tMaking {0} breakdowns".format(len(breakdowns))
        # PollBreakdown.objects.bulk_create(breakdowns)

def undo_move(apps, schema_editor):
    PollInstance = apps.get_model('whatsgoodly', 'PollInstance')
    # TODO fix this: find a way to revoke celery tasks
    # celery_app.control.revoke([
    #     uuid
    #     for uuid, _ in
    #     celery.events.state.State().tasks_by_type('tasks.recompute_breakdowns')
    # ])

    PollInstance.objects.all().update(vote_counts=None)

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0146_breakdowns_on_polls'),
    ]

    operations = [
        migrations.RunPython(move, reverse_code=undo_move),
    ]
