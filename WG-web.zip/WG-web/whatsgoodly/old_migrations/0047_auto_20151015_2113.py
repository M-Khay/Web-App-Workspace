# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0046_message'),
    ]

    operations = [
        migrations.AlterField(
            model_name='pollinstance',
            name='feed',
            field=models.ForeignKey(related_name='poll_instances', to='whatsgoodly.Feed'),
        ),
    ]
