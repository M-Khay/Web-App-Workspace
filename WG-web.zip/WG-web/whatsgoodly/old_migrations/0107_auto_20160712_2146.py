# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0106_auto_20160711_2246'),
    ]

    operations = [
        migrations.CreateModel(
            name='Referrer',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('host', models.URLField(unique=True)),
                ('created_date', models.DateTimeField(auto_now_add=True, db_index=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
            ],
        ),
        migrations.AddField(
            model_name='response',
            name='referring_url',
            field=models.URLField(null=True, blank=True),
        ),
        migrations.AddField(
            model_name='response',
            name='referrer',
            field=models.ForeignKey(blank=True, to='whatsgoodly.Referrer', null=True),
        ),
    ]
