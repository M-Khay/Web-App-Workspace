# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0117_auto_20160802_0555'),
    ]

    operations = [
        migrations.AlterField(
            model_name='comment',
            name='vote_aggregate',
            field=models.IntegerField(default=0, db_index=True),
        ),
    ]
