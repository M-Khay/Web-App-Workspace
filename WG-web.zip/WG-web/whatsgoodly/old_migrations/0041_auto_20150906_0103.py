# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0040_auto_20150907_0509'),
    ]

    operations = [
        migrations.AlterField(
            model_name='user',
            name='gender',
            field=models.IntegerField(default=-1, choices=[(-1, b'Not chosen'), (0, b'Male'), (1, b'Female')]),
        ),
    ]
