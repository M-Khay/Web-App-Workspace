# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings
import django.contrib.gis.db.models.fields


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0031_poll_vote_weight'),
        ('contenttypes', '0002_remove_content_type_name'),
    ]

    operations = [
        migrations.CreateModel(
            name='Feed',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=180)),
                ('active', models.BooleanField(default=False)),
                ('start_date', models.DateTimeField(null=True, blank=True)),
                ('end_date', models.DateTimeField(null=True, blank=True)),
                ('category', models.IntegerField(default=0, choices=[(0, b'Local'), (1, b'Global'), (2, b'Feature')])),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='PollInstance',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('option_counts', models.TextField(default=None, null=True, blank=True)),
                ('location', django.contrib.gis.db.models.fields.PointField(srid=4326)),
                ('ip_address', models.GenericIPAddressField(default=None, null=True, blank=True)),
                ('comment_count', models.IntegerField(default=0)),
                ('favorite_count', models.IntegerField(default=0)),
                ('deleted', models.BooleanField(default=False)),
                ('vote_weight', models.FloatField(default=0)),
                ('promoted', models.BooleanField(default=False)),
                ('banner', models.CharField(default=None, max_length=180, null=True, blank=True)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('feed', models.ForeignKey(to='whatsgoodly.Feed')),
                ('poll', models.ForeignKey(to='whatsgoodly.Poll')),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
            options={
            },
            bases=(models.Model,),
        )
    ]
