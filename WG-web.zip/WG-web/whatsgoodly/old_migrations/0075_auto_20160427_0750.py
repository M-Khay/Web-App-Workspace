# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0074_auto_20160424_0932'),
    ]

    operations = [
        migrations.AddField(
            model_name='announcement',
            name='feed',
            field=models.ForeignKey(blank=True, to='whatsgoodly.Feed', null=True),
        ),
    ]
