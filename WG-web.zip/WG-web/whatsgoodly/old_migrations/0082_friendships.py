# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings

def remove_friendships(apps, schema_editor):
    pass

def add_friendships(apps, schema_editor):
    Friendship = apps.get_model('whatsgoodly', 'Friendship')
    Tag = apps.get_model('whatsgoodly', 'Tag')
    for tag in Tag.objects.all():
        f = Friendship.objects.get_or_create(user=tag.user, friend_phone_number=tag.phone_number, defaults={'friend_name': tag.name})
        tag.friendship = f[0]
        tag.save()

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0081_auto_20160503_0908'),
    ]

    operations = [
        migrations.CreateModel(
            name='Friendship',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('friend_name', models.CharField(max_length=180, null=True, blank=True)),
                ('friend_phone_number', models.CharField(max_length=15)),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.AddField(
            model_name='tag',
            name='friendship',
            field=models.ForeignKey(to='whatsgoodly.Friendship', null=True),
        ),
        migrations.AlterUniqueTogether(
            name='friendship',
            unique_together=set([('user', 'friend_phone_number')]),
        ),
        migrations.AlterIndexTogether(
            name='friendship',
            index_together=set([('user', 'friend_phone_number')]),
        ),

        migrations.RunPython(add_friendships, reverse_code=remove_friendships),

        migrations.AlterField(
            model_name='tag',
            name='friendship',
            field=models.ForeignKey(to='whatsgoodly.Friendship'),
        ),
        migrations.AlterUniqueTogether(
            name='tag',
            unique_together=set([('friendship', 'poll_instance')]),
        ),
        migrations.AlterIndexTogether(
            name='tag',
            index_together=set([('poll_instance', 'friendship')]),
        ),
        migrations.RemoveField(
            model_name='tag',
            name='name',
        ),
        migrations.RemoveField(
            model_name='tag',
            name='phone_number',
        ),
        migrations.RemoveField(
            model_name='tag',
            name='user',
        ),
    ]
