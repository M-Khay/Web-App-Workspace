# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0148_auto_20160911_2114'),
    ]

    operations = [
        migrations.AlterField(
            model_name='pollinstance',
            name='vote_counts',
            field=models.TextField(),
        ),
    ]
