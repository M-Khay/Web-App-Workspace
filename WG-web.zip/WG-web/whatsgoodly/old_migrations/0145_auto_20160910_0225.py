# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0144_auto_20160909_2202'),
    ]

    operations = [
        migrations.AlterField(
            model_name='poll',
            name='options',
            field=models.TextField(),
        ),
        migrations.AlterField(
            model_name='poll',
            name='question',
            field=models.CharField(max_length=180),
        ),
        migrations.AlterIndexTogether(
            name='poll',
            index_together=set([('question', 'options')]),
        ),
        migrations.AlterIndexTogether(
            name='university',
            index_together=set([('name', 'name_short')]),
        ),
    ]
