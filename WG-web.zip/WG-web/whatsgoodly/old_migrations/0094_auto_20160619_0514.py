# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings

def copy_userident_to_user(apps, schema_editor):
    LocalChannel = apps.get_model('whatsgoodly', 'LocalChannel')
    LocalChannel.objects.all().update(user_id=models.F('user_ident'))

def copy_user_to_userident(apps, schema_editor):
    LocalChannel = apps.get_model('whatsgoodly', 'LocalChannel')
    LocalChannel.objects.all().update(user_ident=models.F('user_id'))

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0093_auto_20160619_0513'),
    ]

    operations = [
        migrations.AddField(
            model_name='localchannel',
            name='user',
            field=models.ForeignKey(blank=True, to=settings.AUTH_USER_MODEL, null=True),
        ),

        migrations.RunPython(copy_userident_to_user, reverse_code=copy_user_to_userident),

        migrations.RemoveField(
            model_name='localchannel',
            name='user_ident',
        ),
    ]
