# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0041_auto_20150906_0103'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='recycle',
            name='copy_poll',
        ),
        migrations.RemoveField(
            model_name='recycle',
            name='poll_instance',
        ),
        migrations.RemoveField(
            model_name='recycle',
            name='user',
        ),
        migrations.RemoveField(
            model_name='pollinstance',
            name='is_recycled',
        ),
        migrations.RemoveField(
            model_name='pollinstance',
            name='recycle_count',
        ),
        migrations.AddField(
            model_name='poll',
            name='recycle_count',
            field=models.IntegerField(default=0),
        ),
        migrations.DeleteModel(
            name='Recycle',
        ),
    ]
