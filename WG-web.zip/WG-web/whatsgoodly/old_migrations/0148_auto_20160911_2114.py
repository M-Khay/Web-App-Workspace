# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0147_move_breakdowns'),
    ]

    operations = [
        migrations.AlterUniqueTogether(
            name='responsebreakdown',
            unique_together=set([]),
        ),
        migrations.AlterIndexTogether(
            name='responsebreakdown',
            index_together=set([]),
        ),
        migrations.RemoveField(
            model_name='responsebreakdown',
            name='poll_instance',
        ),
        migrations.RemoveField(
            model_name='responsebreakdown',
            name='university',
        ),
        migrations.DeleteModel(
            name='ResponseBreakdown',
        ),
    ]
