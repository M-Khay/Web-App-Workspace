# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0112_auto_20160726_0635'),
    ]

    operations = [
        migrations.CreateModel(
            name='PollInstanceRemoval',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_date', models.DateTimeField(auto_now_add=True, db_index=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
            ],
        ),
        migrations.AlterIndexTogether(
            name='pollinstance',
            index_together=set([('created_date', 'vote_aggregate')]),
        ),
        migrations.AddField(
            model_name='pollinstanceremoval',
            name='poll_instance',
            field=models.ForeignKey(to='whatsgoodly.PollInstance'),
        ),
        migrations.AddField(
            model_name='pollinstanceremoval',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
        ),
        migrations.AlterIndexTogether(
            name='pollinstanceremoval',
            index_together=set([('poll_instance', 'user')]),
        ),
    ]
