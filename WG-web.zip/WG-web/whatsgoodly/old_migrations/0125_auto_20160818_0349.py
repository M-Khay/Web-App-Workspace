# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0124_comment_count_user_karma_on_create_2'),
    ]

    operations = [
        migrations.AlterField(
            model_name='university',
            name='local_feeds',
            field=models.ManyToManyField(to='whatsgoodly.Feed', blank=True),
        ),
    ]
