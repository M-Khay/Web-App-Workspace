# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations

def add_verify(apps, schema_editor):
    User = apps.get_model('whatsgoodly', 'User')
    User.objects.filter(phone_number__isnull=False)\
        .update(verified_phone_number=True)

def undo_add_verify(apps, schema_editor):
    pass

class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0113_auto_20160801_0850'),
    ]

    operations = [
        migrations.AddField(
            model_name='user',
            name='verified_phone_number',
            field=models.BooleanField(default=False),
        ),

        migrations.RunPython(add_verify, reverse_code=undo_add_verify),
    ]
