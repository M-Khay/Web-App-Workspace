# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0043_auto_20150917_0633'),
    ]

    operations = [
        migrations.AddField(
            model_name='feed',
            name='image_source',
            field=models.URLField(null=True, blank=True),
        ),
    ]
