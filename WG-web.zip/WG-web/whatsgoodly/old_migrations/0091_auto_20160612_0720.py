# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0090_auto_20160612_0632'),
    ]

    operations = [
        migrations.AddField(
            model_name='comment',
            name='rejected',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='pollinstance',
            name='rejected',
            field=models.BooleanField(default=False),
        ),
    ]
