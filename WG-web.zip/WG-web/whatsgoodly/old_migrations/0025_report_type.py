# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0024_auto_20150521_0734'),
    ]

    operations = [
        migrations.AddField(
            model_name='report',
            name='report_type',
            field=models.IntegerField(default=3, choices=[(0, b'Poll targets someone'), (1, b'Poll is offensive'), (2, b'Poll is spam'), (3, b'Other')]),
            preserve_default=True,
        ),
    ]
