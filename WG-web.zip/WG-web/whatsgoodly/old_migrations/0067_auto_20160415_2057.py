# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0066_auto_20160415_1230'),
    ]

    operations = [
        migrations.AlterField(
            model_name='notification',
            name='body',
            field=models.CharField(max_length=180, null=True, blank=True),
        ),
    ]
