# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0107_auto_20160712_2146'),
    ]

    operations = [
        migrations.CreateModel(
            name='UserMerger',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('ip_address', models.GenericIPAddressField(default=None, null=True, blank=True)),
                ('created_date', models.DateTimeField(auto_now_add=True, db_index=True)),
                ('modified_date', models.DateTimeField(auto_now=True)),
                ('merged_user', models.ForeignKey(related_name='merged_into', to=settings.AUTH_USER_MODEL)),
                ('user', models.ForeignKey(related_name='merged', to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.AlterIndexTogether(
            name='usermerger',
            index_together=set([('user', 'merged_user')]),
        ),
    ]
