# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0109_auto_20160715_0055'),
    ]

    operations = [
        migrations.AddField(
            model_name='pollinstance',
            name='option_counts_web',
            field=models.TextField(default=None, null=True, blank=True),
        ),
    ]
