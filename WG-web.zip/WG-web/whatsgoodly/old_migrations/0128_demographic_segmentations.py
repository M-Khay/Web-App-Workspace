# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from whatsgoodly import segmentations

def add_segmentations(apps, schema_editor):
    Segmenter = apps.get_model('whatsgoodly', 'Segmenter')
    for ident, spec in segmentations.IDENTIFIERS:
        if ident == 0:
            continue
        try:
            seg = Segmenter.objects.get(segment_type=ident)
        except Segmenter.DoesNotExist:
            Segmenter.objects.create_segmenter(ident)

def undo_add_segmentations(apps, schema_editor):
    pass


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0127_auto_20160822_0532'),
    ]

    operations = [
        migrations.RunPython(add_segmentations, reverse_code=undo_add_segmentations),
    ]