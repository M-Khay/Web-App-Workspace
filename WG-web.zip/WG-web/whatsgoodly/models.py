# -*- coding: utf-8 -*-

from django.contrib.auth.models import AbstractUser
from django.contrib.gis.db import models
from django.db.models import Q, F # also required for eval() in PollCondition
from elasticsearch_dsl.connections import connections
from elasticsearch.exceptions import ConnectionError
from whatsgoodly import segmentations, managers, analytics
from api.constant_lists import emoji_map
from api.utils import CENSOR_LEVELS
from api.task_helpers.elastic_search_upload import make_epoll, make_ebreakdown
from datetime import datetime, timedelta
from localflavor.us.models import USStateField
import json
import re
import math

# UNIVERSITY_IDS_WITH_BETA_RESTRICTION = [25] # UCLA
# Brawley Union HS, Imperial, Covenant
UNIVERSITY_IDS_WITH_NAME_CENSORSHIP = [637, 692, 424, 699, 652]
DISABLED_UNIVERSITY_IDS = []
GENDER_COLORS = ["#1189FB", "#FF6399"]
# http://www.pewresearch.org/fact-tank/2016/04/25/millennials-overtake-baby-boomers/
MILLENNIALS_IN_US = 75.4 * 1000 * 1000

class BaseModel(models.Model):
  created_date = models.DateTimeField(auto_now_add=True)
  modified_date = models.DateTimeField(auto_now=True)

  class Meta:
    abstract = True

# TODO deprecate in favor of Response?
class LocalChannel(models.Model):
  user = models.ForeignKey('User', blank=True, null=True)
  name = models.CharField(max_length=255)
  active = models.BooleanField(default=False)
  location = models.PointField()

  created_date = models.DateTimeField(auto_now_add=True, null=True)
  modified_date = models.DateTimeField(auto_now=True, null=True)

  def __unicode__(self):
    suffix = " (inactive)" if not self.active else ""
    return u"%s: %s%s" % ( self.user, self.name, suffix, )


class PeekFeed(models.Model):
  name = models.CharField(max_length=180, unique=True)
  name_short = models.CharField(max_length=180)
  active = models.BooleanField(default=False)
  location = models.PointField(blank=True)
  image_source = models.URLField(max_length=200, blank=True, null=True)
  university = models.ForeignKey('University', blank=True, null=True)

  class Meta:
    ordering = ('-active', '-id')

  def __unicode__(self):
    return "{}{}".format(
        "INACTIVE: " if not self.active else "",
        self.name
      )


class User(AbstractUser):
  GENDER_CHOICES = (
    (-1, 'Not chosen'),
    (0, 'Male'),
    (1, 'Female'),
  )
  KARMA_THRESHOLDS = (
    ('Freshmeat', 0),
    ('Basic', 100),
    ('Pledge', 500),
    ('Lingering alum', 1500),
    ('IM all-star', 2500),
    ('Campus po', 3750),
    ('Student council', 5250),
    ('School mascot', 8000),
    ('Drop-out prodigy', 10250),
    ('5th year frat-star', 12750),
    ('WG intern', 15500),
    ('Top doggy', 18500)
  )
  class CREDIT_REWARDS:
    VOTE = 1
    GET_FAVORITED = 5
    TAG_CONTACT = 10
    ADD_PHONE_NUMBER = 100
    REFER_CONTACT = 100
    RANK_UP_PER_RANK = 100
    POST_POLL = 0
  class CREDIT_COSTS:
    UNLOCK_FILTER_POLLS = 20

  MIN_KARMA_FOR_SEGMENTATIONS = 1

  gender = models.IntegerField(choices=GENDER_CHOICES, default=-1)
  notification_count = models.IntegerField(default=0)
  karma = models.IntegerField(default=0)
  credits = models.IntegerField(default=0)
  phone_number = models.CharField(max_length=15, blank=True, null=True, db_index=True)
  verified_phone_number = models.BooleanField(default=False)
  verified_email = models.BooleanField(default=False)
  full_name = models.CharField(max_length=180, blank=True, null=True)

  university = models.ForeignKey('University', blank=True, null=True)
  verified_university = models.BooleanField(default=False)
  verification_token = models.CharField(max_length=10, blank=True, null=True)

  ip_address = models.GenericIPAddressField(blank=True, null=True, default=None)
  last_user_agent = models.CharField(max_length=256, blank=True, null=True)

  posting_suspended = models.BooleanField(default=False)

  # By default, have this be false. User may have enabled push notifications
  # on iOS, but there's no way to definitively know.
  # NOTE: Only to be set to True when user explicitly denies the in-app prompt.
  # If user uninstalls or denies in system Settings, aws_sns_arn_endpoint
  # will be set to None
  denied_push_notifications = models.BooleanField(default=False)

  # Only for iOS applications, but not guaranteed.
  # use gcm_token__isnull to determine whether device is iOS
  ios_apns_token = models.CharField(max_length=255, blank=True, null=True)

  # Only for Android applications.
  # use gcm_token__isnull to determine device type
  gcm_token = models.CharField(max_length=255, blank=True, null=True)

  # AWS SNS ARN Endpoint for Push Notifications
  # If user uninstalls or denies in system Settings, this
  # will be set to None
  aws_sns_arn_endpoint = models.CharField(max_length=255, blank=True, null=True)

  # Flags for when users have sessions on one platform or another
  app_session = models.BooleanField(default=False)
  web_session = models.BooleanField(default=False)

  account = models.ForeignKey('Account', blank=True, null=True)

  created_date = models.DateTimeField(auto_now_add=True, null=True)
  modified_date = models.DateTimeField(auto_now=True, null=True)

  objects = managers.UserManager()

  # AUTHORIZATION HELPERS
  # TODO move to permissions.py
  def can_auto_verify_polls(self):
    return self.get_rank() == len(User.KARMA_THRESHOLDS) - 1

  def can_modify_tag(self, tag, data={}):
    if "accepted" in data and self.phone_number != tag.friendship.friend_phone_number:
      return False
    return True

  def is_banned(self):
    if self.gcm_token:
      return PhoneBan.objects.filter(
          Q(gcm_token=self.gcm_token) |
          Q(user=self)
        ).exists()
    elif self.ios_apns_token:
      return PhoneBan.objects.filter(
          Q(ios_apns_token=self.ios_apns_token) |
          Q(user=self)
        ).exists()
    else:
      return PhoneBan.objects.filter(
          Q(user=self)
        ).exists()

  def has_android(self):
    return bool(self.gcm_token) or " Android " in (self.last_user_agent or "")

  def has_ios(self):
    return bool(self.ios_apns_token) or " iOS " in (self.last_user_agent or "")

  def set_segment_response(self, segment_type, response, changeable=True):
    local_feed = Feed.objects.get(category=Feed.LOCAL)
    seg = SegmenterInstance.objects.filter(
        segmenter__segment_type=segment_type,
      ).filter(
        Q(feed=local_feed, community_id=self.university_id) |
        ~Q(feed=local_feed)
      ).order_by('feed_id').first()
    if not seg:
      raise Exception("No segmenter found of type: {}".format(segment_type))
    if not changeable and Response.objects.filter(poll_instance=seg, user=self).exists():
      return
    return Response.objects.create(
        poll_instance=seg, user=self, response=response
      )

  def get_rank(self):
    for i, threshold in enumerate(User.KARMA_THRESHOLDS):
      if self.karma < threshold[1]:
        return i - 1
    return len(User.KARMA_THRESHOLDS) - 1

  def get_handle(self):
    uni_part = ""
    if self.university:
      uni_part = " ({})".format(self.university.name_short)
    rank_part = User.KARMA_THRESHOLDS[self.get_rank()][0]
    return "{}{}".format(rank_part, uni_part)

  def get_token(self):
    return self.auth_token

  def get_age(self):
    age = self.segment_response(segmentations.AgeLevel.ID)
    if age is not None:
      if age == segmentations.AgeLevel.OTHER:
        # Probably middle schoolers, put in HS feed
        return segmentations.AgeLevel.HIGH_SCHOOL
      if age == segmentations.AgeLevel.GRAD_SCHOOL:
        # Needs ios update to prevent crash;
        # put in POST_GRAD in meantime
        return segmentations.AgeLevel.POST_GRAD
      return age
    else:
      return segmentations.AgeLevel.COLLEGE

  def get_active_location(self):
    channel = LocalChannel.objects.filter(user=self, active=True).order_by('-id').first()
    return channel.location if channel else None

  def get_last_location(self):
    resp = Response.objects.filter(user=self).order_by('-id').first()
    return resp.location if resp else None

  def pronoun(self):
    if self.gender == 0: return "him"
    elif self.gender == 1: return "her"
    else: return "them"

  def possessive_pronoun(self):
    if self.gender == 0: return "his"
    elif self.gender == 1: return "her"
    else: return "their"

  def segment_response(self, seg_type):
    poll = Segmenter.objects.get(segment_type=seg_type).poll_ptr
    res = Response.objects.filter(
        user=self, poll_instance__poll=poll
      ).order_by('-id').first()
    return res.response if res else None

  def __unicode__(self):
    where = ""
    if self.university_id:
      where = "{}, ".format(self.university.name_short)
    elif self.email:
      where = "@{}, ".format(self.email.split('@')[1])
    if self.account_id:
      where = "{}, {}".format(self.account.name, where)

    device = ""
    if self.web_session and not self.app_session:
      device = "Web"
    elif self.has_android():
      device = "Android"
    elif self.has_ios():
      device = "iOS"

    gender = [u"🙇 ", u"💁 ", ""][self.gender]

    if self.is_staff:
      label = self.username
    else:
      label = u"{}{} User {}".format(gender, device, self.id)
    if not self.is_active:
      label = u"{} (INACTIVE)".format(label)
      
    return u"{} [{}{}pts]".format(
        label, where, self.karma
      )


class UserMerger(BaseModel):
  user = models.ForeignKey('User', related_name='merged')
  merged_user = models.ForeignKey('User', related_name='merged_into')
  ip_address = models.GenericIPAddressField(blank=True, null=True, default=None)

  def __unicode__(self):
    return u"%s <-- %s" % (self.user, self.merged_user)

  class Meta:
    index_together = [
      ['user', 'merged_user']
    ]
    unique_together = (
      ('user', 'merged_user'),
    )


class PhoneBan(BaseModel):
  user = models.ForeignKey('User', blank=True, null=True)
  aws_sns_arn_endpoint = models.CharField(max_length=255, blank=True, null=True, db_index=True)
  ios_apns_token = models.CharField(max_length=255, blank=True, null=True, db_index=True)
  gcm_token = models.CharField(max_length=255, blank=True, null=True, db_index=True)

  def accounts(self):
    if self.ios_apns_token:
      return User.objects.filter(ios_apns_token=self.ios_apns_token)
    elif self.gcm_token:
      return User.objects.filter(gcm_token=self.gcm_token)
    elif self.aws_sns_arn_endpoint:
      return User.objects.filter(aws_sns_arn_endpoint=self.aws_sns_arn_endpoint)
    else:
      return User.objects.filter(pk=self.user_id)

  def __unicode__(self):
    if self.ios_apns_token:
      return u"iOS: %s" % self.ios_apns_token
    elif self.gcm_token:
      return u"Android: %s" % self.gcm_token
    else:
      return u"User: %s" % self.user


class Group(models.Model):
  title = models.CharField(max_length=255, unique=True)
  universities = models.ManyToManyField('University')

  def __unicode__(self):
    return self.title

  class Meta:
    ordering = ('title',)


class Feed(models.Model):
  USER_FAVORITES = -3
  USER_COMMENTS = -2
  USER_POLLS = -1
  LOCAL, GLOBAL, FEATURED, MY_FEATURED, CAMPUS_SCENE, CAMPUS, CAMPUS_PEEK = range(7)
  
  LOCAL_CATEGORIES = {LOCAL, CAMPUS, CAMPUS_SCENE, CAMPUS_PEEK}
  EXPLORE_CATEGORIES = {GLOBAL, FEATURED, MY_FEATURED}
  THEMED_CATEGORIES = {FEATURED, MY_FEATURED}
  CAMPUS_ONLY_CATEGORIES = {CAMPUS, CAMPUS_SCENE, CAMPUS_PEEK}
  FAKE_CATEGORIES = {CAMPUS, CAMPUS_PEEK}
  CATEGORY_CHOICES = (
    (LOCAL, 'Local'),
    (GLOBAL, 'Global'),
    (FEATURED, 'Featured'),
    (MY_FEATURED, 'My Feeds Featured'),
    (CAMPUS_SCENE, 'Campus Scene'),
    (CAMPUS, 'Campus'),
    (CAMPUS_PEEK, 'Peek')
  )
  class LEVELS:
    HIGH_SCHOOL, COLLEGE, POST_COLLEGE, ALL_SCHOOL, ALL_AGES = range(5)
    CHOICES = (
      (HIGH_SCHOOL, 'High School'),
      (COLLEGE, 'College'),
      (POST_COLLEGE, 'Post College'),
      (ALL_SCHOOL, 'All in School'),
      (ALL_AGES, 'All Ages')
    )
  class PROMOTION_DAYS:
    NONE, SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY = range(8)
    CHOICES = (
      (NONE, 'None'),
      (SUNDAY, 'Sunday'),
      (MONDAY, 'Monday'),
      (TUESDAY, 'Tuesday'),
      (WEDNESDAY, 'Wednesday'),
      (THURSDAY, 'Thursday'),
      (FRIDAY, 'Friday'),
      (SATURDAY, 'Saturday'),
    )
    @staticmethod
    def from_day(date):
      day_of_week = (date.weekday() + 1) % 7
      return day_of_week + 1

  name = models.CharField(max_length=180)
  active = models.BooleanField(default=False)
  start_date = models.DateTimeField(blank=True, null=True)
  end_date = models.DateTimeField(blank=True, null=True)
  promotion_day = models.IntegerField(choices=PROMOTION_DAYS.CHOICES, default=PROMOTION_DAYS.NONE)

  created_date = models.DateTimeField(null=True, auto_now_add=True)
  modified_date = models.DateTimeField(null=True, auto_now=True)

  category = models.IntegerField(choices=CATEGORY_CHOICES, default=CAMPUS_SCENE, db_index=True)
  level = models.IntegerField(choices=LEVELS.CHOICES, default=LEVELS.ALL_AGES)
  image_source = models.URLField(max_length=200, blank=True, null=True)
  approve_posts = models.BooleanField(default=False)
  allow_audio = models.BooleanField(default=False)
  allow_photos = models.BooleanField(default=False)
  allow_option_photos = models.BooleanField(default=False)
  guaranteed_breakdowns = models.BooleanField(default=False)
  location = models.PointField(null=True, blank=True)

  allowed_breakdowns = models.ManyToManyField('Segmenter', blank=True)

  def __unicode__(self):
    if self.location:
      location_part = " [{}, {}]".format(self.location.x, self.location.y)
    else:
      location_part = ""
    return "{}{} ({}){}".format(
      "INACTIVE: " if not self.active else "",
      self.name, self.get_level_display(),
      location_part
    )

  class Meta:
    ordering = ('-active', 'category', '-id')
    unique_together = (
      ('name', 'level'),
    )


class FeedPreference(models.Model):
  feed = models.ForeignKey('Feed')
  user = models.ForeignKey('User')
  rank = models.IntegerField(default=0)
  disabled = models.BooleanField(default=False)

  created_date = models.DateTimeField(null=True, auto_now_add=True)
  modified_date = models.DateTimeField(null=True, auto_now=True)

  def __unicode__(self):
    return u"{0} - {1}: rank {2}{3}".format(
      self.user, self.feed, self.rank,
      " DISABLED" if self.disabled else ""
    )

  class Meta:
    index_together = [
      ['user', 'feed']
    ]
    unique_together = (
      ('user', 'feed'),
    )


class University(models.Model):
  class LEVELS:
    COLLEGE, HIGH_SCHOOL, MIDDLE_SCHOOL, GRAD_SCHOOL = range(4)
    CHOICES = (
      (COLLEGE, 'College'),
      (HIGH_SCHOOL, 'High School'),
      (MIDDLE_SCHOOL, 'Middle School'),
      (GRAD_SCHOOL, 'Grad School')
    )
    @staticmethod
    def to_age_level(level):
      if level == University.LEVELS.COLLEGE:
        return segmentations.AgeLevel.COLLEGE
      elif level == University.LEVELS.HIGH_SCHOOL:
        return segmentations.AgeLevel.HIGH_SCHOOL
      elif level == University.LEVELS.GRAD_SCHOOL:
        return segmentations.AgeLevel.GRAD_SCHOOL
      else:
        return segmentations.AgeLevel.OTHER
  level = models.IntegerField(choices=LEVELS.CHOICES, default=LEVELS.COLLEGE)
  name = models.CharField(max_length=180, unique=True, db_index=True)
  name_short = models.CharField(max_length=180)
  state = USStateField(blank=True, null=True)
  population_size = models.IntegerField(default=0)
  location = models.PointField()
  radius = models.FloatField(default=2.0)
  email_domain = models.CharField(max_length=180)

  public = models.BooleanField(default=False)

  fraternities = models.TextField(blank=True, null=True)
  sororities = models.TextField(blank=True, null=True)

  created_date = models.DateTimeField(auto_now_add=True, null=True)
  modified_date = models.DateTimeField(auto_now=True, null=True)

  primary_color = models.CharField(max_length=7, null=True, blank=True, default=None)

  local_feeds = models.ManyToManyField('Feed', blank=True, limit_choices_to=Q(category=Feed.CAMPUS_SCENE))
  objects = models.GeoManager()

  def get_longitude(self):
    return self.location.x

  def get_latitude(self):
    return self.location.y

  def __unicode__(self):
    return "{} ({})".format(self.name, self.get_level_display())

  class Meta:
    ordering = ('name', )


class Poll(BaseModel):
  class GENDERS:
    GUYS, GIRLS, ALL = range(3)
    CHOICES = (
      (GUYS, 'Guys'),
      (GIRLS, 'Girls'),
      (ALL, 'All')
    )
  gender = models.IntegerField(choices=GENDERS.CHOICES, default=GENDERS.ALL, db_index=True)
  # If it's based on one of our suggestions
  archetype = models.ForeignKey('PollArchetype', blank=True, null=True)

  user = models.ForeignKey(User)
  question = models.CharField(max_length=180)
  question_picture_url = models.URLField(max_length=200, blank=True, null=True, default=None)
  options = models.TextField()
  # TODO has_picture_options = models.BooleanField(default=False)
  randomize_options = models.BooleanField(default=False)
  audio_options = models.TextField(blank=True, null=True, default=None)
  # TODO rename to instance_count
  recycle_count = models.IntegerField(default=0)

  censor_level = models.IntegerField(choices=CENSOR_LEVELS.CHOICES, default=CENSOR_LEVELS.NONE, db_index=True)
  verified = models.BooleanField(default=False)
  deleted = models.BooleanField(default=False)

  tags = models.ManyToManyField('PollTag', blank=True)

  def index(self):
    try:
      indexed_poll = make_epoll(self)
      if self.deleted:
        indexed_poll.delete(ignore=404)
        return

      for pb in self.breakdowns.all():
        breakdown = make_ebreakdown(pb)
        indexed_poll.breakdowns.append(breakdown)
      
      indexed_poll.save()
    except:
      from raven import Client
      client = Client(settings.RAVEN_CONFIG['dsn'])
      client.captureException()

  def get_error_margin(self, sample_size, population_size=MILLENNIALS_IN_US,
                       confidence_interval=1.96): # 95% confidence
    # Credits: https://www.surveymonkey.com/mp/margin-of-error-calculator/
    pop = population_size
    if self.gender in (Poll.GENDERS.GUYS, Poll.GENDERS.GIRLS):
      pop = pop / 2

    if not sample_size:
      return 100

    return int(round(
      (math.sqrt(0.25/sample_size)*float(confidence_interval))
      *
      (math.sqrt((pop-sample_size)/float(pop-1))*100.0)
    ))

  def get_default_counts(self):
    num_options = len(json.loads(self.options))
    return [0] * num_options

  def update_simple_breakdowns(self, response):
    if Response.objects.exclude(pk=response.pk).filter(
          user_id=response.user_id, poll_instance__poll=self
        ).exists():
      # Don't update if user voted on this poll_id
      return

    try:
      if not response.referrer_id:
        # Mobile vote
        control = self.breakdowns.get(breakdown_type=PollBreakdown.TYPES.MOBILE)
      else:
        # Web vote
        control = self.breakdowns.get(breakdown_type=PollBreakdown.TYPES.WEB)
      control.add_response(response)
    except PollBreakdown.DoesNotExist as e:
      # Don't know why this is happening
      from raven.contrib.django.raven_compat.models import client
      client.captureException()
      control = None

    try:
      # Gender breakdowns
      breakdown = self.breakdowns.get(
        breakdown_type=PollBreakdown.TYPES.GENDER,
        gender=response.user.gender
      )
      breakdown.add_response(response, control)
    except PollBreakdown.DoesNotExist:
      # Not guaranteed, e.g. if poll's gender != ALL
      pass

    if response.user.university_id:
      breakdown, created = self.breakdowns.get_or_create(
        breakdown_type=PollBreakdown.TYPES.UNIVERSITY,
        university_id=response.user.university_id
      )
      breakdown.add_response(response, control)

  def __unicode__(self):
    opts = json.loads(self.options)
    # opts = [re.compile("[^a-zA-Z0-9]+").split(opt)[0] for opt in opts]
    if_deleted = "DELETED: " if self.deleted else ""
    if_gender = ["GUYS: ", "GIRLS: ", ""][self.gender]
    question_part = self.question
    if self.question_picture_url:
      question_part = "{} <IMG{}...>".format(question_part, self.question_picture_url[6:18])
    return u"{}{}{} [{}]".format(if_deleted, if_gender, question_part, ", ".join(opts))


class Segmenter(Poll):
  segment_type = models.IntegerField(choices=segmentations.CHOICES, default=segmentations.NoneType.ID, db_index=True)
  min_votes_for_breakdown = models.IntegerField(default=analytics.MIN_SAMPLE_SIZE)
  option_labels = models.TextField(blank=True, null=True, default=None)
  option_hex_colors = models.TextField(blank=True, null=True, default=None)
  option_indices_excluded_from_breakdowns = models.TextField(blank=True, null=True, default=None)

  def get_segment_color(self, option):
    try:
      opts = json.loads(self.option_hex_colors)
      return opts[option] or None
    except (IndexError, TypeError, ValueError) as e:
      return None

  def get_segment_label(self, option):
    question_short = " ".join(self.question.split()[-3:])
    opts = json.loads(self.options)
    return u"{0} {1}".format(question_short, opts[option])

  def get_segment_label_short(self, option):
    opts = json.loads(self.option_labels or self.options)
    return opts[option]

class PollCondition(BaseModel):
  determining_poll = models.ForeignKey('Poll', related_name='dependent_conditions')
  dependent_poll = models.ForeignKey('Poll', related_name='conditions')

  # Q condition(s) on the user's response that must be satisfied for
  # dependent_poll to display
  response_filter = models.CharField(max_length=255)

  # Whether the user is eligible to receive
  # the dependent_poll
  def is_eligible(self, user):
    return Response.objects.filter(
        user=user,
        poll_instance__poll_id=self.determining_poll_id,
      ).filter(
        # TODO make this safe
        eval(self.response_filter)
      ).exists()

  def __unicode__(self):
    return u'"%s" DEPENDS ON "%s": %s' % (self.dependent_poll.question, self.determining_poll.question,
      self.response_filter)


class FeedCondition(BaseModel):
  determining_poll = models.ForeignKey('Poll', blank=True, null=True)
  feed = models.ForeignKey('Feed')

  # Q condition(s) on the user's response that can be satisfied for
  # feed to display
  response_filter = models.CharField(max_length=255, blank=True, null=True, default=None)

  # Q condition(s) on the user that can be satisfied for
  # feed to display
  user_filter = models.CharField(max_length=255, blank=True, null=True, default=None)

  # The primary way to add users to a feed
  allowed_users = models.ManyToManyField('User', blank=True)

  # Whether the user is eligible to receive
  # the feed
  def is_eligible(self, user):
    if self.allowed_users.filter(pk=user.id).exists():
      return True
    if self.determining_poll_id and Response.objects.filter(
          user=user,
          poll_instance__poll_id=self.determining_poll_id,
        ).filter(
          eval(self.response_filter)
        ).exists():
      return True
    if self.user_filter and User.objects.filter(pk=user.id).filter(
          eval(self.user_filter)
        ).exists():
      return True
    return False

  def __unicode__(self):
    return u'"%s" DEPENDS ON "%s": %s' % (
      self.feed, self.determining_poll or self.user_filter,
      self.response_filter)


class PollInstance(models.Model):
  class PROMOTIONS:
    NONE, ACCELERATED, HOT, GLOBALLED, SPONSORED, PINNED, POLL_OF_WEEK = range(7)
    PREVIOUSLY_PINNED, PREVIOUSLY_HOT = (-2, -1)
    CHOICES = (
      (PREVIOUSLY_PINNED, 'Previously Pinned'),
      (PREVIOUSLY_HOT, 'Previously Hot'),
      (NONE, 'None'),
      (ACCELERATED, 'Accelerated'),
      (HOT, 'Hot'),
      (GLOBALLED, 'Globalled'),
      (SPONSORED, 'Sponsored'),
      (PINNED, 'Pinned'),
      (POLL_OF_WEEK, 'Poll of the Week')
    )
  promotion = models.IntegerField(choices=PROMOTIONS.CHOICES, default=PROMOTIONS.NONE, db_index=True)
  
  # For distributing instances
  user_modulus = models.IntegerField(default=1)
  user_modulus_remainder = models.IntegerField(default=0)

  poll = models.ForeignKey('Poll', related_name='instances')
  # Only tracks mobile vote counts for this PollInstance
  # The rest go in PollBreakdowns
  vote_counts = models.TextField()

  user = models.ForeignKey('User')
  user_karma_on_create = models.IntegerField(default=0)
  ip_address = models.GenericIPAddressField(blank=True, null=True, default=None)

  feed = models.ForeignKey(Feed, related_name='poll_instances')

  location = models.PointField(null=True, blank=True)
  # replaces 'location' as a way of filtering for poll instances 
  # at a particular place
  community = models.ForeignKey('University', blank=True, null=True)

  banner = models.CharField(max_length=180, blank=True, null=True, default=None)
  vote_weight = models.FloatField(default=0) # index in Meta
  vote_aggregate = models.IntegerField(default=0) # index handled with vote_weight
  favorite_count = models.IntegerField(default=0) # index handled with vote_weight, vote_aggregate
  comment_count = models.IntegerField(default=0) # index handled with others
  tag_count = models.IntegerField(default=0) # index handled with others

  verified = models.BooleanField(default=False)
  verified_by = models.ForeignKey(User, blank=True, null=True, related_name="poll_instances_verified")
  # Lets some poll instances skip verification
  auto_verified = models.BooleanField(default=False)
  # Need this field to track when a community downvotes a poll off feed
  # TODO rename
  deleted = models.BooleanField(default=False)
  rejected = models.BooleanField(default=False)
  # TODO: change to deleted_by
  deleted_by_admin = models.BooleanField(default=False)
  deleted_by_creator = models.BooleanField(default=False)

  created_date = models.DateTimeField(auto_now_add=True, db_index=True)
  # TODO remove index
  modified_date = models.DateTimeField(auto_now=True, db_index=True)

  # NOTE: new methods in GeoManager:
  # https://docs.djangoproject.com/en/1.8/ref/contrib/gis/geoquerysets/#geoqueryset-methods
  objects = managers.PollInstanceManager()
  sponsored = managers.SponsoredPollInstanceManager()

  def get_vote_total(self):
    return sum(json.loads(self.vote_counts))

  def get_poll_id(self):
    return self.poll_id

  def get_options(self):
    return self.poll.options

  def get_audio_options(self):
    return self.poll.audio_options or None

  def get_question(self):
    return self.poll.question

  def get_question_picture_url(self):
    return self.poll.question_picture_url or None

  def get_auto_censored(self):
    return self.poll.censor_level not in CENSOR_LEVELS.ALLOWED and \
        not self.get_verified() and \
        self.community_id in UNIVERSITY_IDS_WITH_NAME_CENSORSHIP

  def get_deleted(self):
    return self.deleted or self.poll.deleted

  def get_verified(self):
    return self.verified or self.poll.verified

  def get_gender(self):
    return self.poll.gender

  def get_recycle_count(self):
    # Subtract one, since first poll instance counts
    return max(self.poll.recycle_count - 1, 0)

  def add_response(self, response, should_save=True):
    if not response.referrer_id:
      # Mobile vote
      counts = json.loads(self.vote_counts) if self.vote_counts else self.poll.get_default_counts()
      counts[response.response] += 1
      self.vote_counts = json.dumps(counts)
      if should_save:
        self.save()

    self.poll.update_simple_breakdowns(response)

  def __unicode__(self):
    if_deleted = "DELETED INSTANCE: " if self.deleted else ""
    return u"%s(%s) %s" % ( if_deleted, self.feed.name, self.poll, )

  class Meta:
    # Order matters here, e.g. vote_weight can be used alone,
    # {vote_weight, vote_aggregate} can be used in tandem, 
    # but using vote_aggregate alone will not hit this index
    index_together = [
      ['vote_weight', 'vote_aggregate', 'favorite_count', 'comment_count', 'tag_count']
    ]


class SegmenterInstance(PollInstance):
  segmenter = models.ForeignKey('Segmenter')

  objects = managers.SegmenterInstanceManager()

  def get_segment_type(self):
    return self.segmenter.segment_type

class PollBreakdown(BaseModel):

  class TYPES:
    MOBILE, WEB, GENDER, UNIVERSITY, SEGMENT = range(5)
    SIMPLE = {MOBILE, WEB, GENDER}
    CHOICES = (
      # These two are guaranteed to exist for each poll
      (MOBILE, 'Mobile'),
      (WEB, 'Web'),
      # Requires "gender" to be set to 0 or 1
      (GENDER, 'Gender'),
      # Requires "university" to be set
      (UNIVERSITY, 'University'),
      # Requires "segmenter" and "segment_option" to be set
      (SEGMENT, 'Segment')
    )
  breakdown_type = models.IntegerField(choices=TYPES.CHOICES, default=TYPES.MOBILE)

  class PROMOTIONS:
    NONE, DISPARITY, PINNED = range(3)
    CHOICES = (
      (NONE, 'None'),
      (DISPARITY, 'Disparity'),
      (PINNED, 'Pinned')
    )
  promotion = models.IntegerField(choices=PROMOTIONS.CHOICES, default=PROMOTIONS.NONE)

  poll = models.ForeignKey('Poll', related_name="breakdowns")
  gender = models.IntegerField(choices=User.GENDER_CHOICES, default=-1)
  university = models.ForeignKey('University', blank=True, null=True)
  segmenter = models.ForeignKey('Segmenter', blank=True, null=True)
  segment_option = models.IntegerField(default=-1)

  json = models.TextField()
  # Computed on the fly
  total = models.IntegerField(default=0)
  # Largest percent difference from MOBILE breakdown
  significance = models.FloatField(default=0.0)

  @staticmethod
  def description(instance):
    uni, seg, gender = [""] * 3
    if instance.university_id:
      uni = " | {0}".format(instance.university.name)
    if instance.segmenter_id:
      seg = u" | ...{0}".format(instance.segmenter.get_segment_label(instance.segment_option))
    if instance.gender >= 0:
      gender = " | {0}".format(["GUYS", "GIRLS"][instance.gender])
    return u"{0}{1}{2}{3}".format(
        instance.get_breakdown_type_display(),
        gender, uni, seg
      )

  def get_color(self):
    if self.university:
      return self.university.primary_color
    if self.segmenter:
      return self.segmenter.get_segment_color(self.segment_option)
    if self.gender in [0, 1]:
      return GENDER_COLORS[self.gender]
    return None

  def get_locked_cost(self, user):
    if self.university_id and self.university_id == user.university_id:
      return 0

    if self.breakdown_type == PollBreakdown.TYPES.MOBILE:
      return 0

    if self.breakdown_type == PollBreakdown.TYPES.GENDER and user.gender != -1:
      return 0

    if self.poll.user_id == user.id:
      return 0

    # TODO based on rank?
    return 0 # return User.CREDIT_COSTS.UNLOCK_FILTER_POLLS

  # NOTE: Race conditions make this unreliable
  def add_response(self, response, control=None, should_save=True):
    opt_counts = self.get_counts()
    try:
      opt_counts[response.response] += 1
    except IndexError:
      # Catch weird race condition and fix it
      num = len(json.loads(self.poll.options))
      remaining = num - len(opt_counts)
      opt_counts = opt_counts + (remaining*[0])
      opt_counts[response.response] += 1
    self.json = json.dumps(opt_counts)
    if control:
      self.significance = analytics.calc_significance(self, control)
    if should_save:
      self.save()

  def get_counts(self):
    return json.loads(self.json)

  def get_percentages(self):
    opt_counts = self.get_counts()
    total = sum(opt_counts)
    return [
      round(count / float(total or 1), 3)
      for count in opt_counts
    ]

  def __add__(self, other):
    counts = self.get_counts()
    other_counts = json.loads(other.json)
    combined = [a + b for a, b in zip(counts, other_counts)]
    self.json = json.dumps(combined)
    return self

  # This output is structured to allow quick
  # comparison between universities.
  def __unicode__(self):
    total = sum(self.get_counts())
    percents = [int(round(p * 100.0)) for p in self.get_percentages()]
    percentages = "%, ".join(map(str, percents)) + "%"
    promotion = ""
    if self.promotion != PollBreakdown.PROMOTIONS.NONE:
      promotion = " ({})".format(self.get_promotion_display())
    return u"[{}] ({} total) - {{{}}}{}".format(
      percentages, total, PollBreakdown.description(self), promotion
    )

  class Meta:
    ordering = ('breakdown_type', )
    index_together = [
      ['poll', 'breakdown_type', 'gender', 'university', 'segmenter', 'segment_option']
    ]
    unique_together = (
      ('poll', 'breakdown_type', 'gender', 'university', 'segmenter', 'segment_option'),
    )

class PollBreakdownUnlock(BaseModel):
  user = models.ForeignKey('User')
  poll = models.ForeignKey('Poll')
  # TODO add poll_breakdown to do type unlocking preferences

  def __unicode__(self):
    return u"{} - {}".format(
        self.user, self.poll
      )

  class Meta:
    index_together = [
      ['user', 'poll']
    ]
    unique_together = (
      ('user', 'poll'),
    )

# TODO deprecate
class PollBreakdownPreference(BaseModel):
  user = models.ForeignKey('User')
  breakdown_type = models.IntegerField(choices=PollBreakdown.TYPES.CHOICES, default=PollBreakdown.TYPES.MOBILE)
  gender = models.IntegerField(choices=User.GENDER_CHOICES, default=-1)
  segmenter = models.ForeignKey('Segmenter', blank=True, null=True)
  university = models.ForeignKey('University', blank=True, null=True)
  segment_option = models.IntegerField(default=-1)
  disabled = models.BooleanField(default=False)

  def __unicode__(self):
    descriptor_pb = PollBreakdown(
        breakdown_type=self.breakdown_type,
        gender=self.gender,
        university_id=self.university_id,
        segmenter_id=self.segmenter_id,
        segment_option=self.segment_option
      )
    return u"{0}{1} - {2}".format(
        "DISABLED: " if self.disabled else "",
        self.user,
        PollBreakdown.description(descriptor_pb)
      )

  class Meta:
    ordering = ('breakdown_type', )
    index_together = [
      ['user', 'breakdown_type', 'gender', 'segmenter', 'university', 'segment_option']
    ]
    unique_together = (
      ('user', 'breakdown_type', 'gender', 'segmenter', 'university', 'segment_option'),
    )

  # FOR SERIALIZER
  # if PollBreakdownPreference.objects.filter(
  #       breakdown_type=pb.breakdown_type,
  #       user=user,
  #       gender=pb.gender,
  #       segmenter_id=pb.segmenter_id,
  #       segment_option=pb.segment_option,
  #       university_id=pb.university_id
  #     ).exists():
  #   raise serializers.ValidationError("Already unlocked filter type")

  # FOR PREFETCHING
  # breakdowns.annotate(
  #             unlocked=RawSQL("""
  #                 SELECT EXISTS(select 1 FROM whatsgoodly_pollbreakdownpreference
  #                 WHERE whatsgoodly_pollbreakdownpreference.poll_id = whatsgoodly_pollbreakdown.poll_id
  #                   OR (whatsgoodly_pollbreakdownpreference.breakdown_type = whatsgoodly_pollbreakdown.breakdown_type
  #                   AND whatsgoodly_pollbreakdownpreference.gender = whatsgoodly_pollbreakdown.gender
  #                   AND whatsgoodly_pollbreakdownpreference.segment_option = whatsgoodly_pollbreakdown.segment_option
  #                   AND whatsgoodly_pollbreakdownpreference.segmenter_id IS NOT DISTINCT FROM whatsgoodly_pollbreakdown.segmenter_id
  #                   AND whatsgoodly_pollbreakdownpreference.university_id IS NOT DISTINCT FROM whatsgoodly_pollbreakdown.university_id
  #                   AND whatsgoodly_pollbreakdownpreference.user_id = %s))
  #                 """, [user.id])
  #         )

class Referrer(BaseModel):
  host = models.URLField(max_length=200, unique=True)

  def __unicode__(self):
    return u"%s" % (self.host, )


class Response(BaseModel):
  user = models.ForeignKey('User')
  # Index is covered in index_together
  poll_instance = models.ForeignKey('PollInstance', db_index=False)
  response = models.IntegerField()
  referrer = models.ForeignKey('Referrer', blank=True, null=True)
  referring_url = models.URLField(max_length=200, blank=True, null=True)

  location = models.PointField(null=True, blank=True)

  def __unicode__(self):
    if self.referring_url:
      referrer_label = " (via %s)" % self.referring_url
    else:
      referrer_label = ""
    options = json.loads(self.poll_instance.poll.options)
    vote = options[self.response]
    return u"{}: {} [{}]{}".format(
        self.user, self.poll_instance.poll.question,
        vote, referrer_label
      )

  class Meta:
    # Covers poll_instance index
    index_together = [
      ['poll_instance', 'user']
    ]


class Favorite(models.Model):
  user = models.ForeignKey('User')
  poll_instance = models.ForeignKey('PollInstance')

  created_date = models.DateTimeField(auto_now_add=True)
  modified_date = models.DateTimeField(auto_now=True)

  def __unicode__(self):
    return u"%s | %s" % (self.user, self.poll_instance)

  class Meta:
    index_together = [
      ['poll_instance', 'user']
    ]


class PollInstanceRemoval(models.Model):
  user = models.ForeignKey('User')
  poll_instance = models.ForeignKey('PollInstance')
  is_downvote = models.BooleanField(default=False)

  created_date = models.DateTimeField(auto_now_add=True)
  modified_date = models.DateTimeField(auto_now=True)

  def __unicode__(self):
    return u"%s | %s" % (self.user, self.poll_instance)

  class Meta:
    index_together = [
      ['poll_instance', 'user']
    ]


class Comment(BaseModel):
  user = models.ForeignKey(User)
  poll_instance = models.ForeignKey(PollInstance)
  text = models.CharField(max_length=255)
  # Index needed for top comment Prefetch
  vote_aggregate = models.IntegerField(default=0, db_index=True)

  user_karma_on_create = models.IntegerField(default=0)

  censor_level = models.IntegerField(choices=CENSOR_LEVELS.CHOICES, default=CENSOR_LEVELS.NONE)
  deleted = models.BooleanField(default=False)
  deleted_by_creator = models.BooleanField(default=False)
  verified = models.BooleanField(default=False)
  rejected = models.BooleanField(default=False)

  ip_address = models.GenericIPAddressField(blank=True, null=True, default=None)

  def get_auto_censored(self):
    return self.censor_level not in CENSOR_LEVELS.ALLOWED and \
        not self.verified and \
        self.poll_instance.community_id in UNIVERSITY_IDS_WITH_NAME_CENSORSHIP

  def __unicode__(self):
    if_deleted = "DELETED: " if self.deleted else ""
    if_censored = "CENSORED: " if self.get_auto_censored() else ""
    return u"%s%s%s: %s" % (if_censored, if_deleted, self.user, self.text)


class Mention(models.Model):
  user = models.ForeignKey(User)
  comment = models.ForeignKey(Comment)
  handle = models.CharField(max_length=255)
  gender = models.IntegerField()

  created_date = models.DateTimeField(auto_now_add=True)
  modified_date = models.DateTimeField(auto_now=True)

  def __unicode__(self):
    return u"@%s (%s)" % (self.user, self.comment)


class Report(models.Model):
  user = models.ForeignKey('User')

  REPORT_CHOICES = (
    (0, 'This targets someone'),
    (1, 'This is offensive'),
    (2, 'This is spam'),
    (3, 'Other'),
    (4, 'This is no longer relevant')
  )
  report_type = models.IntegerField(choices=REPORT_CHOICES, default=3)

  # Report object shared by poll and comment, so both are optional
  poll_instance = models.ForeignKey(PollInstance, null=True, blank=True)
  comment = models.ForeignKey(Comment, blank=True, null=True)

  created_date = models.DateTimeField(auto_now_add=True)
  modified_date = models.DateTimeField(auto_now=True)

  def __unicode__(self):
    if self.poll_instance:
      return u"%s | %s" % (self.user, self.poll_instance)
    else:
      return u"%s | %s" % (self.user, self.comment)


class CommentVote(models.Model):
  user = models.ForeignKey(User)
  comment = models.ForeignKey(Comment)
  vote = models.IntegerField()

  created_date = models.DateTimeField(auto_now_add=True)
  modified_date = models.DateTimeField(auto_now=True)

  def __unicode__(self):
    return u"%s: %s" % (self.user, self.comment.text)

  class Meta:
    index_together = [
      ['comment', 'user']
    ]


class Friendship(BaseModel):
  user = models.ForeignKey(User)
  friend_name = models.CharField(max_length=180, blank=True, null=True)
  friend_phone_number = models.CharField(max_length=15, db_index=True)

  def get_friend(self):
    return self.friend_accounts().first()

  def friend_accounts(self):
    return User.objects.filter(
        phone_number=self.friend_phone_number
      ).order_by('-id')

  def __unicode__(self):
    return u"%s -> %s" % (self.user, self.friend_name or self.friend_phone_number)

  class Meta:
    unique_together = (
      ('user', 'friend_phone_number'),
    )


class UserRelationship(BaseModel):
  left = models.ForeignKey('User', related_name='forward_relationships')
  right = models.ForeignKey('User', related_name='backward_relationships')

  response_count = models.IntegerField(default=0)
  favorite_count = models.IntegerField(default=0)
  removal_count = models.IntegerField(default=0)
  is_friend = models.BooleanField(default=False)

  @staticmethod
  def add_friendship(friendship):
    users = User.objects.only('pk').filter(
        phone_number__isnull=False,
        phone_number=friendship.friend_phone_number
      )
    for user in users:
      UserRelationship.edges.update_or_create([friendship.user_id, user.id], is_friend=True)

  # TODO these don't account for undoing things
  # @staticmethod
  # def add_favorite(favorite):
  #   users = Favorite.objects.filter(
  #       poll_instance__poll_id=favorite.poll_instance.poll_id
  #     ).values('user')
  #   UserRelationship.edges.filter(
  #       left__in=users, right__in=users
  #     ).update(favorite_count = F('favorite_count') + 1)

  # @staticmethod
  # def add_removal(removal):
  #   users = PollInstanceRemoval.objects.filter(
  #       poll_instance__poll_id=removal.poll_instance.poll_id
  #     ).values('user')
  #   UserRelationship.edges.filter(
  #       left__in=users, right__in=users
  #     ).update(removal_count = F('removal_count') + 1)

  objects = models.Manager()
  edges = managers.EdgeManager()

  def __unicode__(self):
    return u"{0}{1} -> {2}: {3} responses, {4} favorites, {5} removals".format(
        "FRIEND " if self.is_friend else "",
        self.left, self.right, self.response_count,
        self.favorite_count, self.removal_count
      )

  # TODO took up too much space (20 Gigs!)
  # class Meta:
  #   unique_together = (
  #     ('left', 'right'),
  #   )
    # index_together = [
    #   ['left', 'right'],
    #   ['response_count', 'favorite_count', 'removal_count', 'is_friend']
    # ]


class Tag(models.Model):
  friendship = models.ForeignKey(Friendship)
  poll_instance = models.ForeignKey(PollInstance)

  # Whether the tagged user accepted (and saw user's response)
  # or ignored the tag
  accepted=models.BooleanField(default=False)
  ignored=models.BooleanField(default=False)

  # Whether the user saw the tagged user's response
  saw_response=models.BooleanField(default=False)

  created_date = models.DateTimeField(auto_now_add=True)
  modified_date = models.DateTimeField(auto_now=True)

  def get_tagged_name(self):
    return self.friendship.friend_name

  def get_tagged_phone_number(self):
    return self.friendship.friend_phone_number

  # TODO move to serializer and prefetch
  def get_tagger_response(self):
    if not self.accepted:
      return None

    return Response.objects.filter(
        user=self.friendship.user,
        poll_instance=self.poll_instance,
      ).first()

  def get_tagged_user_response(self):
    if not self.accepted:
      return None

    tagged_user_accounts = self.friendship.friend_accounts()
    if not tagged_user_accounts.exists():
      return None

    return Response.objects.filter(
        user__in=tagged_user_accounts,
        poll_instance=self.poll_instance,
      ).order_by('-id').first()

  def __unicode__(self):
    return u"%s: %s" % (self.friendship, self.poll_instance)

  class Meta:
    index_together = [
      ['poll_instance', 'friendship']
    ]
    unique_together = (
      ('friendship', 'poll_instance'),
    )


class Notification(BaseModel):
  user = models.ForeignKey('User')
  poll_instance = models.ForeignKey('PollInstance', blank=True, null=True)
  feed = models.ForeignKey('Feed', blank=True, null=True)
  title = models.CharField(max_length=180)
  body = models.CharField(max_length=180, blank=True, null=True)
  is_read = models.BooleanField(default=False)
  opened_from_push = models.BooleanField(default=False)
  make_poll = models.BooleanField(default=False)

  campaign = models.ForeignKey('NotificationCampaign', blank=True, null=True)

  class TYPES:
    # Note: these labels get used as push notification titles!
    # TODO move to a separate table
    CHOICES = (
      (-1, 'From SVB'),
      (0, 'From Whatsgoodly'),
      (1, 'Poll Results'), # 15 votes
      (2, 'Audience Boost'),
      (3, 'Reply'),
      (4, 'Popular Comment'), # Comment vote
      (5, 'Claim Your Coins!'), # 100 votes
      (6, 'Top Poll'),
      (7, 'Favorite Poll'),
      (8, 'Referral Joined'),
      (9, 'Tag Accepted'),
      (10, 'You\'ve Been Tagged'),
      (11, 'Pinned Poll'),
      (12, 'Fire Poll'),
      (13, 'New Friend'),
      (14, 'Friend Poll'),
      (15, 'US National Poll'),
      (16, 'Significant Filter Notice'),
      (17, 'You\'ve Been Mentioned'),
      (18, 'Poll of the Week'),
      (19, 'Trump Tracker'),
      (20, 'Report Notice'),
    )
    CHOICES_ENFORCING_UNIQUENESS = (1, 2, 5, 6, 7, 11, 12, 13, 14, 15, 16, 18, 19)
    EMOJIS = (
      (-1, u"💡"),
      (0, u"🐶"),
      (1, u"📊"),
      (2, emoji_map["Globe"]),
      (3, emoji_map["Chat bubble"]),
      (4, emoji_map["Thumbs up"]),
      (5, emoji_map["Money bag"]),
      (6, emoji_map["Rocket ship"]),
      (7, emoji_map["Heart"]),
      (8, emoji_map["100 points"]),
      (9, emoji_map["Checkmark green"]),
      (10, emoji_map["Eyes"]),
      (11, emoji_map["Pin"]),
      (12, emoji_map["Fire"]),
      (13, emoji_map["Party Popper"]),
      (14, emoji_map["Party Popper"]),
      (15, emoji_map["US Flag"]),
      (16, u"📈"),
      (17, u"😘"),
      (18, u"🔵"),
      (19, u"👨"),
      (20, u"❗"),
    )
  notification_type = models.IntegerField(choices=TYPES.CHOICES, default=0)

  def get_emoji(self):
    return dict(Notification.TYPES.EMOJIS)[self.notification_type]

  def __unicode__(self):
    suffix = " (READ)" if self.is_read else ""
    suffix += " (OPENED FROM PUSH)" if self.opened_from_push else ""
    return u"{} {}: {} - {}{}".format(
        self.get_emoji(), self.get_notification_type_display(),
        self.title, self.user, suffix
      )

# TODO
# class NotificationGroupPreference(models.Model):
#   notification_type = models.IntegerField(choices=Notification.TYPES.CHOICES, default=Notification.TYPES.CHOICES[0][0])
#   group = models.ForeignKey('Group')
#   probability_of_sending = models.FloatField(default=1.0)

#   created_date = models.DateTimeField(auto_now_add=True)
#   modified_date = models.DateTimeField(auto_now=True)

class Announcement(models.Model):
  class USER_FILTERS:
    NONE, IOS, ANDROID = range(3)
    CHOICES = (
      (NONE, 'None'),
      (IOS, 'iOS'),
      (ANDROID, 'Android')
    )
  user_filter = models.PositiveSmallIntegerField(choices=USER_FILTERS.CHOICES, default=USER_FILTERS.NONE)

  message = models.CharField(max_length=300)
  show_invite_button = models.BooleanField(default=False)
  active = models.BooleanField(default=False)
  location = models.PointField(null=True, blank=True)
  university = models.ForeignKey('University', blank=True, null=True)
  feed = models.ForeignKey(Feed, blank=True, null=True)
  image_url = models.URLField(max_length=200, blank=True, null=True)

  created_date = models.DateTimeField(auto_now_add=True)
  modified_date = models.DateTimeField(auto_now=True)

  class Meta:
    ordering = ('-active', '-id')

  def __unicode__(self):
    feed_name = self.feed.name if self.feed else "No Feed"
    if self.university_id:
      feed_name = self.university.name_short
    activeness = ", INACTIVE" if not self.active else ""
    return u"(%s%s) %s" % ( feed_name, activeness, self.message )

class PushSubscription(models.Model):
  user = models.ForeignKey('User')
  poll_instance = models.ForeignKey('PollInstance', blank=True, null=True)
  disabled = models.BooleanField(default=False)

  created_date = models.DateTimeField(null=True, auto_now_add=True)
  modified_date = models.DateTimeField(null=True, auto_now=True)

  def __unicode__(self):
    return u"{0} - {1}{2}".format(
      self.user, " DISABLED " if self.disabled else "",
      self.poll_instance
    )

  class Meta:
    index_together = [
      ['user', 'poll_instance']
    ]
    unique_together = (
      ('user', 'poll_instance'),
    )

class PollArchetype(models.Model):
  class CAMPUS_LEVELS:
    ALL, EARLY, ESTABLISHED = range(3)
    CHOICES = (
      (ALL, 'All'),
      (EARLY, 'Early'),
      (ESTABLISHED, 'Established')
    )

  age_level = models.IntegerField(choices=Feed.LEVELS.CHOICES, default=Feed.LEVELS.ALL_AGES)
  campus_level = models.IntegerField(choices=CAMPUS_LEVELS.CHOICES, default=CAMPUS_LEVELS.ALL)
  question = models.CharField(max_length=180)
  options = models.TextField()

  disabled = models.BooleanField(default=False)

  created_date = models.DateTimeField(null=True, auto_now_add=True)
  modified_date = models.DateTimeField(null=True, auto_now=True)

  objects = models.Manager()
  suggested = managers.SuggestionManager()

  def __unicode__(self):
    opts = json.loads(self.options)
    return u"({}, {} campuses) {} [{}]".format(
      self.get_age_level_display(),
      self.get_campus_level_display(),
      self.question,
      ", ".join(opts)
    )

  class Meta:
    index_together = [
      ['age_level', 'campus_level']
    ]

class PollTag(BaseModel):
  parent = models.ForeignKey('PollTag', blank=True, null=True)
  label_lower = models.CharField(max_length=180, unique=True, db_index=True)
  flag_terms = models.TextField(blank=True, null=True, default=None)

  def get_category(self):
    root = self
    while root.parent: root = root.parent
    return root.label_lower

  def __unicode__(self):
    if not self.parent_id:
      return self.label_lower.capitalize()
      
    return u"{} -> #{}".format(
      self.parent, self.label_lower
    )

  class Meta:
    ordering = ('label_lower', )

class SearchQuery(BaseModel):
  query = models.TextField(db_index=True)
  user = models.ForeignKey('User')
  count = models.IntegerField(default=0)

  def __unicode__(self):
    return u"{} searched for \"{}\" {} times".format(
      self.user, self.query, self.count)

# TODO move elsewhere

class Account(BaseModel):
  name = models.CharField(max_length=180)
  name_url = models.CharField(max_length=180, unique=True, db_index=True)
  is_public = models.BooleanField(default=False)
  disable_library = models.BooleanField(default=False)
  subscribed_tags = models.ManyToManyField('PollTag', blank=True)
  subscribed_breakdowns = models.ManyToManyField('Segmenter', blank=True, related_name="subscribed_accounts")

  def __unicode__(self):
    return self.name

  class Meta:
    ordering = ('name_url', )

class Survey(BaseModel):
  name = models.CharField(max_length=180)
  name_url = models.CharField(max_length=180, db_index=True, blank=True, null=True)
  description = models.TextField(blank=True)
  user = models.ForeignKey('User')
  account = models.ForeignKey('Account', blank=True, null=True)
  population_size = models.IntegerField(default=MILLENNIALS_IN_US)
  # TODO feed = models.ForeignKey('Feed', blank=True, null=True)
  polls = models.ManyToManyField('Poll', blank=True, limit_choices_to=Q(deleted=False))
  allowed_breakdowns = models.ManyToManyField('Segmenter', blank=True, related_name="segmented_surveys")

  class TIMELINE_SETTINGS:
    NONE, DAY, WEEK, MONTH = range(4)
    POLL_DEFAULT = WEEK
    CHOICES = (
      (NONE, 'None'),
      (DAY, 'Daily'),
      (WEEK, 'Weekly'),
      (MONTH, 'Monthly')
    )
  timeline_setting = models.IntegerField(choices=TIMELINE_SETTINGS.CHOICES, default=TIMELINE_SETTINGS.NONE)

  class MAP_SETTINGS:
    NONE = 0
    CHOICES = (
      (NONE, 'None'),
    )
  map_setting = models.IntegerField(choices=MAP_SETTINGS.CHOICES, default=MAP_SETTINGS.NONE)

  def __unicode__(self):
    return u"Survey \"{}\"{}".format(
      self.name,
      " ({})".format(self.account) if self.account else ""
    )

class NotificationCampaign(BaseModel):
  name = models.CharField(max_length=180)
  notification_type = models.IntegerField(choices=Notification.TYPES.CHOICES, default=0)
  account = models.ForeignKey('Account', blank=True, null=True)

  class CUSTOMIZATIONS:
    NONE, PREFIX_UNIVERSITY, SUFFIX_UNIVERSITY = range(3)
    CHOICES = (
      (NONE, 'None'),
      (PREFIX_UNIVERSITY, 'University as prefix'),
      (SUFFIX_UNIVERSITY, 'University as suffix')
    )
  customization = models.IntegerField(choices=CUSTOMIZATIONS.CHOICES, default=CUSTOMIZATIONS.NONE)

  determining_poll = models.ForeignKey('Poll', blank=True, null=True)

  # Q condition(s) on the user's response that must be satisfied for
  # push to send
  response_filter = models.CharField(max_length=255, blank=True)

  # Q condition(s) on the user that must be satisfied for
  # feed to display
  user_filter = models.CharField(max_length=255, blank=True)

  active_in_last_days = models.IntegerField(default=0)

  def get_open_rate(self):
    notifs = self.notification_set.all()
    received_count = User.objects.reachable().filter(notification__in=notifs).count()
    read_count = notifs.filter(is_read=True).count()
    ratio = read_count / float(received_count or 1)
    return ratio, received_count

  # Mutates notif_attrs
  def customize(self, user, notif_attrs):
    title = notif_attrs['title']

    if self.customization == NotificationCampaign.CUSTOMIZATIONS.PREFIX_UNIVERSITY:
      notif_attrs['title'] = user.university.name_short + ' ' + title

    elif self.customization == NotificationCampaign.CUSTOMIZATIONS.SUFFIX_UNIVERSITY:
      notif_attrs['title'] = title + ' ' + user.university.name_short

  # Get the eligible users for the push
  def eligible_users(self, queryset=None):
    if queryset is None:
      queryset = User.objects.all()

    if self.user_filter:

      queryset = queryset.filter(eval(self.user_filter))

    if self.determining_poll_id:

      user_ids = Response.objects.filter(
          poll_instance__poll_id=self.determining_poll_id
        ).filter(
          eval(self.response_filter)
        ).values('user_id').distinct()
      queryset = queryset.filter(id__in=user_ids)

    if self.active_in_last_days > 0:

      time_ago = datetime.now() - timedelta(days=self.active_in_last_days)
      active_ids = Response.objects.filter(
          created_date__gte=time_ago
        ).values('user_id').distinct()
      queryset = queryset.filter(id__in=active_ids)

    return queryset

  # TODO: this does two count queries whenever shown in list view
  def __unicode__(self):
    ratio, received_count = self.get_open_rate()
    open_percent = int(round(ratio*100.0))
    read_count = int(ratio * received_count)

    # targeting = ""
    # if self.determining_poll:
    #   targeting += u" -> [{}: {}]".format(self.determining_poll, self.response_filter)
    # if self.user_filter:
    #   targeting += u" -> {}".format(self.user_filter)

    return u'"{}"{} | {} read, open rate: {}%'.format(
      self.name,
      " ({})".format(self.account) if self.account else "",
      read_count,
      open_percent
    )

# class SlackLogEntry(BaseModel):
#   slack_username = models.CharField(max_length=180)
#   content_type = models.ForeignKey('ContentType')
#   object_id = models.IntegerField()
#   object_repr = models.CharField(max_length=200)
#   action = models.IntegerField()

# IMPORT RECEIVERS
# Signals for models proceed their definitions
from whatsgoodly.signals import *
