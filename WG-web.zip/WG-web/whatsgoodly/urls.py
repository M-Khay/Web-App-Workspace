from django.conf.urls import include, url
from django.contrib import admin, auth
from django.conf import settings
from whatsgoodly.views import *

if settings.SILK_ENABLED:
    profiling_pattern = include('silk.urls', namespace='silk')
else:
    profiling_pattern = 'django.views.defaults.page_not_found'

urlpatterns = [
    url(r'^$', index, name='index'),

    # Static pages
    url(r'^campusrep/new/$', campusrep, name='campusrep'),
    url(r'^sales/contact/$', contact_sales, name='contact_sales'),
    url(r'^search_polls/$', search_safe_polls, name='search'),
    url(r'^search_polls/only_count/$', search_safe_polls, {'only_count': True}),
    url(r'^founders/$', static_page, {'page_slug': "founders"}),
    url(r'^login/$', static_page, {'page_slug': "login"}),
    url(r'^privacy/$', static_page, {'page_slug': "privacy"}),
    url(r'^support/$', static_page, {'page_slug': "support"}),
    url(r'^team/$', static_page, {'page_slug': "team"}),
    url(r'^terms/$', static_page, {'page_slug': "terms"}),
    url(r'^writers/$', static_page, {'page_slug': "writers"}),

    url(r'^esuohgod/', include(admin.site.urls)),
    url(r'^silk/', profiling_pattern),

    url(r'^accounts/login/$', 'django.contrib.auth.views.login', {'template_name': 'whatsgoodly/login.html'}, name='login'),
    url(r'^accounts/logout/$', 'django.contrib.auth.views.logout', {'template_name': 'whatsgoodly/login.html'}, name='logout'),
    # TODO
    # url(r'^accounts/password_reset/$', 'django.contrib.auth.views.password_reset', {'template_name': 'whatsgoodly/login.html'}, name='password_reset'),
    # url(r'^accounts/password_reset/done/$', 'django.contrib.auth.views.password_reset_done', {'template_name': 'whatsgoodly/login.html'}, name='password_reset_done'),
    # url(r'^accounts/reset/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$', 'django.contrib.auth.views.password_reset_confirm', {'template_name': 'whatsgoodly/login.html'}, name='password_reset_confirm'),
    # url(r'^accounts/reset/done/$', 'django.contrib.auth.views.password_reset_complete', {'template_name': 'whatsgoodly/login.html'}, name='password_reset_complete'),

    url(r'^api/v1/', include('api.urls_v1')),
    url(r'^api/v2/', include('api.urls_v2')),
    url(r'^api/v3/', include('api.urls_v3')),
    
    url(r'^dashboard/', include('dashboard.urls')),
    url(r'^webhooks/', include('webhooks.urls')),

    url(r'^apps/(?P<name>[0-9a-z]+)', download_app, name='download_app'),

    # Elastic Search pages
    url(r'^search-4k8sd9/$', insights_library, name='insights_library'),
    url(r'^brand/(?P<account_name>[0-9a-z]+)/$', account_insights_library, name='brand_search'),
    url(r'^search/proxy/$', proxy_es_search, name='proxy_es_search'),

    # Embeddable (for surveys to vote on, see Account pages)
    url(r'^poll/(?P<poll_pk>[0-9]+)/$', poll, name='poll'),

    # Survey Reports
    url(r'^survey/(?P<pk>[0-9]+)/$', survey, name='survey'),
    url(r'^survey/(?P<pk>[0-9]+)/update/$', update_survey, name='update_survey'),
    # url(r'^report/(?P<pk>[0-9]+)/$', survey, name='report'),
    url(r'^survey/(?P<pk>[0-9]+)/export/$', export_survey_csv, name='export_survey_csv'),
    # url(r'^report/(?P<pk>[0-9]+)/export/$', export_survey_csv, name='export_report_csv'),
    url(r'^survey/(?P<survey_pk>[0-9]+)/poll/(?P<poll_pk>[0-9]+)/$', survey_poll_breakdowns, name='survey_poll_breakdowns'),
    # url(r'^report/(?P<survey_pk>[0-9]+)/poll/(?P<poll_pk>[0-9]+)/$', survey_poll_breakdowns, name='report_poll_breakdowns'),
    url(r'^survey/add/(?P<poll_pk>[0-9]+)/$', add_poll_to_survey, name='add_poll_to_report'),

    # Timelines
    url(r'^survey/(?P<survey_pk>[0-9]+)/timeline/$', survey_timeline, name='survey_timeline'),
    url(r'^poll/(?P<poll_pk>[0-9]+)/timeline/$', poll_timeline, name='poll_timeline'),

    # Account pages
    url(r'^(?P<account_name>[0-9a-z]+)/$', account_dashboard, name='account_dashboard'),
    url(r'^(?P<account_name>[0-9a-z]+)/library/$', account_insights_library, name='account_insights_library'),
    url(r'^(?P<account_name>[0-9a-z]+)/survey/(?P<survey_identifier>[0-9a-z]+)/$', account_survey, name='account_survey'),
]
