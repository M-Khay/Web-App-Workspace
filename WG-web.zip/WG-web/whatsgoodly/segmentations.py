# -*- coding: utf-8 -*-

########################################
# START OF TYPES REFERENCED BY BACKEND
########################################

class NoneType:
    ID = 0
    DISPLAY_NAME = 'Custom'

class AgeLevel:
    ID = 1
    DISPLAY_NAME = 'Age'
    HIGH_SCHOOL, COLLEGE, POST_GRAD, GRAD_SCHOOL, OTHER = range(5)
    QUESTION = "I'm in?"
    CHOICES = (
        (HIGH_SCHOOL, "High School"),
        (COLLEGE, "College"),
        (POST_GRAD, "Post-grad"),
        (GRAD_SCHOOL, "Grad School"),
        (OTHER, "Other")
    )

class Gender:
    ID = 2
    DISPLAY_NAME = 'Gender'
    MALE, FEMALE = range(2)
    QUESTION = "What's your gender?"
    CHOICES = (
        (MALE, "Male"),
        (FEMALE, "Female")
    )

class PushNotifications:
    ID = 3
    DISPLAY_NAME = 'Push Notifications'
    YES, NO = range(2)
    QUESTION = "Do you want to be push-notified when a friend invites you to a poll?"
    CHOICES = (
        (YES, "Yes!"),
        (NO, "No")
    )

########################################
# END OF TYPES REFERENCED BY FRONTEND
########################################

class Greek:
    ID = 4
    DISPLAY_NAME = 'Greek Life'
    YES, REGRETTING, NO, WISH = range(4)
    QUESTION = "Are you in Greek life?"
    EXCLUDED_FROM_FILTERS = [REGRETTING, WISH]
    class CONDITION:
        SEGMENT_TYPE = AgeLevel.ID
        RESPONSE_FILTER = "Q(response={0})".format(AgeLevel.COLLEGE)
    CHOICES = (
        (YES, "Yes!"),
        (REGRETTING, "Yes but regretting it"),
        (NO, "No!"),
        (WISH, "No but I wanna be...")
    )

class Politics:
    ID = 5
    DISPLAY_NAME = 'Politics'
    CONSERVATIVE, LIBERAL, IN_BETWEEN = range(3)
    QUESTION = "What's your leaning?"
    CHOICES = (
        (CONSERVATIVE, "Conservative 🐘"),
        (LIBERAL, "Liberal 🔷"),
        (IN_BETWEEN, "In-between")
    )

class Race:
    ID = 6
    DISPLAY_NAME = 'Race'
    BLACK, WHITE, HISPANIC, ASIAN, NATIVE_AMERICAN, OTHER = range(6)
    QUESTION = "What do you most closely identify as?"
    CHOICES = (
        (BLACK, "Black 👍🏿"),
        (WHITE, "White 👍🏻"),
        (HISPANIC, "Hispanic 👍🏽"),
        (ASIAN, "Asian 👍🏼"),
        (NATIVE_AMERICAN, "Native American 👍🏾"),
        (OTHER, "Other")
    )

class GradePointAverage:
    ID = 7
    DISPLAY_NAME = 'GPA'
    BELOW_1, BELOW_2, BELOW_3, BELOW_4, ABOVE_4 = range(5)
    QUESTION = "What's your GPA?"
    CHOICES = (
        (BELOW_1, "Below 1.0 😁"),
        (BELOW_2, "1.0 to 2.0"),
        (BELOW_3, "2.0 to 3.0"),
        (BELOW_4, "3.0 to 4.0"),
        (ABOVE_4, "Above 4.0 😏"),
    )

class CommunityService:
    ID = 8
    DISPLAY_NAME = 'Community Service'
    NONE, LESS_THAN_HOUR, HOUR, HOUR_10, ABOVE_10 = range(5)
    QUESTION = "How much community service do you do per month?"
    CHOICES = (
        (NONE, "Realistically, none"),
        (LESS_THAN_HOUR, "Less than an hour"),
        (HOUR, "About 1 hour"),
        (HOUR_10, "1 to 10 hours"),
        (ABOVE_10, "More than 10 hours 😇")
    )
    EXCLUDE_FROM_LOCAL = True

class Leadership:
    ID = 9
    DISPLAY_NAME = 'Leadership'
    NONE, ONE_MINOR, ONE_MAJOR, ABOVE_1 = range(4)
    QUESTION = "Are you currently the leader of any clubs / organizations?"
    CHOICES = (
        (NONE, "No"),
        (ONE_MINOR, "A minor one"),
        (ONE_MAJOR, "A major one"),
        (ABOVE_1, "More than one major org")
    )

class Employment:
    ID = 10
    DISPLAY_NAME = 'Employment'
    FULLTIME, PARTTIME, SEARCHING, NO = range(4)
    QUESTION = "Do you currently have a job?"
    CHOICES = (
        (FULLTIME, "Yes, full-time"),
        (PARTTIME, "Yes, part-time"),
        (SEARCHING, "No, but I'm searching for one"),
        (NO, "Nope, and not looking for one")
    )

class DegreeType:
    ID = 11
    DISPLAY_NAME = 'Degree Type'
    TECHY, FUZZY, UNDECIDED = range(3)
    QUESTION = "What kind of degree are you pursuing?"
    class CONDITION:
        SEGMENT_TYPE = AgeLevel.ID
        RESPONSE_FILTER = "Q(response__gte={0})".format(AgeLevel.COLLEGE)
    CHOICES = (
        (TECHY, "Technical / engineering"),
        (FUZZY, "Humanities"),
        (UNDECIDED, "Undecided")
    )

class TechyMajor:
    ID = 12
    DISPLAY_NAME = 'Techy Major'
    COMP_SCI, ENG, PRE_MED, ECON, OTHER = range(5)
    QUESTION = "What's your major?"
    class CONDITION:
        SEGMENT_TYPE = DegreeType.ID
        RESPONSE_FILTER = "Q(response={0})".format(DegreeType.TECHY)
    CHOICES = (
        (COMP_SCI, "Comp sci"),
        (ENG, "ME/EE/other engineer"),
        (PRE_MED, "Pre-med"),
        (ECON, "Business/Econ/Finance"),
        (OTHER, "Other"),
    )

class FuzzyMajor:
    ID = 13
    DISPLAY_NAME = 'Fuzzy Major'
    POLISCI, COMM, HISTORY, ART, LANGUAGES, OTHER = range(6)
    QUESTION = "What's your major?"
    class CONDITION:
        SEGMENT_TYPE = DegreeType.ID
        RESPONSE_FILTER = "Q(response={0})".format(DegreeType.FUZZY)
    CHOICES = (
        (POLISCI, "Political science / philosophy"),
        (COMM, "Comm / marketing"),
        (HISTORY, "History"),
        (ART, "Visual/performing arts"),
        (LANGUAGES, "Languages"),
        (OTHER, "Other")
    )

class SocioEconomic:
    ID = 14
    DISPLAY_NAME = 'Socio-economic'
    POOR, LOWER, UPPER_MIDDLE, UPPER = range(4)
    QUESTION = "How much do your parents make?"
    CHOICES = (
        (POOR, "Poor (< ~$50K) 😁"),
        (LOWER, "Middle / lower-middle class (~$90K)"),
        (UPPER_MIDDLE, "Upper-middle class (~$160K"),
        (UPPER, "Upper class (> $240K)"),
    )
    OPTION_LABELS = (
        (POOR, "Poor"),
        (LOWER, "Blue collar"),
        (UPPER_MIDDLE, "Middle class"),
        (UPPER, "Rich"),
    )
    EXCLUDE_FROM_LOCAL = True

class StudentDebt:
    ID = 15
    DISPLAY_NAME = 'Student Debt'
    YES, NO = range(2)
    QUESTION = "Do you have student debt?"
    CHOICES = (
        (YES, "Yes"),
        (NO, "No")
    )

class Computer:
    ID = 16
    DISPLAY_NAME = 'Computer'
    PC, MAC, OTHER = range(3)
    QUESTION = "What's better, Mac or PC?"
    CHOICES = (
        (PC, "PC 💻"),
        (MAC, "Mac 🖥"),
        (OTHER, "Other 🐧")
    )
    OPTION_LABELS = (
        (PC, "PC fan"),
        (MAC, "Mac fan"),
        (OTHER, "Geek")
    )

class Virgin:
    ID = 17
    DISPLAY_NAME = 'Virgin'
    YES, NO = range(2)
    QUESTION = "Are you a virgin?"
    CHOICES = (
        (YES, "Yes"),
        (NO, "No")
    )
    OPTION_LABELS = (
        (YES, "Virgin"),
        (NO, "Non-virgin")
    )

class SchoolYear:
    ID = 18
    DISPLAY_NAME = 'Graduation Year'
    FRESHMAN, SOPHOMORE, JUNIOR, SENIOR = range(4)
    QUESTION = "When are you planning on graduating?"
    class CONDITION:
        SEGMENT_TYPE = AgeLevel.ID
        RESPONSE_FILTER = "Q(response__lte={0})".format(AgeLevel.COLLEGE)
    CHOICES = (
        (FRESHMAN, "2020"),
        (SOPHOMORE, "2019"),
        (JUNIOR, "2018"),
        (SENIOR, "2017")
    )
    OPTION_LABELS = (
        (FRESHMAN, "Freshmen"),
        (SOPHOMORE, "Sophomore"),
        (JUNIOR, "Junior"),
        (SENIOR, "Senior")
    )

ENABLED = (
    NoneType,
    AgeLevel,
    # Gender,
    PushNotifications,
    Greek,
    Politics,
    Race,
    GradePointAverage,
    CommunityService,
    Leadership,
    Employment,
    DegreeType,
    TechyMajor,
    FuzzyMajor,
    SocioEconomic,
    StudentDebt,
    Computer,
    Virgin,
    SchoolYear
)

IDENTIFIERS = [(klass.ID, klass) for klass in ENABLED]

CHOICES = [(klass.ID, klass.DISPLAY_NAME) for klass in ENABLED]

