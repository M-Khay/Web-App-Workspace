from django.conf import settings
from django.db.models.signals import post_save, pre_save, post_delete, m2m_changed
from django.db.models import Q
from django.utils import timezone
from django.dispatch import receiver
from django.core.exceptions import FieldError
from rest_framework.authtoken.models import Token
from api import tasks, notifications
from api.utils import send_slack_message
from api.slackbots import Gupta
from datetime import timedelta
from whatsgoodly import analytics, broadcaster
from whatsgoodly.models import *
import json

MAX_CHARS_IN_PHONE_NUMBER = 15
MAX_CHARS_IN_NAME = 175
MAX_CHARS_IN_URL = 195
GIRLS_ONLY_VOTE_WEIGHT = 1.8
GUYS_ONLY_VOTE_WEIGHT = 1.4

POLI_QUESTION = "Who are you voting for?"

# PRE-SAVE

@receiver(pre_save, sender=PollInstance)
def poll_instance_will_save(sender, instance=None, **kwargs):
    if instance.pk:
        return

    if instance.user_karma_on_create == 0:
        instance.user_karma_on_create = instance.user.karma

    if not instance.vote_counts:
        instance.vote_counts = json.dumps(instance.poll.get_default_counts())

@receiver(pre_save, sender=Comment)
def comment_will_save(sender, instance=None, **kwargs):
    if instance.user_karma_on_create == 0:
        instance.user_karma_on_create = instance.user.karma

@receiver(pre_save, sender=Friendship)
def friendship_will_save(sender, instance=None, **kwargs):
    if instance.friend_name:
        instance.friend_name = instance.friend_name[:MAX_CHARS_IN_NAME]
    if instance.friend_phone_number:
        instance.friend_phone_number = instance.friend_phone_number[:MAX_CHARS_IN_PHONE_NUMBER]

@receiver(pre_save, sender=User)
def user_will_save(sender, instance=None, **kwargs):
    if instance.full_name:
        instance.full_name = instance.full_name[:MAX_CHARS_IN_NAME]

@receiver(pre_save, sender=Referrer)
def referrer_will_save(sender, instance=None, **kwargs):
    if instance.host:
        instance.host = instance.host[:MAX_CHARS_IN_URL]

@receiver(pre_save, sender=Response)
def response_will_save(sender, instance=None, **kwargs):
    if instance.referring_url:
        instance.referring_url = instance.referring_url[:MAX_CHARS_IN_URL]

@receiver(pre_save, sender=PollBreakdown)
def poll_breakdown_will_save(sender, instance=None, **kwargs):
    if not instance.json:
        instance.json = json.dumps(instance.poll.get_default_counts())

    if instance.breakdown_type == PollBreakdown.TYPES.UNIVERSITY and \
            not instance.university_id:
        raise FieldError('University type set but no university specified')

    if instance.breakdown_type == PollBreakdown.TYPES.GENDER and \
            instance.gender < 0:
        raise FieldError('Gender type set but no gender specified')

    if instance.breakdown_type == PollBreakdown.TYPES.GENDER and \
            instance.poll.gender != Poll.GENDERS.ALL:
        raise FieldError('Can\'t do gender breakdowns for a gender-specific poll')

    if instance.breakdown_type == PollBreakdown.TYPES.SEGMENT and \
            not (instance.segmenter_id and instance.segment_option >= 0):
        raise FieldError('Segment type set but invalid segment')

    # Ensure total is up to date
    instance.total = sum(json.loads(instance.json))

# POST-SAVE

@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def user_did_save(sender, instance=None, created=False, **kwargs):
    if created:
        Token.objects.create(user=instance)
        return

    did_reward = getattr(instance, '_rewarded', False)

    # Check for rank-up reward
    thresholds = [v for k, v in User.KARMA_THRESHOLDS[1:]]
    if instance.karma in thresholds and not did_reward:
        rank_index = thresholds.index(instance.karma) + 1
        instance.credits += User.CREDIT_REWARDS.RANK_UP_PER_RANK * rank_index
        instance._rewarded = True
        instance.save()

        if instance.karma == thresholds[-1]:
            slack_message = "User {0}{1} became a Top Doggy!".format(
                instance.id,
                " at {0}".format(instance.university.name) if instance.university_id else ""
            )
            send_slack_message(slack_message, event_name="New Superuser", emoji=":crown:")

@receiver(post_save, sender=UserMerger)
def user_merger_did_save(sender, instance=None, created=False, **kwargs):
    if not created:
        return

    user = instance.user
    transfer = instance.merged_user
    user.karma += transfer.karma
    user.credits += transfer.credits
    if transfer.email and not user.email:
        user.email = transfer.email
    user.save()
    # Copy all responses to new user
    transferred_responses = Response.objects.filter(user=transfer)
    for res in transferred_responses:
        res.pk = None
        res.user = user
    Response.objects.bulk_create(transferred_responses)

@receiver(post_save, sender=Tag)
def tag_did_save(sender, instance=None, created=False, **kwargs):
    if created:
        user = instance.friendship.user
        user.karma += 1
        user.credits += User.CREDIT_REWARDS.TAG_CONTACT
        user.save()

        poll_instance = instance.poll_instance
        poll_instance.tag_count += 1
        poll_instance.save(update_fields=['tag_count'])

        # TODO
        # notifications.check_tag_notification(instance)
        
    elif instance.accepted and not instance.saw_response:
        notifications.accepted_tag_notification(instance)

@receiver(post_save, sender=Response)
def response_did_save(sender, instance=None, created=False, **kwargs):
    analytics.periodic_tasks(response_id=instance.id)

    if not created:
        return

    poll_instance = instance.poll_instance
    poll_instance.add_response(instance, should_save=False)
    # UserRelationship.add_response(instance) Can't do this, the update causes deadlock

    # Update weighted vote count (poll_instance.vote_weight)
    vote_count = poll_instance.get_vote_total()
    if poll_instance.poll.gender == Poll.GENDERS.GIRLS:
      poll_instance.vote_weight = vote_count * GIRLS_ONLY_VOTE_WEIGHT
    elif poll_instance.poll.gender == Poll.GENDERS.GUYS:
      poll_instance.vote_weight = vote_count * GUYS_ONLY_VOTE_WEIGHT
    else:
      poll_instance.vote_weight = vote_count

    # Commit changes
    poll_instance.save()

    if instance.user_id != poll_instance.user_id:
        notifications.check_poll_notification(poll_instance)

    instance.user.karma += 1
    instance.user.credits += User.CREDIT_REWARDS.VOTE
    instance.user.save(update_fields=["karma", "credits"])
    broadcaster.broadcast_poll_instance_response(instance)


@receiver(post_save, sender=Comment)
def comment_did_save(sender, instance=None, created=False, **kwargs):
    poll_instance = instance.poll_instance

    if instance.deleted:
        poll_instance.comment_count -= 1
    elif created:
        poll_instance.comment_count += 1
    poll_instance.save(update_fields=['comment_count'])

    if not created:
        return

    # This won't re-enable if disabled
    PushSubscription.objects.get_or_create(
        poll_instance=poll_instance,
        user_id=instance.user_id
    )

    if (instance.user_id != poll_instance.user_id and
            poll_instance.user_id == poll_instance.poll.user_id):
        poll_instance.user.karma += 1
        poll_instance.user.save(update_fields=['karma'])
        
    broadcaster.broadcast_comment(instance)


@receiver(post_save, sender=Mention)
def mention_did_save(sender, instance=None, created=False, **kwargs):
    if not created:
        return

    notifications.check_mention_notification(instance)


# @receiver(post_save, sender=Friendship)
# def friendship_did_save(sender, instance=None, created=False, **kwargs):
#     if not created:
#         return

#     UserRelationship.add_friendship(instance)


@receiver(post_save, sender=Favorite)
def favorite_did_save(sender, instance=None, created=False, **kwargs):
    if not created:
        return

    poll_instance = instance.poll_instance
    poll_instance.favorite_count += 1
    poll_instance.vote_aggregate += 1
    if poll_instance.get_deleted() and poll_instance.vote_aggregate > -5:
        poll_instance.deleted = False
    poll_instance.save()
    # UserRelationship.add_favorite(instance)

    if (instance.user_id != poll_instance.user_id and
            poll_instance.user_id == poll_instance.poll.user_id):
        poll_instance.user.credits += User.CREDIT_REWARDS.GET_FAVORITED
        poll_instance.user.save(update_fields=['credits'])
        notifications.check_favorite_notification(instance)


@receiver(post_save, sender=PollInstanceRemoval)
def removal_did_save(sender, instance=None, created=False, **kwargs):
    if not created:
        return

    # UserRelationship.add_removal(instance)

    if instance.is_downvote:
        poll_instance = instance.poll_instance
        poll_instance.vote_aggregate -= 1
        if not poll_instance.get_deleted() and not poll_instance.get_verified() and \
                poll_instance.vote_aggregate <= -8:
            poll_instance.deleted = True
        poll_instance.save()


@receiver(post_save, sender=Report)
def report_did_save(sender, instance=None, created=False, **kwargs):
    if not created:
        return

    comment = instance.comment
    poll_instance = instance.poll_instance

    if comment and not comment.deleted and not comment.verified:
      reports = Report.objects.filter(comment=comment)
      if reports.count() >= 5:
        comment.deleted = True
        comment.save()

    if poll_instance and not poll_instance.get_deleted() and not poll_instance.get_verified():
      reports = Report.objects.filter(poll_instance=poll_instance)
      if reports.count() >= 5:
        poll_instance.deleted = True
        poll_instance.save()


@receiver(post_save, sender=CommentVote)
def comment_vote_did_save(sender, instance=None, created=False, **kwargs):
    if not created:
        return
    comment = instance.comment
    user = instance.user

    old_vote = CommentVote.objects.filter(comment=comment, user=user).exclude(pk=instance.pk)
    if old_vote.count() > 0:
        old_vote = old_vote.first()
        if old_vote.vote == 0:
            comment.vote_aggregate += 1
        elif old_vote.vote == 1:
            comment.vote_aggregate -= 1
        old_vote.delete()

    if instance.vote == 0:
        comment.vote_aggregate -= 1
        # user.karma -= 1
    else:
        comment.vote_aggregate += 1
        # user.karma += 1
    comment.save()
    # user.save()

    notifications.check_comment_vote_notification(instance)
    broadcaster.broadcast_comment_vote(instance)

@receiver(post_save, sender=PollInstance)
def poll_instance_did_save(sender, instance=None, created=False, **kwargs):
    update_fields = kwargs['update_fields']
    if created:
        if instance.user_id == instance.poll.user_id:
            instance.user.karma += 20
            instance.user.credits += User.CREDIT_REWARDS.POST_POLL
            instance.user.save()

        instance.poll.recycle_count += 1
        instance.poll.save(update_fields=['recycle_count'])
            
        if instance.location:
            broadcaster.broadcast_poll_instance_nearby(instance)
            # TODO notifications.friend_poll_notification(instance, "Your friend posted a poll near you")
        # if instance.verified or instance.auto_verified:
        #     broadcaster.broadcast_poll_instance(instance)

        PushSubscription.objects.get_or_create(
            poll_instance=instance,
            user_id=instance.user_id
        )

        # Inflate_vote_counts checkes these attributes, so this is just a 
        # celery optimization
        if not instance.feed.approve_posts and \
                not instance.get_auto_censored():
            tasks.inflate_vote_counts.apply_async(args=[instance.id], countdown=3600)

    elif not update_fields:
        # Omit if only a minor field is being updated
        check_poll_instance_for_promotion(instance)

@receiver(post_save, sender=PollBreakdown)
def poll_breakdown_did_save(sender, instance=None, created=False, **kwargs):

    # Check for promotions!
    admin_id = dict(settings.ADMIN_IDS).get('Whatsgoodly')

    if instance.promotion != PollBreakdown.PROMOTIONS.NONE:
        return

    if instance.total < analytics.MIN_SAMPLE_SIZE or \
            instance.significance < analytics.MIN_SIGNIFICANCE * 2:
        return

    if instance.poll.user_id == admin_id:
        return

    try:
        if instance.poll.segmenter:
            return
    except Segmenter.DoesNotExist:
        pass

    if instance.breakdown_type == PollBreakdown.TYPES.GENDER and \
            instance.gender == 1:
            # only do this when the second breakdown is done saving

        title = "GENDER: large disparity"
        gender_bdowns = instance.poll.breakdowns.filter(breakdown_type=PollBreakdown.TYPES.GENDER)
        body = "\n".join([str(pb) for pb in gender_bdowns])
        Gupta(poll=instance.poll).promote(body, title=title)
        gender_bdowns.update(promotion=PollBreakdown.PROMOTIONS.DISPARITY)

        # TODO reenable when singleton poll bug is fixed
        # notifications.promoted_breakdown_notification(instance.poll, title="Guys & girls divided")

    elif instance.segmenter and instance.segmenter.question == POLI_QUESTION and \
            instance.segment_option == 1:

        title = "POLITICS: large disparity"
        poli_bdowns = instance.poll.breakdowns.filter(segmenter__question=POLI_QUESTION)
        body = "\n".join([str(pb) for pb in poli_bdowns[:2]])
        Gupta(poll=instance.poll).promote(body, title=title, is_political=True)
        poli_bdowns.update(promotion=PollBreakdown.PROMOTIONS.DISPARITY)

        # TODO reenable when singleton poll bug is fixed
        # notifications.promoted_breakdown_notification(instance.poll, title="Political divide")

@receiver(post_save, sender=Poll)
def poll_did_save(sender, instance=None, created=False, **kwargs):
    poll = instance
    update_fields = kwargs['update_fields']
    
    # Ensure basic breakdowns: MOBILE, WEB, GENDER
    options = json.loads(poll.options)
    default_json = json.dumps([0] * len(options))

    for btype in [PollBreakdown.TYPES.MOBILE, PollBreakdown.TYPES.WEB]:
        poll.breakdowns.get_or_create(
            breakdown_type=btype,
            defaults={'json': default_json}
        )
    
    if poll.gender == Poll.GENDERS.ALL:
        for gender in [0, 1]:
            poll.breakdowns.get_or_create(
                breakdown_type=PollBreakdown.TYPES.GENDER,
                gender=gender,
                defaults={'json': default_json}
            )
    else:
        poll.breakdowns.filter(
            breakdown_type=PollBreakdown.TYPES.GENDER
        ).delete()

    # Update-only hooks
    if not created:

        # Update_fields checked here to prevent excessive indexing
        if update_fields:
            return
            
        for bd in poll.breakdowns.all():
            bd_opts = json.loads(bd.json)
            new_opts = [0] * (len(options) - len(bd_opts))
            if new_opts:
                bd_opts = bd_opts + new_opts
                bd.json = json.dumps(bd_opts)
                bd.save(update_fields=["json"])

        for pi in poll.instances.all():
            pi_opts = json.loads(pi.vote_counts)
            new_opts = [0] * (len(options) - len(pi_opts))
            if new_opts:
                pi_opts = pi_opts + new_opts
                pi.vote_counts = json.dumps(pi_opts)
                pi.save(update_fields=["vote_counts"])

        poll.index()
        return

    # Create-only hooks
    tasks.auto_tag_polls.delay([poll.id])

    if poll.user.has_ios():
        tasks.reward_poll_creator.apply_async(args=[poll.id], countdown=3600*24)



# ManyToMany CHANGED

@receiver(m2m_changed, sender=Poll.tags.through)
def poll_tags_did_change(sender, instance, action, reverse=False, **kwargs):
    if action in ["post_add", "post_remove", "post_clear"]:
        # We changed the tags
        if reverse:
            for poll in instance.poll_set.all():
                poll.index()
        else:
            instance.index()


# POST-DELETE
# NOTE: don't delete data! set deleted=True.
# Exceptions are below

@receiver(post_delete, sender=Tag)
def tag_did_delete(sender, instance=None, **kwargs):
    poll_instance = instance.poll_instance
    poll_instance.tag_count -= 1
    poll_instance.save(update_fields=['tag_count'])

@receiver(post_delete, sender=Favorite)
def favorite_did_delete(sender, instance=None, **kwargs):
    poll_instance = instance.poll_instance
    poll_instance.favorite_count -= 1
    poll_instance.vote_aggregate -= 1
    poll_instance.save()

@receiver(post_delete, sender=PollInstanceRemoval)
def removal_did_delete(sender, instance=None, **kwargs):
    if instance.is_downvote:
        poll_instance = instance.poll_instance
        poll_instance.vote_aggregate += 1
        # TODO maybe undelete?
        # if poll_instance.get_deleted() and poll_instance.vote_aggregate > -5:
        #     poll_instance.deleted = False
        poll_instance.save()

# HELPERS

def check_poll_instance_for_promotion(poll_instance):
    # PROMOTION
    if poll_instance.promotion > PollInstance.PROMOTIONS.NONE:
        return

    # Promote poll, maybe
    is_recent = poll_instance.created_date > (timezone.now() - timedelta(days=5))
    rating = poll_instance.vote_aggregate

    if not is_recent or rating < 3: # or poll_instance.vote_weight < analytics.MIN_SAMPLE_SIZE:
        return

    if not poll_instance.verified and Report.objects.filter(poll_instance=poll_instance).exists():
        return

    two_week_moving_avg, stddev = analytics.moving_average_field(
        poll_instance.feed_id, field_name='vote_aggregate',
        poll_location=poll_instance.location,
        poll_community_id=poll_instance.community_id
    )
    if rating >= two_week_moving_avg + 1.5*stddev:
        poll_instance.refresh_from_db()
        # TODO attempt to fix race cond
        if poll_instance.promotion > PollInstance.PROMOTIONS.NONE:
            return
        poll_instance.promotion = PollInstance.PROMOTIONS.HOT
        poll_instance.save(update_fields=['promotion'])
        notifications.create_poll_notification(poll_instance, made_top=True)
        # TODO notify top posters/voters in feed
        notifications.local_poll_notification(poll_instance, "Local poll getting popular", "Campus poll getting popular")

        # Notify Gupta!
        if poll_instance.feed.category == Feed.LOCAL and poll_instance.community:
            title = "Fire Poll at {}".format(poll_instance.community.name_short)
            body = "{} favorites\n{} comments\n{} weighted votes\n(Average rating in feed: {}, std dev: {})".format(
                poll_instance.favorite_count, poll_instance.comment_count,
                poll_instance.vote_weight,
                round(two_week_moving_avg, 1), round(stddev, 1)
            )
            Gupta(poll_instance=poll_instance).promote(body, title=title, is_fire=True)
