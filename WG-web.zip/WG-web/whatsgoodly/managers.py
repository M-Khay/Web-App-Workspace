from django.conf import settings
from django.contrib.gis.db import models
from django.contrib.auth.models import UserManager as DjangoUserManager
from django.db.models import Count, Q, F
from whatsgoodly.utils import random_object
import whatsgoodly.models
from whatsgoodly import segmentations
from api import tasks
import json

class EdgeManager(models.Manager):
    use_in_migrations = True

    def get_queryset(self):
        return super(EdgeManager, self).get_queryset()

    def update_or_create(self, node_id_pair, **attrs):
        qset = self.get_queryset()
        try:
          obj = qset.get(
              Q(left_id=node_id_pair[0], right_id=node_id_pair[1]) |
              Q(left_id=node_id_pair[1], right_id=node_id_pair[0]))
          for key, value in attrs.items():
            setattr(obj, key, value)
          obj.save()
        except qset.model.DoesNotExist:
          obj = qset.create(
              left_id=node_id_pair[0], right_id=node_id_pair[1], **attrs
            )
        return obj

    def related_node_id_set(self, node_id, filter_space=[]):
        queryset = self.get_queryset()
        if filter_space:
            queryset = queryset.filter(left_id__in=filter_space, right_id__in=filter_space)
        return (
            set(queryset.filter(left_id=node_id).values_list('right_id', flat=True)) |
            set(queryset.filter(right_id=node_id).values_list('left_id', flat=True))
        )

class UserManager(DjangoUserManager):
    use_in_migrations = True

    def active(self):
        return self.get_queryset().filter(is_active=True)

    # TODO
    # def ios_uninstalled(self):
    #     return self.get_queryset().filter(ios_apns_token
    #         Q(is_active=False) |
    #         Q(aws_sns_arn_endpoint__isnull=True, denied_push_notifications=False)
    #     )

    def reachable(self):
        return self.get_queryset().filter(
            denied_push_notifications=False,
            aws_sns_arn_endpoint__isnull=False,
            is_active=True
        )

class SuggestionManager(models.Manager):

    def get_queryset(self):
        return super(SuggestionManager, self).get_queryset().filter(
                disabled=False
            )

    def random(self, **kwargs):
        return random_object(self.filter(**kwargs).all())

class PollInstanceManager(models.GeoManager):
    use_in_migrations = True

    def unique_polls(self):
        return self._unique_polls(self.get_queryset())

    def undeleted(self, unique_polls=False):
        queryset = self.get_queryset().filter(
                deleted=False, poll__deleted=False
            )

        if unique_polls:
            queryset = self._unique_polls(queryset)

        return queryset

    def allowed(self, user, unique_polls=False, newest_first=False):
        if user.is_anonymous():
            # Return only mod 0 polls
            queryset = self.undeleted().filter(user_modulus_remainder=0)

        else:
            queryset = self.get_queryset().filter(
                Q(deleted=False, poll__deleted=False) |
                Q(user=user, deleted_by_creator=False)
            ).annotate(
                remainder=(user.id % F('user_modulus'))
            ).filter(remainder=F('user_modulus_remainder'))

        if unique_polls:
            queryset = self._unique_polls(queryset, newest_first=newest_first)

        return queryset

    def _unique_polls(self, queryset, newest_first=False):
        sorter = '-poll_id' if newest_first else 'poll_id'
        return queryset.order_by(
            'segmenterinstance__segmenter_id', sorter
        ).distinct(
            'segmenterinstance__segmenter_id', 'poll_id'
        )

    # def create(self, user=None, poll=None, feed=None, location=None,
    #             ip_address=None, verified=None, community=None,
    #             auto_verified=False, banner=None):
    #     poll_instance = whatsgoodly.models.PollInstance(
    #         user=user, poll=poll, feed=feed, location=location,
    #         community=community, ip_address=ip_address, verified=verified,
    #         banner=banner, auto_verified=auto_verified)
    #     poll_instance.save()
    #     return poll_instance

    def create_poll(self, user=None, poll={}, feed=None,
                    location=None, ip_address=None, community=None,
                    deleted=False, censor_level=0, verified=False,
                    auto_verified=False, **kwargs):
        poll_obj = whatsgoodly.models.Poll(user=user, question=poll['question'],
                options=poll['options'], gender=poll['gender'],
                archetype=poll.get('archetype'),
                deleted=deleted, censor_level=censor_level,
                verified=verified)
        poll_obj.save()
        poll_instance = self.create(
            user=user, poll=poll_obj, feed=feed,
            location=location, community=community,
            ip_address=ip_address, verified=verified,
            auto_verified=auto_verified)
        return poll_instance

class SegmenterInstanceManager(PollInstanceManager):
    use_in_migrations = True

    def allowed(self, user):
        from whatsgoodly.models import PollCondition
        queryset = super(SegmenterInstanceManager, self).allowed(user)

        # Remove polls where user is ineligible
        conditions = PollCondition.objects.filter(dependent_poll__in=queryset.values('poll'))
        ineligible_poll_ids = [
            condition.dependent_poll_id
            for condition in conditions
            if not condition.is_eligible(user) ]
        
        return queryset.exclude(poll_id__in=ineligible_poll_ids)

    def create_segmenter(self, segment_type,
                    gender=2, ip_address=None, verified=True):
        from whatsgoodly.models import *
        segment = dict(segmentations.IDENTIFIERS).get(segment_type)
        question = segment.QUESTION
        choices = segment.CHOICES
        options = json.dumps([val for k, val in choices])
        option_labels = None
        # TODO: use is_staff and deprecate ADMIN_IDS
        admin_id = dict(settings.ADMIN_IDS).get('Alex Atallah')
        user = User.objects.get(id=admin_id)

        if hasattr(segment, 'GENDER'):
            gender = segment.GENDER

        if hasattr(segment, 'OPTION_LABELS'):
            option_labels = json.dumps([val for k, val in segment.OPTION_LABELS])

        segmenter = Segmenter(
                user=user, question=question,
                options=options, segment_type=segment_type,
                option_labels=option_labels,
                gender=gender, verified=verified)
        segmenter.save()

        if hasattr(segment, 'CONDITION'):
            determining_poll = Segmenter.objects.get(
                    segment_type=segment.CONDITION.SEGMENT_TYPE
                ).poll_ptr
            PollCondition.objects.create(
                    dependent_poll=segmenter.poll_ptr,
                    determining_poll=determining_poll,
                    response_filter=segment.CONDITION.RESPONSE_FILTER
                )

        if hasattr(segment, 'FEED_NAME_INSTEAD_OF_GLOBAL'):
            feed = Feed.objects.get(name=segment.FEED_NAME_INSTEAD_OF_GLOBAL)
        else:
            feed = Feed.objects.get(category=Feed.GLOBAL)

        default_counts = [0] * len(json.loads(segmenter.options))

        segmenter_instances = [
            SegmenterInstance.objects.create(
                user=user, segmenter_id=segmenter.id,
                vote_counts=json.dumps(default_counts),
                poll_id=segmenter.poll_ptr.id, feed=feed,
                ip_address=ip_address, verified=verified)
        ]

        if getattr(segment, 'EXCLUDE_FROM_LOCAL', False) == False:
            segmenter_instances += self.create_missing_campus_instances(segmenter, ip_address=ip_address)

        tasks.recompute_breakdowns([segmenter.id])
        return segmenter

    def create_missing_campus_instances(self, segmenter, ip_address=None):
        from whatsgoodly.models import *
        default_counts = [0] * len(json.loads(segmenter.options))
        feed = Feed.objects.get(category=Feed.LOCAL)
        admin_id = dict(settings.ADMIN_IDS).get('Whatsgoodly')
        user = User.objects.get(id=admin_id)
        university_ids = University.objects.values_list('id', flat=True)
        new_pis = []
        for u_id in university_ids:
            pi, created = PollInstance.objects.get_or_create(
                poll_id=segmenter.id, feed=feed, community_id=u_id,
                defaults={
                    # 'segmenter_id': segmenter.id,
                    'vote_counts': json.dumps(default_counts),
                    'user': user, 'ip_address': ip_address,
                    'verified': True
                }
            )
            q = SegmenterInstance.objects.filter(pk=pi.id)
            if not q.exists():
                si = SegmenterInstance(pollinstance_ptr=pi, segmenter=segmenter)
                si.save_base(raw=True)
            if created:
                new_pis.append(q.first())
        return new_pis

class SponsoredPollInstanceManager(models.Manager):
    use_in_migrations = True
    
    def get_queryset(self):
        return super(SponsoredPollInstanceManager, self).get_queryset().filter(
                promotion=whatsgoodly.models.PollInstance.PROMOTIONS.SPONSORED
            )

    def create_poll(self, question=None, choices=None,
                    feed_category=1, gender=2, location=None,
                    ip_address=None, verified=True):
        # TODO: use is_staff and deprecate ADMIN_IDS
        admin_id = dict(settings.ADMIN_IDS).get('Alex Atallah')
        user = whatsgoodly.models.User.objects.get(id=admin_id)
        feed = whatsgoodly.models.Feed.objects.get(category=feed_category)
        options = json.dumps([val for k, val in choices])
        poll = whatsgoodly.models.Poll(user=user, question=question, options=options,
                    gender=gender, verified=verified)
        poll.save()
        poll_instance = whatsgoodly.models.PollInstance(
            user=user, poll=poll, feed=feed, location=location,
            ip_address=ip_address, verified=verified,
            promotion=whatsgoodly.models.PollInstance.PROMOTIONS.SPONSORED) # banner="Sponsored"
        poll_instance.save()
        return poll_instance
