from django.shortcuts import get_object_or_404, render, redirect
from django.core.mail import EmailMultiAlternatives, send_mail
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.core.urlresolvers import reverse
from django.conf import settings
from django.views.decorators.csrf import ensure_csrf_cookie
from django.views.decorators.clickjacking import xframe_options_exempt
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.contrib.humanize.templatetags.humanize import naturaltime
from django.template.loader import get_template
from django.template import TemplateDoesNotExist
from whatsgoodly.models import Feed, PollInstance, PollBreakdown
from django.db.models import Q, F, Max
from whatsgoodly.serializers import *
from whatsgoodly import analytics, utils
from api import querysets
from api.constant_lists import stop_words
from api.permissions import account_required, can_view_survey, can_edit_survey, can_view_account
from api.utils import send_slack_message, get_ip_address, poll_page_sort
from rest_framework import response
from rest_framework.decorators import api_view, permission_classes, throttle_classes
from rest_framework.permissions import AllowAny, IsAuthenticated, IsAdminUser
from datetime import datetime, timedelta
import json
import os
import unicodecsv as csv

is_development = os.environ.get('env') == 'vagrant'
ELASTICSEARCH_HOST_WEB = settings.AWS_ELASTICSEARCH_HOST
TIMELINE_CHOICES = dict(Survey.TIMELINE_SETTINGS.CHOICES[1:])
# Uncomment for testing on local elasticsearch
# if is_development:
#     ELASTICSEARCH_HOST_WEB = "http://localhost:9200/"

@ensure_csrf_cookie
def index(request):
    global_feed = Feed.objects.get(category=Feed.GLOBAL)

    # TODO move to querysets
    polls = PollInstance.objects.allowed(request.user).select_related('poll', 'feed')\
        .filter(feed=global_feed)
    
    top_5 = polls.order_by('-id')[:5]
    polls = querysets.poll_instance_web_user_related(top_5, request.user)
    breakdowns = querysets.poll_breakdowns_web(polls, request.user)
    context = {'request': request, 'breakdowns': list(breakdowns)}
    serializer = PollInstanceSerializer(polls, many=True, context=context)
    data = dict(
        polls=json.dumps(serializer.data), # need to dump it for bootstrapping data
        navbar_classes="navbar-transparent"
    )
    return render(request, 'whatsgoodly/index.html', data)

@ensure_csrf_cookie
def demo(request):
    data = dict(
        samples=json.dumps({}),
        navbar_classes="navbar-transparent"
    )
    return render(request, 'whatsgoodly/demo.html', data)

@ensure_csrf_cookie
@xframe_options_exempt
def poll(request, poll_pk):
    pi_qset = PollInstance.objects.undeleted().filter(poll_id=poll_pk).order_by('-comment_count')
    if not pi_qset.exists():
        raise Http404('Poll not found')
    pi = querysets.poll_instance_web_user_related(pi_qset, request.user).first()
    breakdowns = querysets.poll_breakdowns_web([pi], request.user)
    context = {'request': request, 'breakdowns': list(breakdowns)}
    serializer = PollInstanceSerializer(pi, context=context)
    data = dict(
        poll=json.dumps(serializer.data),
        poll_instance_id=pi.id
    )
    return render(request, 'whatsgoodly/poll.html', data)

@account_required
def insights_library(request):
    data = {
        "page_name": "Demo",
        "account": "demo",
        "tags": [],
        "elasticsearch_host": ELASTICSEARCH_HOST_WEB,
        "elasticsearch_index": settings.ELASTICSEARCH_INDEX_BREAKDOWNS
    }
    return render(request, 'whatsgoodly/search.html', data)

def account_insights_library(request, account_name):
    account = get_object_or_404(Account, name_url=account_name)
    granted = can_view_account(request.user, account) and not account.disable_library

    log_visit(request, account, granted, event_name='Insights Library', emoji=":books:")

    if not granted:
        return redirect('{}?next={}'.format(reverse('login'), request.path))
    else:
        tags = account.subscribed_tags.all().values_list('label_lower', flat=True)
        
        data = {
            "page_name": account.name,
            "account_uri": account_name,
            "tags": map(str, tags),
            "elasticsearch_host": ELASTICSEARCH_HOST_WEB,
            "elasticsearch_index": settings.ELASTICSEARCH_INDEX_BREAKDOWNS
        }
        return render(request, 'whatsgoodly/search.html', data)    

def proxy_es_search(request):
    data = {"breakdowns": []}
    return response.Response(data, status=200)

@ensure_csrf_cookie
def survey(request, pk):
    survey = get_object_or_404(Survey, pk=pk)
    granted = can_view_survey(request.user, survey)

    log_visit(request, survey, granted, event_name='Survey Report', emoji=":eye:")

    if not granted:
        return redirect('{}?next={}'.format(reverse('login'), request.path))
    else:
        context = { 'request': request }
        serializer = SurveySerializer(survey, context=context)
        data = {
            "page_name": survey.name,
            "survey": json.dumps(serializer.data),
            "timeline_settings": json.dumps(TIMELINE_CHOICES)
        }
        return render(request, 'whatsgoodly/survey.html', data)

@api_view(['PUT', 'PATCH'])
@permission_classes((IsAuthenticated, ))
def update_survey(request, pk):
    survey = get_object_or_404(Survey, pk=pk)
    granted = can_edit_survey(request.user, survey)

    log_visit(request, survey, granted, event_name='Survey Update', emoji=":gear:")

    if not granted:
        return HttpResponse(status=403)

    context = { 'request': request }
    serializer = SurveySerializer(survey, data=request.data, partial=True, context=context)
    if serializer.is_valid(raise_exception=True):
      serializer.save()
      return response.Response(serializer.data, status=200)
    return response.Response(serializer.errors, status=400)

@ensure_csrf_cookie
def account_dashboard(request, account_name):
    account = get_object_or_404(Account, name_url=account_name)
    granted = can_view_account(request.user, account)

    log_visit(request, account, granted, event_name='Account Dashboard', emoji=":eye:")

    if not granted:
        return redirect('{}?next={}'.format(reverse('login'), request.path))
    else:
        context = { 'request': request }
        serializer = AccountSerializer(account, context=context)
        data = {
            "page_name": account.name,
            "account_uri": account_name,
            "account": json.dumps(serializer.data),
            "timeline_settings": json.dumps(TIMELINE_CHOICES)
        }
        return render(request, 'whatsgoodly/account_dashboard.html', data)

@ensure_csrf_cookie
@xframe_options_exempt
def account_survey(request, account_name, survey_identifier):
    try:
        filters = dict(pk=int(survey_identifier), account__name_url=account_name)
    except ValueError:
        filters = dict(name_url=survey_identifier, account__name_url=account_name)
    survey = get_object_or_404(Survey, **filters)
    granted = True # can_view_survey(request.user, survey)

    log_visit(request, survey, granted, event_name='Survey Form', emoji=":pencil:")

    pis = PollInstance.objects.allowed(
                request.user, unique_polls=True, newest_first=True
            ).filter(poll__survey=survey)

    polls = querysets.poll_instance_web_user_related(pis, request.user)
    breakdowns = querysets.poll_breakdowns_web(polls, request.user)

    context = {'request': request, 'breakdowns': list(breakdowns)}
    serializer = PollInstanceSerializer(polls, many=True, context=context)
    poll_data = sorted(serializer.data, key=poll_page_sort(request.user))
    if polls:
        feed_data = FeedInlineSerializer(polls[0].feed, context=context).data
    else:
        feed_data = None

    data = {
        "feed": json.dumps(feed_data),
        "page_name": survey.name,
        "account_uri": account_name,
        "polls": json.dumps(poll_data)
    }
    return render(request, 'whatsgoodly/survey_form.html', data)

@api_view(['GET'])
@permission_classes((AllowAny, ))
def survey_poll_breakdowns(request, survey_pk, poll_pk):
    context = { 'request': request, 'skip_margin_calc': True }
    survey = get_object_or_404(Survey, pk=survey_pk)
    if not can_view_survey(request.user, survey):
        return HttpResponse(status=403)

    poll = survey.polls.get(pk=poll_pk)
    breakdowns = poll.breakdowns.exclude(
        Q(segmenter__isnull=False) & ~Q(segmenter__in=survey.allowed_breakdowns.all())
    )
    serializer = PollBreakdownExportSerializer(breakdowns, many=True, context=context)
    data = {"breakdowns": serializer.data}
    return response.Response(data, status=200)

@api_view(['GET'])
@permission_classes((AllowAny, ))
def survey_timeline(request, survey_pk):
    params = request.query_params
    user = request.user
    survey = get_object_or_404(Survey, pk=survey_pk)
    if not can_view_survey(user, survey):
        return HttpResponse(status=403)
    if survey.timeline_setting == Survey.TIMELINE_SETTINGS.NONE:
        return response.Response("This survey isn't a timeline", status=400)

    timeline_setting = int(params.get('timeline_setting', survey.timeline_setting))

    sql_grouper_class = {
            Survey.TIMELINE_SETTINGS.DAY: utils.Date,
            Survey.TIMELINE_SETTINGS.WEEK: utils.Week,
            Survey.TIMELINE_SETTINGS.MONTH: utils.Month
        }[timeline_setting]
    sql_grouper = sql_grouper_class('created_date')

    responses = Response.objects.filter(
            poll_instance__poll__survey=survey,
            # Exclude today's responses, otherwise it's imbalanced at day start
            created_date__lt=datetime.now().date()
        )
    time_groups = analytics.grouped_responses(responses, sql_grouper)

    # pis = PollInstance.objects.filter(
    #     poll__in=survey.polls.all()
    #   ).order_by(
    #     'created_date'
    #   )
    # breakdowns = querysets.poll_breakdowns_web(pis, user)
    # context = { 'request': request, 'breakdowns': list(breakdowns) }
    # pi_data = PollInstanceSerializer(pis, many=True, context=context).data
    # data = {
    #     "time_groups": json.dumps([
    #         {
    #             "date": pi_datum['created_date'],
    #             "options": pi_datum['options'],
    #             "totals": pi_datum['option_counts']
    #         } for pi_datum in pi_data
    #     ])
    # }
    data = {"time_groups": time_groups}
    return response.Response(data, status=200)

# TODO secure customer polls?
@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def poll_timeline(request, poll_pk):
    params = request.query_params
    user = request.user
    poll = get_object_or_404(Poll, pk=poll_pk, deleted=False)
    # if not can_view_survey(user, survey):
    #     return HttpResponse(status=403)

    timeline_setting = int(params.get('timeline_setting', Survey.TIMELINE_SETTINGS.POLL_DEFAULT))
    sql_grouper_class = {
            Survey.TIMELINE_SETTINGS.DAY: utils.Date,
            Survey.TIMELINE_SETTINGS.WEEK: utils.Week,
            Survey.TIMELINE_SETTINGS.MONTH: utils.Month
        }[timeline_setting]
    sql_grouper = sql_grouper_class('created_date')

    responses = Response.objects.filter(
            poll_instance__poll=poll,
            created_date__lt=datetime.now().date()
        )
    time_groups = analytics.grouped_responses(responses, sql_grouper)
    data = {"time_groups": time_groups}
    return response.Response(data, status=200)

@account_required
@ensure_csrf_cookie
def add_poll_to_survey(request, poll_pk):
    context = { 'request': request }
    poll = get_object_or_404(Poll, pk=poll_pk, deleted=False)
    # serializer = SurveySerializer(survey, context=context)
    # data = {"survey": json.dumps(serializer.data)}
    # return render(request, 'whatsgoodly/survey.html', data)
    return HttpResponse("Fancy web app coming soon! You have an account already, so contact alex@whatsgoodly.com to build your report ahead of time.")

@account_required
def export_survey_csv(request, pk):
    context = { 'request': request }
    survey = get_object_or_404(Survey, pk=pk)

    response = HttpResponse(content_type='text/csv')
    filename = survey.name.replace('"', '')
    response['Content-Disposition'] = 'attachment; filename="Whatsgoodly - {}.csv"'.format(filename)
    writer = csv.writer(response)
    writer.writerow(['Question', 'Segment Type', 'Segment Description', 'Answer', 'Count', 'Percentage'])

    for poll in survey.polls.all():
        breakdowns = poll.breakdowns.all()
        serializer = PollBreakdownExportSerializer(breakdowns, many=True, context=context)

        opts = json.loads(poll.options)
        for b in serializer.data:
            for i, opt in enumerate(opts):
                count, percentage = b['option_counts'][i], b['percentages'][i]
                row = [
                    b['poll']['question'], b['breakdown_type_label'], b['label'], opt, count, percentage
                ]
                writer.writerow(row)

    return response

@api_view(['POST'])
@permission_classes((AllowAny, ))
def contact_sales(request):
    """
    Send an email with the email in the request body
    """
    email = request.data.get('email', None)
    message = request.data.get('message', None)
    try:
        validate_email(email)
    except ValidationError as e:
        return HttpResponse(status=400)
    else:
        msg = EmailMultiAlternatives(
            subject="Sales Request",
            body=message,
            from_email=email,
            to=["alex@whatsgoodly.com"]
        )
        msg.send()

        return HttpResponse(status=200)

def campusrep(request):
    """
    Send an email with the email in the request body
    """
    if request.method != 'POST':
        return HttpResponse(status=400)
    params = request.POST
    email = params.get('email', None)
    try:
        validate_email(email)
    except ValidationError as e:
        return HttpResponse(status=400)
    else:
        msg = EmailMultiAlternatives(
            subject="New Campus Rep",
            body="Email: {}".format(email),
            from_email=email,
            to=["alex@whatsgoodly.com"]
        )
        msg.send()

        return HttpResponse(status=200)

def download_app(request, name):
    if name == "pawp":
        return render(request, 'whatsgoodly/apps.html', {'name': name})
    raise Http404("That app doesn't exist")

def static_page(request, page_slug=""):
    try:
        data = {}
        template = get_template('whatsgoodly/%s.html' % page_slug)
        html = template.render(data, request)
        return HttpResponse(html)
    except TemplateDoesNotExist:
        raise Http404("That page doesn't exist")

@api_view(['GET'])
@permission_classes((AllowAny, ))
def search_safe_polls(request, only_count=False):
    params = request.query_params
    user = request.user
    query = params.get('q', "").strip()
    if not query or query in stop_words:
        return HttpResponse(status=200)

    qset = PollInstance.objects.allowed(user)
    unfiltered_queryset = querysets.search_poll_instances(query, qset)

    if only_count:
        count = unfiltered_queryset.count()
        if not user.is_staff:
            slack_message = u"*\"{0}\"* searched by {1}\nFound {2} results".format(
                    query,
                    "User {0} [{1} pts]".format(user.id, user.karma) if user.id else "anonymous user",
                    count
                )
            send_slack_message(slack_message, event_name="Search", emoji=":mag:")
        data = {'total_polls': count}
        return response.Response(data, status=200)

    # Development environments dont have many votes
    if is_development:
        filtered_queryset = unfiltered_queryset
    else:
        # vote_weight, vote_aggregate matter for indexes
        # https://devcenter.heroku.com/articles/postgresql-indexes
        filtered_queryset = unfiltered_queryset.filter(
                vote_weight__gte=50,
                vote_aggregate__gte=0,
                verified=True
            )

    filtered_queryset = filtered_queryset.order_by(
                '-vote_weight', 'poll_id'
            ).distinct('vote_weight', 'poll_id')

    filtered_queryset = filtered_queryset[:10]
    polls = querysets.poll_instance_web_user_related(filtered_queryset, request.user)
    breakdowns = querysets.poll_breakdowns_web(polls, request.user)
    context = {'request': request, 'breakdowns': list(breakdowns)}
    serializer = PollInstanceSerializer(polls, many=True, context=context)
    data = {'polls': serializer.data}
    return response.Response(data, status=200)

def log_visit(request, object, granted=True, **opts):
    ip_addr = get_ip_address(request)
    referrer = request.META.get('HTTP_REFERER', 'direct link')

    status = "visited" if granted else "was denied access to"
    if not granted:
        opts["emoji"] = ":no_entry_sign:"
        opts["event_name"] = opts["event_name"] + " - Unauthorized Access"
    user = request.user if not request.user.is_anonymous() else None
    slack_message = u"{}{} *{}*: {} via {}".format(
            "" if user else "{} ".format(ip_addr), status,
            object, request.get_full_path(), referrer
        )
    send_slack_message(slack_message, channel="#customer-support", user=user, **opts)
