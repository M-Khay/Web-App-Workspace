from django.contrib import admin
from django.contrib.gis.admin import GeoModelAdmin
from rest_framework.authtoken.admin import TokenAdmin
from whatsgoodly.models import *
from whatsgoodly.utils import ApproximatePaginator
from django.forms import ModelForm
from django.forms.models import BaseInlineFormSet
from django.forms.widgets import TextInput
from django.core.exceptions import ValidationError
from api import tasks
from api.notifications import admin_check_poll_notification, create_poll_notification, local_poll_notification
import json

TokenAdmin.raw_id_fields = ('user',)

class UserAdmin(admin.ModelAdmin):
  readonly_fields = ('date_joined',)
  ordering = ['-id']
  search_fields = ['username', 'email', 'full_name', 'phone_number', 'university__name_short', 'university__name']
  list_filter = ('is_staff', 'is_active', 'gender', 'posting_suspended', 'web_session', 'app_session' )
  list_select_related = ('university', )

  def age(self, obj):
    return obj.get_age()

  def lookup_allowed(self, key, value):
    return True

class AccountAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  search_fields = ['name', 'name_url']
  filter_horizontal = ['subscribed_tags', 'subscribed_breakdowns']

  def lookup_allowed(self, key, value):
    return True

class SurveyAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'polls', 'user', )
  search_fields = ['name', 'account__name']
  list_select_related = ('account', 'user', )
  list_filter = ('account', )
  filter_horizontal = ['allowed_breakdowns']

  def lookup_allowed(self, key, value):
    return True

class UserMergerAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'user', 'merged_user' )
  list_select_related = ('user', 'merged_user')
  search_fields = ['user__username', 'merged_user__username']
  list_filter = ('user__gender', 'merged_user__gender' )

  def lookup_allowed(self, key, value):
    return True

class UserRelationshipAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'left', 'right' )
  list_select_related = ('left', 'right')
  search_fields = ['left__username', 'right__username']
  paginator = ApproximatePaginator # skip counting all the results
  show_full_result_count = False

  def lookup_allowed(self, key, value):
    return True

class PollAdminForm(ModelForm):
  def clean_options(self):
    try:
      json.loads(self.data['options'])
      return self.cleaned_data['options']
    except Exception, e:
      raise ValidationError('Invalid format! Error: %s' % (e))

  def clean_audio_options(self):
    try:
      if self.data['audio_options']:
        json.loads(self.data['audio_options'])
      return self.cleaned_data['audio_options']
    except Exception, e:
      raise ValidationError('Invalid format! Error: %s' % (e))

  def clean_option_labels(self):
    try:
      if self.data['option_labels']:
        json.loads(self.data['option_labels'])
      return self.cleaned_data['option_labels']
    except Exception, e:
      raise ValidationError('Invalid format! Error: %s' % (e))

  def clean_option_hex_colors(self):
    try:
      if self.data['option_hex_colors']:
        json.loads(self.data['option_hex_colors'])
      return self.cleaned_data['option_hex_colors']
    except Exception, e:
      raise ValidationError('Invalid format! Error: %s' % (e))

  def clean_option_indices_excluded_from_breakdowns(self):
    try:
      if self.data['option_indices_excluded_from_breakdowns']:
        json.loads(self.data['option_indices_excluded_from_breakdowns'])
      return self.cleaned_data['option_indices_excluded_from_breakdowns']
    except Exception, e:
      raise ValidationError('Invalid format! Error: %s' % (e))

class PollTagAdminForm(ModelForm):
  def clean_flag_terms(self):
    try:
      json.loads(self.data['flag_terms'])
      return self.cleaned_data['flag_terms']
    except Exception, e:
      raise ValidationError('Invalid format! Error: %s' % (e))

class UniversityAdminForm(ModelForm):
  def clean_fraternities(self):
    if len(self.data['fraternities']):
      try:
        json.loads(self.data['fraternities'])
        return self.cleaned_data['fraternities']
      except Exception, e:
        raise ValidationError('Invalid format! Error: %s' % (e))

  def clean_sororities(self):
    if len(self.data['sororities']):
      try:
        json.loads(self.data['sororities'])
        return self.cleaned_data['sororities']
      except Exception, e:
        raise ValidationError('Invalid format! Error: %s' % (e))

  class Meta:
    widgets = dict(
        primary_color=TextInput(attrs={'type': 'color'})
      )

class PollBreakdownInlineFormset(BaseInlineFormSet):
  def clean(self):
    for form in self.forms:
      try:
        json.loads(form.cleaned_data['json'])
      except Exception as e:
        raise ValidationError('Invalid format! json error: %s' % (e))

class PollBreakdownAdminForm(ModelForm):
  def clean_json(self):
    try:
      json.loads(self.data['json'])
      return self.cleaned_data['json']
    except Exception, e:
      raise ValidationError('Invalid format! Error: %s' % (e))

class PollBreakdownAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date', 'total',)
  ordering = ['-poll_id', 'breakdown_type', 'segmenter__segment_type', '-total']
  raw_id_fields = ( 'poll', )
  list_filter = ('breakdown_type', 'segmenter__segment_type', )
  show_full_result_count = False # dont count search / filter results
  paginator = ApproximatePaginator # skip counting all the results
  form = PollBreakdownAdminForm
  list_select_related = ('poll', 'university', 'segmenter' )
  search_fields = ['poll__question', 'poll__options']

  def lookup_allowed(self, key, value):
    return True

  def save_model(self, request, obj, form, change):
    if change and 'json' in form.changed_data:
      if not len(json.loads(obj.json)) == len(json.loads(obj.poll.options)):
        raise ValidationError('Number of option counts must match number of options')
    obj.save()

class PollBreakdownInline(admin.TabularInline):
  ordering = ['breakdown_type']
  model = PollBreakdown
  fields = ('breakdown_type', 'json', 'gender', 'university',
      'segmenter', 'segment_option', 'significance', 'total')
  readonly_fields = ( 'total', 'significance', )
  formset = PollBreakdownInlineFormset
  extra = 0
  # TODO why doesn't this work?
  max_num = 5
  can_delete = False

  def save_model(self, request, obj, form, change):
    if change and 'json' in form.changed_data:
      if len(json.loads(obj.json)) != len(json.loads(obj.poll.options)):
        raise ValidationError('Number of vote counts must match number of options')
    obj.save()

class SegmenterBreakdownInline(PollBreakdownInline):
  fk_name = 'poll'

class PollAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  form = PollAdminForm
  raw_id_fields = ( 'user', 'archetype', )
  # inlines = [PollBreakdownInline, ]
  # date_hierarchy = 'created_date'
  list_select_related = ('user', )
  list_filter = ('gender', 'censor_level', 'deleted', 'verified')
  search_fields = ['question', 'options', 'user__username']
  filter_horizontal = ['tags']

  def lookup_allowed(self, key, value):
    return True

class SegmenterAdmin(PollAdmin):
  ordering = ['segment_type']
  # inlines = [SegmenterBreakdownInline, ]
  list_filter = ('segment_type', 'gender', )

class PollArchetypeAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  list_filter = ('campus_level', 'age_level', )
  search_fields = ['question', 'options']

  def lookup_allowed(self, key, value):
    return True

class PollInstanceAdminForm(ModelForm):
  def clean_vote_counts(self):
    try:
      json.loads(self.data['vote_counts'])
      return self.cleaned_data['vote_counts']
    except Exception, e:
       raise ValidationError('Invalid format! Error: %s' % (e))

class PollInstanceHTTPSGeoModelAdmin(GeoModelAdmin):
  readonly_fields = ('created_date', 'vote_weight', )
  ordering = ['-id']
  raw_id_fields = ( 'user', 'poll', 'verified_by' )
  openlayers_url = '/static/openlayers/OpenLayers.js'
  show_full_result_count = False # dont count search / filter results
  form = PollInstanceAdminForm
  # date_hierarchy = 'created_date'
  list_select_related = ('user', 'poll', 'feed', )
  list_filter = ('promotion', 'poll__censor_level', 'verified', 'auto_verified', 'deleted', 'deleted_by_admin', 'deleted_by_creator', 'feed', )
  list_select_related = ('poll', )
  search_fields = ['poll__question', 'poll__options', 'community__name', 'community__name_short']

  def lookup_allowed(self, key, value):
    return True

  # Reset vote count field on save in case user modifies option counts
  def save_model(self, request, obj, form, change):
    if not change:
      obj.save()
      return

    if 'vote_counts' in form.changed_data:
      if not len(json.loads(obj.vote_counts)) == len(json.loads(obj.poll.options)):
        raise ValidationError('Number of option counts must match number of options')
      poll_instance = PollInstance.objects.get(pk=obj.id)
      prev_vote_count = sum(json.loads(poll_instance.vote_counts))
      admin_check_poll_notification(obj, prev_vote_count)
    elif 'user_modulus' in form.changed_data or 'user_modulus_remainder' in form.changed_data:
      if not (0 <= obj.user_modulus_remainder < obj.user_modulus):
        raise ValidationError('Remainder must be between 0 and modulus - 1.')
    elif 'feed' in form.changed_data and obj.feed.category == Feed.GLOBAL:
      # Sends a congrats notification to poll author
      create_poll_notification(obj, made_global=True)
    elif 'feed' in form.changed_data and obj.feed.category != Feed.GLOBAL:
      create_poll_notification(obj, made_new_feed=True)
    elif 'promotion' in form.changed_data and obj.promotion == PollInstance.PROMOTIONS.GLOBALLED:
      # Sends a notification to poll's local users minus the author
      local_poll_notification(obj, "A Local poll made the Featured feed!", "A campus poll made the Featured feed!")
    elif 'promotion' in form.changed_data and obj.promotion == PollInstance.PROMOTIONS.PINNED:
      create_poll_notification(obj, made_pinned=True)
      # tasks.remove_promotion.apply_async(args=[obj.id], countdown=3600*48)
      # Sends a notification to feed's contributors minus the author
      # featured_poll_notification(obj, "Pinned poll in {}".format())

    obj.save()

class SegmenterInstanceHTTPSGeoModelAdmin(PollInstanceHTTPSGeoModelAdmin):
  list_filter = ('segmenter__segment_type', 'promotion', 'feed', )

class UniversityHTTPSGeoModelAdmin(GeoModelAdmin):
  """
  Override geo model admin class to use local copy of OpenLayers
  """
  readonly_fields = ('created_date',)
  openlayers_url = '/static/openlayers/OpenLayers.js'
  form = UniversityAdminForm
  search_fields = ['name', 'name_short']
  list_filter = ['level', 'public']
  filter_horizontal = ['local_feeds']

class PeekFeedHTTPSGeoModelAdmin(GeoModelAdmin):
  """
  Override geo model admin class to use local copy of OpenLayers
  """
  openlayers_url = '/static/openlayers/OpenLayers.js'
  ordering = ['-id']

  def save_model(self, request, obj, form, change):
    if (obj.location is None and obj.university is None):
      raise ValidationError('Feed must have a location if no university is provided')
    elif not obj.university == None:
      obj.location = obj.university.location
    obj.save()

class CommentAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'user', 'poll_instance' )
  # date_hierarchy = 'created_date'
  list_filter = ('censor_level', 'verified', 'deleted', 'deleted_by_creator')
  list_select_related = ('user', 'poll_instance__poll', )
  search_fields = ['text']

  def lookup_allowed(self, key, value):
    return True

class ReferrerAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  date_hierarchy = 'created_date'
  search_fields = ['host']

class ResponseHTTPSGeoModelAdmin(GeoModelAdmin):
  openlayers_url = '/static/openlayers/OpenLayers.js'
  readonly_fields = ('created_date',)
  ordering = ['-id']
  paginator = ApproximatePaginator # skip counting all the results
  show_full_result_count = False # dont count search / filter results
  # NOTE: DO NOT put in a date_hierarchy until index is added on created_date
  # date_hierarchy = 'created_date'
  raw_id_fields = ( 'user', 'poll_instance', 'referrer' )
  list_select_related = ('user', 'poll_instance', 'poll_instance__poll' )
  list_filter = ( 'poll_instance__promotion', )
  search_fields = ['poll_instance__poll__question', 'poll_instance__poll__options', 'referring_url']

  def lookup_allowed(self, key, value):
    return True

class PollConditionAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'determining_poll', 'dependent_poll' )
  list_select_related = ('determining_poll', 'dependent_poll', )
  search_fields = ['determining_poll__question', 'dependent_poll__question']

  def lookup_allowed(self, key, value):
    return True

class PollTagAdmin(admin.ModelAdmin):
  form = PollTagAdminForm
  readonly_fields = ('created_date',)
  list_select_related = ('parent', )
  # list_filter = ( 'parent', )
  search_fields = ['label_lower', 'flag_terms']

  def lookup_allowed(self, key, value):
    return True

  def save_model(self, request, obj, form, change):
    obj.save()
    # if change and 'flag_terms' in form.changed_data:
    #   # TODO This will take a long time, each time
    #   tasks.regex_tag_polls.delay([obj.id])

class FeedConditionAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'determining_poll', 'allowed_users' )
  list_select_related = ('determining_poll', 'feed', )
  search_fields = ['determining_poll__question', 'feed__name']

  def lookup_allowed(self, key, value):
    return True

class PollInstanceRemovalAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'user', 'poll_instance' )
  list_select_related = ('user', 'poll_instance__poll', )
  search_fields = ['poll_instance__poll__question']

  def lookup_allowed(self, key, value):
    return True

class FavoriteAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'user', 'poll_instance' )
  list_select_related = ('user', 'poll_instance__poll', )
  search_fields = ['poll_instance__poll__question']

  def lookup_allowed(self, key, value):
    return True

class ReportAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'user', 'poll_instance', 'comment' )
  list_select_related = ('user', 'poll_instance__poll', )
  search_fields = ['poll_instance__poll__question']

  def lookup_allowed(self, key, value):
    return True

class PhoneBanAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ('user', )
  list_select_related = ('user', )
  date_hierarchy = 'modified_date'

  def lookup_allowed(self, key, value):
    return True

class CommentReportAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'user', 'comment' )
  list_select_related = ('user', )

  def lookup_allowed(self, key, value):
    return True

class CommentVoteAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'user', 'comment' )
  list_select_related = ('user', )

  def lookup_allowed(self, key, value):
    return True

class NotificationAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date', 'campaign', )
  show_full_result_count = False # dont count search / filter results
  ordering = ['-id']
  raw_id_fields = ( 'user', 'poll_instance' )
  list_select_related = ('user', 'poll_instance__poll', )
  list_filter = ('opened_from_push', 'is_read', 'notification_type', )
  search_fields = ['title', 'body']

  def lookup_allowed(self, key, value):
    return True

class NotificationCampaignAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'determining_poll', )
  list_select_related = ('determining_poll', 'account', )
  search_fields = ['name', 'determining_poll__question', 'account__name']

  def lookup_allowed(self, key, value):
    return True

class FriendshipAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'user', )
  list_select_related = ('user', )
  search_fields = ['friend_name', 'friend_phone_number']

  def lookup_allowed(self, key, value):
    return True

class TagAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'friendship', 'poll_instance' )
  list_select_related = ('friendship', 'friendship__user', 'poll_instance__poll', )
  search_fields = ['poll_instance__poll__question']

  def lookup_allowed(self, key, value):
    return True

class FeedHTTPSGeoModelAdmin(GeoModelAdmin):
  openlayers_url = '/static/openlayers/OpenLayers.js'
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( )
  search_fields = ['name']
  list_filter = ('active', 'level', 'promotion_day', 'category', )
  filter_horizontal = ['allowed_breakdowns']

  def lookup_allowed(self, key, value):
    return True

class FeedPreferenceAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'user', )
  search_fields = ['feed__name', 'user__username']
  list_select_related = ('feed', 'user' )
  list_filter = ('disabled', 'feed', )

  def lookup_allowed(self, key, value):
    return True

class PollBreakdownUnlockAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)

  raw_id_fields = ( 'user', 'poll' )
  list_select_related = ('user', 'poll' )
  search_fields = ['poll__question', 'poll__options', 'user__username']

  def lookup_allowed(self, key, value):
    return True

class PushSubscriptionAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'user', 'poll_instance' )
  search_fields = ['poll_instance__poll__question', 'user__username']
  list_select_related = ('poll_instance', 'poll_instance__poll', 'user' )
  list_filter = ('disabled', )

  def lookup_allowed(self, key, value):
    return True

class AnnouncementHTTPSGeoModelAdmin(GeoModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  openlayers_url = '/static/openlayers/OpenLayers.js'
  list_select_related = ('feed', )
  list_filter = ('active', 'user_filter', 'feed', )

  def lookup_allowed(self, key, value):
    return True

class LocalChannelHTTPSGeoModelAdmin(GeoModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'user', )
  openlayers_url = '/static/openlayers/OpenLayers.js'
  search_fields = ['name', 'user__username', 'user__university__name', 'user__university__name_short']
  list_select_related = ('user', 'user__university' )
  list_filter = ('active', )

  def lookup_allowed(self, key, value):
    return True

class SearchQueryAdmin(admin.ModelAdmin):
  readonly_fields = ('created_date',)
  ordering = ['-id']
  raw_id_fields = ( 'user', )
  search_fields = ['user__username', 'query', 'user__university__name', 'user__university__name_short']
  list_select_related = ('user', 'user__university' )

  def lookup_allowed(self, key, value):
    return True

admin.site.register(User, UserAdmin)
admin.site.register(Account, AccountAdmin)
admin.site.register(Survey, SurveyAdmin)
admin.site.register(UserMerger, UserMergerAdmin)
admin.site.register(UserRelationship, UserRelationshipAdmin)
admin.site.register(PhoneBan, PhoneBanAdmin)
admin.site.register(Poll, PollAdmin)
admin.site.register(PollArchetype, PollArchetypeAdmin)
admin.site.register(PollTag, PollTagAdmin)
admin.site.register(PollInstance, PollInstanceHTTPSGeoModelAdmin)
admin.site.register(PollCondition, PollConditionAdmin)
admin.site.register(FeedCondition, FeedConditionAdmin)
admin.site.register(PollBreakdown, PollBreakdownAdmin)
admin.site.register(Segmenter, SegmenterAdmin)
admin.site.register(SegmenterInstance, SegmenterInstanceHTTPSGeoModelAdmin)
admin.site.register(Response, ResponseHTTPSGeoModelAdmin)
admin.site.register(Referrer, ReferrerAdmin)
admin.site.register(Report, ReportAdmin)
admin.site.register(Favorite, FavoriteAdmin)
admin.site.register(PollInstanceRemoval, PollInstanceRemovalAdmin)
admin.site.register(Comment, CommentAdmin)
admin.site.register(CommentVote, CommentVoteAdmin)
admin.site.register(University, UniversityHTTPSGeoModelAdmin)
admin.site.register(Notification, NotificationAdmin)
admin.site.register(NotificationCampaign, NotificationCampaignAdmin)
admin.site.register(Tag, TagAdmin)
admin.site.register(Friendship, FriendshipAdmin)
admin.site.register(Feed, FeedHTTPSGeoModelAdmin)
admin.site.register(FeedPreference, FeedPreferenceAdmin)
admin.site.register(PollBreakdownUnlock, PollBreakdownUnlockAdmin)
admin.site.register(PushSubscription, PushSubscriptionAdmin)
admin.site.register(PeekFeed, PeekFeedHTTPSGeoModelAdmin)
admin.site.register(Announcement, AnnouncementHTTPSGeoModelAdmin)
admin.site.register(LocalChannel, LocalChannelHTTPSGeoModelAdmin)

