(function() {

var D = React.DOM;
var R = window.Recharts;

var ACTION_RENDER_BREAKDOWNS = "ACTION_RENDER_BREAKDOWNS";
var ACTION_SET_LOADING = "ACTION_SET_LOADING";

// Chrome bug needs delay before rechart data is fetched
var RECHART_CHROME_INITAL_RENDER_DELAY = 100;

WG.Survey = React.createFactory(React.createClass({

  propTypes: {
    survey: React.PropTypes.shape({
      id: React.PropTypes.number.isRequired,
      name: React.PropTypes.string.isRequired,
      timeline_setting: React.PropTypes.number.isRequired,
      map_setting: React.PropTypes.number.isRequired,
      population_size: React.PropTypes.number.isRequired,
      polls: React.PropTypes.arrayOf(React.PropTypes.shape({
        id: React.PropTypes.number.isRequired,
        question: React.PropTypes.string.isRequired,
        created_date: React.PropTypes.string.isRequired
      }).isRequired).isRequired
    }).isRequired,
    timelineSettings: React.PropTypes.object
  },

  getInitialState: function() {
    return {
      loading: false,
      breakdowns: [],
      currentPoll: this.props.survey.polls[0]
    }
  },

  componentWillMount: function() {
    this.spinner = new Spinner(WG.constants.SPINNER_SETUP);

    this.listeners = [
      PubSub.subscribe(ACTION_RENDER_BREAKDOWNS, function(topic, breakdowns) {
        this.setState({
          loading: false,
          breakdowns: breakdowns
        })
      }.bind(this)),

      PubSub.subscribe(ACTION_SET_LOADING, function(topic, poll) {
        this.setState({
          loading: true,
          breakdowns: [],
          currentPoll: poll
        })
      }.bind(this)),
    ];
  },

  componentWillUnmount: function() {
    this.listeners.map(PubSub.unsubscribe);
  },

  componentDidMount: function() {
    this.spinnerNode = ReactDOM.findDOMNode(this);
    setTimeout(this.fetchBreakdowns.bind(this, this.state.currentPoll), RECHART_CHROME_INITAL_RENDER_DELAY);
  },

  componentDidUpdate: function(prevProps, prevState) {
    if (this.state.loading && !prevState.loading) {
      this.spinner.spin(this.spinnerNode);
    }
    if (!this.state.loading) {
      this.spinner.stop();
    }
    if (this.props.survey.id != prevProps.survey.id) {
      this.setState(this.getInitialState(), function() {
        this.fetchBreakdowns(this.state.currentPoll);
      }.bind(this));
    }
  },

  fetchBreakdowns: function(poll) {
    PubSub.publish(ACTION_SET_LOADING, poll);

    if (this.xhr) {
      this.xhr.abort();
    }

    var url = "/survey/" + this.props.survey.id + "/poll/" + poll.id;

    this.xhr = $.getJSON(url).done(function(data) {
      PubSub.publish(ACTION_RENDER_BREAKDOWNS, data.breakdowns);
    });
  },

  renderPollDropdown: function() {
    return (
      D.div({className: "btn-group", role: "group"},
        D.button({className: "btn btn-default dropdown-toggle", 'data-toggle': "dropdown"},
          D.span({className: "toc-name"}, "Question"),
          D.span({className: "caret", style: {marginLeft: 10}})
        ),
        D.ul({className: "dropdown-menu"},
          this.props.survey.polls.map(function(poll) {
            return D.li({key: poll.id, className: "clearfix"}, D.a({href: "#", onClick: this.fetchBreakdowns.bind(this, poll)}, 
              D.small({className: "text-muted pull-right"},
                moment(poll.created_date).calendar()
              ),
              D.span({style: {paddingRight: 100}}, poll.question)
            ))
          }.bind(this))
        )
      )
    )
  },

  render: function() {
    var minHeight = $(window).height() - 120;
    var opacity = this.state.loading ? 0.2 : 1;
    var style = {minHeight: minHeight, opacity: opacity};

    var timelineSettings = this.props.timelineSettings;

    return D.div({className: "Survey"},
      // TODO this.props.survey.name,
      D.header({className: "row"},
        WG.Spinner({
          className: "pull-left", scale: 0.2,
          spinning: this.state.loading,
          onClick: this.fetchBreakdowns.bind(this, this.state.currentPoll)
        }),
        D.div({className: "btn-group pull-right", role: "group"},
          this.renderPollDropdown()
        ),
        D.h2({className: "question", style: {margin: 5}},
          this.state.currentPoll.question
        )
      ),

      WG.Methodology({
        poll: this.state.currentPoll,
        populationSize: this.props.survey.population_size
      }),

      this.props.survey.timeline_setting
        ? WG.ResponseTimeline({
            survey: this.props.survey,
            timelineSettings: timelineSettings
          })
        : null,

      WG.Analysis({
        poll: this.state.currentPoll,
        breakdowns: this.state.breakdowns,
        surveyID: this.props.survey.id,
        style: style,
        loading: this.state.loading
      })
    )
  }

}));

})();