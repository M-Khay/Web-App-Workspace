(function() {

WG = window.WG || {};
var D = React.DOM;
var R = window.Recharts;
var S = window.Searchkit;

// var indexName = "whatsgoodly-breakdowns";
// var host = "https://search-whatsgoodly-o7jwlfxxqyx35d4ehliykxl2f4.us-east-1.es.amazonaws.com/";
// var host = "http://localhost:9200/"; // "http://demo.searchkit.co/api/movies";
S.AxiosESTransport.timeout = 15*1000; // Force timeout to 15 seconds

var SearchkitProvider = React.createFactory(S.SearchkitProvider);
var SearchBox = React.createFactory(S.SearchBox);
var Hits = React.createFactory(S.Hits);
var NoHits = React.createFactory(S.NoHits);
var InitialLoader = React.createFactory(S.InitialLoader);
var Pagination = React.createFactory(S.Pagination);
var HitsStats = React.createFactory(S.HitsStats);
var Layout = React.createFactory(S.Layout);
var LayoutBody = React.createFactory(S.LayoutBody);
var LayoutResults = React.createFactory(S.LayoutResults);
var ActionBar = React.createFactory(S.ActionBar);
var ActionBarRow = React.createFactory(S.ActionBarRow);
var TopBar = React.createFactory(S.TopBar);
var SideBar = React.createFactory(S.SideBar);
var ViewSwitcherToggle = React.createFactory(S.ViewSwitcherToggle);
var SortingSelector = React.createFactory(S.SortingSelector);
var MenuFilter = React.createFactory(S.MenuFilter);
var ItemList = React.createFactory(S.ItemList);
var CheckboxItemList = React.createFactory(S.CheckboxItemList);
var ItemHistogramList = React.createFactory(S.ItemHistogramList);
var TagCloud = React.createFactory(S.TagCloud);
var TagFilterList = React.createFactory(S.TagFilterList);
var Toggle = React.createFactory(S.Toggle);
var Tabs = React.createFactory(S.Tabs);
var Select = React.createFactory(S.Select);
var InputFilter = React.createFactory(S.InputFilter);
var HierarchicalRefinementFilter = React.createFactory(S.HierarchicalRefinementFilter);
var RefinementListFilter = React.createFactory(S.RefinementListFilter);
var RangeFilter = React.createFactory(S.RangeFilter);
var DynamicRangeFilter = React.createFactory(S.DynamicRangeFilter);
var GroupedSelectedFilters = React.createFactory(S.GroupedSelectedFilters);
var ResetFilters = React.createFactory(S.ResetFilters);

var MAX_BARS = 5;
var MAX_SEGMENTS = 4;
var MIN_VOTES = 15;
var BLUE = "#1189FB";
var PINK = "#FF6399";
var LIGHT_PURPLE = "#AB7BFF";
var BAR_COLORS = [LIGHT_PURPLE, "#FAA43A", "#F15854", "#4D4D4D", "#60BD68", "#F17CB0", "#B2912F"];

WG.SubscribeButtons = React.createFactory(React.createClass({

  propTypes: {
    poll: React.PropTypes.shape({
        tags: React.PropTypes.arrayOf(React.PropTypes.object),
        question: React.PropTypes.string.isRequired
      }).isRequired
  },

  clickedEmailSubscribe: function(e) {
    var tags = (this.props.poll.tags || []).map(function(t){
        return t.value
      });
    var message = tags.length ?
        "I'm interested in polls tagged #" + tags.join(', #')
      : "I'm interested in polls similar to \"" + this.props.poll.question + "\"";
    $('#subscribeModal').modal()
      .find('#message-text').val(message);
  },

  render: function() {
    return D.div({className: "text-left", style: {marginTop: 10}},
      D.a({href: "https://slack.com/oauth/authorize?scope=incoming-webhook&client_id=3996905789.97854341030"},
        D.img({
          alt: "Add to Slack",
          height: "35",
          width: "115",
          src: "https://platform.slack-edge.com/img/add_to_slack.png",
          srcSet: "https://platform.slack-edge.com/img/add_to_slack.png 1x, https://platform.slack-edge.com/img/add_to_slack@2x.png 2x"
        })
      ),
      D.span({style: {margin: 8}}, "or"),
      D.button({className: "btn btn-default btn-sm", onClick: this.clickedEmailSubscribe},
        D.span({className: "glyphicon glyphicon-envelope left"}),
        "Subscribe"
      )
    )
  }
}));

WG.SearchResult = React.createFactory(React.createClass({

  getColor: function(datum, i) {
    if (datum.gender) {
      return datum.gender == "Male" ? BLUE : PINK;
    } else if (datum.targeting) {
      return datum.targeting == "Male" ? BLUE : PINK;
    }
    return BAR_COLORS[i || 0];
  },

  getBreakdownsFromInnerHits: function() {
    var breakdowns = [];
    var result = this.props.result;
    var innerHitTypes = Object.keys(result.inner_hits || []).sort().filter(function(key) {
      // See fixSearchkitFilter for fix; only use one of the inner hits, like the root
      return key.indexOf("breakdowns__root") == 0;
    });
    if (!innerHitTypes.length) {
      breakdowns = result._source.breakdowns.filter(function(b) {
        // Remove communities and web votes
        return !b.community && b.breakdown_type != 1;
      });
    } else {
      // Use inner hits and include communities in case two are being compared
      innerHitTypes.forEach(function(key) {
        var innerHits = result.inner_hits[key].hits.hits.map(function(hit) {
          return hit._source
        });
        breakdowns = breakdowns.concat(innerHits);
      });
    }
    return breakdowns;
  },

  getGraphData: function(poll, breakdowns, keyFunc) {
    var data = [];

    poll.options.forEach(function(opt, i) {
      var datum = {option: opt};
      breakdowns.forEach(function(breakdown) {
        // console.log(breakdown);
        var count = breakdown.vote_counts[i];
        var key = keyFunc(breakdown);
        datum[key] = count / (breakdown.total || 1);
      });
      data.push(datum);
    });

    return data;
  },

  renderChart: function(poll, breakdowns) {
    var toPercent = function(percent) {
      return percent ? Math.round(percent*100) : "0%";
    };

    var data = this.getGraphData(poll, breakdowns, breakdownName);

    breakdowns = breakdowns.sort(function(a, b) {
      // Descending by total votes
      return b.total - a.total;
    }).slice(0, MAX_BARS);

    return React.createElement(R.ResponsiveContainer, {aspect: 2},
      React.createElement(R.BarChart, {data: data, margin: { top: 10, right: 30, left: -30, bottom: 0 }},
        React.createElement(R.XAxis, {dataKey: "option", type: "category"}),
        React.createElement(R.YAxis, {tickFormatter: toPercent, type: "number"}),
        React.createElement(R.CartesianGrid, {strokeDasharray: "3 3"}),
        React.createElement(R.Tooltip),
        // React.createElement(R.Legend),
        breakdowns.map(function(bdown, i) {
          var formatter = function(val) {
            return Math.round(val * bdown.total) + " votes (" + Math.round(val * 100) + "%)";
          };
          return React.createElement(R.Bar, {
            key: i, dataKey: breakdownName(bdown), fill: this.getColor(bdown, i),
            formatter: formatter
          });
        }.bind(this))
      )
    )
  },

  render() {
    var result = this.props.result;
    // These require additional creds
    var url = "/dashboard/analyze/" + result._id;
    var reportUrl = "/survey/add/" + result._id; // TODO inline on page
    var questionUrl = "/esuohgod/whatsgoodly/poll/" + result._id; // url;
    // Make prefix
    var getPrefix = function(poll) {
        return poll.targeting ? poll.targeting.toUpperCase() + ": " : "";
      };
    var prefix = getPrefix(result._source);
    // Compute breakdowns
    var breakdownsForChart = this.getBreakdownsFromInnerHits();
    // For computing total vote count
    var overallBdown = result._source.breakdowns.filter(function(b){
        return b.breakdown_type == 0;
      })[0];

    var tagValues = (result._source.tags || []).map(function(t){
        return t.value;
      });

    var topSegs = result._source.breakdowns.filter(function(b){
        return !!b.segmenter;
      }).sort(function(a, b) {
        return b.total - a.total;
      });
      
    var topSegmentSummary = getBreakdownLabelsTruncated(topSegs).join(', ');

    var outlierSegs = result._source.breakdowns.filter(function(b){
        return !b.community && b.breakdown_type != 0 && b.breakdown_type != 1;
      }).sort(function(a, b) {
        return b.abnormality - a.abnormality;
      }).slice(0, MAX_SEGMENTS);

    var outlierSegmentSummary = getBreakdownLabelsTruncated(outlierSegs).join(', ');

    var communities = result._source.breakdowns.filter(function(b){
        return !!b.community;
      }).sort(function(a, b) {
        return b.total - a.total;
      });

    var communityValues = getBreakdownLabelsTruncated(communities);

    return (
      D.div({className: "row " + this.props.bemBlocks.item().mix(this.props.bemBlocks.container("item")),
             key:result._id},

        D.div({className: "col-xs-12 " + this.props.bemBlocks.item("title")},
          D.div({className: "btn-group pull-right"},
            D.a({className: "btn btn-default btn-sm", href: url, target:"_blank" },
              D.span({className: "glyphicon glyphicon-signal left"}),
              "Analyze"
            ),
            D.a({className: "btn btn-default btn-sm", href: reportUrl, target:"_blank" },
              D.span({className: "glyphicon glyphicon-plus left"}),
              "Add to Survey"
            )
          ),
          D.a({href:questionUrl, target:"_blank"},
            D.span({style: {color: this.getColor(result._source)}}, prefix),
            result._source.question
          )
        ),
        D.div({className: "col-sm-5 col-xs-12"},
          D.div({style: {marginTop: 5, fontSize: 12}},
            D.label({style: {color: LIGHT_PURPLE, textTransform: "uppercase"}},
              WG.utils.numberWithCommas(overallBdown.total) + " votes"
              // TODO
              // "\u00a0\u00a0",
              // WG.MethodologyTooltip({poll: })
            ),
            D.span({className: "text-muted", style: {margin: "0 8px"}}, "•"),
            D.small({className: "text-muted"},
              moment(result._source.created_date).calendar()
            )
          ),
          D.div({className: "well well-simple well-start", style: {marginTop: 10}},
            D.div({style: {marginTop: 0}},
              D.strong({}, "Tags: "),
              tagValues.length ?
                TagFilterList({
                  field: "tags.value",
                  values: tagValues
                })
                : D.i({}, "none")
            ),
            tagValues.length ?
              WG.SubscribeButtons({
                poll: this.props.result._source
              })
              : null
          ),
          D.div({className: "well well-simple well-end", style: {marginTop: 0}},
            D.div({className: "sk-segment-filter-list", style: {marginTop: 5}},
              D.strong({}, "Schools: "),
              TagFilterList({
                field: "breakdowns.community.name.raw",
                values: communityValues
              })
            ),
            D.div({className: "sk-segment-filter-list", style: {marginTop: 5}},
              D.strong({}, "Top Segments: "),
              // TagFilterList({
              //   field: "breakdowns.segmenter.segment_label.raw",
              topSegmentSummary
            ),
            D.div({className: "sk-segment-filter-list", style: {marginTop: 5}},
              D.strong({}, "Outlier Segments: "),
              // TagFilterList({
              //   field: "breakdowns.segmenter.segment_label.raw",
              outlierSegmentSummary
            ),
            !tagValues.length ?
              WG.SubscribeButtons({
                poll: this.props.result._source
              })
              : null
          )
        ),
        D.div({className: "col-sm-7 col-xs-12", style: {marginTop: 10}},
          this.renderChart(result._source, breakdownsForChart)
        )
      )
    )
  }
}));

WG.SearchFullscreen = React.createFactory(React.createClass({

  propTypes: {
    initialTags: React.PropTypes.arrayOf(React.PropTypes.string),
    host: React.PropTypes.string.isRequired,
    indexName: React.PropTypes.string.isRequired
  },

  getDefaultProps: function() {
    return {
      initialTags: []
    }
  },

  getInitialState: function() {
    return {
      submitting: false,
      isTrending: false,
      loading: false,
      emailValid: false
    };
  },

  componentWillUnmount: function() {
    this.searchkitUnsub();
  },

  componentWillMount: function() {
    var searchOnLoad = !this.props.initialTags.length || location.search;
    this.searchkit = new S.SearchkitManager(this.props.host + this.props.indexName, {
      searchOnLoad: searchOnLoad
    });
    // Set initial tags
    if (!searchOnLoad) {
      var q = {"poll-tags": this.props.initialTags};
      // TODO listen to registration, not timeout
      setTimeout(function() {
        this.searchkit.searchFromUrlQuery(q);
      }.bind(this), 1);
    }

    // Fix bugs in Searchkit for ES2.3
    this.searchkit.setQueryProcessor(function(plainQueryObject) {
      for (var key in plainQueryObject.aggs) {
        WG.utils.fixSearchkitFilter(plainQueryObject.aggs[key].filter, key);
      }
      WG.utils.fixSearchkitFilter(plainQueryObject.filter);
      WG.utils.fixSearchkitQuery(plainQueryObject.query);

      // See if this is trending
      var isTrending = false;
      var isRecent = plainQueryObject.sort && plainQueryObject.sort.filter(function(sort) {
          return sort.created_date == "desc";
        }).length > 0;
      var isSignificant = WG.utils.find(plainQueryObject, 'breakdowns.total').filter(function(f) {
          return f.gte >= MIN_VOTES*3;
        }).length > 0;
      if (isRecent && isSignificant) {
        isTrending = true;
      }

      this.setState({isTrending: isTrending, loading: true});
      return plainQueryObject;
    }.bind(this));

    this.searchkitUnsub = this.searchkit.addResultsListener(function(results) {
      this.setState({loading: false});
    }.bind(this));

    // Only get polls with min votes
    this.searchkit.addDefaultQuery(function(query) {
      return query.addQuery({
        "nested":{
          "path": "breakdowns",
          "filter":{
            "range": {
              "breakdowns.total": { gte: MIN_VOTES}
            }
          }
        }
      })
    });

    // Only get polls with a tag
    // this.searchkit.addDefaultQuery(function(query) {
    //   return query.addQuery({
    //     "nested":{
    //       "path": "tags",
    //       "filter":{
    //         "exists":{"field":"tags.value"}
    //       }
    //     }
    //   })
    // });
  },

  submitSubscribe: function() {
    this.setState({submitting: true});
    $.post("/sales/contact/", {
        email: this.state.contactEmail,
        message: this.state.contactMessage})
      .done(function(data) {
          $("#subscribeModal").modal('hide');
        }.bind(this))
      .fail(function(xhr, status, err) {
          alert(err);
        }.bind(this))
      .always(function() {
          this.setState({submitting: false});
        }.bind(this))
  },

  search: function(simpleQueryObject) {
    var q = $.extend({}, this.searchkit.state, simpleQueryObject);
    this.searchkit.searchFromUrlQuery(q);
    this.searchkit.history.push({pathname: window.location.pathname, query:this.searchkit.state});
  },

  renderSubscribeModal: function() {
    var changeEmail = function(e) {
      this.setState({
        contactEmail: e.target.value,
        emailValid: WG.utils.isValidEmail(e.target.value)
      });
    }.bind(this);

    var changeMessage = function(e) {
      this.setState({contactMessage: e.target.value});
    }.bind(this);

    var checkmarkStyle = {
      position: "absolute",
      right: 18,
      top: 45,
      height: 40,
      width: 40
    };

    return (
      D.div({className: "modal fade", role: "dialog", id: "subscribeModal"},
        D.div({className: "modal-dialog", role: "document"},
          D.div({className: "modal-content"},
            D.div({className: "modal-header"},
              D.button({className: "close", "data-dismiss": "modal"},
                D.span({}, "×")
              ),
              D.h4({className: "modal-title", id: "exampleModalLabel"}, "Contact sales to get started!")
            ),
            D.div({className: "modal-body"},
              D.form({style: {paddingRight: 25}},
                D.div({className: "form-group"},
                  this.state.emailValid ?
                    WG.Checkmark({style: checkmarkStyle})
                    : null,
                  D.label({htmlFor: "recipient-email", className: "control-label"}, "Your email:"),
                  D.input({onChange: changeEmail, defaultValue: this.state.contactEmail, className: "form-control", type: "email", id: "recipient-email", placeholder: "you@company.com"})
                ),
                D.div({className: "form-group"},
                  D.label({htmlFor: "message-text", className: "control-label"}, "Message (optional):"),
                  D.textarea({onChange: changeMessage, defaultValue: this.state.contactMessage, className: "form-control", id: "message-text"})
                )
              )
            ),
            D.div({className: "modal-footer"},
              D.button({className: "btn btn-default", 'data-dismiss': "modal"}, "Close"),
              D.button({
                  className: "btn btn-primary " + (this.state.submitting ? "disabled" : ""),
                  onClick: this.submitSubscribe},
                this.state.submitting ? "Sending" : "Set me up"
              )
            )
          )
        )
      )
    )
  },

  render: function() {

    var sortingOptions = [
      {label:"Most Votes", key: "votes", fields: [{
          field: "breakdowns.total", options: {
            order:"desc", mode: "max", "nested_path": "breakdowns"
          }
        }], defaultOption:true},
      {label:"Most Recent", field:"created_date", order:"desc"},
      {label:"Most Relevant", field:"_score", order:"desc"}
    ];

    var onTrendingClick = function(e) {
      var q = this.state.isTrending ? {
          total : {},
          sort: null
        } : {
          total: {min: MIN_VOTES*3},
          sort: "created_date_desc"
        };
      this.search(q);
    }.bind(this);

    return D.div({className: "SearchFullscreen"},
      this.renderSubscribeModal(),
      SearchkitProvider({ searchkit: this.searchkit },
        Layout({size: "l"},
          TopBar({},
            SearchBox({
              autofocus: true,
              searchOnChange: false,
              placeholder: "Search polls and segments",
              queryFields: ["question^3", "options", "breakdowns.segmenter.question",
                "breakdowns.segmenter.segment_label^2", "breakdowns.community.name^2",
                "breakdowns.community.name_short^2"],
              prefixQueryFields: ["question^4", "breakdowns.community.name", "breakdowns.community.name_short^2", "breakdowns.segmenter.segment_label^2"]
            })
          ),
          LayoutBody({},
            SideBar({},
              DynamicRangeFilter({
                field:"breakdowns.total",
                id:"total",
                title:"Vote Count",
                fieldOptions: {type:'nested', options:{path:'breakdowns', inner_hits: {
                  // name: 'breakdown_total_hits'
                }}}
              }),
              RefinementListFilter({
                field: "breakdowns.gender.raw",
                title: "Gender Segments",
                id: "gender",
                operator: "AND",
                size: 5,
                listComponent: ItemHistogramList,
                fieldOptions: {type:'nested', options:{path:'breakdowns', inner_hits: {
                  // name: 'breakdown_gender_hits'
                }}}
              }),
              HierarchicalRefinementFilter({
                field: "tags",
                title: "Categories",
                id: "categories",
              }),
              // // <DateRangeFilter 
              // // id="date"
              // // field="created_date"
              // // title="Date"
              // // min={2005} 
              // // max={new Date().getFullYear()} 
              // // interval="week"
              // // showHistogram={true} />
              // InputFilter({
              //   id: "segment-input",
              //   title: "Other Segments",
              //   prefixQueryFields: ["breakdowns.segmenter.segment_label"],
              //   queryFields: ["breakdowns.segmenter.segment_label^3", "breakdowns.segmenter.question"],
              //   searchOnChange: true
              // }),
              // RefinementListFilter({
              //   id: "segments",
              //   title: "Segment",
              //   field: "breakdowns.segmenter.segment_label.raw",
              //   operator: "AND",
              //   size: 5,
              //   listComponent: ItemHistogramList,
              //   fieldOptions: {type:'nested', options:{path:'breakdowns', inner_hits: {
              //     // name: 'breakdown_segment_hits'
              //   }}}
              // }),
              RefinementListFilter({
                field: "breakdowns.community.name.raw",
                title: "Schools",
                id: "community",
                operator: "AND",
                size: 5,
                listComponent: ItemHistogramList,
                fieldOptions: {type:'nested', options:{path:'breakdowns', inner_hits: {
                  // name: 'breakdown_community_hits'
                }}}
              }),
              RefinementListFilter({
                id: "poll-tags",
                title: "Tags",
                field: "tags.value",
                operator: "OR",
                size: 5,
                fieldOptions: {type:'nested', options:{path:'tags', inner_hits: {
                }}}
                // listComponent: ItemHistogramList
              }),
              // // RefinementListFilter({
              // //   id: "segmenter-tags",
              // //   title: "Segment Tags",
              // //   field: "segmenter.tags",
              // //   operator: "OR",
              // //   size: 5,
              // //   listComponent: ItemHistogramList
              // // }),
              RangeFilter({
                min:0,
                max:100,
                field:"breakdowns.abnormality",
                id:"abnormality",
                showHistogram:true,
                title:"Deviation from Mean",
                fieldOptions: {type:'nested', options:{path:'breakdowns', inner_hits: {
                  // name: 'breakdown_abnormality_hits'
                }}},
                interval: 5,
                rangeFormatter: function(number) {
                  return Math.round(number) + "%";
                }
              })
            ),
            LayoutResults({},
              ActionBar({},
                ActionBarRow({},
                  HitsStats(),
                  // ViewSwitcherToggle(),
                  D.button({className: "btn btn-sm btn-default " + (this.state.isTrending ? "active" : ""),
                      onClick: onTrendingClick},
                    D.span({className: "glyphicon glyphicon-fire left"}),
                    "Trending"
                  ),
                  SortingSelector({
                    options: sortingOptions
                    // listComponent: Toggle
                  })
                ),
                ActionBarRow({},
                  GroupedSelectedFilters(),
                  ResetFilters()
                )
              ),
              D.div({style: {opacity: this.state.loading ? 0.2 : 1}},
                Hits({
                  mod: "sk-hits-list",
                  hitsPerPage: 10,
                  itemComponent: WG.SearchResult,
                  // TODO
                  // highlightFields: ["targeting", "question", "options", "breakdowns.segmenter.segment_label"],
                  // sourceFilter: ["question", "options", "segmenter.segment_option"]
                }),
                NoHits({suggestionsField: "question"})
              ),
              // InitialLoader({component: function(props) { return WG.Spinner({scale: 0.4}) }}),
              this.state.loading ?
                WG.Spinner({scale: 0.4})
                : null,
              Pagination({showNumbers: true})
            )
          )
        )
      )
    )
  }
}));

function breakdownName(b) {
  if (b.segmenter) {
    return b.segmenter.segment_label;
  }
  if (b.community) {
    return b.community.name;
  }
  if (b.breakdown_type == 1) {
    return "[Web votes]";
  }
  if (b.gender) {
    return b.gender;
  }
  return "OVERALL";
}

function getBreakdownLabelsTruncated(segs) {
  var labels = segs.map(breakdownName);
  var numSegs = segs.length;
  var values = WG.utils.uniq(labels).slice(0, MAX_SEGMENTS + 1).map(function(label, i){
    if (i >= MAX_SEGMENTS) {
      return "and " + (numSegs - MAX_SEGMENTS) + " others";
    }
    return label;
  });
  return values; // .join(', ');
}

})();