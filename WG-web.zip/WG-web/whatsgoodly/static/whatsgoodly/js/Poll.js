var SCHOOL_FEED_ICON_URL = "https://d2tyav66cc90rz.cloudfront.net/school_icon_tintable.png";

var D = React.DOM;

WG.Poll = React.createFactory(React.createClass({

  propTypes: {
    poll: React.PropTypes.shape({
        id: React.PropTypes.number.isRequired,
        poll_id: React.PropTypes.number.isRequired,
        question: React.PropTypes.string.isRequired,
        picture_question: React.PropTypes.string,
        user: React.PropTypes.shape({
          university_short: React.PropTypes.string
        }).isRequired,
        response: React.PropTypes.object,
        margin_of_error: React.PropTypes.number.isRequired
      }).isRequired,

    theme: React.PropTypes.object,

    showResults: React.PropTypes.bool,

    // TODO
    showAsCard: React.PropTypes.bool
  },

  isInstance: function() {
    return this.props.poll.id != this.props.poll.poll_id
  },

  getDefaultProps: function() {
    return {
      theme: WG.themes.choices.DEFAULT
    }
  },

  onRender: function(elem) {
    if (!elem) return;
    $(function () {
      $(elem).find('[data-toggle="tooltip"]').tooltip({
        html: true,
        trigger: "click"
      });
    });
  },

  getResponseCount: function() {
    var count = this.props.poll
      .option_counts
      .reduce(function(a, b) { return a + b }, 0);

    return count;
  },

  shouldShowResults: function() {
    if (this.props.showResults || this.props.poll.response != null) {
      return true;
    }

    var user = WG.utils.getUser();
    var forOtherGender = user &&
      this.props.poll.gender != user.gender &&
      user.gender != WG.constants.User.NOT_CHOSEN &&
      this.props.poll.gender != WG.constants.Poll.ALL;
    
    return forOtherGender;
  },

  getPollUrl: function() {
    var p = this.props.poll;
    return window.location.protocol + "//" + window.location.host + "/poll/" + p.poll_id + "/";
  },

  getShareTooltip: function() {
    var url = this.getPollUrl();
    return "COPY AND SHARE" + "<br/><br/>" +
      url + "<br/><br/>" +
      "OR EMBED" + "<br/><br/>" + 
      "<input type='text' value='&lt;iframe src=\"" + url +
        "\" height=\"450\" width=\"367\" frameborder=\"0\"&gt;&lt;/iframe&gt;' />";
  },

  getCommentTooltip: function() {
    var url = this.getPollUrl();
    return "See comments on the app" + "<br/><br/>" +
      "<a class='btn btn-transparent' href='" + WG.constants.BRANCH_LINK + "'>Get it</a><br/><br/>" +
      (this.isInstance() ? "" : "*This count combines all schools with the poll.");
  },

  renderBanner: function() {
    var p = this.props.poll;
    var voteTotal = this.getResponseCount();
    var suffix = voteTotal == 1 ? " vote" : " votes";
    var createdDate = moment(p.created_date).fromNow();
    var genderClass = p.gender == 0 ? 'text-blue' :
                      p.gender == 1 ? 'text-pink' : 'text-purple';

    return (
      D.div({className: "banner text-muted"},
        D.span({className: "vote-count " + genderClass},
          D.strong({}, voteTotal + suffix),
          "\u00a0\u00a0",
          WG.MethodologyTooltip({poll: p})
        ),
        p.banner
          ? p.banner + " • "
          : "",
        !p.banner && !p.feed && p.user.university_short
          ? p.user.university_short + " • "
          : "",
        createdDate,
        "\u00a0 • \u00a0",
        D.a({"data-toggle":"tooltip", "data-placement":"top",
              title: this.getCommentTooltip()},
          D.span({className: "glyphicon glyphicon-comment"}),
          "\u00a0\u00a0",
          p.comment_count
        ),
        "\u00a0 • \u00a0",
        D.a({"data-toggle":"tooltip", "data-placement":"top",
             title:this.getShareTooltip()},
          D.span({className: "glyphicon glyphicon-share"})
        )
      )
    )
  },

  renderFeedBanner: function() {
    var p = this.props.poll;
    // FOR TESTING
    // p.user.university_color = "#C4444E";
    // p.user.university_name = "Stanford University";
    var uni_style = p.user.university_color ? {
      borderRadius: 100,
      backgroundColor: p.user.university_color
    } : null;

    return (
      D.p({className: this.props.theme.POLL_BANNER_CLASS },
        p.feed.category == WG.constants.Feed.LOCAL && p.user.university_short
          ? D.span({},
              D.img({style: uni_style, src: SCHOOL_FEED_ICON_URL}),
              D.span({className: "Poll--school" },
                p.user.university_name
              )
            )
          : D.span({},
              D.img({src: p.feed.image_source}),
              p.feed.name
            )
      )
    )
  },

  renderOption: function(option, index) {
    var p = this.props.poll;
    var total = this.getResponseCount() || 1;
    var count = p.option_counts[index];
    var percentage = parseInt(count*100/total);
    var barWidth = this.shouldShowResults() ? percentage : 0;
    var genderClass = p.gender == 0 ? 'bg-blue' :
                      p.gender == 1 ? 'bg-pink' :
                      this.props.theme.OPTION_CLASS;

    var handleOptionSelect = function() {
      // TODO: if wrong gender, still send event to show popup?
      if (!this.shouldShowResults()) {
        PubSub.publish(WG.actions.VOTE_ON_POLL, {
          pollID: p.id,
          response: index
        });
      }
    }.bind(this);

    return (
      D.li({key:index, onClick:handleOptionSelect},
        D.div({className: "inset-shadow"}),
        D.div({className: "option"}, option),
        this.shouldShowResults() ?
          D.div({className: "percentage"},
            p.response && p.response.response == index ?
              D.img({src: this.props.theme.VOTE_MARK_URL})
              : null,
            percentage +"%"
          )
          : null,
        D.div({className: "bar " + genderClass,
               style: {width: barWidth + "%"}})
      )
    )
  },

  render: function() {
    var prefix, genderClass,
        p = this.props.poll;
        
    if (p.gender == 0) {
      prefix = 'Guys:';
      genderClass = 'text-blue';
    } else if (p.gender == 1) {
      prefix = 'Girls:';
      genderClass = 'text-pink';
    } else {
      prefix = '';
      genderClass = '';
    }

    return (
      D.div({className: "Poll clearfix " +
                        (this.shouldShowResults() ? "voted" : ""),
             ref: this.onRender},
        p.feed
          ? this.renderFeedBanner()
          : null,

        D.div({className: "question"},
          D.span({className: "prefix " + genderClass}, prefix),
          " " + p.question,
          p.picture_question?
            D.div({className: "question"},
              D.img({src: p.picture_question})
            )
          : null
        ),

        D.ul({},
          p.options.map(this.renderOption)
        ),

        this.renderBanner()
      )
    )
  }
}));
