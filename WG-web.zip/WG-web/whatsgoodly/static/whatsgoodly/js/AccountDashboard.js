(function() {

var D = React.DOM;
var ACTION_RENDER_BREAKDOWNS = "ACTION_RENDER_BREAKDOWNS";
var ACTION_SET_LOADING = "ACTION_SET_LOADING";

var GOOGLE_FORM_LINK = "https://docs.google.com/a/whatsgoodly.com/forms/d/e/1FAIpQLSfWK-dVof1zJ6j3cq17je6OcYajPlrI015ug0TpXm7k5EDqVA/viewform";

WG.AccountDashboard = React.createFactory(React.createClass({

  propTypes: {
    account: React.PropTypes.shape({
      name: React.PropTypes.string.isRequired,
      surveys: React.PropTypes.arrayOf(
        React.PropTypes.shape({
          id: React.PropTypes.number.isRequired,
          name: React.PropTypes.string.isRequired,
          polls: React.PropTypes.arrayOf(React.PropTypes.shape({
            id: React.PropTypes.number.isRequired,
            question: React.PropTypes.string.isRequired
          }).isRequired).isRequired,
          feed: React.PropTypes.shape({
            image_source: React.PropTypes.string.isRequired
          }),
          timeline_setting: React.PropTypes.number.isRequired
        }).isRequired
      ).isRequired
    }),
    timelineSettings: React.PropTypes.object
  },

  getInitialState: function() {
    return {
      currentSurvey: null,
      forcePollViewOnSurveyIDs: {}
    }
  },

  renderSurveysPlaceholder: function() {
    return (
      D.div({className: "AccountDashboard--placeholder row bg-purple text-center jumbotron"},
        D.div({className: "container container-sm"},
          D.h2({}, "No surveys yet!"),
          D.img({src: "/static/img/FullDogWhite.png"}),
          D.br(),
          D.br(),
          D.a({href: "mailto:adam@whatsgoodly.com", className: "btn btn-default btn-lg"},
            "Request your first survey"
          )
        )
      )
    )
  },

  comingSoon: function() {
    PubSub.publish(WG.actions.SHOW_WARNING, "Coming soon! email alex@whatsgoodly.com in the meantime");
  },

  toggleView: function(survey) {
    var settings = this.state.forcePollViewOnSurveyIDs;
    if (survey.id in settings) {
      delete settings[survey.id];
    } else {
      settings[survey.id] = true;
    }
    this.setState({forcePollViewOnSurveyIDs: settings});
  },

  // TODO
  toggleFullScreen: function() {
    var elem = $('#analyzeModal')[0];
    var rfs = elem.requestFullscreen
        || elem.webkitRequestFullscreen
        || elem.mozRequestFullScreen
        || elem.msRequestFullscreen;
    var check = document.fullscreenElement
        || document.webkitFullscreenElement
        || document.mozFullScreenElement
        || document.msFullscreenElement;
    var exit = document.exitFullscreen
        || document.webkitExitFullscreen
        || document.mozCancelFullScreen
        || document.msExitFullscreen;
    if (!check) {
      rfs.call(elem);
    }
  },

  renderSurveyStats: function(survey) {
    var totalPolls = WG.utils.uniq(survey.polls, function(pi){return pi.poll}).length;
    var totalResponses = survey.polls.reduce(function(sum, pi) {
      return sum + WG.utils.getResponseCount(pi);
    }, 0);
    var totalComments = survey.polls.reduce(function(sum, pi) {
      return sum + pi.comment_count;
    }, 0);

    return (
      D.small({style: {opacity: 0.5}},
        "Updated ",
        D.strong({},
          moment().subtract(1, 'day').format("MMM Do")
        ),

        D.span({style:{margin: "0 8px"}}, "|"),
        D.strong({}, totalPolls),
        " question" + (totalPolls == 1 ? "" : "s"),

        D.span({style:{margin: "0 8px"}}, "|"),
        D.strong({}, WG.utils.numberWithCommas(totalResponses)),
        " response" + (totalResponses == 1 ? "" : "s"),

        D.span({style:{margin: "0 8px"}}, "|"),
        D.strong({}, WG.utils.numberWithCommas(totalComments)),
        " comment" + (totalComments == 1 ? "" : "s")
      )
    )
  },

  renderSurvey: function(survey, surveyIndex) {

    var pollWrapperStyle = {
      width: 330,
      maxHeight: 330,
      marginRight: 10,
      display: "inline-block",
      verticalAlign: "top",
      overflowY: "auto"
    };

    var surveyPath = "survey/" + (survey.name_url || survey.id);

    var onAnalyzeClick = function () {
      this.setState({currentSurvey: survey}, function() {
        $('#analyzeModal').modal();
      });
    }.bind(this);

    var showTimeline = !!survey.timeline_setting;
    if (survey.id in this.state.forcePollViewOnSurveyIDs) {
      showTimeline = false;
    }

    var timelineSettings = this.props.timelineSettings;

    return (
      D.div({className: "AccountDashboard--Survey row", key: survey.id},
        D.div({className: "panel panel-default"},
          D.div({className: "panel-heading"},
            D.button({className: "btn btn-default pull-right btn-end", onClick: onAnalyzeClick},
              D.span({className: "glyphicon glyphicon-signal left"}),
              "Analyze"
            ),
            D.a({className: "btn btn-default pull-right btn-middle", target: "_blank", href: surveyPath},
              D.span({className: "glyphicon glyphicon-new-window left"}),
              "View"
            ),
            D.a({className: "btn btn-default pull-right btn-start", href: "#", onClick: this.comingSoon},
              D.span({className: "glyphicon glyphicon-pencil left"}),
              "Edit"
            ),
            D.span({className: "panel-title", style: {marginRight: 10}},
              D.a({href: "#", onClick: onAnalyzeClick},
                survey.feed ?
                  D.img({src: survey.feed.image_source})
                  : null,
                survey.name
              )
            ),
            this.renderSurveyStats(survey)
          ),
          D.div({className: "panel-body"},

            showTimeline
              ? 
              WG.ResponseTimeline({
                survey: survey,
                timelineSettings: timelineSettings
              })
              :
              D.div({style: {width: "auto", whiteSpace: "nowrap", overflowX: "auto"}},
                survey.polls.map(function(poll) {
                  return D.div({style: pollWrapperStyle, key: poll.id},
                    WG.Poll({
                      poll: poll,
                      showResults: true,
                      // theme: WG.themes.choices.MINIMAL
                    })
                  )
                })
              ),

            survey.timeline_setting ?
              D.div({className: "btn-group pull-right"},
                D.button({className: "btn btn-default btn-xs " + (showTimeline ? "active" : ""),
                          onClick: this.toggleView.bind(this, survey) },
                  D.span({className: "glyphicon glyphicon-time left"}),
                  "Show Timeline"
                ),
                D.button({className: "btn btn-default btn-xs " + (showTimeline ? "" : "active"),
                          onClick: this.toggleView.bind(this, survey) },
                  D.span({className: "glyphicon glyphicon-signal left"}),
                  "Show Polls"
                )
              )
              : null
          )
        )
      )
    )
  },

  renderModal: function() {

    var survey = this.state.currentSurvey
      ? $.extend({}, this.state.currentSurvey, {
        // Modify polls to use poll_id instead of poll_instance_id
          polls: this.state.currentSurvey.polls.map(function(pi) {
            return $.extend({}, pi, {id: pi.poll});
          })
        })
      : null;
    var surveyID = survey ? survey.id : null;

    return (
      D.div({className: "modal fade", role: "dialog", id: "analyzeModal"},
        D.div({className: "modal-dialog modal-lg", role: "document"},
          D.div({className: "modal-content"},
            D.div({className: "modal-header"},
              D.button({className: "close", "data-dismiss": "modal"},
                D.span({}, "×")
              ),
              D.h4({className: "modal-title"},
                D.a({className: "btn btn-default pull-right left", target: "_blank", href: "/survey/" + surveyID },
                  D.span({className: "glyphicon glyphicon-fullscreen left"}),
                  "Fullscreen"
                ),
                survey ?
                  survey.name
                : null
              )
            ),
            D.div({className: "modal-body"},
              D.div({className: ""},
                survey ?
                  WG.Survey({
                    survey: survey,
                    timelineSettings: this.props.timelineSettings
                  })
                : null
              )
            )
          )
        )
      )
    )
  },

  render: function() {

    return D.div({className: "AccountDashboard container"},
      this.renderModal(),

      D.div({className: "row vertical-align"},
        D.div({style: {marginRight: "auto"}},
          D.h1({className: "text-left"},
            this.props.account.name,
            D.small({className: "right", style: {opacity: 0.6, fontFamily: "Gotham-Light"}},
              "Survey Dashboard"
            )
          )
        ),
        D.button({className: "btn btn-default disabled", onClick: this.comingSoon}, // target: "_blank", href: GOOGLE_FORM_LINK},
          D.span({className: "glyphicon glyphicon-plus left"}),
          "New"
        )
      ),
      this.props.account.surveys.length
        ? this.props.account.surveys.map(this.renderSurvey)
        : this.renderSurveysPlaceholder()
    )
  }

}));

})();