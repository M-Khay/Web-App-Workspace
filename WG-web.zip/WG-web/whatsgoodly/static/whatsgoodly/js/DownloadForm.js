$(function DownloadForm() {
  var $this = $(".DownloadForm");
  var $input = $this.find('.phone_input');
  var $submitBtn = $this.find('.phone_input_submit').html('Send');

  var ORIGINAL_INPUT_PLACEHOLDER = $input.attr("placeholder");
  var FOCUSED_INPUT_PLACEHOLDER = "XXX XXX XXXX";

  PubSub.subscribe(WG.actions.FOCUS_GET_APP, function() {
    $("html,body").animate({scrollTop: 0}, 600, function() {
      $input.focus();
    });
  });

  setTimeout(function() {
    $input.attr("disabled", null);
  }, 100);

  $input.on("focus", handleFocus).on("blur", handleBlur);
  $this.on("submit", handleSubmit);

  function handleSubmit(e) {
    e.preventDefault();
    $submitBtn.html('Sending...');
    
    var phone = $input.val().trim();

    var options = { make_new_link: false }; // Link made in branch.js
    var linkData = { feature: "custom_sms_field", data: WG.utils.getDeeplinkData() };
    branch.sendSMS(phone, linkData, options, handleBranchResult);
  }

  function handleFocus() {
    $input.attr('placeholder', FOCUSED_INPUT_PLACEHOLDER);
    $input.siblings('.Tooltip').addClass('active');
    $input.addClass("active");
    $submitBtn.removeClass('collapsed-x');
  }

  function handleBlur() {
    $input.attr('placeholder', ORIGINAL_INPUT_PLACEHOLDER);
    setTimeout(function() {
      // Delay to allow link clicks
      $input.siblings('.Tooltip').removeClass('active');
    }, 100);
    if (!$input.val()) {
      $input.removeClass("active");
    }
  }

  function handleBranchResult(err, result) {
    $submitBtn.addClass('collapsed-x');
    if (err) {
      PubSub.publish(WG.actions.SHOW_WARNING, 'Sorry something went wrong. Please make sure you entered your number correctly!');
      $submitBtn.html('Try Again');
    } else {
      PubSub.publish(WG.actions.SHOW_SUCCESS, 'Download link sent!');
      $submitBtn.html('Send Another');
    }
  }
});
