// TODO: for Alex: convert this to React (and the index.html content)

$(function StickyTop() {

  var $this = $(".StickyTop");
  var $header = $("header");
  var $logoDog = $this.find('.StickyTop--logo');
  var $propeller = $this.find(".StickyTop--propeller");
  var $nav = $("#navbar");
  $("#logo-colored, .StickyTop--nav").css({
    opacity: 0
  });

  var $navHeader = $nav.prev('.navbar-header');

  var CONTENT_OFFSET_INITIAL = $(window).height() - WG.constants.NAVBAR_HEIGHT;
  var spinInterval = setInterval(spinPropeller, 4000);
  var slowdownTimeout;

  $logoDog.on("click", handleDogClick);
  $(window).on("scroll.StickyTop", didChangeTopOffset);

  $this.parent().css({
    marginTop: CONTENT_OFFSET_INITIAL,
  });

  if (window.branch) {
    branch.addListener('didShowBanner', function() {
      $this.parent().css({
        marginTop: CONTENT_OFFSET_INITIAL - WG.constants.BRANCH_BANNER_HEIGHT,
      });
    });
  }

  PubSub.subscribe(WG.actions.ACTIVATE_SEARCH, function(topic, searchBarOffset) {
    // searchBarOffset = searchBarOffset || 0;
    $this.add($header).addClass('search-active');
  });

  PubSub.subscribe(WG.actions.DEACTIVATE_SEARCH, function() {
    $this.add($header).removeClass('search-active');
    // $this.parent().css({
    //   marginTop: CONTENT_OFFSET_INITIAL,
    // });
  });
  
  function spinPropeller() {
    $propeller.toggleClass("spin");
  }

  function handleDogClick() {
    var scroll = $(window).scrollTop();
    var threshold = $this.parent().offset().top - 150;
    var newScroll = scroll >= threshold ? 0 : threshold;
    $("html, body").animate({ scrollTop: newScroll }, 600);
  }

  function didChangeTopOffset() {
    var contentOffset = $this.parent().offset().top;
    var scroll = $(window).scrollTop();
    var threshold = $(window).height() / 1.2;
    var opacity = Math.min(scroll / threshold, 1);
    var filter = "brightness(" + opacity + ") invert(" + (1-opacity) + ")";
    // var zoomLevel = Math.max((threshold - scroll)/threshold, 0.5);
    // var topLevel = 120*(1/zoomLevel - 1);
    // $this.css({zoom: zoomLevel, top: topLevel});

    $("#logo-colored").css({opacity: opacity});
    $("#logo-white").css({opacity: 1-opacity});
    $("#logo-propeller")
      .css({filter: filter, webkitFilter: filter, mozFilter: filter});

    clearInterval(spinInterval);
    clearTimeout(slowdownTimeout);

    $propeller.addClass("animated animated-fast");
    slowdownTimeout = setTimeout(function() {
      $propeller.removeClass("animated-fast");
    }, 10);

    if (contentOffset - scroll + $nav.outerHeight() <= 0) {
      $(window)
        .off("scroll.StickyTop");
      // $this.parent().css({paddingTop: $nav.outerHeight()});
      // $this.addClass("fixed");
      $nav.add($navHeader).removeClass("navbar-transparent");
      setTimeout(function() {
        $(window).on("scroll.StickyTop", didChangeTopOffset);
      }, 100);
    } else {
      $nav.add($navHeader).addClass("navbar-transparent");
      // $this.parent().css({paddingTop: 0});
      // $this.removeClass("fixed");
    }
  }
});
