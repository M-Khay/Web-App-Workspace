var D = React.DOM;
var POLLS_URL = "/api/v3/polls/";

WG.PollList = React.createFactory(React.createClass({

  propTypes: {
    initialPolls: React.PropTypes.arrayOf(React.PropTypes.shape({
      id: React.PropTypes.number.isRequired,
      poll_id: React.PropTypes.number.isRequired,
      gender: React.PropTypes.number.isRequired,
      option_counts: React.PropTypes.arrayOf(React.PropTypes.number).isRequired,
      user: React.PropTypes.shape({
        university_short: React.PropTypes.string
      }).isRequired,
    })),

    onlyShowPolls: React.PropTypes.bool,

    theme: React.PropTypes.object
  },

  getInitialState: function() {
    return {
      loading: false,
      polls: this.props.initialPolls || [],
      count: 0,
      isCountEstimated: false,
    }
  },

  componentWillMount: function() {
    this.spinner = new Spinner(WG.constants.SPINNER_SETUP);

    this.listeners = [
      PubSub.subscribe(WG.actions.RENDER_POLLS, function(topic, data) {
        this.setState({
          loading: false,
          polls: data.polls,
          count: data.total_polls || data.total_polls_estimate,
          isCountEstimated: data.total_polls == null &&
            data.total_polls_estimate != null
        })
      }.bind(this)),

      PubSub.subscribe(WG.actions.SHOW_POLL_COUNT, function(topic, data) {
        this.setState({ count: data.total_polls, isCountEstimated: false })
      }.bind(this)),

      PubSub.subscribe(WG.actions.SET_LOADING, function() {
        this.setState({ loading: true })
      }.bind(this)),

      PubSub.subscribe(WG.actions.VOTE_ON_POLL, function(topic, voteData) {
        this.validateAndVote(voteData);
      }.bind(this)),
    ];
  },

  componentWillUnmount: function() {
    this.listeners.map(PubSub.unsubscribe);
  },

  componentDidMount: function() {
    this.parentNode = $(ReactDOM.findDOMNode(this)).parent()[0];
    if (this.state.loading) {
      this.spinner.spin(this.parentNode);
    }
  },

  componentDidUpdate: function(prevProps, prevState) {
    if (this.state.loading && !prevState.loading) {
      this.spinner.spin(this.parentNode);
    }
    if (!this.state.loading) {
      this.spinner.stop();
    }
  },

  filterUnique: function(polls) {
    return polls.filter(function onlyUnique(poll_instance, i, self) {

      var this_poll = poll_instance.poll_id,
          this_uni = poll_instance.user.university_short;

      var foundIndex = -1;
      self.some(function firstPollAtUni(pi, j) {
        if (pi.poll_id == this_poll &&
            pi.user.university_short == this_uni) {
          foundIndex = j;
          return true;
        }
        return false;
      });

      return i == foundIndex;
    });
  },

  validateAndVote: function(voteData) {
    PubSub.unsubscribe(this._userValidationWall);
    var user = WG.utils.getUser();

    // Check signed in
    if (!user) {
      PubSub.publish(WG.actions.CREATE_USER);
      this._userValidationWall = PubSub.subscribe(
        WG.actions.STORED_USER,
        this.validateAndVote.bind(this, voteData)
      );
      return;
    }

    var poll = this.state.polls.filter(function(p){
      return p.id == voteData.pollID;
    })[0];
    if (!poll) {
      console.error(["No poll found for id " + voteData.pollID, this.state.polls]);
      return;
    }

    // Check gender
    if (poll.gender != WG.constants.Poll.ALL &&
        user.gender != poll.gender) {

      if (user.gender == WG.constants.User.NOT_CHOSEN) {
        PubSub.publish(WG.actions.UPDATE_USER);
        this._userValidationWall = PubSub.subscribe(
          WG.actions.STORED_USER,
          this.validateAndVote.bind(this, voteData)
        );
      } else {
        alert("Oops, that poll is for the other gender 💁. We'll show you the results though.");
        this.forceUpdate();
      }
      return;
    }

    // We're valid!
    var body = {response: voteData.response};
    poll.response = body;
    poll.option_counts[voteData.response] += 1;
    this.forceUpdate();
    // Save to server
    $.ajax({
      url: POLLS_URL + poll.id + "/response/new/",
      dataType: 'json',
      type: 'POST',
      contentType: 'application/json',
      data: JSON.stringify(body)
    })
    .done(function(data) {
      PubSub.publish(WG.actions.STORE_USER, data);
    })
    .fail(function(jqXHR) {
      // Forbidden or unauthorized
      if (jqXHR.status == 403 || jqXHR.status == 401) {
        WG.utils.resetUser();
        // Try again
        this.validateAndVote(voteData);
      }
    }.bind(this));
  },

  renderStats: function() {
    var loggedIn = WG.utils.getUser();
    var attrs = {
      className: "text-muted",
      style: {
        textAlign: loggedIn ? "left" : "center",
        marginTop: loggedIn ? 0 : 50,
        transition: "all 0.2s ease",
        opacity: this.state.loading ? 0 : 1
      }
    };

    // Render an empty space if there's no count data
    if (!this.state.count) {
      var actionText = WG.utils.isMobile() ? "Tap" : "Click";
      return D.p(attrs,
        D.small({},
          loggedIn ? "\u00a0" : actionText + " on a grey box to see results"
        )
      );
    }

    var count,
        units,
        estimation = "";

    if (this.state.count > this.state.polls.length) {
      count = this.state.count;
      estimation = " about";
    } else {
      count = this.state.polls.length;
      estimation = " at least";
    }
    units = count == 1 ? "poll" : "polls";

    if (!this.state.isCountEstimated) {
      estimation = "";
    }

    return D.p(attrs,
        D.small({}, "Found" + estimation + " " + count.toLocaleString() +
                    " " + units
      )
    )
  },
  
  render: function() {
    var style = {
      opacity: this.state.loading ? 0.5 : 1
    };

    return (
      D.div({ className: "PollList row", style: style },

        this.props.onlyShowPolls
          ? null
          : this.renderStats(),

        this.state.polls.map(function(poll) {
          return WG.Poll({poll: poll, key: poll.id, showAsCard: this.props.onlyShowPolls, theme: this.props.theme})
        }.bind(this)),

        this.props.onlyShowPolls
          ? null
          : WG.PollListFooter()
      )
    )
  }
}));

WG.PollListFooter = React.createFactory(React.createClass({

  componentWillMount: function() {
    this.listeners = [
      PubSub.subscribe(WG.actions.STORED_USER, function(topic) {
        this.forceUpdate();
      }.bind(this)),
    ];
  },

  componentWillUnmount: function() {
    this.listeners.map(PubSub.unsubscribe);
  },

  render: function() {
    var user = WG.utils.getUser();
    var pointSuffix = "";
    if (user) {
      pointSuffix = user.karma == 1 ? " coin!" : " coins!";
    }

    return (
      D.div({ className: "well well-lg text-center" },
        D.p({},
          "Everyone's opinion in your pocket. See more on the app, for both iPhone and Android!",
          user && user.karma > 0 ?
            D.small({className: "text-muted"},
              D.br(),
              "You already have an account with " + user.karma + pointSuffix
            )
            : null
        ),
        D.a({className: "btn btn-success btn-lg",
             href: WG.constants.BRANCH_LINK},
          "Get the app"
        )
      )
    )
  },
}));
