(function(b,r,a,n,c,h,_,s,d,k){if(!b[n]||!b[n]._q){for(;s<_.length;)c(h,_[s++]);d=r.createElement(a);d.async=1;d.src="https://cdn.branch.io/branch-latest.min.js";k=r.getElementsByTagName(a)[0];k.parentNode.insertBefore(d,k);b[n]=h}})(window,document,"script","branch",function(b,r){b[r]=function(){b._q.push([r,arguments])}},{_q:[],_v:1},"addListener applyCode banner closeBanner creditHistory credits data deepview deepviewCta first getCode init link logout redeem referrals removeListener sendSMS setBranchViewData setIdentity track validateCode".split(" "), 0);

// INIT
branch.init('key_live_mbjwQ61qqWaLiUar0k4hpmapAxgTmZxn', function(err, data) {

  if (err) {
    Raven.captureException(err);
    console.error(err);
    return;
  }

  var initialUser = WG.utils.getUser();
  var isDeepView = WG.constants.POLL_ID || WG.constants.FEED_ID;

  updateBranchLinks();

  PubSub.subscribe(WG.actions.STORED_USER, function(topic, user) {
    if (!!user != !!initialUser ||
        (initialUser && user && initialUser.id != user.id)) {
      // User changed
      initialUser = user;
      updateBranchLinks();
    }
  });

  function updateBranchLinks() {

    var stage = initialUser ? 'web user' : 'no web user';

    branch.link({
        channel: 'Web',
        data: WG.utils.getDeeplinkData(),
        stage: stage,
        feature: 'get-app-button'
      },{
        make_new_link: true,
        open_app: false
      }, function(err, link) {
        if (err) {
          console.error(err);
        } else {
          WG.constants.BRANCH_LINK = link;
        }
    });

    var bannerOptions = {
      icon: '/static/whatsgoodly/img/logo_white_circle.png',
      title: 'Whatsgoodly',
      description: WG.constants.MOTTO,
      // rating: 4,                              // Displays a star rating out of 5. Supports half stars through increments of .5
      // reviewCount: 150,                      // Amount of reviews your app has received next to the star rating
      openAppButtonText: 'Open App',              // Text to show on button if the user has the app installed
      downloadAppButtonText: 'Download App',      // Text to show on button if the user does not have the app installed
      sendLinkText: 'Text Me the Link',           // Text to show on desktop button to allow users to text themselves the app
      showiOS: true,                          // Should the banner be shown on iOS devices (both iPhones and iPads)?
      showiPad: true,                         // Should the banner be shown on iPads (this overrides showiOS)?
      showAndroid: true,                      // Should the banner be shown on Android devices?
      showBlackberry: true,                   // Should the banner be shown on Blackberry devices?
      showWindowsPhone: true,                 // Should the banner be shown on Windows Phone devices?
      showKindle: true,                       // Should the banner be shown on Kindle devices?
      showDesktop: true,                      // Should the banner be shown on desktop devices?
      iframe: true,                           // Show banner in an iframe, recomended to isolate Branch banner CSS
      disableHide: true,                     // Should the user have the ability to hide the banner? (show's X on left side)
      forgetHide: true,                      // Should we show the banner after the user closes it? Can be set to true, or an integer to show again after X days
      respectDNT: false,                      // Should we skip showing the banner when a user's settings show 'Do Not Track'?
      mobileSticky: false,                    // Determines whether the mobile banner will be set `position: fixed;` (sticky) or `position: absolute;`, defaults to false *this property only applies when the banner position is 'top'
      desktopSticky: false,                    // Determines whether the desktop banner will be set `position: fixed;` (sticky) or `position: absolute;`, defaults to true *this property only applies when the banner position is 'top'
      make_new_link: false,                   // Should the banner create a new link, even if a link already exists?
      open_app: false,                        // Should the banner try to open the app passively (without the user actively clicking) on load?
    };

    if (!isDeepView) {
      branch.banner(bannerOptions, {
        feature: 'smart_banner',
        stage: stage,
        data : WG.utils.getDeeplinkData()
      });
    }
  }

});
