(function() {

var D = React.DOM;
var PollList = WG.PollList;

WG.SurveyForm = React.createFactory(React.createClass({

  propTypes: {
    name: React.PropTypes.string.isRequired,
    polls: React.PropTypes.arrayOf(
        React.PropTypes.shape({
          id: React.PropTypes.number.isRequired,
          question: React.PropTypes.string.isRequired
        })
      ).isRequired,
    feed: React.PropTypes.shape({
        image_source: React.PropTypes.string.isRequired
      }),
    theme: React.PropTypes.object
  },

  renderHeader: function() {
    
    return (
      D.h1({className: this.props.theme.POLL_BANNER_CLASS },
        this.props.feed ?
          D.img({src: this.props.feed.image_source})
          : null,
        this.props.name
      )
    )
  },

  render: function() {

    return D.div({className: "SurveyForm"},
      this.renderHeader(),
      PollList({
        onlyShowPolls: true,
        initialPolls: this.props.polls,
        theme: this.props.theme
      })
    )
  }

}));

})();