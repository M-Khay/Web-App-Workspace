(function() {

var D = React.DOM;
var Raven = window.Raven;
var CREATE_USER_URL = "/api/v3/users/new/";
var UPDATE_USER_URL = "/api/v3/users/update/";
var EMAIL_PLACEHOLDER = "winston@ugoodly.edu";

WG.UserManager = React.createFactory(React.createClass({
  getInitialState: function() {
    var user = WG.utils.getUser() || {};
    return {
      signupModalOpen: false,
      isUpdating: false,
      gender: WG.constants.User.NOT_CHOSEN,
      email: user.email,
      emailValid: false
    }
  },

  componentWillMount: function() {
    this.listeners = [
      PubSub.subscribe(WG.actions.CREATE_USER, function() {
        this.setState({signupModalOpen: true, isUpdating: false});
      }.bind(this)),

      PubSub.subscribe(WG.actions.UPDATE_USER, function(topic, data) {
        this.setState({signupModalOpen: true, isUpdating: true});
      }.bind(this)),
    ];
  },

  componentWillUnmount: function() {
    this.listeners.map(PubSub.unsubscribe);
  },

  validate: function() {
    if (!this.state.email ||
        !this.state.email.trim().length ||
        !(this.state.email.indexOf("ugoodly.") == -1)) {

      PubSub.publish(WG.actions.SHOW_WARNING,
        "Email is required! Otherwise you won't be able to login later ☹️");
      return false;
    }
    return true;
  },

  createOrUpdateUser: function() {
    if (!this.validate()) {
      return;
    }
    var initialUser = WG.utils.getUser() || {};
    var body = {
      gender: this.state.gender,
      email: this.state.email
    };

    $.ajax({
      url: this.state.isUpdating ? UPDATE_USER_URL : CREATE_USER_URL,
      dataType: 'json',
      type: this.state.isUpdating ? 'PATCH' : 'POST',
      contentType: 'application/json',
      data: JSON.stringify(body)
    })
    .done(function(data) {
      if (data && data.id) {

        var event = this.state.isUpdating ? "SET_GENDER" : "SIGNED_UP";
        branch.track(event);
        this.setState({signupModalOpen: false}, function() {
          PubSub.publish(WG.actions.STORE_USER, data);
        });

        Raven.setUserContext({
          id: data.id
        });
        Raven.setExtraContext({
          gender: data.gender
        });
      }
    }.bind(this))
    .fail(function(error) {
      var errorMessage = "Problem contacting the server. Please try again!";
      if (error.responseJSON && error.responseJSON.email) {
        errorMessage = error.responseJSON.email[0];
      }
      PubSub.publish(WG.actions.SHOW_WARNING, errorMessage);
    })
  },

  handleGenderClick: function(gender) {
    if (this.state.gender == gender) {
      this.setState({gender: WG.constants.User.NOT_CHOSEN});
    } else {
      this.setState({gender: gender});
    }
  },

  handleEmailChange: function(e) {
    this.setState({
      email: e.target.value,
      emailValid: WG.utils.isValidEmail(e.target.value)
    });
  },

  renderSignupModalContent: function() {
    var maleClassName = "btn UserManager--choice " +
        (this.state.gender == WG.constants.User.MALE ? "active border-blue" : "");
    var femaleClassName = "btn UserManager--choice " +
        (this.state.gender == WG.constants.User.FEMALE ? "active border-pink" : "");

    var prompt = this.state.isUpdating ?
      "needed for this poll" : "optional, but needed for some polls.";

    var checkmarkStyle = {
      position: "absolute",
      right: 15,
      height: 40,
      width: 40
    };

    return (
      D.div({className: "UserManager--signup container-fluid"},
        D.h3({},
          '1. Enter your email',
          D.br(),
          D.small({},
            "so you can see polls from your school.",
            D.br(),
            "remember, everything's anonymous!"
          )
        ),
        D.div({className: "row"},
          D.div({className: "form-group form-transparent"},
            this.state.emailValid ?
              WG.Checkmark({style: checkmarkStyle})
              : null,
            D.input({type: "email", defaultValue: this.state.email,
                     placeholder: EMAIL_PLACEHOLDER,
                     onChange: this.handleEmailChange})
          )
        ),
        D.h3({},
          '2. Select your gender',
          D.br(),
          D.small({}, prompt)
        ),
        D.div({className: "row"},
          D.div({className: maleClassName,
                  onClick: this.handleGenderClick.bind(this, WG.constants.User.MALE)},
            "Male"
          ),
          D.div({className: femaleClassName,
                  onClick: this.handleGenderClick.bind(this, WG.constants.User.FEMALE)},
            "Female"
          )
        ),
        D.div({className: "btn btn-default btn-lg", onClick: this.createOrUpdateUser},
          this.state.isUpdating ? "Set gender" : "Vote!"
        )
      )
    )
  },

  // TODO modal component
  renderSignupModal: function() {
    var style = {
      position: "fixed", top: 0, left: 0, bottom: 0, right: 0,
      transition: "opacity 0.4s ease",
      pointerEvents: this.state.signupModalOpen ? "all" : "none",
      zIndex: 2000,
      opacity: this.state.signupModalOpen ? 1 : 0,
    };

    var childStyle = {
      position: "absolute", top: "50%", left: "50%",
      transform: this.state.signupModalOpen ? "translate(-50%, -50%) scale(1)" : "translate(-50%, -50%) scale(0.6)",
      transition: "transform 0.3s cubic-bezier(0.55, 0.55, 0.76, 1.51)",
      width: "80%",
      maxWidth: 400,
      textAlign: "center"
    };

    var closeStyle = {
      fontSize: 32,
      margin: "5px 10px",
      opacity: 0.75,
      color: "white"
    };

    var handleClose = function() {
      this.setState({signupModalOpen: false});
    }.bind(this);

    return (
      D.div({className: "Modal bg-purple bg-peek", style: style},
        D.button({ type: "button", style: closeStyle, className: "close", onClick: handleClose},
          D.span({}, "×")
        ),
        D.div({style: childStyle, className: "text-white"},
          this.renderSignupModalContent()
        )
      )
    )
  },

  render: function() {
    return (
      D.div({className: "UserManager"},
        this.renderSignupModal()
      )
    )
  }
}));

})();