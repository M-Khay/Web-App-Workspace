$(function Lightbox() {
  var $this = $(".Lightbox");

  $(window).on("scroll", handleScroll);

  function handleScroll() {
    var scroll = $(window).scrollTop();
    var threshold = $(window).height() / 3;
    var opacity = Math.min(scroll / threshold, 1);

    $this.css({opacity: opacity/3});
  }
});
