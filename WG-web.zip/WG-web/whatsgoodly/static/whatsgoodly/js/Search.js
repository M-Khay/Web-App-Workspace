(function() {

WG = window.WG || {};
var D = React.DOM;

var DEBOUNCE_THRESHOLD = 400;
var SEARCH_POLLS_URL = "/search_polls/";
var COUNT_POLLS_URL = "/search_polls/only_count/";
var SAMPLE_SEARCHES = ["Apple", "Facebook", "Black Lives Matter", "Call of duty", "Hillary", "ISIS", "Cornell", "Northwestern", "Stanford", "Brock Turner", "Pokemon", "love", "UVA", "adderall",  "Israel", "2015", "Kylie", "assault", "SAE", "career", "socially acceptable", "stranger things", "netflix", "meme", "Harambe", "Goldman", "jail", "millennial", "brand", "democracy", "ISIS", "Favorite", "Instagram", "Nickelback", "Nike", "Obama", "Offensive", "Pixar", "Snapchat", "Tesla", "Trump", "Victoria's Secret", "Whatsgoodly", "Yik Yak", "animals", "awkward", "best netflix", "bored", "brexit", "cargo shorts", "cheat", "childhood", "cigarettes", "coffee", "dating", "disney", "dorm", "fall", "funniest", "game of thrones", "greek", "gun control", "history", "hottest", "marry", "naked", "our generation", "peace", "pick up line", "protest", "puppy", "racism", "scholarship", "sexy", "spring", "summer", "weed", "worst"];

WG.Search = React.createFactory(React.createClass({

  propTypes: {
    placeholder: React.PropTypes.string
  },

  getDefaultProps: function() {
    return {
      placeholder: "Search the world's largest database of millennial opinions"
    }
  },

  getInitialState: function() {
    return {
      active: false
    };
  },

  componentWillMount: function() {
    this.listeners = [
      PubSub.subscribe(WG.actions.ACTIVATE_SEARCH, function() {
        if ($(window).scrollTop() < $(window).height() / 1.5) {
          this.scrollToResults();
        }
        this.setState({active: true});
      }.bind(this)),

      PubSub.subscribe(WG.actions.DEACTIVATE_SEARCH, function() {
        this.setState({active: false});
        $(window).off("scroll.Search--resetScroll");
      }.bind(this))
    ];
  },

  componentDidMount: function() {
    // TODO get hash from URL
  },

  componentWillUnmount: function() {
    this.listeners.map(PubSub.unsubscribe);
  },

  scrollToResults: function() {
    var newScroll = $(window).height() - $(this._searchBar).outerHeight(true);
    // NOTE: don't subtract WG.constants.NAVBAR_HEIGHT on mobile
    // because mobile won't move navbar down on keyboard expand
    if (WG.utils.isMobile()) {
      newScroll -= 10;
    } else {
      newScroll -= WG.constants.NAVBAR_HEIGHT;
    }

    $("html, body").animate({scrollTop: newScroll}, 600, function() {
      $(window).on("scroll.Search--resetScroll", function() {
        var scroll = $(window).scrollTop();
        if (scroll < newScroll/3) {
          PubSub.publish(WG.actions.DEACTIVATE_SEARCH);
        }
      });
    });
  },

  searchPolls: function(query) {
    PubSub.publish(WG.actions.ACTIVATE_SEARCH);

    if (query.trim().length < 2) {
      PubSub.publish(WG.actions.RESET_POLLS);
      return;
    }

    PubSub.publish(WG.actions.SET_LOADING);

    if (this.xhr) {
      this.xhr.abort();
    }

    this.xhr = $.get(SEARCH_POLLS_URL, {q: query})
      .done(function(data) {

        if (data.polls) {
          PubSub.publish(WG.actions.RENDER_POLLS, data);

          if (!data.total_polls) {
            this.fetchCount(query);
          }
        } else {
          console.info("Total polls: " + (data.total_polls || ""));
          PubSub.publish(WG.actions.RESET_POLLS, data.total_polls);
        }
      }.bind(this));
  },

  fetchCount: function(query) {
    if (this.xhr) {
      this.xhr.abort();
    }

    this.xhr = $.get(COUNT_POLLS_URL, {q: query})
      .done(function(data) {
        if (data.total_polls) {
          PubSub.publish(WG.actions.SHOW_POLL_COUNT, data);
        }
      }.bind(this));
  },

  shuffleSearchTerm: function() {
    var query = WG.utils.sample(SAMPLE_SEARCHES);
    this.refs.searchBarInput.value = query;
    this.searchPolls(query);
  },

  render: function() {
    var search = WG.utils.debounce(this.searchPolls, DEBOUNCE_THRESHOLD);
    var handleChange = function(e) {
      search(e.target.value);
    };
    var handleBlur = function(e) {
      PubSub.publish(WG.actions.DEACTIVATE_SEARCH);
    }.bind(this);
    var handleFocus = function() {
      if (WG.utils.isMobile()) {
        PubSub.publish(WG.actions.ACTIVATE_SEARCH);
      }
    }.bind(this);
    var handleSearchIconClick = function() {
      this.refs.searchBarInput.focus();
    }.bind(this);
    var onSearchBarMount = function(elem) {
      if (elem && !this._searchBar) {
        this._searchBar = elem;
        this._activeOffset = $(window).height()
          - $(elem).outerHeight(true)
          - $(elem).offset().top;
      }
    }.bind(this);

    var shouldEnable = true; // window.location.hash == "#winston";

    var searchBarStyle = {
      top: this.state.active && this._activeOffset ?
        this._activeOffset
        : 0,
      opacity: shouldEnable ? 1 : 0.2,
      pointerEvents: shouldEnable ? "all" : "none"
    };

    return (
      D.div({ className: "Search center-block" },
        D.div({ className: "row Search--bar " + (this.state.active ? "active" : ""),
                style: searchBarStyle,
                ref: onSearchBarMount },
          D.button({className: "btn btn-default text-purple",
                    onClick: handleSearchIconClick},
            D.span({ className: "glyphicon glyphicon-search"})
          ),
          D.input({ type: "search",
                    ref: "searchBarInput",
                    // placeholder: "Live in the know",
                    disabled: shouldEnable ? false : true,
                    onChange: handleChange,
                    onBlur: handleBlur,
                    onFocus: handleFocus }),
          this.state.active
            ? D.button({className: "btn btn-default text-purple",
                        title: "I'm feeling goodly",
                        onClick: this.shuffleSearchTerm},
                "🎉"
              )
            : null
        ),
        D.div({ className: "Search--placeholder row" },
          this.props.placeholder),
        D.button({className: "btn btn-transparent",
                  style: {margin: "1em"},
                  onClick: this.shuffleSearchTerm},
          "🎉\u00a0\u00a0 I'm feeling goodly"
        )
      )
    );
  }
}));


})();