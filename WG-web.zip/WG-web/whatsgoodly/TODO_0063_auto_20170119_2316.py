# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.contrib.gis.db.models.fields
from whatsgoodly.utils import non_atomic_migration

BATCHSIZE = 5000

@non_atomic_migration
def add_locations_to_responses(apps, schema_editor):
    Feed = apps.get_model('whatsgoodly', 'Feed')
    PollInstance = apps.get_model('whatsgoodly', 'PollInstance')

    local_feed = Feed.objects.get(category=0)

    max_pk = PollInstance.objects.aggregate(models.Max('pk'))['pk__max']

    for offset in range(0, max_pk+1, BATCHSIZE):
        # print "OFFSET {}".format(offset)
        for pi in PollInstance.objects.filter(
                community__isnull=False, feed=local_feed,
                pk__gte=offset,
                pk__lt=offset+BATCHSIZE
            ):
            pi.response_set.update(location=pi.location)

def undo_add_locations_to_responses(apps, schema_editor):
    pass


class Migration(migrations.Migration):

    dependencies = [
        ('whatsgoodly', '0062_user_verified_email'),
    ]

    operations = [
        migrations.AddField(
            model_name='response',
            name='location',
            field=django.contrib.gis.db.models.fields.PointField(srid=4326, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='response',
            name='status',
            field=models.IntegerField(default=0, db_index=True, choices=[(0, b'None'), (1, b'Expired')]),
        ),

        migrations.RunPython(add_locations_to_responses, reverse_code=undo_add_locations_to_responses),
    ]
