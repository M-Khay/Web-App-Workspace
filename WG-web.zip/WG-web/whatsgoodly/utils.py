import os
import json
from django.db import connection
from django.core.exceptions import ImproperlyConfigured
from django.core.paginator import Paginator
from django.db.models.expressions import RawSQL
from django.db.models import Count, BigIntegerField, Func
from django.utils.functional import cached_property
from functools import wraps
from random import randint

# TODO use Django 1.10's native Cast impl when upgrade
class CastToString(Func):
    function = 'CAST'
    template = '%(function)s(%(expressions)s AS varchar(10))'

def DateTZ(expression, timezone):
    '''
    Custom query expression to get date from datetime object with
    time zone offset.
    Example usage
    queryset.annotate(
        created_date=DateTZ('created_at', '+05:30')
    )
    from django-pg-utils
    '''
    class DateWithTZ(Date):
        template = '%(function)s(%(expressions)s AT TIME ZONE '\
                   'INTERVAL \'{timezone}\')'.format(timezone=timezone)

    return DateWithTZ(expression)

class Date(Func):
    '''
    Custom query expression to get date from datetime object.
    Example usage
    queryset.annotate(
        created_at=Date('created_at')
    )
    '''
    function = 'DATE'

class Seconds(Func):
    '''
    Custom query expression to convert time interval to seconds.
    Example usage
    queryset.annotate(
        duration=Seconds(F('end_time') - F('start_time'))
    )
    from django-pg-utils
    '''
    function = 'EXTRACT'
    template = '%(function)s(EPOCH FROM %(expressions)s)'

class Month(Func):
    function = 'EXTRACT'
    template = '%(function)s(MONTH from %(expressions)s)'
    # output_field = IntegerField()

class Week(Func):
    function = 'EXTRACT'
    template = '%(function)s(WEEK from %(expressions)s)'
    # output_field = IntegerField()

class ApproximatePaginator(Paginator):
    """
    Like Paginator, but approximates the total count
    """
    @cached_property
    def count(self):
        """
        Returns the total number of objects, across all pages.
        """
        try:
            return get_estimated_count(self.object_list)
        except (AttributeError, TypeError):
            # AttributeError if object_list has no count() method.
            # TypeError if object_list.count() requires arguments
            # (i.e. is of type list).
            return len(self.object_list)

# See http://pankrat.github.io/2015/django-migrations-without-downtimes/
# This will be built-in in Django 1.10
def non_atomic_migration(func):
    @wraps(func)
    def wrapper(apps, schema_editor):
        if schema_editor.connection.in_atomic_block:
            schema_editor.atomic.__exit__(None, None, None)
        return func(apps, schema_editor)
    return wrapper

def get_env_variable(var_name):
    """ Get the environment variable or return exception """
    try:
        return os.environ[var_name]
    except KeyError:
        error_msg = "Set the %s environment variable" % var_name
        raise ImproperlyConfigured(error_msg)

# Returns SQL for computing a poll's date-weighted popularity
# Requires user table to be in query if promoted_gender gender is set
def decayed_score_sql(promoted_gender=None):
    sql = [
        # weighted response count
        "POWER(whatsgoodly_pollinstance.vote_weight, 0.5)",
        "+",
        # square of related count
        "POWER(whatsgoodly_pollinstance.vote_aggregate + whatsgoodly_pollinstance.favorite_count, 2)",
        "-",
        # square of days since creation
        "POWER(ABS(EXTRACT(EPOCH FROM current_timestamp - whatsgoodly_pollinstance.created_date))/86400, 2)"
    ]
    # promote same-gender polls and penalize unspecified-gender (-1) polls
    if promoted_gender == 0:
        sql += ["+", "10*(1 - ABS(whatsgoodly_user.gender))"]
        # female poll (targeted) penalty
        # TODO remove when ppl upgrade
        # sql += ["-", "100*(whatsgoodly_poll.gender % 2)"]
    elif promoted_gender == 1:
        sql += ["+", "5*(whatsgoodly_user.gender)"]
        # male poll (targeted) penalty
        # TODO remove when ppl upgrade
        # sql += ["+", "100*(whatsgoodly_poll.gender)"]

    return RawSQL(" ".join(sql), [], output_field=BigIntegerField())

# Get a random object from a queryset
def random_object(queryset):
    count = queryset.aggregate(count=Count('id'))['count']
    if not count:
        return None
    try:
        random_index = randint(0, count - 1)
        return queryset[random_index]
    except IndexError:
        print "Not sure why, but SQL Count failed"
        return queryset.first()

# from Tastypie:
# http://django-tastypie.readthedocs.io/en/latest/paginator.html#paginator-estimated-count
def get_estimated_count(queryset):
    """Get the estimated count by using the database query planner."""
    return _get_postgres_estimated_count(queryset)

# NOTE: this very frequently has a giant margin of error, sometimes
# by orders of magnitude
def _get_postgres_estimated_count(queryset):

    # This method only works with postgres >= 9.0.
    # If you need postgres vesrions less than 9.0, remove "(format json)"
    # below and parse the text explain output.

    try:
        if get_postgres_version() < 90000:
            raise ImproperlyConfigured("PostgreSQL is too old")
    except AttributeError:
        raise ImproperlyConfigured("PostgreSQL is too old")

    cursor = connection.cursor()
    query = queryset.query

    # Remove limit and offset from the query, and extract sql and params.
    query.low_mark = 0
    query.high_mark = None
    query, params = queryset.query.sql_with_params()

    # Fetch the estimated rowcount from EXPLAIN json output.
    query = 'explain (format json) %s' % query
    cursor.execute(query, params)
    explain = cursor.fetchone()[0]
    # Older psycopg2 versions do not convert json automatically.
    if isinstance(explain, basestring):
        explain = json.loads(explain)
    rows = explain[0]['Plan']['Plan Rows']
    return rows

def get_postgres_version():
    # Due to django connections being lazy, we need a cursor to make
    # sure the connection.connection attribute is not None.
    connection.cursor()
    return connection.connection.server_version
