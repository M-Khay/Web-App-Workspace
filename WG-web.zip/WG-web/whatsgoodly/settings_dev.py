from whatsgoodly.settings import *
from whatsgoodly.utils import get_env_variable

#SECRET_KEY = 'sdghusdfgklnsetkryhsdfkjgnzdkfgjhs456789'

INSTALLED_APPS = INSTALLED_APPS +  (
        'silk',
    )

MIDDLEWARE_CLASSES = MIDDLEWARE_CLASSES + (
        'silk.middleware.SilkyMiddleware',
    )

DATABASES = {
    'default': {
        'ENGINE': 'django.contrib.gis.db.backends.postgis',
        'NAME': 'whatsgoodly_prod',
        'USER': 'whatsgoodly_prod',
        'PASSWORD': get_env_variable("postgres_password"),
        'HOST': 'whatsgoodlydev.cgl5xrzwdnf5.us-east-1.rds.amazonaws.com',
    }
}
ANALYTICS_INSTANCE_IP = '10.10.3.187'

# Profiling
SILK_ENABLED = True
SILKY_AUTHORISATION = True  # User must have is_staff permission
SILKY_MAX_REQUEST_BODY_SIZE = -1  # Silk takes anything <0 as no limit
SILKY_MAX_RESPONSE_BODY_SIZE = 1024  # If response body>1024kb, ignore
SILKY_META = True # Log what Silky adds to the response time
SILKY_INTERCEPT_PERCENT = 100 # if DEBUG else 2 # log only 2% of requests on prod
# OR log only if session comes from an admin.
# def is_admin(request):
#     request.user.is_staff # or user.id in dict(ADMIN_IDS).values()
# SILKY_INTERCEPT_FUNC = is_admin

ALLOWED_HOSTS = ['.whatsgoodly.com', 'whatsgoodlydev.com']

STATIC_ROOT = '/opt/app/web/current/static/'

# Push notifications (deprecated)
APNS_CERT = '/opt/app/files/APNSCert.pem'
APNS_KEY = '/opt/app/files/APNSKey.pem'

# Real-time updates in app
PUSHER_APP_ID = '188376'
PUSHER_KEY = 'a0fb9f5bd302c8555f25'
PUSHER_SECRET = '7767c22de74959ceb4e3'

ADMIN_IDS = (
    ('Alex Atallah', 79909),
    ('Whatsgoodly', 4110)
)

ELASTICSEARCH_INDEX_BREAKDOWNS = 'whatsgoodly-breakdowns--dev'

from elasticsearch_dsl.connections import connections
connections.create_connection(hosts=[AWS_ELASTICSEARCH_HOST])
