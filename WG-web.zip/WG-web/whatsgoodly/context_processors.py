from django.conf import settings
from api.utils import WG_WEB_AUTH_HEADER

def static_files(request):
    return {
        'DEBUG': settings.DEBUG,
        'RAVEN_KEY': settings.RAVEN_CONFIG['key'],
        'release': settings.RAVEN_CONFIG['release'],
        'auth_header': WG_WEB_AUTH_HEADER
    }
