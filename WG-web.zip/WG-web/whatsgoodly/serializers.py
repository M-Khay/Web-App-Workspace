from rest_framework import serializers
from whatsgoodly.models import *
from api.serializers import *
from api import querysets
import json

class PollSimpleSerializer(serializers.ModelSerializer):
  options = OptionsField()

  class Meta:
    model = Poll
    fields = ( 'id', 'question', 'question_picture_url', 'options', 'audio_options',
      'gender', 'created_date', )

class PollSerializer(PollSimpleSerializer):
  poll_id = serializers.IntegerField(source='pk')
  margin_of_error = serializers.SerializerMethodField()
  option_counts = serializers.SerializerMethodField()
  user = PublicUserSerializer()
  comment_count = serializers.SerializerMethodField()

  def get_option_counts(self, poll):
    if hasattr(poll, 'web_breakdowns'):
      return _get_total_counts(poll.web_breakdowns, poll)

    print "Warning: Didn't prefetch breakdowns!"
    return _get_total_counts(None, poll)

  def get_comment_count(self, poll):
    if hasattr(poll, 'total_comment_count'): # prefetched
      return poll.total_comment_count
    # Optimization
    print "Warning: Didn't prefetch comment count!"
    return 0

  def get_margin_of_error(self, poll):
    if self.context.get('skip_margin_calc', False):
      print "Warning: Didn't prefetch population size!"
      return 0
    pop = self.context.get('population_size', MILLENNIALS_IN_US)
    if hasattr(poll, 'web_breakdowns'):
      vote_count = poll.web_breakdowns[0].total + poll.web_breakdowns[1].total
    else:
      print "Warning: Didn't prefetch breakdowns!"
      vote_count = sum(_get_total_counts(None, poll))
    margin = poll.get_error_margin(sample_size=vote_count, population_size=pop)
    return margin

  class Meta:
    model = Poll
    fields = PollSimpleSerializer.Meta.fields + (
      'poll_id', 'user', 'option_counts', 'margin_of_error', 'comment_count')

class SurveySerializer(serializers.ModelSerializer):
  polls = serializers.SerializerMethodField()
  is_public = serializers.BooleanField(source='account.is_public')

  def get_polls(self, survey):
    self.context['population_size'] = survey.population_size
    polls = querysets.survey_polls_web(survey)
    return PollSerializer(polls, many=True, context=self.context).data

  def validate_timeline_setting(self, timeline_setting):
    if timeline_setting not in dict(Survey.TIMELINE_SETTINGS.CHOICES).keys():
      raise serializers.ValidationError("Invalid setting")
    return timeline_setting

  class Meta:
    model = Survey
    read_only_fields = ('id', 'name', 'name_url',
      'polls', 'user', 'created_date', 'population_size', 'is_public' )
    fields = read_only_fields + ('timeline_setting', 'map_setting' )

class AccountSerializer(serializers.ModelSerializer):
  surveys = serializers.SerializerMethodField()

  def get_surveys(self, account):
    surveys = account.survey_set.order_by('id')
    return SurveySerializer(surveys, many=True, context=self.context).data

  class Meta:
    model = Account
    fields = ('id', 'name', 'surveys', )

class PollBreakdownExportSerializer(PollBreakdownSerializer):
  poll = PollSimpleSerializer()
  percentages = serializers.ListField(
      child=serializers.FloatField(min_value=0.0, max_value=1.0),
      source='get_percentages'
    )
  breakdown_type_label = serializers.SerializerMethodField()
  university = UniversitySerializer(required=False)
  segmenter = PollSimpleSerializer(required=False)

  def get_breakdown_type_label(self, poll_breakdown):
    if poll_breakdown.breakdown_type == PollBreakdown.TYPES.SEGMENT:
      return "Custom"
    return poll_breakdown.get_breakdown_type_display()

  class Meta(PollBreakdownSerializer.Meta):
    fields = (
        'id', 'option_counts', 'color', 'gender', 'label',
        'label_short',
        'total', 'significance',
        'breakdown_type_label', 'percentages', 'poll', 'university',
        'segmenter', 'segment_option', 
      )

class PollInstanceSerializer(serializers.ModelSerializer):
  poll_id = serializers.IntegerField()
  response = serializers.SerializerMethodField()
  skipped_moderation = serializers.BooleanField(source='auto_verified')
  question = serializers.CharField(source='get_question')
  picture_question = serializers.CharField(source='get_question_picture_url')
  gender = serializers.IntegerField(source='get_gender')
  deleted = serializers.BooleanField(source='get_deleted')
  options = OptionsField(source='get_options')
  option_counts = serializers.SerializerMethodField()
  feed = serializers.SerializerMethodField()
  user = PublicUserSerializer(required=False)
  margin_of_error = serializers.SerializerMethodField()

  def get_margin_of_error(self, poll_instance):
    pop = self.context.get('population_size', MILLENNIALS_IN_US)

    option_counts = self.get_option_counts(poll_instance)
    sample = sum(option_counts)
    return poll_instance.poll.get_error_margin(sample_size=sample, population_size=pop)

  def is_singleton(self):
    return not (self.parent and self.parent.many)

  def get_feed(self, poll_instance):
    # Only send feed in singleton mode
    if self.is_singleton():
      return FeedInlineSerializer(poll_instance.feed, context=self.context).data
    return None

  def get_response(self, poll_instance):
    try:
      if len(poll_instance.user_response) > 0: # prefetched
        return ResponseSerializer(poll_instance.user_response[0]).data
    except AttributeError:
      pass
    return None

  def get_option_counts(self, poll_instance):
    all_breakdowns = self.context['breakdowns']
    poll_breakdowns = [pb for pb in all_breakdowns
                          if pb.poll_id == poll_instance.poll_id]

    return _get_total_counts(poll_breakdowns, poll_instance.poll)

  class Meta:
    model = PollInstance
    read_only_fields = ( 'id', 'poll_id', 'user', 'feed', 'options', 'option_counts', 'created_date',
      'banner', 'comment_count', 'favorite_count', 'feed', 'question', 'picture_question',
      'gender', 'promotion', 'skipped_moderation', 'deleted',
      'vote_aggregate', 'verified', 'response', 'margin_of_error' )
    fields = read_only_fields

def _get_total_counts(prefetched_breakdowns, poll):
  breakdowns = prefetched_breakdowns or poll.breakdowns.filter(
      breakdown_type__in=[
        PollBreakdown.TYPES.MOBILE, PollBreakdown.TYPES.WEB
      ]
    ).order_by('breakdown_type')

  # sum web and mobile counts
  mobile_counts = json.loads(breakdowns[PollBreakdown.TYPES.MOBILE].json)
  web_counts = json.loads(breakdowns[PollBreakdown.TYPES.WEB].json)
  return [a + b for a, b in zip(mobile_counts, web_counts)]
