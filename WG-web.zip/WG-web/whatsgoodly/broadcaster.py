from django.conf import settings
import pusher
import whatsgoodly.models
from django.contrib.gis.measure import D
from api.utils import KM_DISTANCE_FILTER
# from firebase import firebase
from api.serializers import FirebasePollInstanceSerializer
import multiprocessing

# fbd = firebase.FirebaseApplication(settings.FIREBASE_DATABASE, None)
GF_DEFAULT_PRECISION = 10
BITS_PER_BASE32_CHAR = 5
BASE_32_CHARS = "0123456789bcdefghjkmnpqrstuvwxyz"

import os
is_development = os.environ.get('env') == 'vagrant'

def broadcast_user(user):
    send_pusher_broadcast(
        channel=u'user_%s' % user.id,
        event=u'user_updated',
        data={
            u'karma': user.karma
        }
    )

def broadcast_poll_instance(poll_instance):
    send_pusher_broadcast(
        channel=u'feed_%s' % poll_instance.feed.id,
        event=u'poll_instance_created',
        data={u'poll_instance_id': poll_instance.id}
    )

def broadcast_poll_instance_nearby(poll_instance):
    loc = poll_instance.location
    # Firebase database
    # poll = FirebasePollInstanceSerializer(poll_instance).data

    # def hash_geo(response):
    #     geo = {
    #         'g': geo_hash(loc),
    #         'l': [loc.y, loc.x]
    #     }
    #     fbd.put("/pollgeo", response['name'], geo)

    # if multiprocessing.current_process().daemon:
    #     # daemonic processes are not allowed to have children
    #     hash_geo(fbd.post("/polls", poll))
    # else:
    #     fbd.post_async("/polls", poll, callback=hash_geo)

    # Main Whatsgoodly database
    # local_channels = whatsgoodly.models.LocalChannel.objects.filter(
    #     active=True,
    #     location__distance_lte=(location, D(km=KM_DISTANCE_FILTER))
    # )
    # for channel in local_channels:
    #     send_pusher_broadcast(
    #         channel=u'%s' % channel.name,
    #         event=u'poll_instance_created',
    #         data={u'poll_instance_id': poll_instance.id}
    #     )

def broadcast_poll_instance_vote(poll_instance_vote):
    poll_instance = poll_instance_vote.poll_instance
    send_pusher_broadcast(
        channel=u'poll_instance_%s' % poll_instance.id,
        event=u'vote_created',
        data={
            u'vote_aggregate': poll_instance.vote_aggregate
        }
    )

def broadcast_poll_instance_response(poll_instance_response):
    poll_instance = poll_instance_response.poll_instance
    send_pusher_broadcast(
        channel=u'poll_instance_%s' % poll_instance.id,
        event=u'response_created',
        data={
            u'response': poll_instance_response.response,
            u'user_id': poll_instance_response.user_id
        }
    )

def broadcast_comment(comment):
    poll_instance = comment.poll_instance
    send_pusher_broadcast(
        channel=u'poll_instance_%s' % poll_instance.id,
        event=u'comment_created',
        data={
          u'user': {u'id': comment.user_id},
          u'text': comment.text,
          u'comment_count': whatsgoodly.models.Comment.objects.filter(
            poll_instance=poll_instance,
            deleted=False
          ).count()
        }
    )

def broadcast_comment_vote(comment_vote):
    comment = comment_vote.comment
    poll_instance = comment.poll_instance
    send_pusher_broadcast(
        channel=u'poll_instance_%s' % poll_instance.id,
        event=u'comment_vote_created',
        data={
            u'comment_id': comment.id,
            u'vote': comment_vote.vote
        }
    )

def send_pusher_broadcast(channel, event, data):
    if is_development:
        print "Optimization; ignoring Pusher on vagrant"
        return

    wg_pusher = pusher.pusher.Pusher(
        app_id=settings.PUSHER_APP_ID,
        key=settings.PUSHER_KEY,
        secret=settings.PUSHER_SECRET
    )

    try:
        wg_pusher.trigger(
            channel,
            event,
            data
        )
    except:
        # pusher.errors.PusherForbidden as exception
        # could also be a server timestamp issue
        # TODO: let this task fail asynchronously
        pass

# Mimics Geofire locations
def geo_hash(location, precision=GF_DEFAULT_PRECISION):
    longitudeRange = [ -180 , 180 ]
    latitudeRange = [ -90 , 90 ]

    buffer = []

    for i in range(precision):
        hashVal = 0
        for j in range(BITS_PER_BASE32_CHAR):
            even = ((i*BITS_PER_BASE32_CHAR)+j) % 2 == 0
            val = location.x if even else location.y
            locRange = longitudeRange if even else latitudeRange
            mid = (locRange[0] + locRange[1])/2.0
            if val > mid:
                hashVal = (hashVal << 1) + 1
                locRange[0] = mid
            else:
                hashVal = (hashVal << 1) + 0
                locRange[1] = mid
        buffer += BASE_32_CHARS[hashVal]

    return ''.join(buffer)
