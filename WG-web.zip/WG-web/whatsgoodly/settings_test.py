from whatsgoodly.settings import *
import os

# For Codeship
DATABASES = {
  'default': {
    'ENGINE': 'django.contrib.gis.db.backends.postgis',
    'NAME': 'test',
    'USER': os.environ.get('PG_USER'),
    'PASSWORD': os.environ.get('PG_PASSWORD'),
    'HOST': '127.0.0.1',
  }
}

RAVEN_CONFIG = {
    'dsn': None
}

APNS_CERT = '/opt/app/files/APNSCert.pem'
APNS_KEY = '/opt/app/files/APNSKey.pem'

PUSHER_APP_ID = '188376'
PUSHER_KEY = 'a0fb9f5bd302c8555f25'
PUSHER_SECRET = '7767c22de74959ceb4e3'
