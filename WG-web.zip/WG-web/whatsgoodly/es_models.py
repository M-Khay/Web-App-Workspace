from django.conf import settings
from elasticsearch_dsl import Index, InnerObjectWrapper, DocType, Date, Integer, Float, String, Object, Nested, GeoPoint
from elasticsearch_dsl import analyzer, tokenizer
# from elasticsearch_dsl.connections import connections
# # Define a default Elasticsearch client
# connections.create_connection(hosts=['10.0.2.2:9200'])
# 10.0.2.2

# html_strip = analyzer('html_strip',
#     tokenizer="standard",
#     filter=["standard", "lowercase", "stop", "snowball"],
#     char_filter=["html_strip"]
# )

# See http://docs.searchkit.co/stable/docs/components/navigation/hierarchical-refinement-filter.html
class ETag(InnerObjectWrapper):
    properties = dict(
        level = Integer(),
        ancestors = String(index='not_analyzed'),
        value = String(index='not_analyzed'),
        order = Integer()
    )

class EBreakdown(InnerObjectWrapper):
    class PROMOTIONS:
        NONE, DISPARITY, PINNED = range(3)
    class TYPES:
        MOBILE, WEB, GENDER, UNIVERSITY, SEGMENT = range(5)

    properties = dict(
        segmenter = Object(properties=dict(
            pk = Integer(),
            question = String(),
            options = String(),
            targeting = String(fields={'raw': String(index='not_analyzed')}),
            # TODO tags

            segment_option = Integer(),
            segment_label = String(fields={'raw': String(index='not_analyzed')}),

            created_date = Date()
        )),
        community = Object(properties=dict(
            pk = Integer(),
            types = String(fields={'raw': String(index='not_analyzed')}),
            name = String(fields={'raw': String(index='not_analyzed')}),
            name_short = String(fields={'raw': String(index='not_analyzed')}),
            location = GeoPoint()
        )),
        gender = String(fields={'raw': String(index='not_analyzed')}),
        vote_counts = Integer(),
        total = Integer(), # TODO use script_fields in query instead
        abnormality = Integer(),
        breakdown_type = Integer(null_value=TYPES.MOBILE),
        promotion = Integer(null_value=PROMOTIONS.NONE)
    )

class EPoll(DocType):
    class Meta:
        index = settings.ELASTICSEARCH_INDEX_BREAKDOWNS

    question = String()
    options = String()
    targeting = String(fields={'raw': String(index='not_analyzed')})
    tags = Nested(
        doc_class=ETag,
        properties=ETag.properties
    )
    created_date = Date()

    breakdowns = Nested(
        doc_class=EBreakdown,
        properties=EBreakdown.properties
    )
