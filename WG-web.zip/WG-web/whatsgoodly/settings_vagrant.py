import raven
from whatsgoodly.settings import *

DATABASES = {
    'default': {
        'ENGINE': 'django.contrib.gis.db.backends.postgis',
        'NAME': 'whatsgoodly',
        'USER': 'whatsgoodly',
        'PASSWORD': 'password',
        'HOST': 'localhost',
    }
}

RAVEN_CONFIG = {
    'key': '',
    'dsn': None,
    'release': raven.fetch_git_sha(BASE_DIR)
}

NOTIFICATIONS_ENABLED = False

PUSHER_APP_ID = '188375'
PUSHER_KEY = 'b0dae620fdc7bc531167'
PUSHER_SECRET = '8e38cc14a7ea958f118d'

LOGGING = {
    'version': 1,
    'handlers': {
        'console':{
            'level':'DEBUG',
            'class':'logging.StreamHandler',
        },
    },
    'loggers': {
        'django.request': {
            'handlers':['console'],
            'propagate': True,
            'level':'DEBUG',
        }
    },
}

# Uncomment to test elasticsearch indexing locally
from elasticsearch_dsl.connections import connections
# Connect to locally-running elasticsearch instance, outside Vagrant
connections.create_connection(hosts=['http://10.0.2.2:9200/'])
