"""
Django settings for whatsgoodly project.

For more information on this file, see
https://docs.djangoproject.com/en/1.7/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/1.7/ref/settings/
"""

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
import os
import raven
import re

BASE_DIR = os.path.dirname(os.path.dirname(__file__))


# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/1.7/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = '*0(g*@bjg0ie3_-iigw)&w&okh-$$nmu=%_wh$99@b9+xek5h5'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

NOTIFICATIONS_ENABLED = True

ANALYTICS_INSTANCE_IP = '127.0.0.1'

ALLOWED_HOSTS = []

# Error emails disabled
# ADMINS = (
#     ('Adam Halper', 'adam@whatsgoodly.com'),
#     ('Alex Atallah', 'alex@whatsgoodly.com'),
# )

# TODO: use is_staff and deprecate this
ADMIN_IDS = (
    ('Alex Atallah', 1),
    ('Whatsgoodly', 2)
)

# Application definition

INSTALLED_APPS = (
    'raven.contrib.django.raven_compat',
    'api',
    'dashboard',
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.gis',
    'django.contrib.humanize',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'rest_framework.authtoken',
    'whatsgoodly',
    'djcelery',
    'djrill',
    'django_extensions',
    'logentry_admin',
    'localflavor',
)

AUTH_USER_MODEL = 'whatsgoodly.User'

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework.authentication.SessionAuthentication',
        'rest_framework.authentication.TokenAuthentication',
    ),
    'DEFAULT_THROTTLE_CLASSES': (
        'rest_framework.throttling.ScopedRateThrottle',
    ),
    'DEFAULT_THROTTLE_RATES': {
        'polls': '10/minute',
        'comments': '10/minute',
        'votes': '500/minute',
        'comment_votes': '50/minute',
        'favorites': '50/minute',
        'reports': '50/minute',
        'contacts': '5/minute',
        'tags': '50/minute',
    }
}

APPEND_SLASH = True

MIDDLEWARE_CLASSES = (
    'raven.contrib.django.raven_compat.middleware.Sentry404CatchMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.auth.middleware.SessionAuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
)

INTERNAL_IPS = (
    '127.0.0.1',
    '0.0.0.0'
)

ROOT_URLCONF = 'whatsgoodly.urls'
LOGIN_REDIRECT_URL = '/'

WSGI_APPLICATION = 'whatsgoodly.wsgi.application'

EMAIL_HOST = 'localhost'
EMAIL_PORT = 25


# Database
# https://docs.djangoproject.com/en/1.7/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.contrib.gis.db.backends.postgis',
        'NAME': 'whatsgoodly',
        'USER': 'whatsgoodly',
        'PASSWORD': 'password',
        'HOST': 'localhost',
    }
}

FIREBASE_DATABASE = 'https://whatsgoodly-dev.firebaseio.com'

# Internationalization
# https://docs.djangoproject.com/en/1.7/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_L10N = True

USE_TZ = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.6/howto/static-files/

STATIC_ROOT = '/home/deploy/static'

STATIC_PATH = os.path.join(BASE_DIR, 'static')

STATIC_URL = '/static/'

STATICFILES_DIRS = (
    STATIC_PATH,
)

STATICFILES_FINDERS = (
  'django.contrib.staticfiles.finders.FileSystemFinder',
  'django.contrib.staticfiles.finders.AppDirectoriesFinder',
)

# Media files (user-uploaded content)
# https://docs.djangoproject.com/en/1.6/howto/static-files/

MEDIA_URL = '/media/'

MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

# Template files
# https://docs.djangoproject.com/en/1.6/ref/templates/api/

TEMPLATE_PATH = os.path.join(BASE_DIR, 'templates')

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [
            TEMPLATE_PATH,
        ],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.contrib.auth.context_processors.auth',
                'django.template.context_processors.debug',
                'django.template.context_processors.i18n',
                'django.template.context_processors.media',
                'django.template.context_processors.static',
                'django.template.context_processors.tz',
                'django.contrib.messages.context_processors.messages',
                'whatsgoodly.context_processors.static_files'
            ],
        },
    },
]

# Profiling
SILK_ENABLED = False

APNS_CERT = '/home/deploy/APNSCert.pem'
APNS_KEY = '/home/deploy/APNSKey.pem'
APNS_SANDBOX = True

 # TODO dev android ARNS
AWS_ARNS_ANDROID = 'arn:aws:sns:us-east-1:631478180214:app/GCM/whatsgoodly_android'
AWS_ARNS_IOS = 'arn:aws:sns:us-east-1:631478180214:app/APNS_SANDBOX/whatsgoodly_ios_dev'

AWS_ACCESS_KEY_ID = 'AKIAJOYUBHLQ3XSA6ZTQ'
AWS_SECRET_ACCESS_KEY = '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'
AWS_REGION = 'us-east-1'

# Real-time updates in app
PUSHER_APP_ID = 'pusher_app_id'
PUSHER_KEY = 'pusher_key'
PUSHER_SECRET = 'pusher_secret'

MANDRILL_API_KEY = 'GfbDE8nbdJwbHuhpoyG6VQ'
EMAIL_BACKEND = 'djrill.mail.backends.djrill.DjrillBackend'
DEFAULT_FROM_EMAIL = 'support@whatsgoodly.com'

# Error logging with Sentry
RAVEN_CONFIG = {
    'key': 'https://47b8c398966a4528a9b9b16408f72f32@sentry.io/68700',
    'dsn': 'https://47b8c398966a4528a9b9b16408f72f32:314529a701374fa18f03559830d9e8f2@sentry.io/68700',
    # If you are using git, you can also automatically configure the
    # release based on the git info.
    'release': raven.fetch_git_sha(BASE_DIR),
}
# Ignore for 404 handling
IGNORABLE_404_URLS = (
    re.compile('/api/v\d+/polls'),
    re.compile('/api/v\d+/admin/polls'),
    re.compile('/esuohgod'),
    re.compile('/dashboard'),
    re.compile('[&?]latitude='),
)

# Bad actor detection
SMYTE_API_KEY = 'b767287a'
SMYTE_SECRET_KEY = '9aa6c91611597de0a67e01e353f86c01'
SMYTE_CLIENT_KEY = '5be369e6859cbca02b3968bfb6b9ec6e'

# Background jobs
# BROKER_URL = 'sqs://AKIAINDJKW4XBIKUXFQA:RVZ9f57XckDSH+ypV+1ITmp2cXhJR+E1CbFhBAtU@'
BROKER_URL = 'redis://localhost:6379/0'
CELERY_ACCEPT_CONTENT = ['json']
CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'
CELERY_IGNORE_RESULT = True

# SMS messaging
TWILIO_NUMBER = '+18557126356'
TWILIO_ACCOUNT_SID = 'ACe8854848442e691c53f9194b37615243'
TWILIO_AUTH_TOKEN = 'dd6cfe34181f672a4ae87261a3132c3f'
TWILIO_SMS_URL = 'https://api.twilio.com/2010-04-01/Accounts/ACe8854848442e691c53f9194b37615243/Messages.json'

BRANCH_KEY = 'key_live_mbjwQ61qqWaLiUar0k4hpmapAxgTmZxn'

AWS_ELASTICSEARCH_HOST = 'https://search-whatsgoodly-o7jwlfxxqyx35d4ehliykxl2f4.us-east-1.es.amazonaws.com/'
ELASTICSEARCH_INDEX_BREAKDOWNS = 'whatsgoodly-breakdowns'

try:
  # Local dev settings - use local_settings_template.py as a template and move
  # it to local_settings.py
  from local_settings import *
except ImportError:
  pass
