from whatsgoodly.settings import *
from whatsgoodly.utils import get_env_variable

DEBUG = False

SECRET_KEY = '*0(g*@bjg0ie3_-iigw)&w&okh-$$nmu=%_wh$99@b9+xek5h5'

DATABASES = {
    'default': {
        'ENGINE': 'django.contrib.gis.db.backends.postgis',
        'NAME': 'whatsgoodly_prod',
        'USER': 'whatsgoodly_prod',
        'PASSWORD': get_env_variable("postgres_password"),
        'HOST': 'prodrds.cgl5xrzwdnf5.us-east-1.rds.amazonaws.com',
    }
}
FIREBASE_DATABASE = 'https://whatsgoodly.firebaseio.com'

ANALYTICS_INSTANCE_IP = '10.10.6.250'

STATIC_ROOT = '/opt/app/web/current/static/'

APNS_CERT = '/opt/app/files/APNSCert.pem'
APNS_KEY = '/opt/app/files/APNSKey.pem'
APNS_SANDBOX = False

ALLOWED_HOSTS = ['.whatsgoodly.com']

GCM_APIKEY = 'AIzaSyChCbUBhPnGJthzWdnjwRObGkZT2n9FHBA'

AWS_ARNS_IOS = 'arn:aws:sns:us-east-1:631478180214:app/APNS/whatsgoodly_ios'
AWS_ARNS_ANDROID = 'arn:aws:sns:us-east-1:631478180214:app/GCM/whatsgoodly_android'

AWS_S3_ACCESS_KEY_ID = 'AKIAI7JNEHJSV4UNF4GQ'
AWS_S3_SECRET_ACCESS_KEY = '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'
AWS_BACKUPS_BUCKET_NAME = 'whatsgoodly-db-backup'

SERVER_EMAIL = 'noreply@whatsgoodly.com'

# Error logging with Sentry
RAVEN_CONFIG = {
    'key': 'https://dc108271c9604e4bbbcb95970d0e251b@sentry.io/66371',
    'dsn': 'https://dc108271c9604e4bbbcb95970d0e251b:5dcf7d5d950d460f8127cce148d16fba@sentry.io/66371',
    # If you are using git, you can also automatically configure the
    # release based on the git info.
    'release': raven.fetch_git_sha(BASE_DIR),
}

# Real-time updates in app
PUSHER_APP_ID = '188386'
PUSHER_KEY = '3a5fa38b0e2e0809ad38'
PUSHER_SECRET = 'bb8e47cf30b32f5626bd'

# Bad actor detection
SMYTE_API_KEY = '74a0defa'
SMYTE_SECRET_KEY = 'a25fbbf5db33886effa0d8b1f63aa3de'
SMYTE_CLIENT_KEY = '06753523217e3272a46990c66294c5ba'

ADMIN_IDS = (
    ('Alex Atallah', 103771),
    ('Whatsgoodly', 4110)
)

from elasticsearch_dsl.connections import connections
connections.create_connection(hosts=[AWS_ELASTICSEARCH_HOST])
