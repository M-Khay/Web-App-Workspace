from django.test import TestCase
import mock
from whatsgoodly import broadcaster
import pusher
from django.contrib.gis.geos import GEOSGeometry
from webhooks.pusher.views import local_channel_details, activate_local_channel

class PusherTest(TestCase):

    @mock.patch('pusher.pusher.Pusher')
    def test_user_points_change(self, mock_pusher):
        user = mock.Mock(id=1, karma=12)

        broadcaster.broadcast_user(user)

        mocked_pusher = mock_pusher.return_value
        mocked_pusher.trigger.assert_called_once_with(
            u'user_1',
            u'user_updated',
            {
                u'karma': user.karma
            }
        )

    @mock.patch('pusher.pusher.Pusher')
    def test_poll_instance_creation(self, mock_pusher):
        feed = mock.Mock(id=1)
        poll_instance = mock.Mock(feed=feed, id=1)

        broadcaster.broadcast_poll_instance(poll_instance)

        mocked_pusher = mock_pusher.return_value
        mocked_pusher.trigger.assert_called_once_with(
            u'feed_1',
            u'poll_instance_created',
            {u'poll_instance_id': poll_instance.id}
        )

    @mock.patch('pusher.pusher.Pusher')
    def test_poll_instance_nearby_channel_broadcast(self, mock_pusher):
        lat = 40.748817
        lon = -73.985428

        channel_lat = 40.7490
        channel_lon = -73.9819
        user_id = 10
        channel = "local-{0};{1}_{2}".format(user_id, channel_lat, channel_lon)
        channel_details = local_channel_details(channel)
        activate_local_channel(channel_details)

        location = GEOSGeometry("POINT({0} {1})".format(lat, lon))
        poll_instance = mock.Mock(id=1, location=location)
        broadcaster.broadcast_poll_instance_nearby(poll_instance)

        mocked_pusher = mock_pusher.return_value
        mocked_pusher.trigger.assert_called_once_with(
            u"%s" % channel,
            u'poll_instance_created',
            {u'poll_instance_id': poll_instance.id}
        )

    @mock.patch('pusher.pusher.Pusher')
    def test_poll_instance_vote(self, mock_pusher):
        poll_instance = mock.Mock(id=1, vote_aggregate=10)
        poll_instance_vote = mock.Mock(
            vote=1,
            poll_instance=poll_instance
        )

        broadcaster.broadcast_poll_instance_vote(
            poll_instance_vote
        )

        mocked_pusher = mock_pusher.return_value
        mocked_pusher.trigger.assert_called_once_with(
            u'poll_instance_1',
            u'vote_created',
            {
                u'vote_aggregate': poll_instance.vote_aggregate
            }
        )

    @mock.patch('pusher.pusher.Pusher')
    def test_poll_instance_response(self, mock_pusher):
        poll_instance = mock.Mock(id=1)
        poll_instance_response = mock.Mock(
          user=mock.Mock(id=10),
          response=1,
          poll_instance=poll_instance
        )

        broadcaster.broadcast_poll_instance_response(
            poll_instance_response
        )

        mocked_pusher = mock_pusher.return_value
        mocked_pusher.trigger.assert_called_once_with(
            u'poll_instance_1',
            u'response_created',
            {
                u'response': 1,
                u'user_id': 10
            }
        )

    @mock.patch('whatsgoodly.models.Comment.objects.filter')
    @mock.patch('pusher.pusher.Pusher')
    def test_comment_created(self, mock_pusher, mock_comments):
        mock_count = mock.Mock()
        mock_count.return_value = 1
        mock_comments.return_value = mock.Mock(count=mock_count)
        poll_instance = mock.Mock(id=1, comments=['test comment'])
        user = mock.Mock(id=99)
        comment = mock.Mock(
            poll_instance=poll_instance,
            user=user,
            text='test comment',
            vote_aggregate=0
        )

        broadcaster.broadcast_comment(
            comment
        )

        mocked_pusher = mock_pusher.return_value
        mocked_pusher.trigger.assert_called_once_with(
            u'poll_instance_1',
            u'comment_created',
            {
                u'user': {u'id': 99},
                u'text': 'test comment',
                u'comment_count': 1
            }
        )

    @mock.patch('pusher.pusher.Pusher')
    def test_comment_vote(self, mock_pusher):
        poll_instance = mock.Mock(id=1)
        comment = mock.Mock(
            id=234,
            poll_instance=poll_instance,
        )
        voting_user = mock.Mock(id=99)
        comment_vote = mock.Mock(
            user=voting_user,
            comment=comment,
            vote=0
        )

        broadcaster.broadcast_comment_vote(
            comment_vote
        )

        mocked_pusher = mock_pusher.return_value
        mocked_pusher.trigger.assert_called_once_with(
            u'poll_instance_1',
            u'comment_vote_created',
            {
                u'comment_id': 234,
                u'vote': 0
            }
        )
