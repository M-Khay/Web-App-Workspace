from django.test import TestCase
from django.test.client import RequestFactory
import mock
from webhooks.pusher.views import local_channel_details, activate_local_channel, deactivate_local_channel, handle_webhook_events
from whatsgoodly.models import LocalChannel

class WebhooksPusherTest(TestCase):
    @mock.patch('webhooks.pusher.views.local_channel_details')
    @mock.patch('webhooks.pusher.views.activate_local_channel')
    def test_handle_webhook_event_occupied(self, mock_activate_local_channel, mock_local_channel_details):
        webhook = {
            'events': [
                {
                    'channel': 'local-something',
                    'name': 'channel_occupied'
                }
            ]
        }

        mock_local_channel_details.return_value = 'local_channel_details'

        handle_webhook_events(webhook)

        mock_activate_local_channel.assert_called_once_with('local_channel_details')

    @mock.patch('webhooks.pusher.views.local_channel_details')
    @mock.patch('webhooks.pusher.views.deactivate_local_channel')
    def test_handle_webhook_event_vacated(self, mock_deactivate_local_channel, mock_local_channel_details):
        webhook = {
            'events': [
                {
                    'channel': 'local-something',
                    'name': 'channel_vacated'
                }
            ]
        }

        mock_local_channel_details.return_value = 'local_channel_details'

        handle_webhook_events(webhook)

        mock_deactivate_local_channel.assert_called_once_with('local_channel_details')

    def test_activate_local_channel(self):
        details = dict(
            channel='local-18;37.332331_-122.031219',
            user_id=18,
            lat=37.332331,
            lon=-122.031219
        )

        lookup_details = dict(
            name='local-18;37.332331_-122.031219',
            user_id=18,
            location="POINT (37.332331 -122.031219)",
            active=True
        )

        self.assertEqual(LocalChannel.objects.filter(**lookup_details).count(), 0)

        activate_local_channel(details)

        self.assertEqual(LocalChannel.objects.filter(**lookup_details).count(), 1)

    def test_deactivate_local_channel(self):
        details = dict(
          channel='local-18;37.332331_-122.031219',
          user_id=18,
          lat=37.332331,
          lon=-122.031219
        )
        activate_local_channel(details)

        lookup_details = dict(
          name='local-18;37.332331_-122.031219',
          user_id=18,
          location="POINT (37.332331 -122.031219)",
          active=True
        )
        self.assertEqual(LocalChannel.objects.filter(**lookup_details).count(), 1)

        deactivate_local_channel(details)

        self.assertEqual(LocalChannel.objects.filter(**lookup_details).count(), 0)

    def test_local_channel_details(self):
        details = dict(
          channel='local-18;37.332331_-122.031219',
          user_id=18,
          lat=37.332331,
          lon=-122.031219
        )

        self.assertEqual(local_channel_details(details['channel']), details)
