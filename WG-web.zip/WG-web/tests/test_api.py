from rest_framework.test import APITestCase
from whatsgoodly.models import User, Poll, PollInstance
import mock

class PollInstanceLocalAPITestCase(APITestCase):
    def setUp(self):
        self.user = User.objects.create_superuser(
          'super',
          'super@example.com',
          'password'
        )
        self.client.login(username='super', password='password')

    @mock.patch('whatsgoodly.broadcaster')
    def test_create_local_poll(self, mock_broadcaster):
        # do something
        post_data = {
            'feed': 1,
            'gender': 2,
            'options': [
                'Yes',
                'No'
            ],
            'question': 'Test Question?',
            'latitude': '40.748817',
            'longitude': '-73.985428'
        }
        response = self.client.post(
            '/api/v3/polls/local/new/',
            data=post_data,
            format='json'
        )
        self.assertEqual(response.status_code, 201)
        poll = Poll.objects.get(
            user=self.user,
        )
        self.assertEqual(poll.question, 'Test Question?')
        poll_instance = PollInstance.objects.get(
            poll=poll,
        )
        self.assertEqual(response.data, {
            'feed': 1,
            'gender': 2,
            'options': [
                'Yes',
                'No'
             ],
            'question': 'Test Question?',
            'id': poll_instance.id
        })
