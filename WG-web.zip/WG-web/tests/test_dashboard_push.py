from django.test import TestCase
from dashboard.push import CustomPush
from whatsgoodly.models import User, Feed, Notification, University
from api.serializers import PollInstanceCreateSerializer
from django.contrib.gis.geos import Point
from django.test.client import RequestFactory
import mock

@mock.patch('pusher.pusher.Pusher')
class DashboardPushTest(TestCase):
  def test_plain_notification(self, mocked_pusher):
    push = CustomPush(
      notification_title='Test Notification Title',
      notification_copy='Test Notification Copy'
    )
    self.assertEqual(push.is_plain_notification(), True)
  
  def test_featured_notification(self, mocked_pusher):
    push = CustomPush(
      notification_title='Featured Notification Title',
      notification_copy='Featured Notification Copy',
      featured_poll_id=1
    )
    self.assertEqual(push.is_plain_notification(), False)
    self.assertEqual(push.is_featured_notification(), True)

  def test_local_notification(self, mocked_pusher):
    push = CustomPush(
      notification_title='Local Notification Title',
      notification_copy='Local Notification Copy',
      local_poll_id=1
    )
    self.assertEqual(push.is_plain_notification(), False)
    self.assertEqual(push.is_featured_notification(), False)

  def test_build_notification(self, mocked_pusher):
    user = User.objects.create(karma=0)
    feed = Feed.objects.create(name='Test Feed')

    request_factory = RequestFactory()
    request = request_factory.get('/test', REMOTE_ADDR='127.0.0.1')
    request.user = user
    context = {
      'request': request
    }
    poll_data = {
      'feed': feed.id,
      'question': 'Question',
      'options': ["Option 1", "Option 2"],
      'gender': 0,
      'lat': -86,
      'lon': 36
    }
    poll_instance_serializer = PollInstanceCreateSerializer(
      data=poll_data,
      context=context
    )
    poll_instance_serializer.is_valid(raise_exception=True)
    poll_instance = poll_instance_serializer.save(
      user=user,
      ip_address='127.0.0.1',
      location=Point(-86, 36),
      deleted=False
    )

    push = CustomPush(
      notification_title='Notification Title',
      notification_copy='Notification Copy',
    )
    build_notification = push.build_notification(
      user=user,
      options={"poll_instance": poll_instance}
    )
    self.assertEqual(build_notification.user, user)
    self.assertEqual(build_notification.title, 'Notification Title')
    self.assertEqual(build_notification.body, 'Notification Copy')
    self.assertEqual(build_notification.notification_type, 0)
    self.assertEqual(build_notification.poll_instance, poll_instance)

  def test_eligible_universities(self, mocked_pusher):
    user = User.objects.create(karma=0)
    feed = Feed.objects.create(name='Test Feed')
    latitude = -86
    longitude = 36

    university = University.objects.create(
      name='Test University',
      location=Point(latitude, longitude)
    )
    other_university = University.objects.create(
      name='Other University',
      location=Point(latitude+1, longitude+1)
    )

    request_factory = RequestFactory()
    request = request_factory.get('/test', REMOTE_ADDR='127.0.0.1')
    request.user = user
    context = {
      'request': request
    }
    poll_data = {
      'feed': feed.id,
      'question': 'Question',
      'options': ["Option 1", "Option 2"],
      'gender': 0,
      'lat': latitude,
      'lon': longitude
    }
    poll_instance_serializer = PollInstanceCreateSerializer(
      data=poll_data,
      context=context
    )
    poll_instance_serializer.is_valid(raise_exception=True)
    poll_instance = poll_instance_serializer.save(
      user=user,
      ip_address='127.0.0.1',
      location=Point(latitude, longitude),
      deleted=False
    )
    local_poll = poll_instance.poll

    push = CustomPush(
      notification_title='Notification Title',
      notification_copy='Notification Copy',
      local_poll_id=local_poll.id
    )

    eligible_universities = push.eligible_universities(
      local_poll_id=local_poll.id
    )
    self.assertEqual(eligible_universities, [university.id])

  def test_university_filters(self, mocked_pusher):
    push = CustomPush(
      notification_title='Test Notification Title',
      notification_copy='Test Notification Copy'
    )
    empty_filter = push.university_filters()
    self.assertEqual(empty_filter, {})

    male_filter = push.university_filters(
      user_filter='male'
    )
    self.assertEqual(male_filter, {'gender': 0})

    female_filter = push.university_filters(
      user_filter='female'
    )
    self.assertEqual(female_filter, {'gender': 1})

    university_registered_filter = push.university_filters(
      user_filter='university-registered'
    )
    self.assertEqual(university_registered_filter, {'verified_university': True})
