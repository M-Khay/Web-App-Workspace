from django.core.urlresolvers import resolve
from django.test import TestCase, Client
from django.http import HttpRequest
from mock import patch
from whatsgoodly.models import User, Poll

from dashboard.views import push, create_push

class PushNotificationTest(TestCase):
  def setUp(self):
    self.user = User.objects.create_superuser(
      'super',
      'super@example.com',
      'password'
    )
    self.client = Client()
    self.client.login(username='super', password='password')

  def test_push_url_resolves_to_push_page(self):
    found = resolve('/dashboard/push/')
    self.assertEqual(found.func, push)

  @patch('api.tasks.create_and_send_notifs')
  def test_basic_push_creation(self, mock_task):
    response = self.client.post('/dashboard/api/push/create/', {
      'notification_title': 'Test Notification',
      'notification': 'Test Copy',
      'users': 'all',
      'include_nearby_timeframe': 3
    })
    self.assertEqual(response.status_code, 200)
    mock_task.delay.assert_called_once_with(
      notification_title='Test Notification',
      notification_copy='Test Copy',
      include_nearby=False,
      include_nearby_timeframe=3,
      featured_poll_id=None,
      local_poll_id=None,
      university_ids=None,
      user_filter=None,
      user_ids=None
    )

  @patch('api.tasks.create_and_send_notifs')
  def test_push_for_featured_poll(self, mock_task):
    featured_poll = Poll(user=self.user, question="Will this work?", verified=True)
    featured_poll.save()
    response = self.client.post('/dashboard/api/push/create/', {
      'notification_title': 'Featured Notification',
      'notification': 'Featured Copy',
      'featured_poll_id': featured_poll.pk,
      'users': 'all',
      'include_nearby_timeframe': 3
    })
    self.assertEqual(response.status_code, 200)
    mock_task.delay.assert_called_once_with(
      featured_poll_id=featured_poll.pk,
      include_nearby=False,
      include_nearby_timeframe=3,
      local_poll_id=None,
      notification_copy='Featured Copy',
      notification_title='Featured Notification',
      university_ids=None,
      user_filter=None,
      user_ids=None
    )

  @patch('api.tasks.create_and_send_notifs')
  def test_push_error(self, mock_task):
    mock_task.delay.side_effect = Exception('strange error')
    response = self.client.post('/dashboard/api/push/create/', {})
    self.assertEqual(response.status_code, 403)
    self.assertEqual(response.content, '{"error":"strange error"}')
