from django.test import TestCase, Client
from whatsgoodly.models import Feed, PollInstance, User
from api.serializers import PollInstanceCreateSerializer
from django.test.client import RequestFactory
from django.contrib.gis.geos import Point

class FeedLevelTest(TestCase):

    def setUp(self):
        self.user = User.objects.create_superuser(
          'super',
          'super@example.com',
          'password'
        )
        self.high_school_global_feed = Feed.objects.create(
            name='Global Feed',
            level=0,
            active=True,
            category=Feed.GLOBAL
        )
        self.college_global_feed = Feed.objects.create(
            name='Global Feed',
            level=1,
            active=True,
            category=Feed.GLOBAL
        )
        self.high_school_feature_feed = Feed.objects.create(
            name='Feature Feed',
            level=Feed.LEVELS.HIGH_SCHOOL,
            active=True,
            category=Feed.FEATURED
        )
        self.college_feature_feed = Feed.objects.create(
            name='Feature Feed',
            level=1,
            active=True,
            category=Feed.FEATURED
        )
        self.client = Client()
        self.client.login(username='super', password='password')

        self.create_poll_instance(
            feed=self.high_school_global_feed,
            question='High School Question'
        )
        self.create_poll_instance(
            feed=self.college_global_feed,
            question='College Question'
        )
        self.create_poll_instance(
            feed=self.high_school_feature_feed,
            question='High School Feature Question'
        )
        self.create_poll_instance(
            feed=self.college_feature_feed,
            question='College Feature Question'
        )


    def test_high_school_global_feed(self):
        response = self.client.get('/api/v3/feed/global/all/', {
            'level': 0
        })
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data), 1)
        response_poll_instance = response.data[0]
        self.assertEqual(response_poll_instance['question'], 'High School Question')

    def test_high_school_feature_feed(self):
        feed_id = self.high_school_feature_feed.id
        response = self.client.get('/api/v3/feed/{0}/all/'.format(feed_id), {
            'level': Feed.LEVELS.HIGH_SCHOOL
        })
        self.assertEqual(response.status_code, 200)
        top_polls = response.data['top_polls']
        recent_polls = response.data['recent_polls']

        self.assertEqual(len(top_polls), 1)
        self.assertEqual(len(recent_polls), 1)

        self.assertEqual(top_polls[0]['question'], 'High School Feature Question')
        self.assertEqual(recent_polls[0]['question'], 'High School Feature Question')

    def test_college_feed(self):
        response = self.client.get('/api/v3/feed/global/all/', {
            'level': 1
        })
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data), 1)
        response_poll_instance = response.data[0]
        self.assertEqual(response_poll_instance['question'], 'College Question')

    def test_college_feature_feed(self):
        feed_id = self.college_feature_feed.id
        response = self.client.get('/api/v3/feed/{0}/all/'.format(feed_id), {
            'level': 1
        })
        top_polls = response.data['top_polls']
        recent_polls = response.data['recent_polls']

        self.assertEqual(top_polls[0]['question'], 'College Feature Question')
        self.assertEqual(recent_polls[0]['question'], 'College Feature Question')

    def create_poll_instance(self, feed, question):
        poll_data = {
          'feed': feed.id,
          'question': question,
          'options': ["Option 1", "Option 2"],
          'gender': 0,
          'lat': -86,
          'lon': 36
        }
        request_factory = RequestFactory()
        request = request_factory.get('/test', REMOTE_ADDR='127.0.0.1')
        request.user = self.user
        context = {
          'request': request
        }
        poll_instance_serializer = PollInstanceCreateSerializer(
          data=poll_data,
          context=context
        )
        poll_instance_serializer.is_valid(raise_exception=True)
        poll_instance = poll_instance_serializer.save(
          user=self.user,
          ip_address='127.0.0.1',
          location=Point(-86, 36),
          deleted=False,
          verified=True
        )
