#!/usr/bin/env python
import os
import sys
from django.core.exceptions import ImproperlyConfigured
from whatsgoodly.utils import get_env_variable

if __name__ == "__main__":
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "whatsgoodly.settings_%s" % get_env_variable("env"))

    from django.core.management import execute_from_command_line

    execute_from_command_line(sys.argv)
