from django.contrib import admin
from django.contrib.gis.admin import GeoModelAdmin
from dashboard.models import District


class HTTPS_GeoModelAdmin(GeoModelAdmin):
    """
    Override geo model admin class to use local copy of OpenLayers
    """
    openlayers_url = '/static/openlayers/OpenLayers.js'


admin.site.register(District, HTTPS_GeoModelAdmin)
