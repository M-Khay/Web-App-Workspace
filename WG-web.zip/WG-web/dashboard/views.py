from dashboard.serializers import *
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.admin.models import LogEntry, CHANGE, ADDITION
from django.contrib.contenttypes.models import ContentType
from django.contrib.gis.geos import GEOSGeometry
from django.contrib.gis.measure import D
from django.conf import settings
from django.db.models import Count, Q, Prefetch
from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from rest_framework import generics, permissions
from whatsgoodly import broadcaster
from whatsgoodly.models import *
from whatsgoodly.utils import decayed_score_sql
from dashboard.models import District
from api.utils import CENSOR_LEVELS, convert_to_point, send_delete_poll_email, send_smyte_message, send_slack_message, get_ip_address
from api import querysets
from api.permissions import account_required
from api.notifications import create_poll_notification
from dashboard.push import CustomPush
from rest_framework import response
from rest_framework.decorators import api_view, permission_classes
import traceback
import datetime
import json
import unicodecsv as csv
import requests
from django.utils import timezone
# TODO move
from bs4 import BeautifulSoup

POLL_PAGE_SIZE = 30
INSTAGRAM_TOKEN = "539771724.1486051.e8999a10c4f04a8690995e39d62ffe50"
# Whatsgoodly token: "1691430141.1486051.b714168b2f584f5897219798c442a7ec"

@staff_member_required
def index(request):
    return render(request, 'dashboard/index.html', {})

@staff_member_required
def groups(request):
    return render(request, 'dashboard/groups.html', {})

@staff_member_required
def push(request):
    emojis = dict(Notification.TYPES.EMOJIS)
    notification_types = [
        u"{0} {1}".format(emojis[key], label)
        for key, label in Notification.TYPES.CHOICES
    ]
    return render(request, 'dashboard/push.html', {
            "notification_types": json.dumps(notification_types)
        })

@staff_member_required
def university(request):
    local_feed = Feed.objects.get(category=Feed.LOCAL)
    universities = []
    for u in University.objects.all().order_by('-modified_date')[:5]:
        uni = { 'name': u.name }
        time_threshold = datetime.datetime.now() - datetime.timedelta(days=7)
        polls = PollInstance.objects.filter(feed=local_feed,
                user__university=u, created_date__gt=time_threshold)
        responses = Response.objects.filter(poll_instance__in=polls)
        response_count = responses.count()
        poll_count = polls.count()
        avg_response = round(response_count / float(max(poll_count, 1)), 2)
        uni["7"] = {
            'poll_count': poll_count,
            'response_count': response_count,
            'avg_response': avg_response
        }
        universities.append(uni)
    data = {
        'universities': universities
    }
    return render(request, 'dashboard/university.html', data)

@staff_member_required
def post(request):
    return render(request, 'dashboard/post.html', {})

@staff_member_required
def post_comment(request):
    return render(request, 'dashboard/post_comment.html', {})

@staff_member_required
def featurefeeds(request):
    return render(request, 'dashboard/featurefeed.html', {})

@account_required
def analyze_poll(request, pk):
    context = { 'request': request }
    poll = get_object_or_404(Poll, pk=pk)
    breakdowns = poll.breakdowns.all()
    serializer = PollBreakdownExportSerializer(breakdowns, many=True, context=context)
    poll_serializer = PollSerializer(poll, context=context)
    data = {
        "poll": json.dumps(poll_serializer.data),
        "breakdowns": json.dumps(serializer.data),
        "timeline_settings":  json.dumps(dict(Survey.TIMELINE_SETTINGS.CHOICES[1:]))
    }
    return render(request, 'dashboard/analyze_poll.html', data)

@staff_member_required
@api_view(['GET'])
def instagram_analysis(request, user_id):
    context = { 'request': request }
    url = "https://api.instagram.com/v1/users/{}/media/recent/?access_token={}".format(
        user_id, INSTAGRAM_TOKEN
    )
    resp = requests.get(url, headers={'Content-Type': 'application/json'})
    data = resp.json()
    images = data.get("data", [])
    matches = []
    for image in images:
        url = image['images']['standard_resolution']['url']
        code = doImageSearch(url)
        result = parseImageSearchResults(code)
        if result.get("thief_images"):
            matches.append({
                'url': url,
                'google_image_search': result
            })
    return response.Response(matches, status=200)

@account_required
def export_poll_csv(request, pk):
    context = { 'request': request }
    poll = get_object_or_404(Poll, pk=pk)
    breakdowns = poll.breakdowns.all()
    serializer = PollBreakdownExportSerializer(breakdowns, many=True, context=context)
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="WhatsgoodlyData.csv"'

    writer = csv.writer(response)
    writer.writerow(['Question', 'Segment Type', 'Segment Description', 'Answer', 'Count', 'Percentage'])
    opts = json.loads(poll.options)
    for b in serializer.data:
        for i, opt in enumerate(opts):
            count, percentage = b['option_counts'][i], b['percentages'][i]
            row = [
                b['poll']['question'], b['breakdown_type_label'], b['label'], opt, count, percentage
            ]
            writer.writerow(row)

    return response

@staff_member_required
def profiles(request, pk=None):
    pk = pk or request.user.pk
    user = get_object_or_404(User, pk=pk)
    serializer = UserSerializer(user)
    data = {"current_user": json.dumps(serializer.data)}
    return render(request, 'dashboard/profiles.html', data)

@staff_member_required
def teacherspet(request):
    return render(request, 'dashboard/teacherspet.html', {})

@staff_member_required
def point_post(request):
    return render(request, 'dashboard/point_post.html', {})

@staff_member_required
@api_view(['GET'])
def get_profile(request, pk):
    pk = pk or request.user.id
    user = get_object_or_404(User, pk=pk)
    response_qset = Response.objects.filter(user=user)\
        .select_related('poll_instance', 'poll_instance__poll', 'poll_instance__feed')\
        .order_by('-id')
    responses = response_qset[:200]
    favs = list(Favorite.objects.filter(
            poll_instance__in=responses.values('poll_instance'),
            user=user
        ))
    removals = list(PollInstanceRemoval.objects.filter(
            poll_instance__in=responses.values('poll_instance'),
            user=user
        ))
    context = { 'request': request, 'favs': favs, 'removals': removals }
    responses_data = ResponseSerializer(responses, many=True, context=context).data
    data = {
        'responses': responses_data,
        'count': response_qset.count()
    }
    return response.Response(data, status=200)

@staff_member_required
@api_view(['POST'])
def create_group(request):
    name = request.data.get("name", None)
    university_ids = request.data.get("universities", None)
    universities = University.objects.filter(pk__in=university_ids)
    group = Group(title=name)
    group.save()
    group.universities = universities
    group.save()
    serializer = UniversityGroupSerializer(group, many=False)
    return response.Response(serializer.data, status=200)

@staff_member_required
@api_view(['DELETE'])
def delete_group(request, pk):
    group = Group.objects.get(pk=pk)
    group.delete()
    return response.Response("Success", status=200)

class GroupUpdate(generics.UpdateAPIView):
    permission_classes = ( permissions.IsAdminUser, )
    serializer_class = UniversityGroupSerializer
    def get_object(self):
        group_id = int(self.kwargs['pk'])
        return Group.objects.get(pk=group_id)
    def perform_update(self, serializer):
        options = serializer.validated_data.get('get_options', None)
        group = serializer.save()

@staff_member_required
@api_view(['GET'])
def retrieve_groups(request):
    groups = Group.objects.all()
    serializer = UniversityGroupSerializer(groups, many=True)
    return response.Response(serializer.data, status=200)

# POST needed here because university_ids and user_ids
# may be too large for a GET
@staff_member_required
@api_view(['POST'])
def recipients_for_push(request):
    data = request.data
    include_nearby = data.get("include_nearby", False) == "true"
    try:
        qset = CustomPush(
                user_ids=data.getlist("user_ids[]", []),
                user_filter=data.get("user_filter", None),
                include_nearby=include_nearby,
                include_nearby_timeframe=int(data.get("include_nearby_timeframe", 3)),
                university_ids=data.getlist("university_ids[]", [])
            ).recipient_queryset()
        data = {"count": qset.count()}
        return response.Response(data, status=200)
    except Exception as e:
        traceback.print_exc()
        return response.Response({'error': e.message}, status=400)

@staff_member_required
@api_view(['POST'])
def create_push(request):
    local_poll_id = request.data.get("local_poll_id")
    if local_poll_id:
        local_poll_id = int(local_poll_id)

    featured_poll_id = request.data.get("featured_poll_id")
    if featured_poll_id:
        featured_poll_id = int(featured_poll_id)

    user_ids = request.data.getlist("user_ids[]", [])
    include_nearby = request.data.get("include_nearby", False) == "true"

    try:
        p = CustomPush(
            notification_title=request.data["notification_title"],
            notification_copy=request.data.get("notification", None),
            notification_type=int(request.data.get("notification_type", 0)),
            poll_id=local_poll_id,
            poll_instance_id=featured_poll_id,
            user_ids=user_ids,
            user_filter=request.data.get("user_filter", None),
            include_nearby=include_nearby,
            include_nearby_timeframe=int(request.data.get("include_nearby_timeframe", 3)),
            university_ids=request.data.getlist("university_ids[]", [])
        )
        p.send()
        return response.Response({}, status=200)
    except Exception as e:
        traceback.print_exc()
        return response.Response({'error': e.message}, status=400)

@staff_member_required
@api_view(['GET'])
def retrieve_universities(request):
    universities = University.objects.all().order_by('name')
    serializer = UniversitySerializer(universities, many=True)
    return response.Response(serializer.data, status=200)

@staff_member_required
@api_view(['POST'])
def retrieve_eligible_universities(request):
    local_poll_id = request.data.get("local_poll_id", "").strip()
    universities = []

    if local_poll_id:
        poll_instances = PollInstance.objects.filter(poll_id=int(local_poll_id))
        universities = University.objects.filter(
                location__in=poll_instances.values('location')
            ).order_by('name')

    serializer = UniversitySerializer(universities, many=True)
    return response.Response(serializer.data, status=200)

@staff_member_required
@api_view(['POST'])
def post_to_point(request):
    question = request.data.get("question", None)
    options = request.data.get("options", None)
    gender = request.data.get("gender", None)
    latitude = request.data.get("latitude", None)
    longitude = request.data.get("longitude", None)
    promoted = request.data.get("promotion", False)
    data = [question, options, gender, latitude, longitude]
    if None in data:
        return response.Response("Bad request", status=400)
    for option in options:
        if len(option) == 0:
            return response.Response("Invalid request", status=400)
    latitude = float(latitude)
    longitude = float(longitude)
    location = convert_to_point(latitude, longitude)
    user = User.objects.get(username='whatsgoodly')
    feed = Feed.objects.get(category=Feed.LOCAL)
    poll = Poll(user=user, question=question, gender=gender, options=json.dumps(options), verified=True)
    poll.save()
    poll_instance = PollInstance(user=user, poll=poll, feed=feed, location=location, promotion=promotion, verified=True)
    poll_instance.save()
    return response.Response("Success", status=201)

@staff_member_required
@api_view(['GET'])
def retrieve_feature_feeds(request):
    feeds = Feed.objects.filter(
            category__in=[Feed.FEATURED, Feed.MY_FEATURED]
        ).order_by("-active", "category", "-level", "id")
    serializer = FeedSerializer(feeds, many=True)
    return response.Response(serializer.data, status=200)

@staff_member_required
@api_view(['GET'])
def feeds(request):
    feeds = Feed.objects.exclude(
            category__in=Feed.FAKE_CATEGORIES
        ).order_by("-active", "category", "-level", "id")
    serializer = FeedSerializer(feeds, many=True)
    return response.Response(serializer.data, status=200)

@staff_member_required
@api_view(['POST'])
def accept_feature_poll(request, pk):
    user = request.user
    poll_instance = PollInstance.objects.get(pk=pk)
    poll_instance.verified = True
    poll_instance.verified_by = user
    time_now = timezone.now()
    poll_instance.created_date = time_now
    poll_instance.save()
    p = CustomPush(
        notification_title="Poll Accepted",
        notification_copy="Congrats! Your poll was featured!",
        poll_instance_id=pk,
        user_ids=[poll_instance.user.pk]
    )
    p.send()
    broadcaster.broadcast_poll_instance(poll_instance)
    poll_data = PollInstanceSerializer(poll_instance).data
    log_poll_moderated(poll_data, 'accepted', request)

    # if poll_instance.poll.censor_level != CENSOR_LEVELS.NONE:
    #     slack_message = u"*\"<https://whatsgoodly.com/esuohgod/whatsgoodly/pollinstance/{0}|{1}>\"* \nfrom User {2} [{3} pts] \naccepted into *{4}* by {5}".format(
    #             poll_instance.id,
    #             poll_instance.poll.question,
    #             poll_instance.user.id,
    #             poll_instance.user.karma,
    #             poll_instance.feed.name,
    #             user.username
    #         )
    #     if not user.is_staff:
    #         slack_message = "{0} (CAMPUS REP for {1}: User {2})".format(
    #                 slack_message,
    #                 user.university.name,
    #                 user.id
    #             )
    #     send_slack_message(slack_message, event_name="Poll Accepted",
    #         emoji=":white_check_mark:", channel="#moderation")
    return response.Response("Success", status=200)

@staff_member_required
@api_view(['POST'])
def toggle_verified_teacherspet_poll(request, pk):
    poll_instance = PollInstance.objects.get(pk=pk)
    if poll_instance.verified:
        poll_instance.verified = False
    else:
        if poll_instance.rejected:
            poll_instance.rejected = False
        poll_instance.verified = True
    poll_instance.save()
    return response.Response("Success", status=200)

@staff_member_required
@api_view(['POST'])
def toggle_verified_teacherspet_comment(request, pk):
    comment = Comment.objects.get(pk=pk)
    if comment.verified:
        comment.verified = False
    else:
        if comment.rejected:
            comment.rejected = False
        comment.verified = True
    comment.save()
    return response.Response("Success", status=200)

@staff_member_required
@api_view(['POST'])
def toggle_rejected_teacherspet_poll(request, pk):
    poll_instance = PollInstance.objects.get(pk=pk)
    if poll_instance.rejected:
        poll_instance.rejected = False
    else:
        if poll_instance.verified:
            poll_instance.verified = False
        poll_instance.rejected = True
    poll_instance.save()
    return response.Response("Success", status=200)

@staff_member_required
@api_view(['POST'])
def toggle_rejected_teacherspet_comment(request, pk):
    comment = Comment.objects.get(pk=pk)
    if comment.rejected:
        comment.rejected = False
    else:
        if comment.verified:
            comment.verified = False
        comment.rejected = True
    comment.save()
    return response.Response("Success", status=200)

@staff_member_required
@api_view(['POST'])
def toggle_feature_feed_status(request, pk):
    feed = Feed.objects.get(pk=pk)
    feed.active = not feed.active;
    feed.save()
    serializer = FeedSerializer(feed)
    return response.Response(serializer.data, status=200)

@staff_member_required
@api_view(['POST'])
def remove_feature_poll(request, pk):
    poll_instance = PollInstance.objects.get(pk=pk)
    poll_instance.verified = False
    poll_instance.auto_verified = False
    poll_instance.save()
    poll_data = PollInstanceSerializer(poll_instance).data
    log_poll_moderated(poll_data, 'removed', request)
    return response.Response("Success", status=200)

@staff_member_required
@api_view(['DELETE'])
def trash_feature_poll(request, pk):
    poll_instance = PollInstance.objects.get(pk=pk)
    poll_instance.poll.deleted = True
    poll_instance.poll.save()
    poll_instance.deleted_by_admin = True
    poll_instance.deleted = True
    poll_instance.save()
    return response.Response("Success", status=200)

@staff_member_required
@api_view(['GET'])
def retrieve_feature_polls(request, pk):
    feed = Feed.objects.get(pk=pk)
    queryset = PollInstance.objects.undeleted().filter(feed=feed).order_by('-id')
    page = int(request.GET.get('page', 1))

    polls = queryset[POLL_PAGE_SIZE*(page - 1):POLL_PAGE_SIZE*page]
    serializer = PollInstanceSerializer(querysets.poll_instance_dashboard_related(polls), many=True)
    return response.Response(serializer.data, status=200)

@staff_member_required
@api_view(['GET'])
def retrieve_pending_polls(request):
    polls = PollInstance.objects.undeleted().filter(feed=Feed.objects.get(category=Feed.LOCAL),
            verified=False, rejected=False).order_by('-id')
    serializer = PollInstanceSerializer(querysets.poll_instance_dashboard_related(polls), many=True)
    return response.Response(serializer.data, status=200)

@staff_member_required
@api_view(['GET'])
def retrieve_pending_comments(request):
    comments = Comment.objects.filter(poll_instance__feed=Feed.objects.get(category=Feed.LOCAL),
        verified=False, rejected=False, deleted=False, poll_instance__deleted=False).order_by('-id')
    serializer = CommentSerializer(comments, many=True)
    return response.Response(serializer.data, status=200)

@staff_member_required
@api_view(['GET'])
def comments_for_poll(request, pk):
    comments = Comment.objects.filter(poll_instance__id=pk).order_by('id').all()
    serializer = CommentSerializer(comments, many=True)
    return response.Response(serializer.data, status=200)

@staff_member_required
@api_view(['POST','DELETE'])
def toggle_comment(request, pk):
    comment = Comment.objects.get(pk=pk)
    comment.deleted = not comment.deleted
    comment.save()
    serializer = CommentSerializer(comment)
    return response.Response(serializer.data, status=200)

@staff_member_required
@api_view(['POST'])
def post_comments(request):
    poll_id = request.data.get("pollID", None)
    poll_instance_ids = request.data.get("pollInstanceIDs", "").replace(" ", "")
    admin_id = dict(settings.ADMIN_IDS).get('Whatsgoodly')
    user_id = request.data.get("userID", None) or admin_id
    body = request.data.get("comment", None)
    only_first_comment = request.data.get("onlyFirstComment", None) == "true"

    if not body:
        return response.Response("No comment text provided", status=400)

    if poll_id and poll_instance_ids:
        return response.Response("Only provide poll or poll instances", status=400)

    if poll_instance_ids:
        pis = PollInstance.objects.filter(pk__in=poll_instance_ids.split(",")).only('id')
    elif poll_id:
        pis = PollInstance.objects.filter(poll_id=poll_id).only('id')
    else:
        return response.Response("No poll or poll instances provided", status=400)

    comments = []

    for pi in pis:
        if only_first_comment and \
                Comment.objects.filter(poll_instance=pi, deleted=False).exists():
            continue
        comments.append(
            Comment(
                verified=True, ip_address=get_ip_address(request),
                text=body,
                user_id=user_id,
                poll_instance=pi,
                vote_aggregate=1
            )
        )

    Comment.objects.bulk_create(comments, 500)

    data = {
        "count": len(comments)
    }
    return response.Response(data, status=201)

@staff_member_required
@api_view(['POST'])
def post_polls(request):
    poll_id = request.data.get("pollID", None)
    question = request.data.get("question", None)
    question_picture_url = request.data.get("questionPicture") or None
    options = request.data.get("options", None)
    feed = get_object_or_404(Feed, pk=request.data.get("feedID"))
    gender = request.data.get("gender", None)
    universities = request.data.get("universities", None)
    isFraternities = request.data.get("isFraternities", False)
    isSororities = request.data.get("isSororities", False)
    banner = request.data.get("banner", None)
    
    required_data = [question, options, gender, universities]
    if not poll_id:
        if None in required_data or len(question) == 0:
            return response.Response("Invalid request: empty question", status=400)
        if isFraternities is False and isSororities is False:
            for option in options:
                if len(option) == 0:
                    return response.Response("Invalid request: empty option", status=400)
    if feed.category == Feed.GLOBAL and not banner:
        return response.Response("Invalid request: no banner set", status=400)

    admin = User.objects.get(username='whatsgoodly')
        
    if poll_id:
        user = Poll.objects.get(pk=poll_id).user
    else:
        user = admin
    if not poll_id and (isFraternities or isSororities) and feed.category == Feed.LOCAL:
        for uni_id in universities:
            uni = University.objects.get(id=uni_id)
            if isFraternities:
                if uni.fraternities is None:
                    continue
                else:
                    options = uni.fraternities
            elif isSororities:
                if uni.sororities is None:
                    continue
                else:
                    options = uni.sororities

            poll = Poll(
                user=user,
                question=question,
                question_picture_url=question_picture_url,
                gender=gender, options=options,
                verified=True
            )
            poll.save()
            make_poll_instance(admin, poll, feed, community=uni)
        return response.Response("success", status=201)

    if poll_id:
        poll = Poll.objects.get(pk=poll_id)
    else:
        poll = Poll(
            user=user, question=question, question_picture_url=question_picture_url,
            gender=gender, options=json.dumps(options), verified=True
        )
        poll.save()
    if feed.category != Feed.LOCAL:
        location = convert_to_point(0,0)
        make_poll_instance(
            user, poll, feed,
            location=location, banner=banner,
            should_notify=bool(poll_id)
        )
    else:
        # Local feed, make lots of polls for each school
        for uni_id in universities:
            uni = University.objects.get(id=uni_id)
            make_poll_instance(
                admin, poll, feed,
                community=uni,
                should_notify=False
            )
    return response.Response("success", status=201)

@staff_member_required
@api_view(['PATCH'])
def update_tags_on_post(request, pk):
    pi = get_object_or_404(PollInstance, pk=pk)
    labels = request.data.getlist("tags[]", [])
    tags = [
        PollTag.objects.get_or_create(label_lower=label.lower())[0]
        for label in labels
    ]
    # pi.poll.tags.set(tags) #only available in 1.9. calls .remove for old tags and then .add for new ones
    pi.poll.tags.clear()
    pi.poll.tags.add(*tags)
    LogEntry.objects.log_action(
        user_id=request.user.id,
        content_type_id=ContentType.objects.get_for_model(Poll).pk,
        object_id=pi.poll.id,
        object_repr=unicode(pi.poll),
        action_flag=CHANGE,
        change_message="Changed tags from dashboard."
    )
    serializer = PollInstanceSerializer(pi, context={'request': request})
    return response.Response(serializer.data, status=200)

class PollTagList(generics.ListAPIView):
    serializer_class = PollTagSerializer
    permission_classes = ( permissions.IsAdminUser, )

    def get_queryset(self):
        params = self.request.query_params
        return PollTag.objects.all()

class PollList(generics.ListAPIView):
    """
    author: Ayush
    @desc: Serializer for the poll object.
    """
    serializer_class = PollInstanceSerializer
    permission_classes = ( permissions.IsAdminUser, )

    def get_queryset(self):
        """
        author: Ayush
        """
        params = self.request.query_params


        area = GEOSGeometry("POLYGON((%s %s, %s %s, %s %s, %s %s, %s %s))" % (
          str(params['ne_lo']),  str(params['ne_la']), str(params['ne_lo']),
          str(params['sw_la']), str(params['sw_lo']), str(params['sw_la']),
          str(params['sw_lo']), str(params['ne_la']), str(params['ne_lo']),
          str(params['ne_la'])))

        filters = params['filters']
        filter_args = {}
        annotate_args = {}
        order = ""
        queryset = PollInstance.objects.all()

        if "location" in filters:
            filter_args['location__within'] = area
        if "reported" in filters:
            annotate_args['num_reports'] = Count('report')
            filter_args['num_reports__gte'] = 1
        if "auto-flagged" in filters:
            filter_args['poll__censor_level__gt'] = CENSOR_LEVELS.DELETE
        if "not-deleted" in filters:
            filter_args['deleted'] = False
        if "verified" in filters:
            filter_args['verified'] = True

        sort = params['sort']
        if sort == "recent":
            order = ['-id']
        if sort == "reports":
            annotate_args['num_reports'] = Count('report')
            order = ['-num_reports']
        if sort == "favorites":
            order = ['-favorite_count']
        if sort == "tags":
            order = ['-tag_count']
        if sort == "algorithm":
            annotate_args['decayed_score'] = decayed_score_sql()
            order = ['-decayed_score']
        if sort == "response count":
            order = ['-vote_weight']

        search_query = params.get('search', "").strip()
        if search_query:
            queryset = querysets.search_poll_instances(search_query, queryset)
        else:
            queryset = queryset.filter(feed=Feed.objects.get(category=Feed.LOCAL))

        queryset = queryset\
            .annotate(**annotate_args)\
            .filter(**filter_args)\
            .order_by(*order)
        # Paginate the queryset
        page = int(params.get('page', 1))
        start = POLL_PAGE_SIZE * (page - 1)
        end = POLL_PAGE_SIZE * page

        return querysets.poll_instance_dashboard_related(queryset[start:end])

class PollUpdate(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = ( permissions.IsAdminUser, )
    serializer_class = PollInstanceSerializer
    def get_object(self):
        poll_id = int(self.kwargs['pk'])
        return PollInstance.objects.get(pk=poll_id)
    def perform_destroy(self, instance):
        toggle_value = self.request.data.get('deleted', 'true') == 'true'
        instance.poll.deleted = toggle_value
        instance.poll.save()
        instance.deleted_by_admin = toggle_value
        instance.deleted = toggle_value
        if not toggle_value:
            # Undelete instance, overriding user
            instance.deleted = False
        instance.save()
    def perform_update(self, serializer):
        options = serializer.validated_data.get('get_options')
        poll_instance = serializer.save()
        if options:
            poll_instance.poll.options = options
            poll_instance.poll.save()

@staff_member_required
def district_post(request):
    if request.method == 'POST':
        question = request.POST['question']
        options = []
        option_counts = []
        for i in range(1,5):
            if request.POST['opt' + str(i)]:
                options.append(request.POST['opt' + str(i)])
                option_counts.append(0)
        gender = request.POST['gender']
        if gender not in ['0', '1', '2']:
            gender = 2

        user = User.objects.get(username='whatsgoodly')

        poll = Poll(user=user, question=question, gender=gender, options=json.dumps(options), verified=True)
        poll.save()

        feed = Feed.objects.get(category=Feed.LOCAL)

        for d in District.objects.all():
            poll_instance = PollInstance(user=user, poll=poll, feed=feed,
                option_counts=json.dumps(option_counts), location=d.location)
            poll_instance.save()

    return render(request, 'dashboard/district_post.html', {})

def doImageSearch(image_url):
    """Perform the image search and return the HTML page response."""

    url = 'https://www.google.com/searchbyimage?&image_url=' + image_url

    resp = requests.get(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'})
    return resp.text

def parseImageSearchResults(code):
    """Parse/Scrape the HTML code for the info we want."""

    soup = BeautifulSoup(code)

    results = {
        'descriptions': [],
        'thief_titles': [],
        'thief_links': [],
        'thief_images': []
    }

    for desc in soup.findAll('span', attrs={'class':'st'}):
        results['descriptions'].append(desc.get_text())

    for group in soup.findAll('div', attrs={'class': 'srg'}):
        title = group.find('h3', attrs={'class':'r'})
        results['thief_titles'].append(title.get_text())
        link = group.find('div', attrs={'class':'g'}).find('a')
        results['thief_links'].append(link['href'])
        # tmp = json.loads(group.get_text())
        # img_url = tmp['ou']
        img = group.find('img')
        if img:
            results['thief_images'].append(img['src'])

    return results

# TODO move somewhere better
def make_poll_instance(user, poll, feed,
                       community=None, location=None, banner=None,
                       should_notify=False):

    if community and not location:
        location = community.location

    try:
        poll_instance = SegmenterInstance(
            user=user, poll=poll, feed=feed, banner=banner,
            community=community,
            location=location, verified=True,
            segmenter_id=poll.segmenter.id
        )
    except Segmenter.DoesNotExist:
        poll_instance = PollInstance(
            user=user, poll=poll, feed=feed, banner=banner,
            community=community,
            location=location, verified=True
        )

    poll_instance.save()

    if should_notify:
        made_global = feed.category == Feed.GLOBAL
        create_poll_notification(poll_instance, made_global=made_global)

def log_poll_moderated(poll_data, action_type, request):
    pass
    # data = {'poll': poll_data}
    # send_smyte_message(data, 'admin_{0}_poll'.format(action_type), request)
