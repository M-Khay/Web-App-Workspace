var Modal = Class.extend({
  init: function() {
    var self = this;
    $("#modal_close").click(function(e) {
      self.close();
    }); 
    $("#modal_submit").click(function(e) {
      self.submitEdit();
    }); 
  },
  submitEdit: function() {
    var poll_id = parseInt($("#modal-id").val())
    var new_options = [];
    var new_option_counts = [];
    var new_question = $("#question").val().trim();
    $('#options').children('input').each(function () {
      new_options.push(this.value.trim());
    });
    $('#option_counts').children('input').each(function () {
      new_option_counts.push(parseInt(this.value.trim()));
    });
    var self = this;
    $("#modal_submit").innerHTML = "Loading...";
    var request_data = { question: new_question, options: new_options, option_counts: new_option_counts }
    $.ajax({
      url: "/dashboard/api/polls/update/" + poll_id + '/', 
      dataType: 'json',
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      type : "PATCH",
      data : JSON.stringify(request_data),
      contentType: "application/json",
      success: function(data) {
        self.callback(data);
        self.close();
        $("#modal_submit").innerHTML = "Submit";
      }.bind(this),
      error: function(xhr, status, err) {
        $("#modal_submit").innerHTML = "Submit";
      }.bind()
    });
  },
  clear: function() {
    this.index = 0;
    $("#options").empty(); 
    $("#option_counts").empty();
  },
  open: function(data, callback) {
    $("#modal-id").val(data.id);
    this.data = data;
    this.callback = callback;
    this.clear();
    $("#question").val(this.data.question);
    var self = this;
    this.data.options.forEach(function(option) {
      if(option == null) return;
      var inputHTML = "<input id='" + self.index + "'  type='text'>";
      var newInput = $(inputHTML)
      newInput.val(option);
      $("#options").append(newInput); 
      self.index++;
    });
    self.index = 0;
    this.data.option_counts.forEach(function(option_count) {
      if(option_count == null) return;
      var inputHTML = "<input id='" + self.index + "'  type='text'>";
      var newInput = $(inputHTML)
      newInput.val(option_count);
      $("#option_counts").append(newInput); 
      self.index++;
    });
    $("#modal").css("display", "block");
  },
  close: function() {
    $("#modal").css("display", "none");
  }
});

var CommentModal = React.createClass({
  toggleComment: function(e) {
    var comment_id = parseInt($(e.target).attr("data-comment-id"));
    this.props.onToggle(comment_id);
  },
  render: function() {
    var comments = this.props.comments.map(function(comment, i) {
      var deletedText;
      var buttonText = "DELETE";
      if(comment.deleted) {
        deletedText = (<span className="comment-deleted">DELETED</span>)
        buttonText = "UN-DELETE"
      }
      return (
        <div className="comment-box" key={i}>
          <div className="comment-text">
            {comment.text}
            {deletedText}
          </div>
          <div className="comment-metadata">
            VOTE AGGREGATE: {comment.vote_aggregate} | REPORTS: {comment.report_count} | ID: {comment.id} | USER ID: {comment.user}
            <br />
            <span className="comment-delete-action" data-comment-id={comment.id} onClick={this.toggleComment}>{buttonText}</span>
          </div>
        </div>
      );
    }.bind(this));
    return (
      <div id="comment-modal">
        <button id="comment-modal-exit" className="button close" onClick={this.props.onExit}>&nbsp;X&nbsp;</button>
        <div className="comment-poll-data">
          {this.props.poll.question}
          <br />
          POLL INST ID: {this.props.poll.id} USER ID: {this.props.poll.user}
        </div>
        <div className="comment-container">
          {comments}
        </div>
      </div>
    );
  }
});

// TODO remove this crap
var editModal = new Modal();
var markers = [];
var color = 1;

var Poll = React.createClass({
  contextTypes: {
    bloodhound: React.PropTypes.object.isRequired
  },
  showComments: function(e) {
    this.props.showComments(this.props.data);
  },
  pollAdminClicked: function(e) {
    var url = "https://whatsgoodly.com/admin/whatsgoodly/poll/" + this.props.data.id;
    window.open(url, '_blank');
  },
  userAdminClicked: function(e) {
    var url = "https://whatsgoodly.com/admin/whatsgoodly/user/" + this.props.data.user;
    window.open(url, '_blank');
  },
  editClicked: function(e) {
    var data = this.props.data;
    var self = this;
    editModal.open(this.props.data, function(response) {
      self.props.handleEdited(response);
    });
  },
  verifyClicked: function(e) {
    $.ajax({
      url: "/dashboard/api/polls/update/" + this.props.data.id + "/", 
      dataType: 'json',
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      type : "PATCH",
      data : "verified=" + (!this.props.data.verified),
      success: function(data) {
        this.props.handleVerified(this.props.data.id, data.verified);
      }.bind(this),
      error: function(xhr, status, err) {
      }.bind()
    });
  },
  deleteClicked: function(e) {
    var newDeletedValue = !this.props.data.deleted;
    $.ajax({
      url: "/dashboard/api/polls/update/" + this.props.data.id + "/", 
      dataType: 'json',
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      type : "DELETE",
      data : {
        deleted: newDeletedValue
      },
      success: function(data) {
        this.props.handleDeleted(this.props.data.id, newDeletedValue);
      }.bind(this),
      error: function(xhr, status, err) {
      }.bind(this)
    });
  },

  renderPollContent: function() {
    var gender;
    if (parseInt(this.props.data.gender) === 0) {
      gender = "GUYS";
    } else if(parseInt(this.props.data.gender) === 1) {
      gender = "GIRLS";
    } else if(parseInt(this.props.data.gender) === 2) {
      gender = "ALL";
    }

    var opts_and_counts = this.optionsAndCounts();

    return (
      <div className="poll-content">
        <div className="poll-meta">
          <span className="light">CREATED: </span> {moment(this.props.data.created_date).fromNow()}
        </div>
        <div className="poll-meta">
          <span className="light">GENDER: </span> {gender}
        </div>
        <div className="poll-meta">
          <span className="light">VOTE AGGREGATE: </span> {this.props.data.vote_aggregate}
        </div>
        <div className="question">
          {this.props.data.question}
        </div>
        {opts_and_counts.map(function(result, i) {
          return <div key={i} className="option">{result}</div>;
        })}
      </div>
    );
  },

  optionsAndCounts: function() {
    var opts_and_counts = [];
    for (var i = 0; i < this.props.data.options.length; i++) {
      opts_and_counts.push(this.props.data.options[i] + " (" + this.props.data.option_counts[i]
        + ((this.props.data.option_counts[i] == 1) ? " vote" : " votes") + ")");
    }
    return opts_and_counts;
  },

  renderPollActions: function() {
    var deleted;
    var verified; 
    var flagged;
    var recycled;
    if (this.props.data.deleted)  {
      var deletedMessage;
      if (this.props.data.deleted_by_admin) {
        deletedMessage = 'DELETED BY ADMIN';
      } else {
        deletedMessage = 'DELETED';
      }
      deleted = (<div className="type deleted">{deletedMessage}</div>);
    }

    if (this.props.data.verified) {
      verified = (<div className="type verified">VERIFIED</div>);
    }
    if (this.props.data.auto_censored) {
      flagged = (<div className="type flagged">CENSORED</div>);
    } else if (this.props.data.censor_level > 1) {
      flagged = (<div className="type flagged">FLAGGED</div>);
    }
    if (this.props.data.recycled) {
      recycled = (<div className="type recycled">RECYCLED</div>);
    }

    return (
      <div className="poll-actions">
        <div className="stat">
          {this.props.data.report_count} <span className="light">REPORTS</span>
        </div>
        <div className="stat">
          {this.props.data.favorite_count} <span className="light">FAVORITES</span>
        </div>
        <div className="stat">
          {this.props.data.tag_count} <span className="light">SHARES</span>
        </div>
        <div className="status">
          {deleted}
          {verified}
          {flagged}
          {recycled}
        </div>
      </div>
    );
  },

  renderAdminActions: function() {
    return (
      <div className="actions">
        <button className="button verify" onClick={this.verifyClicked} >VERIFY</button>
        <button className="button delete" onClick={this.deleteClicked} >DELETE</button>
        <button className="button" onClick={this.editClicked}>EDIT</button>
        <a target="_blank" href={"https://whatsgoodly.com/esuohgod/whatsgoodly/pollinstance/" + this.props.data.id} className="button">
          POLL INST ID: {this.props.data.id}
        </a>
        <a target="_blank" href={"https://whatsgoodly.com/esuohgod/whatsgoodly/user/" + this.props.data.user} className="button">
          USER ID: {this.props.data.user}
        </a>
        <button className="button" onClick={this.showComments} >COMMENTS: {this.props.data.comment_count} </button>
        <WG.TagAutocomplete poll={this.props.data} bloodhound={this.context.bloodhound} />
      </div>
    );
  },

  render: function() {
    color = 1 - color;
    return (
      <div className= {(color) ? "poll" : "poll alt"}>
        <div className="inside-poll">
          {this.renderPollContent()}
          {this.renderPollActions()}
          {this.renderAdminActions()}
        </div>
      </div>
    );
  }
});

var PollBox = React.createClass({
  render: function() {
    color = 1;
    return (
      <div className="pollBox">
        <PollList loading={this.props.loading} data={this.props.data} showComments={this.props.showComments} handleEdited={this.props.handleEdited} handleVerified={this.props.handleVerified} handleDeleted={this.props.handleDeleted} />
      </div>
    );
  }
});

var PollList = React.createClass({

  componentWillMount: function() {
    this.spinner = new Spinner(WG.constants.SPINNER_SETUP);
  },

  componentDidMount: function() {
    this.parentNode = ReactDOM.findDOMNode(this);
    if (this.props.loading) {
      this.spinner.spin(this.parentNode);
    }
  },

  componentDidUpdate: function(prevProps, prevState) {
    if (this.props.loading && !prevProps.loading) {
      this.spinner.spin(this.parentNode);
    }
    if (!this.props.loading) {
      this.spinner.stop();
    }
  },

  renderPollNodes: function() {
    var self = this;
    return this.props.data.map(function(poll, index) {
      return (
        <Poll data={poll} key={index} showComments={self.props.showComments} handleEdited={self.props.handleEdited} handleVerified={self.props.handleVerified} handleDeleted={self.props.handleDeleted}>
        </Poll>
      );
    });
  },

  render: function() {
    return (
      <div id="content">
        <div className="pollList" style={{opacity: this.props.loading ? 0.5 : 1}}>
          {this.renderPollNodes()}
        </div>
      </div>
    );
  }
});

var GoogleMap = React.createClass({  
  getInitialState: function() {
    return { 
      markers : [],
    }
  },
  getDefaultProps: function () {
    return {
      initialZoom: 10,
      mapCenterLat: 37.4225, 
      mapCenterLng: -122.1653,
    };
  },
  componentDidMount: function () {
    var mapOptions = {
      center: this.mapCenterLatLng(),
      zoom: this.props.initialZoom
    }
    this.map = new google.maps.Map(ReactDOM.findDOMNode(this), mapOptions);
    google.maps.event.addListener(this.map, 'dragend', function() {
      var bounds = this.map.getBounds();
      var ne = bounds.getNorthEast();
      var sw = bounds.getSouthWest();
      this.props.onMapChange(ne.lat(), ne.lng(), sw.lat(), sw.lng());
    }.bind(this));
    google.maps.event.addListener(this.map, 'zoom_changed', function() {
      var bounds = this.map.getBounds();
      var ne = bounds.getNorthEast();
      var sw = bounds.getSouthWest();
      this.props.onMapChange(ne.lat(), ne.lng(), sw.lat(), sw.lng());
    }.bind(this));
  },
  mapCenterLatLng: function () {
    var props = this.props;
    return new google.maps.LatLng(props.mapCenterLat, props.mapCenterLng);
  },
  render: function () {
    markers.forEach(function(marker) {
      marker.setMap(null);
    });
    markers = [];
    var infowindow = new google.maps.InfoWindow();
    var locationPolls = this.props.data.filter(function(poll){ return !!poll.location });
    locationPolls.forEach(function(poll) {
      var m = new google.maps.Marker({
        position: (new google.maps.LatLng(poll.location.lat, poll.location.lng)),
        map: this.map,
        title: poll.question
      });
      google.maps.event.addListener(m, 'click', function() {
        infowindow.setContent(poll.question);
        infowindow.open(this.map, m);
      }); 
      markers.push(m);
    }.bind(this));
    return (
      <div id="map-canvas">
        <div className='map-gic'></div>
      </div>
    );
  }
});
var Option = React.createClass({
  render: function() {
    return (
      <label>
        <input type="checkbox" onChange={this.props.handleChange} id={this.props.name} value={this.props.type}/><span className="filter-title">{this.props.name}</span>
      </label>
    );
  }
});
var Radio = React.createClass({
  render: function() {
    return (
      <label>
        <input type="radio" name="sort" checked={this.props.select} onChange={this.props.handleChange} id={this.props.name} value={this.props.name}/><span className="filter-title">{this.props.name}</span> 
      </label>
    );
  }
});

var OptionForm = React.createClass({
  handleFilterChange: function(x, event) {
    this.props.handleFilterChange(x.opt);
  },
  handleSortChange: function(x, event) {
    this.props.handleSortChange(x.opt);
  },
  render: function() {
    var self = this;
    var filterOpts = this.props.fil.map(function(opt, index) {
      return (
        <Option key={index} name={opt} ref={opt} handleChange={self.handleFilterChange.bind(null, {opt})} type="filter"></Option>
        );
    });
    var sortOpts = this.props.sort.map(function(opt, index) {
      return (
        <Radio key={index} name={opt} select={self.props.sortOption === opt} handleChange={self.handleSortChange.bind(null, {opt})} type="sort"></Radio>
        );
    });
    return ( 
      <div className="filter-options">
        <span className="filter-type">FILTERS</span>
          {filterOpts} 
          <br />
         <span className="filter-type">SORT&nbsp;&nbsp;&nbsp;</span>
          {sortOpts}
      </div>  
    );
  }   
});

var SearchForm = React.createClass({
  contextTypes: {
    bloodhound: React.PropTypes.object.isRequired
  },

  componentWillMount: function() {
    this.debouncedHandleChange = WG.utils.debounce(this.props.handleSearchChange, 300);
  },

  onInputMount: function(elem) {
    if (!elem) return;

    this.input = elem;

    $(elem).tagsinput({
      tagClass: function(item) {
        if (item.category == item.label_lower) {
          return 'label label-primary';
        }
        return 'label label-default';
      },
      itemValue: function(d) { return '#' + d.label_lower},
      itemText: function(d) { return '#' + d.label_lower},
      freeInput: false,
      typeaheadjs: [{
          minLength: 0,
          highlight: true,
          hint: true,
          limit: 15
        },{
          name: 'tags',
          displayKey: function(d) { return '#' + d.label_lower},
          source: this.context.bloodhound
        }
      ]
    });

    var freeInput = $(elem).parent().find(".tt-input")[0];

    var onChange = function() {
      var tagPart = $(elem).tagsinput('items').map(function(d) {
        return "#" + d.label_lower;
      }).join(' ');
      var query = (tagPart ? tagPart + ' ' : '') + freeInput.value;
      this.debouncedHandleChange(query);
    }.bind(this);

    $(elem).parent().find(".tt-input").on("keyup", onChange);

    $(elem).on('itemAdded itemRemoved', onChange);
  },

  render: function() {

    return ( 
      <div className="search-form">
        <input type="search"
          className="search-field"
          defaultValue={this.props.search}
          placeholder="Search poll questions..."
          ref={this.onInputMount} />
      </div>  
    );
  }   
});

var Page = React.createClass({
  onNextPage: function(e) {
    this.props.handleNextPage(e);
  },
  onPrevPage: function(e) {
    if(this.props.currentPage == 1) return;
    this.props.handlePrevPage(e);
  }, 
  render: function() {
    var right;
    if(!this.props.isEmpty) {
      right = (<button className="button arrow" onClick={this.onNextPage}>&nbsp;&gt;&nbsp;</button>);
    }
    return (
      <div className="pager">
        <button className="button arrow left" onClick={this.onPrevPage}>&nbsp;&lt;&nbsp;</button>
        Page {this.props.currentPage}
        {right}
      </div>
    );    
  } 
});

var Dashboard = React.createClass({
  childContextTypes: {
    bloodhound: React.PropTypes.object
  },
  getInitialState: function() {
    var bloodhound = new Bloodhound({
      datumTokenizer: function(d) { 
        return Bloodhound.tokenizers.whitespace(d.label_lower); 
      },
      queryTokenizer: Bloodhound.tokenizers.whitespace,
      identify: function(obj) { return obj.label_lower; },
      prefetch: {
        url: '/dashboard/api/poll_tags/',
        cache: false,
        // transform: function(t) {
        //   return t.label_lower;
        // },
        // filter: function(list) {
        //   return $.map(list, function(label) {
        //     return { label: label }; });
        // }
      }
    });
    return {
      pollForComments: null,
      bloodhound: bloodhound,
      comments: [],
      data: [],
      filters: [],
      sort: 'Recent',
      page: 1,
      search: null,
      loading: false,
      coords: [37.5543504761973351, -121.84120332031252, 37.307895806491943, -122.53608857421875] 
    };
  },
  getChildContext: function() {
    return {bloodhound: this.state.bloodhound};
  },
  componentWillMount: function() {
    this.state.bloodhound.initialize();
  },
  componentDidMount: function() {
    this.loadPollsFromServer();
  },
  showComments: function(poll) {
    var pollID = poll.id;
    if(this.state.pollForComments && this.state.pollForComments.id == poll.id) 
      return;
    $.ajax({
      url: "/dashboard/api/comments/" + pollID,
      dataType: 'json',
      success: function(data) {
        this.setState({ comments: data, pollForComments: poll });
      }.bind(this),
      error: function(xhr, status, err) {
      }.bind(this)
    }); 
  },
  loadPollsFromServer: function() {
    var ne_la = this.state.coords[0],
      ne_lo = this.state.coords[1],
      sw_la = this.state.coords[2],
      sw_lo = this.state.coords[3],
      data = {
        ne_la: ne_la, ne_lo: ne_lo, sw_la: sw_la, sw_lo: sw_lo,
        search: (this.state.search || ''),
        filters: this.state.filters.join().toLowerCase(),
        sort: this.state.sort.toLowerCase(),
        page: this.state.page
      };

    this.setState({loading: true});
    if (this.xhr) {
      this.xhr.abort();
    }

    this.xhr = $.get(this.props.url, data)
      .done(function(data) {
          this.xhr = null;
          this.setState({data: data, loading: false});
        }.bind(this))
      .fail(function(xhr, status, err) {
          this.xhr = null;
          // this.setState({loading: false});
        }.bind(this));
  },
  handleFilterChange: function(x) {
    var arr = this.state.filters.slice();
    var index = arr.indexOf(x);
    if(index > -1) arr.splice(index, 1);
    else           arr.push(x);
    this.setState({filters: arr, page: 1}, this.makeRequest);
  },
  handleSearchChange: function(query) {
    this.setState({search: query}, this.makeRequest);
  },
  makeRequest: function() {
    this.loadPollsFromServer();
  },
  handleVerified: function(id, state) {
    var updatedPolls = this.state.data;
    var self = this;
    updatedPolls.forEach(function(poll) {
      if(poll.id == id) {
        poll.verified = state;  
        self.setState({data : updatedPolls});
        return;
      } 
    }); 
  },
  handleDeleted: function(id, state) {
    var updatedPolls = this.state.data;
    var self = this;
    updatedPolls.forEach(function(poll) {
      if(poll.id == id) {
        poll.deleted = state;  
        poll.deleted_by_admin = state;
        self.setState({data : updatedPolls});
        return;
      }  
    });  
  },
  handleEdited: function(poll) {
    var updatedPolls = this.state.data;
    var self = this;
    updatedPolls.forEach(function(p) {
      if(p.id == poll.id) {
        p.options = poll.options;
        p.option_counts = poll.option_counts
        p.question = poll.question
        self.setState({data : updatedPolls});
        return;
      } 
    }); 
  },
  handleNextPage: function(e) {
    this.setState({page: this.state.page+1}, this.makeRequest); 
  },
  handlePrevPage: function(e) {
    this.setState({page: this.state.page-1}, this.makeRequest); 
  },
  handleSortChange: function(x) {
    this.setState({sort: x, page: 1}, this.makeRequest);
  },
  handleMapChange: function(ne_lat, ne_lng, sw_lat, sw_lng) {
    this.setState({coords: [ne_lat, ne_lng, sw_lat, sw_lng], page: 1}, this.makeRequest);
  },
  closeCommentModal: function() {
    this.setState({ pollForComments: null });
  },
  toggleComment: function(commentID) {
    $.ajax({
      url: "/dashboard/api/comments/" + commentID + "/toggle/", 
      dataType: 'json',
      type : "POST",
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      success: function(data) {
        var comments = this.state.comments.map(function(comment) {
          if(comment.id == commentID) {
            comment.deleted = !comment.deleted;
          }
          return comment;
        });
        this.setState({ comments: comments });
      }.bind(this),
      error: function(xhr, status, err) {
      }.bind(this)
    });
  },
  render: function() {
    var filteropts = ['Location', 'Reported', 'Auto-flagged', 'Not-deleted', 'Verified'];
    var sortopts = ['Recent', 'Algorithm', 'Reports', 'Favorites', 'Tags', 'Response Count'];
    var commentsModal;
    if(this.state.pollForComments) {
      commentsModal = (<CommentModal poll={this.state.pollForComments} comments={this.state.comments} onToggle={this.toggleComment} onExit={this.closeCommentModal} />);
    }
    return (
      <div id="parent-container">
        <OptionForm fil={filteropts} sort={sortopts} sortOption={this.state.sort} handleFilterChange={this.handleFilterChange} handleSortChange={this.handleSortChange} />
        <Page currentPage={this.state.page} isEmpty={this.state.data.length == 0} handleNextPage={this.handleNextPage} handlePrevPage={this.handlePrevPage} />
        <SearchForm data={this.state.data} search={this.state.search} handleSearchChange={this.handleSearchChange} />
        <PollBox data={this.state.data} loading={this.state.loading} showComments={this.showComments} handleEdited={this.handleEdited} handleVerified={this.handleVerified} handleDeleted={this.handleDeleted} />
        <GoogleMap data={this.state.data} onMapChange={this.handleMapChange} />
        {commentsModal}
      </div>
    );
  }
});

$(document).ready(function() {
  ReactDOM.render(
    <Dashboard url="/dashboard/api/polls/" />, $("#parent")[0]
  );
});
