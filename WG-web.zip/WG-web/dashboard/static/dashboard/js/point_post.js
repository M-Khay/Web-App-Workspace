var OptionForm = React.createClass({
  removeOption: function(e) {
    var id = $(e.target).attr('data-option');
    var opts = this.state.opts;
    if(opts.length > 2) {
      opts.splice(id, 1);
    } 
    this.setState({ opts: opts });
    this.props.setOptions(opts);
  },
  editOption: function(e) {
    var id = $(e.target).attr('data-ref');
    id = parseInt(id);
    var opts = this.state.opts;
    opts[id] = $(e.target).val();
    this.setState({ opts: opts });
    this.props.setOptions(opts);
  },
  addOption: function(e) {
    var opts = this.state.opts;
    opts.push("");
    this.setState({ opts: opts });
    this.props.setOptions(opts);
  },
  getInitialState: function() {
    return { 
      opts: ["", ""]
    }
  },
  componentWillMount: function() {
    this.addOptionSubscription = PubSub.subscribe("addOption", function() {
      this.addOption();
    }.bind(this));
    this.props.setOptions(this.state.opts);
  },
  componentWillUnmount: function() {
    PubSub.unsubscribe(this.addOptionSubscription);
  },
  render: function() {
    var index = 0;
    var optionInputs = []; 
    for(var i = 0; i < this.state.opts.length; i++) {
      var jsx = (
        <div className="input-group" key={i}>
          <input type="text" data-ref={i} onChange={this.editOption} className="form-control" value={this.state.opts[i]} />
          <span className="input-group-btn">
            <button className="btn btn-default" type="button">
              <span className="glyphicon glyphicon-remove-sign" data-option={i} onClick={this.removeOption} ></span>
            </button>
          </span>
        </div>
      );
      optionInputs.push(jsx);
    }
    return (
      <div id="options-container">
        {optionInputs}
      </div>
    );
  } 
});

var AddOption = React.createClass({
  sendAddOption: function() {
    PubSub.publish("addOption");
  },
  render: function() {
    return (
      <button className="btn btn-default" type="button">
        <span className="glyphicon glyphicon-plus-sign" onClick={this.sendAddOption} ></span>
      </button>
    );
  }
})

var GenderSelect = React.createClass({
  genderChanged: function(e) {
    var index = this.state.genders.indexOf(e.target.value)
    this.props.genderChanged(index);
  },
  getInitialState: function(e) {
    return {
      genders: ["Male", "Female", "All"]
    }
  },
  render: function() {
    var options = this.state.genders.map(function(gender, i) {
      return (
        <option key={i} value={gender}>{gender}</option>
      );
    });
    return (
      <select id="genderSelect" defaultValue={"All"} className="form-control" onChange={this.genderChanged} >
        {options}
      </select>
    );
  }
});

var GoogleMap = React.createClass({  
  getInitialState: function() {
  	return { 
      marker: null,
  	}
  },
  getDefaultProps: function () {
  	return {
  	  initialZoom: 10,
  	  mapCenterLat: 37.4225, 
  	  mapCenterLng: -122.1653,
  	};
  },
  componentWillUnmount: function() {
    PubSub.unsubscribe(this.locationChangeSubscription);
  },
  componentDidMount: function (rootNode) {
  	var mapOptions = {
  	  center: this.mapCenterLatLng(),
  	  zoom: this.props.initialZoom
  	}
  	this.map = new google.maps.Map(ReactDOM.findDOMNode(this), mapOptions);
    this.locationChangeSubscription = PubSub.subscribe("changedLocation", function(topic, data) {
      var position = new google.maps.LatLng(data.latitude, data.longitude)
      if(this.state.marker == null) {
        var m = new google.maps.Marker({
          position: position,
          map: this.map,
          draggable: false
        });
        this.setState({marker: m});
      } else {
        this.state.marker.setPosition(position);
      }
      this.map.panTo(position);
    }.bind(this));
  },
  mapCenterLatLng: function () {
  	var props = this.props;
  	return new google.maps.LatLng(props.mapCenterLat, props.mapCenterLng);
  },
  render: function () {
  	return (
  	  <div className="col-md-12" id="map-canvas">
    		<div className='map-gic'></div>
  	  </div>
  	);
  }
});


var Dashboard = React.createClass({
  questionChanged: function(e) {
    var changed = $(e.target).val();
    this.setState({question: changed})
  },
  genderChanged: function(e) {
    this.setState({ gender: e})
  },
  optionsChanged: function(e) {
    this.setState({ options: e});
  },
  getInitialState: function() {
  	return { 
      question: "",
      gender: 2,
      options: [],
      latitude: 0.0,
      longitude: 0.0,
      promoted: false
    };
  },
  setLocation: function() {
    var latitude = $("#latitude-input").val()
    var longitude = $("#longitude-input").val()
    if(latitude.length == 0 || longitude.length == 0) return;
    latitude = parseFloat(latitude)
    longitude = parseFloat(longitude)
    if(isNaN(latitude) || isNaN(longitude)) {
      alert("invalid location");
      return;
    }
    this.setState({latitude:latitude, longitude: longitude});
    PubSub.publish("changedLocation", {latitude:latitude, longitude: longitude});
  },
  handleSubmit: function(e) {
    var state = this.state;
    $.ajax({
      url: "/dashboard/api/polls/point_post/",
      dataType: 'json',
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      type: "POST",
      data: JSON.stringify(state),
      contentType: "application/json",
      success: function(data) {
        alert("Polls successfully created!");
        location.reload();
      }.bind(this),
      error: function(xhr, status, err) {
      }.bind(this)
    });
  },
  promotedClicked: function(e) {
    var promoted = !this.state.promoted;
    this.setState({promoted:promoted});
  },
  render: function() {
  	return (
      <div className="content">
    	  <div id="row">
      		<GoogleMap />
        </div>
        <div id="row">
          <div className="col-md-6 col-md-offset-3" id="form">
            <label>Latitude</label>
            <input type="text" id="latitude-input" className="form-control" />
            <label>Longitude</label>
            <input type="text" id="longitude-input" className="form-control" />
            <br/>
            <button type="submit" id="submit_location" className="btn btn-primary" onClick={this.setLocation} >Set location</button>
            <br/><br/>Make sure to press Set Location before submitting the poll<br/><br/>
            <label>Question</label>
            <textarea id="question" className="form-control" onChange={this.questionChanged} />
            <label>Gender</label>
            <GenderSelect genderChanged={this.genderChanged} />
            <label>Options</label>
            <OptionForm setOptions={this.optionsChanged} />
            <AddOption />
          </div>
    	  </div>
        <div id="row">
          <div className="col-md-6 col-md-offset-3">
            <input type="checkbox" onChange={this.promotedClicked} />Promoted
            <br/>
            <button type="submit" id="submit" className="btn btn-primary" onClick={this.handleSubmit} >Submit</button>
          </div>
        </div>
      </div>
  	);
  }
});

$(document).ready(function() {
  ReactDOM.render(
    <Dashboard />, $(".container-fluid")[0]
  );
});
