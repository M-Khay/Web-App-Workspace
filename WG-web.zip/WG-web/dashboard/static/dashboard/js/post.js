WG.constants.Feed = WG.constants.Feed || {
  LOCAL: 0,
  GLOBAL: 1,
  FEATURED: 2,
  MY_FEATURED: 3,
};

var OptionForm = React.createClass({
  removeOption: function(optionIndex, e) {
    var opts = this.props.opts;
    if(opts.length > 2) {
      opts.splice(optionIndex, 1);
    } 
    this.props.setOptions(opts);
  },
  editOption: function(optionIndex, e) {
    var opts = this.props.opts;
    opts[optionIndex] = e.target.value;
    this.props.setOptions(opts);
  },
  addOption: function(e) {
    var opts = this.props.opts;
    opts.push("");
    this.props.setOptions(opts);
  },
  render: function() {
    return (
      <div id="options-container">
        {this.props.opts.map(function(opt, i) {
          return (
            <div key={i} className="input-group">
              <input type="text" onChange={this.editOption.bind(this, i)} className="form-control" value={opt} />
              <span className="input-group-btn">
                <button className="btn btn-default" type="button" onClick={this.removeOption.bind(this, i)}>
                  <span className="glyphicon glyphicon-remove-sign"></span>
                </button>
              </span>
            </div>
          )
        }.bind(this))}
        <button className="btn btn-default" type="button" onClick={this.addOption}>
          <span className="glyphicon glyphicon-plus-sign" ></span>
        </button>
      </div>
    );
  } 
});

var GenderSelect = React.createClass({
  genderChanged: function(e) {
    var index = this.state.genderList.indexOf(e.target.value)
    this.props.genderChanged(index);
  },
  getInitialState: function (argument) {
    return {
      genderList: ["Male", "Female", "All"]
    }
  },
  render: function() {
    var options = this.state.genderList.map(function(gender, index) {
      return (
        <option key={index} value={gender}>{gender}</option>
      );
    }.bind(this));
    return (
      <select id="genderSelect" defaultValue={"All"} className="form-control" onChange={this.genderChanged} >
        {options}
      </select>
    );
  }
});

var Universities = React.createClass({
  handleSelectAll: function(e) {
    var dict = $.extend(true, {}, this.state.universities);
    for (var key in dict) {
      if (dict.hasOwnProperty(key)) {
        dict[key].selected = true;
        PubSub.publish("addUniversity", dict[key])
      }
    }  
    this.setState({ universities: dict });
  },
  handleSelectNone: function(e) {
    var dict = $.extend(true, {}, this.state.universities);
    for (var key in dict) {
      if (dict.hasOwnProperty(key)) {
        dict[key].selected = false;
        PubSub.publish("removeUniversity", dict[key])
      }
    }  
    this.setState({ universities: dict });
  },
  handleSelect: function(e) {
    var id = $(e.target).attr('data-university');
    var selected = !this.state.universities[id].selected;
    this.state.universities[id].selected = selected;
    var message = selected ? "addUniversity" : "removeUniversity";
    PubSub.publish(message, this.state.universities[id]);
    this.setState({ universities: this.state.universities });
  },
  getInitialState: function() {
    return { 
      universities: {},
      groups: [],
    }
  },
  componentDidMount: function() {
    this.getUniversities();
    this.getGroups();
  },

  getUniversities: function() {
    $.ajax({
      url: this.props.url,
      dataType: 'json',
      success: function(data) {
        var dict = {}
        data = data.map(function(u) {
          u.selected = false;
          dict[u.id] = u;
          return null;
        });
        this.setState({ universities: dict });
      }.bind(this),
      error: function(xhr, status, err) {
      }.bind(this)
    });
  },

  getGroups: function() {
    $.ajax({
      url: this.props.groupsUrl,
      dataType: 'json',
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      type: 'GET',
      contentType: 'application/json',
      success: function(data) {
        this.setState({
          groups: data
        });
      }.bind(this),
      error: function(xhr, status, err) {
        console.error('xhr', xhr);
        console.error('status', status);
        console.error('err', err);
      }.bind(this)
    });
  },

  renderGroupList: function() {
    return this.state.groups.map(function(group, i) {
      var selectGroup = function() {
        var editingUniversities = $.extend(true, {}, this.state.universities);
        for (var university_id in editingUniversities) {
          editingUniversities[university_id].selected = false;
          PubSub.publish("removeUniversity", this.state.universities[university_id]);
        }
        group.universities.forEach(function(uniId) {
          editingUniversities[uniId].selected = true;
          PubSub.publish("addUniversity", this.state.universities[uniId]);
        }.bind(this));
        this.setState({universities: editingUniversities});
      }.bind(this);

      return (
        <div key={i} className="universityOption all" onClick={selectGroup}>{group.title}</div>
      );
    }.bind(this));
  },

  render: function() {
    var universityList = [];
    var groups = this.state.groups;
    var dict = $.extend(true, {}, this.state.universities);
    for (var key in dict) {
      if (dict.hasOwnProperty(key)) {
        var className = "universityOption";
        if(dict[key].selected) {
          className += " selected"
        }
        var metadata = " ";
        if (dict[key].fraternities && dict[key].fraternities.length > 0) {
          metadata += "(F) ";
        }
        if (dict[key].sororities && dict[key].sororities.length > 0) {
          metadata += "(S)";
        }
        universityList.push(
          (<div key={key} className={className} data-university={key} onClick={this.handleSelect}>{dict[key].name + metadata}</div>)
        );
      }
    }
    return (
      <div className="col-md-4" id="universityList">
        <div className="universityOption all" onClick={this.handleSelectAll}>Select all</div>
        <div className="universityOption none" onClick={this.handleSelectNone}>Select none</div>
        {this.renderGroupList()}
        {universityList}
      </div>
    );
  }
});

var GoogleMap = React.createClass({  
  getInitialState: function() {
  	return { 
  	  universityMarkers : {}
  	}
  },
  getDefaultProps: function () {
  	return {
  	  initialZoom: 10,
  	  mapCenterLat: 37.4225, 
  	  mapCenterLng: -122.1653,
  	};
  },
  componentWillMount: function() {
    this.addUniversitySubscription = PubSub.subscribe('addUniversity', function(topic, uni) {
      var markers = $.extend(true, {}, this.state.universityMarkers);
      if(!markers.hasOwnProperty(uni.id)) {
        var m = new google.maps.Marker({
          position: (new google.maps.LatLng(uni.latitude, uni.longitude)),
          map: this.map,
          title: uni.name
        });
        markers[uni.id] = m; 
        this.state.universityMarkers = markers;
      }
    }.bind(this));
    this.removeUniversitySubscription = PubSub.subscribe('removeUniversity', function(topic, uni) {
      var markers = $.extend(true, {}, this.state.universityMarkers);
      if(markers.hasOwnProperty(uni.id)) {
        markers[uni.id].setMap(null);
      } 
      delete markers[uni.id];
      this.state.universityMarkers = markers;
    }.bind(this));
  },
  componentWillUnmount: function() {
    PubSub.unsubscribe(this.addUniversitySubscription);
    PubSub.unsubscribe(this.removeUniversitySubscription);
  },
  componentDidMount: function (rootNode) {
  	var mapOptions = {
  	  center: this.mapCenterLatLng(),
  	  zoom: this.props.initialZoom
  	}
  	this.map = new google.maps.Map(ReactDOM.findDOMNode(this), mapOptions);
  },
  mapCenterLatLng: function () {
  	var props = this.props;
  	return new google.maps.LatLng(props.mapCenterLat, props.mapCenterLng);
  },
  render: function () {
    var m = new google.maps.Marker({
      position: (new google.maps.LatLng(0, 0)),
      map: this.map,
      title: "hello"
    });
  	return (
  	  <div className="col-md-12" id="map-canvas">
    		<div className='map-gic'></div>
  	  </div>
  	);
  }
});

var FeedSelect = React.createClass({
  
  getInitialState: function() {
    return { 
      feeds: [],
      feedID: undefined
    }
  },
  componentDidMount: function() {
    this.getFeeds();
  },

  getFeeds: function() {
    $.ajax({
      url: this.props.url,
      dataType: 'json',
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      type: 'GET',
      contentType: 'application/json',
      success: function(data) {
        var localFeed = data.filter(function(f) {
          return f.category == WG.constants.Feed.LOCAL;
        })[0];
        this.setState({
          feeds: data,
          feedID: localFeed.id
        });
        this.props.feedChanged(localFeed);
      }.bind(this),
      error: function(xhr, status, err) {
        console.error('xhr', xhr);
        console.error('status', status);
        console.error('err', err);
      }.bind(this)
    });
  },

  handleRadioChange: function(feed, e) {
    if (!e.target.checked) {
      return;
    }
    this.setState({
      feedID: feed.id
    });
    this.props.feedChanged(feed);
  },

  bannerChanged: function(e) {
    var changed = $(e.target).val();
    this.setState({ banner: changed })
    this.props.bannerChanged(changed);
  },

  renderFeed: function(feed, i) {
    var isActive = this.state.feedID == feed.id;
    var isGlobal = feed.category == WG.constants.Feed.GLOBAL;
    return (
      <div key={i}>
        <label className="feedOption">
          <input
            type="radio"
            checked={isActive}
            onChange={this.handleRadioChange.bind(this, feed)} />
            {feed.name}
            {!feed.active
              ? " (inactive)"
              : null}
        </label>
        {isActive && isGlobal ?
            <input type="text" placeholder="Banner (required)" onChange={this.bannerChanged} className="form-control" /> 
          : null
        }
      </div>
    )
  },

  render: function() {
    return (
      <div className="feed-container radio">
        {this.state.feeds.map(this.renderFeed)}
      </div>
    );
  }
});

var FraternitiesSelect = React.createClass({
  checkClicked: function(e) {
    var selected = (e.target.value == "on");
    this.setState({ isFraternities: selected });
    this.props.fraternitiesChanged(selected);
  },
  getInitialState: function() {
    return {
      isFraternities: false
    }
  },
  render: function() {
    return (
      <div className="fraternities-container">
        <div className="radio">
          <label>
            <input type="radio" name="radio" onChange={this.checkClicked} />Fraternities
          </label>
        </div>
      </div>
    );
  }
});

var SororitiesSelect = React.createClass({
  checkClicked: function(e) {
    var selected = (e.target.value == "on");
    this.setState({ isSororities: selected });
    this.props.sororitiesChanged(selected);
  },
  getInitialState: function() {
    return {
      isSororities: false
    }
  },
  render: function() {
    return (
      <div className="sororities-container">
        <div className="radio">
          <label>
            <input type="radio" name="radio" onChange={this.checkClicked} />Sororities
          </label>
        </div>
      </div>
    );
  }
});

var PostPoll = React.createClass({
  pollIDChanged: function(e) {
    var value = $(e.target).val();
    this.setState({pollID: value, enableForm: !value});
  },
  questionChanged: function(e) {
    var value = $(e.target).val();
    this.setState({question: value, enablePollID: !value});
  },
  questionPictureChanged: function(e) {
    var value = $(e.target).val();
    this.setState({questionPicture: value, enablePollID: !value});
  },
  genderChanged: function(e) {
    this.setState({ gender: e});
  },
  universityAdded: function(e) {
    var universities = this.state.universities;
    if(universities.indexOf(e.id) < 0)
      universities.push(e.id)
    this.setState({ universities: universities })
  },
  universityRemoved: function(e) {
    var universities = this.state.universities;
    var index = universities.indexOf(e.id);
    if(index > -1)
      universities.splice(index, 1);
    this.setState({ universities: universities })
  },
  optionsChanged: function(options) {
    this.setState({ options: options });
  },
  getInitialState: function() {
  	return {
      pollID: null,
      question: "",
      questionPicture: "",
      gender: 2,
      options: ["",""],
      universities: [],
      groups: [],
      feedID: null,
      isLocal: true,
      isFraternities: false,
      isSororities: false, 
      banner: null,
      enablePollID: true,
      enableForm: true,
    };
  },
  bannerChanged: function(e) {
    this.setState({ banner: e })
  },
  feedChanged: function(feed) {
    this.setState({
      feedID: feed.id,
      isLocal: feed.category == WG.constants.Feed.LOCAL
    });
    if (feed.category != WG.constants.Feed.LOCAL) {
      this.setState({
        isFraternities: false,
        isSororities: false
      })
    }
  },
  fraternitiesChanged: function(e) {
    this.setState({
      isFraternities: e,
      isSororities: !e
    })
  },
  sororitiesChanged: function(e) {
    this.setState({
      isFraternities: !e,
      isSororities: e
    })
  },
  handleSubmit: function(e) {
    var state = this.state;
    $.ajax({
      url: "/dashboard/api/polls/post/",
      dataType: 'json',
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      type: "POST",
      data: JSON.stringify(state),
      contentType: "application/json",
      success: function(data) {
        alert("Polls successfully created!");
        location.reload();
      }.bind(this),
      error: function(xhr, status, err) {
        PubSub.publish(WG.actions.SHOW_ERROR, xhr.responseText);
      }.bind(this)
    });
  },
  componentWillMount: function() {
    this.addUniversitySubscription = PubSub.subscribe("addUniversity", function(message, data) {
      this.universityAdded(data);
    }.bind(this));
    this.removeUniversitySubscription= PubSub.subscribe("removeUniversity", function(message, data) {
      this.universityRemoved(data);
    }.bind(this));
  },
  componentWillUnmount: function () {
    PubSub.unsubscribe(this.addUniversitySubscription);
    PubSub.unsubscribe(this.removeUniversitySubscription);
  },
  render: function() {

  	return (
      <div className="content">
    	  <div className="row">
      		<GoogleMap data={this.state.data} />
        </div>
        <div className="row">
          <div className="col-md-4">
            <div className={this.state.enablePollID ? "" : "disabled"}>
              <label>Poll ID</label>
              <input type="number" id="poll_id" min={1} className="form-control" onChange={this.pollIDChanged} />
              <em> -- or make a new poll -- </em>
            </div>
            <div id="form" style={{border: "1px solid lightgrey", padding: 5}}
                className={this.state.enableForm ? "" : "disabled"}>
              <label>Question</label>
              <textarea id="question" className="form-control" onChange={this.questionChanged} />
              <label>Question Picture URL</label>
              <input type="url" id="picture_question" placeholder="optional" className="form-control" onChange={this.questionPictureChanged} />
              <label>Gender</label>
              <GenderSelect gender={this.state.gender} genderChanged={this.genderChanged} />
              <label>Options</label>
              <OptionForm opts={this.state.options} setOptions={this.optionsChanged} />
            </div>
          </div>
          <div className={this.state.isLocal ? "" : "disabled"}>
            <Universities
              url="/dashboard/api/universities/"
              groupsUrl="/dashboard/api/groups/" />
          </div>
          <div className="col-md-4">
            <button type="submit" id="submit" className="btn btn-primary" onClick={this.handleSubmit}>Submit</button>
            <div className={this.state.enableForm && this.state.isLocal ? "" : "disabled"}>
              <FraternitiesSelect fraternitiesChanged={this.fraternitiesChanged} />
              <SororitiesSelect sororitiesChanged={this.sororitiesChanged} />
            </div>
            <FeedSelect url="/dashboard/api/feeds/all/" bannerChanged={this.bannerChanged} feedChanged={this.feedChanged} />
          </div>
        </div>
      </div>
  	);
  }
});

$(document).ready(function() {
  ReactDOM.render(
    <PostPoll url="/dashboard/api/polls/" />, $("#PostPoll")[0]
  );
});
