(function() {

var D = React.DOM;

var url = "/dashboard/api/comments/post/";

WG.PostComment = React.createFactory(React.createClass({

  // NOTE: updating state causes all charts to rerender and animate
  getInitialState: function() {
    return {
      pollID: "",
      pollInstanceID: "",
      userID: "",
      comment: "",
      onlyFirstComment: false
    }
  },

  submit: function(e) {
    e.preventDefault();

    $.post(url, this.state)
      .done(function(response){
        PubSub.publish(WG.actions.SHOW_SUCCESS, "Posted " + response.count + " comments!");
        this.setState(this.getInitialState());
      }.bind(this))
      .fail(function(response){
        PubSub.publish(WG.actions.SHOW_ERROR, response.responseText);
      }.bind(this));
  },
  
  render: function() {

    var onChange = function(field, e) {
      var state = {};
      state[field] = e.target.value;
      this.setState(state);
    }.bind(this);

    return (
      D.div({className: "PostComment"},
        D.form({className: "form-horizontal"},
          D.div({className: "form-group"},
            D.label({className: "col-sm-2 control-label"}, "Poll"),
            D.div({className: "col-sm-10"},
              D.input({type: "number", min: 1, placeholder: "Poll ID", className: "form-control",
                value: this.state.pollID,
                onChange: onChange.bind(this, "pollID")}),
              D.input({type: "number", min: 1, placeholder: "or Poll Instance IDs (comma-separated)", className: "form-control",
                value: this.state.pollInstanceID,
                onChange: onChange.bind(this, "pollInstanceID")})
            )
          ),
          D.div({className: "form-group"},
            D.label({className: "col-sm-2 control-label"}, "User"),
            D.div({className: "col-sm-10"},
              D.input({type: "number", min: 1, placeholder: "User ID (defaults to admin id)", className: "form-control",
                value: this.state.userID,
                onChange: onChange.bind(this, "userID")})
            )
          ),
          D.div({className: "form-group form-group-lg"},
            D.label({className: "col-sm-2 control-label"}, "Comment"),
            D.div({className: "col-sm-10"},
              D.textarea({placeholder: "Comment body", maxLength: 254, className: "form-control",
                value: this.state.comment,
                required: true,
                onChange: onChange.bind(this, "comment")})
            )
          ),
          D.div({className: "form-group"},
            D.div({className: "col-sm-offset-2 col-sm-10"},
              D.div({className: "checkbox"},
                D.label({},
                  D.input({type: "checkbox",
                    checked: this.state.onlyFirstComment,
                    onChange: function(e) {
                      this.setState({onlyFirstComment: e.target.checked});
                    }.bind(this)}),
                  "Only post if it's the first comment"
                )
              )
            )
          ),
          D.div({className: "form-group"},
            D.div({className: "col-sm-offset-2 col-sm-10 text-right"},
              D.button({type: "submit", className: "btn btn-primary btn-lg", onClick: this.submit},
                "Post"
              )
            )
          )
        )
      )
    )
  }
}));

})();

