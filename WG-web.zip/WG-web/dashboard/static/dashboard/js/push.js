var UniversityFilter = React.createClass({
  setAllUsers: function() {
    this.props.setFilter('allUsers');
  },

  setAllUniversities: function() {
    this.props.setFilter('allUniversities');
  },

  setSelectedUniversities: function() {
    this.props.setFilter('selectedUniversities');
  },

  setSelectedUsers: function() {
    this.props.setFilter('selectedUsers');
  },
  
  render: function() {
    var notificationLink = this.props.notificationLink;
    var filter = this.props.filter;
  
    var allUsers = (
      <li role="presentation" className={(filter === 'allUsers') ? 'active' : 'inactive'}>
        <a href="#" onClick={this.setAllUsers}>All Active Users</a>
      </li>
    );
    var allUniversities = (
      <li role="presentation" className={(filter === 'allUniversities') ? 'active' : 'inactive'}>
        <a href="#" onClick={this.setAllUniversities}>All Universities</a>
      </li>
    );
    var selectedUniversities = (
      <li role="presentation" className={(filter === 'selectedUniversities') ? 'active' : 'inactive'}>
        <a href="#" onClick={this.setSelectedUniversities}>Selected Universities</a>
      </li>
    );
    var selectedUser = (
      <li role="presentation" className={(filter === 'selectedUsers') ? 'active' : 'inactive'}>
        <a href="#" onClick={this.setSelectedUsers}>User IDs</a>
      </li>
    );
    var filterCategories = (
      <ul className="nav nav-pills nav-stacked">
        {allUsers}
        {allUniversities}
        {selectedUniversities}
        {selectedUser}
      </ul>
    );

    var includeNearbyCheckbox;
    var canIncludeNearbyUsers = false;
    if ((notificationLink === 'textOnly') || (notificationLink === 'featuredPoll')) {
      canIncludeNearbyUsers = ((filter !== 'allUsers') && (filter !== 'selectedUsers'));
    }
    if (canIncludeNearbyUsers) {
      includeNearbyCheckbox = (
        <input type="checkbox" id="includeNearby" checked={this.props.includeNearby} onChange={this.props.changeIncludeNearby} />
      );
    } else {
      includeNearbyCheckbox = (
        <input type="checkbox" id="includeNearby" checked={this.props.includeNearby} disabled />
      );
    }
    var includeNearbyDropdown = (
      <select id="includeNearbyTimeframe" value={this.props.includeNearbyTimeframe} onChange={this.props.changeIncludeNearbyTimeframe} className="form-control" disabled={!canIncludeNearbyUsers}>
        <option value="6">6 Weeks</option>
        <option value="5">5 Weeks</option>
        <option value="4">4 Weeks</option>
        <option value="3">3 Weeks</option>
        <option value="2">2 Weeks</option>
        <option value="1">1 Week</option>
      </select>
    );
    var includeNearbyDropdownAndLabel = (
      <div className="row">
        <div className="col-xs-12">
          <label htmlFor="includeNearbyTimeframe">Who were active in the last</label>
        </div>
        <div className="col-xs-8">
          {includeNearbyDropdown}
        </div>
      </div>
    );
    var includeNearby = (
      <div>
        <p className="filter">
          <label htmlFor="includeNearby">Include Nearby Users</label>
          {includeNearbyCheckbox}
        </p>
        {includeNearbyDropdownAndLabel}
      </div>
    );

    return (
      <div className="row">
        <div className="col-xs-12">
          <h3>Users</h3>
          {filterCategories}
          <br />
          {includeNearby}
          <br /><hr />
          <UniversityList
            notificationLink={this.props.notificationLink}
            universities={this.props.universities}
            selectedUniversities={this.props.selectedUniversities}
            eligibleUniversities={this.props.eligibleUniversities}
            selectUniversity={this.props.selectUniversity}
            deselectUniversity={this.props.deselectUniversity} />
        </div>
      </div>
    );
  }
});

var UniversityList = React.createClass({
  universityEligible: function(university) {
    var eligibleUniversities = this.props.eligibleUniversities;
    for (var universityIndex = 0; universityIndex < eligibleUniversities.length; universityIndex++) {
      var eligibleUniversity = eligibleUniversities[universityIndex];
      if (eligibleUniversity.id === university.id) {
        return true;
      }
    }
    return false;
  },

  render: function() {
    var universityItems = this.props.universities.map(function(university) {
      var universitySelected = (this.props.selectedUniversities.indexOf(university) == -1) ? false : true;
      var universityAction = universitySelected ? this.props.deselectUniversity : this.props.selectUniversity;
      var universityActionFunction = function() 
      {
        universityAction(university);
      }.bind(this);

      var key = "university-" + university.id;

      if (this.props.notificationLink === 'localPoll') {
        if (!(this.universityEligible(university))) {
          return (
            <li key={key}><s>{university.name}</s></li>
          );
        }
      }

      return (
        <li key={key}>{university.name} <input type="checkbox" checked={universitySelected} onChange={universityActionFunction} /></li>
      );
    }.bind(this));

    return (
      <div>
        <h3>Universities</h3>
        <ul>
          {universityItems}
        </ul>
      </div>
    );
  }
});

var UserFilter = React.createClass({
  filter: function(e) 
  {
    this.props.setFilter(e.target.value);
  },

  render: function() 
  {
    var options = ['All', 'Male', 'Female', 'University-Registered'];
    return (
      <div className="row">
        <div className="col-xs-12 filter">
          <h3>Filter</h3>
          <ul className="nav nav-pills nav-stacked">
            {options.map(function(option) 
              {
              var rawOption = option.toLowerCase();
              var filter = function() 
              {
                this.props.setFilter(rawOption);
              }.bind(this);
              return (
                <li role="presentation" key={rawOption} className={this.props.filter === rawOption ? 'active' : 'inactive'}>
                  <a href="#" onClick={filter}>{option}</a>
                </li>
              );
            }.bind(this))}
          </ul>
        </div>
      </div>
    );
  }
});

var PushNotificationDashboard = React.createClass({
  getInitialState: function() {
    return {
      notificationTitle: '',
      notification: '',
      submitted_notification: false,
      selected_user_ids: [],
      notification_link: 'textOnly',
      notificationType: 0,
      checking_local_poll: false,
      local_poll_valid: false,
      local_poll_id: '',
      featured_poll_id: '',
      notification_error: '',
      universityFilter: '',
      userFilter: 'all',
      universities: [],
      selectedUniversities: [],
      eligibleUniversities: [],
      includeNearby: false,
      includeNearbyTimeframe: '3',
      recipientCount: 0
    };
  },

  componentDidMount: function() {
    this.getUniversities();
  },

  componentDidUpdate: function(prevProps, prevState) {
    var recipientDependent = [
      "selected_user_ids", "userFilter", "universityFilter", "includeNearby",
      "includeNearbyTimeframe", "selectedUniversities"
    ];
    var changed = recipientDependent.filter(function(key) {
        return this.state[key] != prevState[key]
      }.bind(this));
    if (changed.length > 0) {
      this.updateRecipientCount();
    }
  },

  updateRecipientCount: function() {
    this.setState({recipientCount: undefined});
    $.ajax({
      url: this.props.recipientsUrl,
      data: {
        user_ids: this.state.selected_user_ids,
        user_filter: this.state.userFilter,
        include_nearby: this.state.includeNearby,
        include_nearby_timeframe: this.state.includeNearbyTimeframe,
        university_ids: this.computeUniversityIDs()
      },
      type: 'POST',
      success: function(data) {
        this.setState({
          recipientCount: data.count
        });
      }.bind(this),
      error: handleError
    });
  },

  selectUniversity: function(university) {
    var selectedUniversities = this.state.selectedUniversities;
    if (selectedUniversities.indexOf(university) === -1) {
      selectedUniversities.push(university);
      var newState = {selectedUniversities: selectedUniversities};

      var universityFilter = this.state.universityFilter;
      if (universityFilter !== 'selectedUniversities') {
        newState.universityFilter = 'selectedUniversities';
      }

      this.setState(newState);
    }
  },

  deselectUniversity: function(university) {
    var selectedUniversities = this.state.selectedUniversities;
    var indexOfSelectedUniversity = selectedUniversities.indexOf(university);
    if (indexOfSelectedUniversity !== -1) {
      selectedUniversities.splice(indexOfSelectedUniversity, 1);
      var newState = {selectedUniversities: selectedUniversities};

      var universityFilter = this.state.universityFilter;
      if (universityFilter !== 'selectedUniversities') {
        newState.universityFilter = 'selectedUniversities';
      }

      this.setState(newState);
    }
  },

  changeIncludeNearby: function() {
    var includeNearby = this.state.includeNearby;
    this.setState({includeNearby: !includeNearby});
  },

  changeIncludeNearbyTimeframe: function(e) {
    this.setState({includeNearbyTimeframe: e.target.value});
  },

  getUniversities: function() {
    $.ajax({
      url: this.props.universitiesUrl,
      type: 'GET',
      success: function(data) {
        this.setState({
          universities: data
        });
      }.bind(this),
      error: handleError
    });
  },

  canSubmitNotification: function() {
    var notificationLength = this.state.notificationTitle.length;
    var notificationTitleValid = (notificationLength > 0) && (notificationLength <= this.props.maxNotificationLength)
    var notificationLink = this.state.notification_link;
    var universityFilter = this.state.universityFilter;

    if (!notificationTitleValid) {
      return false;
    }
    
    if (universityFilter === 'selectedUniversities') {
      if (this.state.selectedUniversities.length == 0) {
        return false;
      }
    } else if (universityFilter == 'selectedUsers') {
      if (this.state.selected_user_ids.length == 0) {
        return false;
      }
    }

    if (notificationLink === 'textOnly') {
      return notificationTitleValid;
    } else if (notificationLink == 'localPoll') {
      var localPollID = this.state.local_poll_id;
      return (localPollID.length > 0);
    } else {
      var featuredPollID = this.state.featured_poll_id;
      return (featuredPollID.length > 0);
    }
  },

  updateNotificationTitle: function(e) {
    this.setState({notificationTitle: e.target.value});
  },

  updateNotification: function(e) {
    this.setState({notification: e.target.value});
  },

  setLocalPollID: function(e) {
    this.setState({local_poll_id: e.target.value}, this.findEligibleUniversities);
  },

  findEligibleUniversities: function() {
    $.ajax({
      url: this.props.eligibleUniversitiesUrl,
      type: 'POST',
      data: {local_poll_id: this.state.local_poll_id},
      success: function(data) {
        this.setState({eligibleUniversities: data});
      }.bind(this),
      error: handleError
    });
  },

  setFeaturedPollID: function(e) {
    this.setState({featured_poll_id: e.target.value});
  },

  setSelectedUserIDs: function(e) {
    var user_ids = e.target.value.split(/\s*,\s*/gi)
      .filter(function(id) {return !!id});
    this.setState({selected_user_ids: user_ids});
  },

  computeUniversityIDs: function() {
    var universityIds = [];
    if (this.state.notification_link === 'localPoll') {
      var eligibleUniversities = this.state.eligibleUniversities;
      var selectedUniversities = this.state.selectedUniversities;

      for (var eligibleIndex = 0; eligibleIndex < eligibleUniversities.length; eligibleIndex++) {
        var eligibleUniversity = eligibleUniversities[eligibleIndex];

        for (var selectedIndex = 0; selectedIndex < selectedUniversities.length; selectedIndex++) {
          var selectedUniversity = selectedUniversities[selectedIndex];

          if (eligibleUniversity.id === selectedUniversity.id) {
            universityIds.push(eligibleUniversity.id);
            break;
          }
        }
      }
    } else {
      universityIds = this.state.selectedUniversities.map(function(university) {
        return university.id;
      });
    }
    return universityIds;
  },

  submit: function() {
    var notificationLink = this.state.notification_link;
    var canIncludeNearbyUsers = false;
    var filter = this.state.userFilter;
    if ((notificationLink === 'textOnly') || (notificationLink === 'featuredPoll')) {
      canIncludeNearbyUsers = ((filter !== 'allUsers') && (filter !== 'selectedUsers'));
    }
    var notificationData = {
      notification_title: this.state.notificationTitle,
      notification: this.state.notification,
      notification_type: this.state.notificationType,
      user_filter: this.state.userFilter,
      include_nearby: canIncludeNearbyUsers ? this.state.includeNearby : false,
      include_nearby_timeframe: this.state.includeNearbyTimeframe
    };

    if (this.state.notification_link === 'localPoll') {
      notificationData.local_poll_id = this.state.local_poll_id;
    } else if (this.state.notification_link === 'featuredPoll') {
      notificationData.featured_poll_id = this.state.featured_poll_id;
    }

    if (this.state.universityFilter === 'selectedUsers') {
      notificationData.user_ids = this.state.selected_user_ids;
    } else {
      notificationData.university_ids = this.computeUniversityIDs();
    }
    $.ajax({
      url: this.props.url,
      type: 'POST',
      data: notificationData,
      success: function(data) {
        var reset = this.getInitialState();
        reset.submitted_notification = true;
        this.setState(reset, this.submittedNotification);
      }.bind(this),
      error: function(xhr, status, err) {
        this.setState({
          notification_error: xhr.responseText
        }, this.submissionFailed);
        console.log('xhr', xhr);
        console.log('status', status);
        console.log('err', err);
      }.bind(this)
    });
  },

  setNotificationType: function(e) {
    this.setState({notificationType: e.target.value});
  },

  setTextOnly: function() {
    this.setState({notification_link: 'textOnly'});
  },

  setLocalPoll: function() {
    this.setState({notification_link: 'localPoll'});
  },

  setFeaturedPoll: function() {
    this.setState({notification_link: 'featuredPoll'});
  },

  setUniversityFilter: function(filter) {
    var newState = {universityFilter: filter};
    if (filter != 'selectedUsers') {
      newState.selected_user_ids = [];
    }
    if (['allUsers', 'selectedUsers'].indexOf(filter) > -1) {
      newState.selectedUniversities = [];
    } else if (filter === 'allUniversities') {
      newState.selectedUniversities = this.state.universities.slice();
    }
    this.setState(newState);
  },

  setUserFilter: function(filter) {
    this.setState({userFilter: filter});
  },

  submittedNotification: function() {
    if (this.state.submitted_notification) {
      $('#submitted-notification').delay(1000).fadeOut(1000, function() {
        this.setState({submitted_notification: false});
      }.bind(this));
    }
  },

  submissionFailed: function() {
    if (this.state.notification_error !== '') {
      $('#notification-error').delay(5000).fadeOut(1000, function() {
        this.setState({notification_error: ''});
      }.bind(this));
    }
  },

  render: function() {
    var notificationTitle = (
      <div className="row">
        <label htmlFor="notificationTitle" className="col-xs-3">Message:</label>
        <div className="col-xs-9">
          <input type="text" className="form-control" id="notificationTitle" onChange={this.updateNotificationTitle} value={this.state.notificationTitle} />
        </div>
      </div>
    );

    var notificationText = (
      <div className="row">
        <label htmlFor="notification" className="col-xs-3">Quote (optional):</label>
        <div className="col-xs-9">
          <textarea maxLength={this.props.maxNotificationLength} className="form-control" id="notification" rows="2" cols="25" onChange={this.updateNotification} value={this.state.notification} />
        </div>
      </div>
    );

    var notificationTypes = (
      <div className="row">
        <label htmlFor="notificationTypes" className="col-xs-3">Title:</label>
        <div className="col-xs-9">
          <select value={this.state.notificationType} onChange={this.setNotificationType}>
            {this.props.notificationTypes.map(function(type, i) {
              return <option key={i} value={i}>{type}</option>
            })}
          </select>
        </div>
      </div>
    );

    var notificationIsTextOnly = (this.state.notification_link === 'textOnly');
    var textOnlyNotificationType = (
      <li role="presentation" className={notificationIsTextOnly ? 'active' : 'inactive'}>
        <a href="#" onClick={this.setTextOnly}>Text Only</a>
      </li>
    );

    var notificationIsLocalPoll = (this.state.notification_link === 'localPoll');
    var localPollNotificationType = (
      <li role="presentation" className={notificationIsLocalPoll ? 'active' : 'inactive'}>
        <a href="#" onClick={this.setLocalPoll}>Local Poll</a>
      </li>
    );

    var notificationIsFeaturedPoll = (this.state.notification_link === 'featuredPoll');
    var featuredPollNotificationType = (
      <li role="presentation" className={notificationIsFeaturedPoll ? 'active' : 'inactive'}>
        <a href="#" onClick={this.setFeaturedPoll}>Featured Poll</a>
      </li>
    );
    
    var notificationLinkSelection = (
      <div className="row notification-type">
        <div className="col-xs-9 col-xs-offset-3">
          <ul className="nav nav-pills">
            {textOnlyNotificationType}
            {localPollNotificationType}
            {featuredPollNotificationType}
          </ul>
        </div>
      </div>
    );

    var notificationDetails;
    if (notificationIsLocalPoll || notificationIsFeaturedPoll) {
      var changeAction = notificationIsLocalPoll ? this.setLocalPollID : this.setFeaturedPollID;
      var pollValue = notificationIsLocalPoll ? this.state.local_poll_id : this.state.featured_poll_id;

      notificationDetails = (
        <div className="row notification-details">
          <div className="col-xs-9 col-xs-offset-3">
            <div className="row">
              <div className="col-xs-4">
                <label htmlFor="pollID">{notificationIsLocalPoll ? 'Local Poll' : 'Featured Poll Instance'} ID:</label>
              </div>
              <div className="col-xs-8">
                <input type="text" className="form-control" id="pollID" onChange={changeAction} value={pollValue} />
              </div>
            </div>
          </div>
        </div>
      );
    }
    if (this.state.universityFilter == 'selectedUsers') {
      var changeAction = this.setSelectedUserIDs;
      var userValue = this.state.selected_user_ids.join(',');

      notificationDetails = (
        <div className="row notification-details">
          <div className="col-xs-9 col-xs-offset-3">
            <div className="row">
              <div className="col-xs-4">
                <label htmlFor="userID">User IDs:</label>
              </div>
              <div className="col-xs-8">
                <input type="text" className="form-control" id="userID" onChange={changeAction} defaultValue={userValue} placeholder="Comma-separated" />
              </div>
            </div>
          </div>
        </div>
      );
    }
    var notificationTextStatus = (
      <div className="row submission">
        <div className="col-xs-6 col-xs-offset-3">
          <span>
            {this.props.maxNotificationLength - this.state.notification.length} Characters Available
          </span>
        </div>
      </div>
    );

    var notificationStatus;
    if (this.state.submitted_notification) {
      notificationStatus = (
        <div className="row" id="submitted-notification">
          <div className="col-xs-12">
            <p className="bg-success">
              Submitted Notification
            </p>
          </div>
        </div>
      );
    }

    var notificationError;
    if (this.state.notification_error !== '') {
      notificationError = (
        <div className="row" id="notification-error">
          <div className="col-xs-12">
            <p className="bg-danger">
              {this.state.notification_error}
            </p>
          </div>
        </div>
      );
    }

    var submitButton;
    if (this.canSubmitNotification()) {
      submitButton = (
        <button type="submit" className="btn btn-primary btn-block" onClick={this.submit}>Submit</button>
      );
    } else {
      submitButton = (
        <button type="submit" className="btn btn-primary btn-block" disabled>Submit</button>
      );
    }

    return (
      <div className="row">
        <div className="col-xs-6">
          {notificationLinkSelection}
          <br />
          {notificationTitle}
          <br />
          {notificationText}
          <br />
          {notificationTypes}
          <br />
          {notificationDetails}
          {notificationTextStatus}
          {notificationStatus}
          {notificationError}
          <div className="row">
            <div className="col-xs-6 col-xs-offset-3 bg-info">
              <p style={{marginTop: 10}}>Number of recipients:&nbsp;
                <strong>{this.state.recipientCount != null
                    ? this.state.recipientCount
                    : "..."}
                </strong>
              </p>
            </div>
          </div>
        </div>
        <div className="col-xs-3">
          <UniversityFilter
            notificationLink={this.state.notification_link}
            setFilter={this.setUniversityFilter}
            universities={this.state.universities}
            selectedUniversities={this.state.selectedUniversities}
            eligibleUniversities={this.state.eligibleUniversities}
            selectUniversity={this.selectUniversity}
            deselectUniversity={this.deselectUniversity}
            includeNearby={this.state.includeNearby}
            changeIncludeNearby={this.changeIncludeNearby}
            includeNearbyTimeframe={this.state.includeNearbyTimeframe}
            changeIncludeNearbyTimeframe={this.changeIncludeNearbyTimeframe}
            filter={this.state.universityFilter} />
        </div>
        <div className="col-xs-3">
          <UserFilter
            setFilter={this.setUserFilter}
            filter={this.state.userFilter} />
          <br />
          <hr />
          <br />
          {submitButton}
        </div>
      </div>
    );
  }
});

$(document).ready(function() {
  ReactDOM.render(
    <PushNotificationDashboard
      url="/dashboard/api/push/create/"
      recipientsUrl="/dashboard/api/push/recipients/"
      universitiesUrl="/dashboard/api/universities/"
      eligibleUniversitiesUrl="/dashboard/api/universities/eligible/"
      maxNotificationLength="80"
      notificationTypes={window.WG_notificationTypes} />,
    $("#parent")[0]
  );
});

// Helpers

function handleError(xhr, status, err) {
  console.log('xhr', xhr);
  console.log('status', status);
  console.log('err', err);
}
