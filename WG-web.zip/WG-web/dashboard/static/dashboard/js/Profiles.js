(function() {

var D = React.DOM;
var PROFILES_URL = "/dashboard/api/profiles/";
var ACTION_RENDER_RESPONSES = "ACTION_RENDER_RESPONSES";
var ACTION_SET_LOADING = "ACTION_SET_LOADING";

WG.ProfileTable = React.createFactory(React.createClass({

  propTypes: {
    initialUser: React.PropTypes.shape({
      id: React.PropTypes.number.isRequired,
      gender: React.PropTypes.number.isRequired
    }).isRequired,
  },

  getInitialState: function() {
    return {
      loading: false,
      responses: [],
      response_count: 0,
      // TODO respect poll choice
      polls: [],
      user: this.props.initialUser
    }
  },

  componentWillMount: function() {
    this.spinner = new Spinner(WG.constants.SPINNER_SETUP);

    this.listeners = [
      PubSub.subscribe(ACTION_RENDER_RESPONSES, function(topic, data) {
        this.setState({
          loading: false,
          responses: data.responses,
          response_count: data.count
        })
      }.bind(this)),

      PubSub.subscribe(ACTION_SET_LOADING, function() {
        this.setState({ loading: true })
      }.bind(this)),
    ];

    this.fetchProfile();
  },

  componentWillUnmount: function() {
    this.listeners.map(PubSub.unsubscribe);
  },

  componentDidMount: function() {
    this.parentNode = $(ReactDOM.findDOMNode(this)).parent()[0];
    if (this.state.loading) {
      this.spinner.spin(this.parentNode);
    }
  },

  componentDidUpdate: function(prevProps, prevState) {
    if (this.state.loading && !prevState.loading) {
      this.spinner.spin(this.parentNode);
    }
    if (!this.state.loading) {
      this.spinner.stop();
    }
  },

  fetchProfile: function() {
    PubSub.publish(ACTION_SET_LOADING);

    if (this.xhr) {
      this.xhr.abort();
    }

    var poll_ids = this.state.polls.map(function(p) {return p.id});
    var url = PROFILES_URL + this.state.user.id;

    this.xhr = $.get(url, {poll_ids: poll_ids})
      .done(function(data) {
        PubSub.publish(ACTION_RENDER_RESPONSES, data);
      });
  },

  // TODO use or deprecate
  // getPollsInvertProfiles: function() {
  //   var pollDict = {};

  //   this.state.profiles.forEach(function(user) {
  //     user.responses.forEach(function(response) {
  //       var key = response.poll_instance;
  //       var poll = pollDict[key] || {
  //         id: key,
  //         responses: []
  //       };
  //       poll.responses.push(response);
  //       pollDict[key] = poll;
  //     });
  //   });

  //   return Object.keys(pollDict).map(function(pollID) {
  //     return pollDict[pollID];
  //   });
  // },
  
  render: function() {
    var style = {
      opacity: this.state.loading ? 0.5 : 1
    };

    var genderClass = {
      0: "text-blue",
      1: "text-pink"
    }[this.state.user.gender] || "text-purple";

    return (
      D.div({className: "ProfileTable"},
        D.h3({className: "text-center"},
          "User " + this.state.user.id + " ",
          D.small({},
            D.span({className: genderClass},
              "\"" + this.state.user.username + "\""
            ),
            this.state.user.university_short
              ? " from " + this.state.user.university_short
              : "",
            ": " + this.state.response_count + " responses"
          )
        ),
        D.table({ className: "table table-striped table-hover",
                  style: style },
          D.tbody({},
            this.state.responses.map(function(response) {
              return WG.Response({
                key: response.id,
                question: response.poll.question,
                options: response.poll.options,
                feed: response.feed,
                rating: response.rating,
                response: response
              })
            }.bind(this))
          )
        ),
        this.state.response_count > this.state.responses.length
          ? D.p({className: "text-muted"},
              "Showing only most recent " + this.state.responses.length
            )
          : null
      )
    )
  }
}));


/**
 * PollResponseList class (each row)
 */

WG.Response = React.createFactory(React.createClass({

  propTypes: {
    question: React.PropTypes.string.isRequired,
    feed: React.PropTypes.shape({
      image_source: React.PropTypes.string,
      name: React.PropTypes.string.isRequired,
    }).isRequired,
    options: React.PropTypes.arrayOf(React.PropTypes.string.isRequired).isRequired,
    response: React.PropTypes.shape({
      id: React.PropTypes.number.isRequired,
      response: React.PropTypes.number.isRequired,
      created_date: React.PropTypes.string.isRequired
    }).isRequired,
    rating: React.PropTypes.number
  },

  renderChoice: function(response) {
    return D.td({key: response.id},
      this.props.options[response.response]
    )
  },

  render: function() {
    var headerStyle = {
      width: '50%'
    };

    var ratingClass = {
      0: "danger",
      1: "success"
    }[this.props.rating] || "";

    return (
      D.tr({ className: "Response " + ratingClass},
        D.th({style: headerStyle}, this.props.question),
        this.renderChoice(this.props.response),
        D.td({},
          D.small({className: "text-muted"},
            moment(this.props.response.created_date).calendar()
          )
        ),
        D.td({className: "Response--feed"},
          this.props.feed.image_source
            ? D.img({src: this.props.feed.image_source})
            : D.span({}, this.props.feed.name)
        )
      )
    )
  }

}));



})();
