var Feed = React.createClass({

  render: function() {
    var active;
    var feed_status_title = "INACTIVE";
    var feed_status_class = "inactive";
    var feed_action = "ACTIVATE";
    if(this.props.feed.active) {
      feed_status_title = "ACTIVE";
      feed_status_class = "active";
      feed_action = "DEACTIVATE";
    }
    var selected;
    var submissions;
    
    if(this.props.selected) {
      selected = (<span className="bullet">&#8226;</span>);
    } else {
      submissions = (<div data-feed-id={this.props.feed.id} className="item" onClick={this.props.onSelectFeed}>SUBMISSIONS</div>);
    }

    return (
      <div className="feed">
        {selected} 
        {this.props.feed.name}
        <div className="feed-level">({this.props.feed.level_display})</div>
        <div className={"feed-status " + feed_status_class}>{feed_status_title}</div>
        <br/>
        <div className="item" data-feed-id={this.props.feed.id} onClick={this.props.onToggleFeedStatus}>{feed_action}</div>
        {submissions}
      </div>
    );
  }
});

/* based on from dashboard/js/monitoring; should be extracted and shared */
var Page = React.createClass({
  onNextPage: function(e) {
    this.props.handleNextPage(e);
  },
  onPrevPage: function(e) {
    if(this.props.currentPage == 1) return;
    this.props.handlePrevPage(e);
  },
  render: function() {
    var right;
    if (this.props.isEmpty) {
      right = (<button className="button arrow" disabled>&nbsp;&gt;&nbsp;</button>);
    } else {
      right = (<button className="button arrow" onClick={this.onNextPage}>&nbsp;&gt;&nbsp;</button>);
    }
    return (
      <div className="pager">
        <button className="button arrow left" onClick={this.onPrevPage}>&nbsp;&lt;&nbsp;</button>
        Page {this.props.currentPage}
        {right}
      </div>
    );
  }
});

var FeedList = React.createClass({

  didSelectFeed: function(e) {
    var feed_id = parseInt($(e.target).attr("data-feed-id"));
    if(this.state.selected != feed_id) {
      this.setState({ selected : feed_id });
      PubSub.publish("changeFeed", feed_id);
    }
  },
  toggleFeedStatus: function(e) {
    var feed_id = parseInt($(e.target).attr("data-feed-id"));
    var url = "/dashboard/api/feeds/" + feed_id + "/toggle/";
    $.ajax({
      url: url,
      dataType: 'json',
      type : "POST",
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      data: {},
      success: function(data) {
        var updatedFeeds = this.state.feeds.map(function(feed) {
          if(feed.id === feed_id) {
            feed.active = data.active
          }
          return feed;
        });
        this.setState({feeds: updatedFeeds});
      }.bind(this),
      error: function(xhr, status, err) {
        console.error(xhr.responseText)
      }.bind(this)
    });
  },
  loadFeeds: function() {
    $.ajax({
      url: this.props.getFeedsURL,
      dataType: 'json',
      success: function(data) {
        var feeds = data.map(function(feed) {
          feed.selected = false;
          return feed;
        });
        this.setState({ feeds: feeds });
      }.bind(this),
      error: function(xhr, status, err) {
        console.error(xhr.responseText)
      }.bind(this)
    });
  },
  refreshFeeds: function() {
    this.setState({selected: null});
    this.loadFeeds();
    PubSub.publish("clearPolls");
  },
  getInitialState: function() {
    return {
      feeds: [],
      selected: null
    }
  },
  componentDidMount: function() {
    this.loadFeeds();
  },
  render: function() {
    var feeds = this.state.feeds.map(function(feed, i) {
      return (
        <Feed key={i} feed={feed} selected={feed.id == this.state.selected} onSelectFeed={this.didSelectFeed} onToggleFeedStatus={this.toggleFeedStatus} />
      );
    }.bind(this));
    return (
      <div className="col-md-4 col-md-offset-1">
        <div className="feed-container">
          <label className="list-label">Feature feeds</label>
          <span className="list-option" onClick={this.refreshFeeds}>REFRESH</span>
          <div className="feed-list">
            {feeds}
          </div>
        </div>
      </div>
    );
  }
});

var Poll = React.createClass({

  getInitialState: function() {
    return {
      filter: null
    }
  },
  render: function() {
    var status, action, prefix;
    if (this.props.poll.gender == 0) {
      prefix = 'GUYS: ';
    } else if (this.props.poll.gender == 1) {
      prefix = 'GIRLS: ';
    } else {
      prefix = '';
    }
    if(this.props.poll.verified) {
      status = (<div className="poll-status accepted">ACCEPTED</div>);
      action = (<div className="remove" onClick={this.props.onRemove}> REMOVE </div>);
    } else if (this.props.poll.auto_verified) {
      status = (<div className="poll-status auto-accepted">AUTO ACCEPTED</div>);
      action = (<div className="remove" onClick={this.props.onRemove}> REMOVE </div>);
    } else {
      status = (<div className="poll-status">PENDING</div>);
      action = (<div className="accept" onClick={this.props.onAccept}> ACCEPT </div>);
    }
    var options = this.props.poll.options.map(function(option, i) {
      var count = this.props.poll.option_counts[i];
      return (<div key={i} className="option">{option} ({count} votes)</div>);
    }.bind(this));
    var trashAction;
    if (!this.props.poll.verified) {
      trashAction = (<div className="trash" onClick={this.props.onTrash}> TRASH </div>);
    }
    return (
      <div className="poll">
        <div className="poll-data"> 
          {prefix}{this.props.poll.question}
          {this.props.poll.picture_question ?
            <img src={this.props.poll.picture_question} />
            : null
          }
          {options}
          {status}
          <div className="metadata">
            {moment(this.props.poll.created_date).fromNow()} &#8226; USER: {this.props.poll.user} &#8226;&nbsp;
            <a target="_blank" href={"https://whatsgoodly.com/esuohgod/whatsgoodly/pollinstance/" + this.props.poll.id}>
              POLL INSTANCE: {this.props.poll.id}
            </a>
          </div>
          <WG.TagAutocomplete poll={this.props.poll} bloodhound={this.props.bloodhound} />
        </div>
        <div className="poll-actions">
          {action}
          <div className="edit" onClick={this.props.onEdit}> EDIT </div>
          {trashAction}
        </div>
      </div>
    );
  }
});

var PollList = React.createClass({

  getInitialState: function() {
    return {
      feed: null,
      polls: [],
      filter: 0,
      filters: ["ALL", "PENDING", "ACCEPTED"],
      page: 1
    }
  },
  loadPolls: function(feed_id) {
    $.ajax({
      url: "/dashboard/api/" + feed_id + "/featurepolls/?page=" + this.state.page,
      dataType: 'json',
      success: function(data) {
        this.setState({ polls: data, feed: feed_id });
      }.bind(this),
      error: function(xhr, status, err) {
        console.error(xhr.responseText)
      }.bind(this)
    });
  },
  handleNextPage: function(e) {
    this.setState({page: this.state.page+1}, this.refreshPolls);
  },
  handlePrevPage: function(e) {
    this.setState({page: this.state.page-1}, this.refreshPolls);
  },
  componentWillMount: function() {
    this.feedChangeSubscription = PubSub.subscribe("changeFeed", function(topic, feed_id) {
      this.setState({page: 1});
      this.loadPolls(feed_id);
    }.bind(this));
    this.clearPollsSubscription = PubSub.subscribe("clearPolls", function(topic) {
      this.setState(this.getInitialState());
    }.bind(this));
    this.bloodhound = new Bloodhound({
      datumTokenizer: function(d) { 
        return Bloodhound.tokenizers.whitespace(d.label_lower); 
      },
      queryTokenizer: Bloodhound.tokenizers.whitespace,
      identify: function(obj) { return obj.label_lower; },
      prefetch: {
        url: '/dashboard/api/poll_tags/',
        cache: false,
        // transform: function(t) {
        //   return t.label_lower;
        // },
        // filter: function(list) {
        //   return $.map(list, function(label) {
        //     return { label: label }; });
        // }
      }
    });
    this.bloodhound.initialize();
  },
  componentWillUnmount: function() {
    PubSub.unsubscribe(this.feedChangeSubscription);
    PubSub.unsubscribe(this.clearPollsSubscription);
  },
  onAccept: function(poll) {
    var poll_id = poll.id
    $.ajax({
      url: "/dashboard/api/featurepolls/" + poll_id + "/accept/",
      dataType: 'json',
      type : "POST",
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      data: {},
      success: function(data) {
        var polls = this.state.polls
        for(var i = 0; i < polls.length; i++) {
          if(polls[i].id == poll_id) {
            polls[i].verified = true
          }
        }
        this.setState({ polls: polls })
      }.bind(this),
      error: function(xhr, status, err) {
        console.error(xhr.responseText)
      }.bind(this)
    });
  },
  onTrash: function(poll) {
    var poll_id = poll.id
    $.ajax({
      url: "/dashboard/api/featurepolls/" + poll_id + "/trash/",
      dataType: 'json',
      type : "DELETE",
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      data: {},
      success: function(data) {
        var polls = this.state.polls
        polls = polls.filter(function(existingPoll) {
          return existingPoll.id !== poll_id
        })
        this.setState({ polls: polls })
      }.bind(this),
      error: function(xhr, status, err) {
        console.error(xhr.responseText)
      }.bind(this)
    });
  },
  onRemove: function(poll) {
    var poll_id = poll.id
    $.ajax({
      url: "/dashboard/api/featurepolls/" + poll_id + "/remove/",
      dataType: 'json',
      type : "POST",
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      data: {},
      success: function(data) {
        var polls = this.state.polls
        for(var i = 0; i < polls.length; i++) {
          if(polls[i].id == poll_id) {
            polls[i].verified = false
          }
        }
        this.setState({ polls: polls })
      }.bind(this),
      error: function(xhr, status, err) {
        console.error(xhr.responseText)
      }.bind(this)
    });
  },
  onEdit: function(poll) {
    var parent_poll_id = poll.parent_poll_id;
    var url = "https://whatsgoodly.com/esuohgod/whatsgoodly/poll/" + parent_poll_id
    window.open(url, '_blank');
  },
  refreshPolls: function() {
    this.loadPolls(this.state.feed);
  },
  changeFilter: function(e) {
    var filter_id = parseInt($(e.target).attr("data-filter"));
    var old_filter_id = this.state.filter;
    var newState = { filter: filter_id };
    if (filter_id == old_filter_id) {
      this.setState(newState);
    } else {
      newState.page = 1;
      this.setState(newState, this.refreshPolls);
    }
  },
  render: function() {
    var polls = this.state.polls.map(function(poll, i) {
      if(this.state.filters[this.state.filter] == "ACCEPTED" && !poll.verified) {
        return;
      }
      if(this.state.filters[this.state.filter] == "PENDING" && poll.verified) {
        return;
      }
      return (
        <Poll key={i}
              onAccept={this.onAccept.bind(this, poll)} 
              onRemove={this.onRemove.bind(this, poll)} 
              onEdit={this.onEdit.bind(this, poll)} 
              onTrash={this.onTrash.bind(this, poll)}
              poll={poll}
              bloodhound={this.bloodhound} />
      );
    }.bind(this));
    var filters = [];
    for(var f = 0; f < this.state.filters.length; f++) {
      var filterClass = "list-filter";
      if(this.state.filter == this.state.filters[f]) {
        filterClass += " selected";
      }
      var filter = (<span key={f} className={filterClass} data-filter={f} onClick={this.changeFilter}>{this.state.filters[f]}</span>);
      filters.push(filter);
    }
    var pagination;
    if (!(this.state.feed === null)) {
      var isEmpty = (this.state.polls.length == 0);
      pagination = (
        <Page currentPage={this.state.page} isEmpty={isEmpty} handleNextPage={this.handleNextPage} handlePrevPage={this.handlePrevPage} />
      );
    }
    return (
      <div className="col-md-6">
        <div className="poll-container">
          <div className="poll-header">
            <label className="list-label">Poll submissions</label>
            <span className="list-option" onClick={this.refreshPolls}>REFRESH</span>
            {filters}
            {pagination}
          </div>
          <div className="poll-list">
            {polls}
          </div>
        </div>
      </div>
    );
  }
});

$(document).ready(function() {
  ReactDOM.render(
    <div className="row">
      <FeedList getFeedsURL="/dashboard/api/feeds/"/>
      <PollList />
    </div>, $(".container-fluid")[0]
  );
});
