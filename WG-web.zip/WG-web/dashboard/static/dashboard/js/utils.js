WG.TagAutocomplete = React.createClass({

  propTypes: {
    bloodhound: React.PropTypes.object.isRequired,
    poll: React.PropTypes.shape({
      id: React.PropTypes.number.isRequired,
      poll_tags: React.PropTypes.array.isRequired
    }).isRequired
  },

  getInitialState: function() {
    return {
      needsSave: false,
      tagLabels: this.props.poll.poll_tags.map(function(tag) {
        return tag.label_lower;
      })
    }
  },

  componentDidMount: function() {
    this.resetTags();
  },

  componentDidUpdate: function(prevProps, prevState) {
    if (this.props.poll.poll_tags != prevProps.poll.poll_tags) {
      this.resetTags();
    }
  },

  resetTags: function() {
    $(this.tagger).tagsinput('removeAll', {silent: true});

    this.props.poll.poll_tags.forEach(function(tag) {
      $(this.tagger).tagsinput('add', tag, {silent: true});
    }.bind(this));

    // TODO why no work?
    // this.setState({needsSave: false});
  },

  onSubmit: function() {
    $.ajax({
      url: "/dashboard/api/poll_tags/update/" + this.props.poll.id + "/", 
      type : "PATCH",
      data : {tags: this.state.tagLabels},
      success: function(data) {
        this.setState({needsSave: false});
      }.bind(this),
      error: function(xhr, status, err) {
        console.log(arguments);
      }.bind()
    })
  },

  onTaggerMount: function(elem) {
    if (!elem) return;

    this.tagger = elem;

    var tagsWithDefaults = function(q, sync) {
      if (q === '') {
        sync(this.props.bloodhound.index.all());
      } else {
        this.props.bloodhound.search(q, sync);
      }
    }.bind(this);

    $(elem).tagsinput({
      tagClass: function(item) {
        if (item.category == item.label_lower) {
          return 'label label-primary';
        }
        return 'label label-default';
      },
      itemValue: 'label_lower',
      itemText: 'label_lower',
      typeaheadjs: [{
          minLength: 0,
          highlight: true,
          hint: true,
          limit: 15
        },{
          name: 'tags',
          displayKey: 'label_lower',
          source: tagsWithDefaults
        }
      ]
    });

    $(elem).on('itemAdded', function (event) {
      if (event.options && event.options.silent) return;
      var labels = this.state.tagLabels;
      labels.push(event.item.label_lower);
      this.setState({labels: labels, needsSave: true});
    }.bind(this));

    $(elem).on('itemRemoved', function (event) {
      if (event.options && event.options.silent) return;
      var labels = this.state.tagLabels;
      var index = labels.indexOf(event.item.label_lower);
      labels.splice(index, 1);
      this.setState({labels: labels, needsSave: true});
    }.bind(this));
  },

  render: function() {
    return (
      <div className="TagAutocomplete">
        <small style={{marginRight: 8}}>TAGS</small>
        <select multiple ref={this.onTaggerMount}>
        </select>
        {this.state.needsSave ? 
          <button className="btn btn-default" onClick={this.onSubmit}>
            Save
          </button>
          :
          null
        }
      </div>
    )
  }
});