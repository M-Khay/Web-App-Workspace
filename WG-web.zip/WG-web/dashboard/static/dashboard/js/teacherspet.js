var Comment = React.createClass({
  render: function() {
    var status;
    var verify_action;
    var reject_action;
    console.log(this.props)
    if (this.props.comment.verified) {
      status = (<div className="post-status accepted">ACCEPTED</div>);
      verify_action = null
      reject_action = (<div className="remove" onClick={this.props.onReject} value={this.props.comment.id}> REJECT </div>);
    } else if (this.props.comment.rejected) {
      status = (<div className="post-status rejected">REJECTED</div>);
      verify_action = (<div className="accept" onClick={this.props.onAccept} value={this.props.comment.id}> ACCEPT </div>);
      reject_action = null
    } else {
      status = (<div className="post-status">PENDING</div>);
      verify_action = (<div className="accept" onClick={this.props.onAccept} value={this.props.comment.id}> ACCEPT </div>);
      reject_action = (<div className="remove" onClick={this.props.onReject} value={this.props.comment.id}> REJECT </div>);
    }
    return (
      <div className="post">
        <div className="post-data"> 
          <div className="comment-text">{this.props.comment.text}</div>
          {status}
        </div>
        <div className="post-actions">
          {verify_action}
          {reject_action}
        </div>
      </div>
    );
  }
});

var CommentList = React.createClass({
  loadComments: function() {
    $.ajax({
      url: "/dashboard/api/teacherspet/comments/",
      dataType: 'json',
      success: function(data) {
        this.setState({ comments: data });
      }.bind(this),
      error: function(xhr, status, err) {
        console.error(xhr.responseText)
      }.bind(this)
    });
  },
  getInitialState: function() {
    return {
      feed: null,
      comments: []
    }
  },
  componentDidMount: function() {
    this.loadComments();
  },
  onAccept: function(e) {
    comment_id = parseInt($(e.target).attr('value'));
    $.ajax({
      url: "/dashboard/api/teacherspet/comments/" + comment_id + "/verified/",
      dataType: 'json',
      type : "POST",
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      data: {},
      success: function(data) {
        var comments = this.state.comments
        for(var i = 0; i < comments.length; i++) {
          if(comments[i].id == comment_id) {
            comments[i].verified = true
            if (comments[i].rejected = true) {
              comments[i].rejected = false;
            }
          }
        }
        this.setState({ comments: comments })
      }.bind(this),
      error: function(xhr, status, err) {
        console.error(xhr.responseText)
      }.bind(this)
    });
  },
  onReject: function(e) {
    comment_id = parseInt($(e.target).attr('value'));
    $.ajax({
      url: "/dashboard/api/teacherspet/comments/" + comment_id + "/rejected/",
      dataType: 'json',
      type : "POST",
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      data: {},
      success: function(data) {
        var comments = this.state.comments
        for(var i = 0; i < comments.length; i++) {
          if(comments[i].id == comment_id) {
            comments[i].rejected = true
            if (comments[i].verified = true) {
              comments[i].verified = false;
            }
          }
        }
        this.setState({ comments: comments })
      }.bind(this),
      error: function(xhr, status, err) {
        console.error(xhr.responseText)
      }.bind(this)
    });
  },
  refreshComments: function() {
    this.loadComments();
  },
  render: function() {
    var comments = this.state.comments.map(function(comment) {
      return (
        <Comment onAccept={this.onAccept} onReject={this.onReject} comment={comment} />
      );
    }.bind(this));
    return (
      <div className="col-md-5">
        <div className="posts-container">
          <label className="list-label">Comments</label>
          <span className="list-option" onClick={this.refreshComments}>REFRESH</span>
          <div className="post-list">
            {comments}
          </div>
        </div>
      </div>
    );
  }
});

var Poll = React.createClass({
  render: function() {
    var status;
    var verify_action;
    var reject_action;
    if (this.props.poll.verified) {
      status = (<div className="post-status accepted">ACCEPTED</div>);
      verify_action = null;
      reject_action = (<div className="remove" onClick={this.props.onReject} value={this.props.poll.id}> REJECT </div>);
    } else if (this.props.poll.rejected) {
      status = (<div className="post-status rejected">REJECTED</div>);
      verify_action = (<div className="accept" onClick={this.props.onAccept} value={this.props.poll.id}> ACCEPT </div>);
      reject_action = null;
    } else {
      status = (<div className="post-status">PENDING</div>);
      verify_action = (<div className="accept" onClick={this.props.onAccept} value={this.props.poll.id}> ACCEPT </div>);
      reject_action = (<div className="remove" onClick={this.props.onReject} value={this.props.poll.id}> REJECT </div>);
    }
    var options = this.props.poll.options.map(function(option) {
      return (<div className="option">{option}</div>);
    });
    return (
      <div className="post">
        <div className="post-data"> 
          {this.props.poll.question}
          {options}
          {status}
        </div>
        <div className="post-actions">
          {verify_action}
          {reject_action}
        </div>
      </div>
    );
  }
});

var PollList = React.createClass({
  loadPolls: function() {
    $.ajax({
      url: "/dashboard/api/teacherspet/polls/",
      dataType: 'json',
      success: function(data) {
        this.setState({ polls: data });
      }.bind(this),
      error: function(xhr, status, err) {
        console.error(xhr.responseText)
      }.bind(this)
    });
  },
  getInitialState: function() {
    return {
      feed: null,
      polls: []
    }
  },
  componentDidMount: function() {
    this.loadPolls();
  },
  onAccept: function(e) {
    poll_id = parseInt($(e.target).attr('value'));
    $.ajax({
      url: "/dashboard/api/teacherspet/polls/" + poll_id + "/verified/",
      dataType: 'json',
      type : "POST",
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      data: {},
      success: function(data) {
        var polls = this.state.polls
        for(var i = 0; i < polls.length; i++) {
          if(polls[i].id == poll_id) {
            polls[i].verified = true
            if (polls[i].rejected = true) {
              polls[i].rejected = false;
            }
          }
        }
        this.setState({ polls: polls })
      }.bind(this),
      error: function(xhr, status, err) {
        console.error(xhr.responseText)
      }.bind(this)
    });
  },
  onReject: function(e) {
    poll_id = parseInt($(e.target).attr('value'));
    $.ajax({
      url: "/dashboard/api/teacherspet/polls/" + poll_id + "/rejected/",
      dataType: 'json',
      type : "POST",
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      data: {},
      success: function(data) {
        var polls = this.state.polls
        for(var i = 0; i < polls.length; i++) {
          if(polls[i].id == poll_id) {
            polls[i].rejected = true
            if (polls[i].verified = true) {
              polls[i].verified = false;
            }
          }
        }
        this.setState({ polls: polls })
      }.bind(this),
      error: function(xhr, status, err) {
        console.error(xhr.responseText)
      }.bind(this)
    });
  },
  refreshPolls: function() {
    this.loadPolls();
  },
  render: function() {
    var polls = this.state.polls.map(function(poll) {
      return (
        <Poll onAccept={this.onAccept} onReject={this.onReject} poll={poll} />
      );
    }.bind(this));
    return (
      <div className="col-md-5 col-md-offset-1">
        <div className="posts-container">
          <label className="list-label">Polls</label>
          <span className="list-option" onClick={this.refreshPolls}>REFRESH</span>
          <div className="posts-list">
            {polls}
          </div>
        </div>
      </div>
    );
  }
});

$(document).ready(function() {
  ReactDOM.render(
    <div className="row">
      <PollList/>
      <CommentList/>
    </div>, $(".container-fluid")[0]
  );
});