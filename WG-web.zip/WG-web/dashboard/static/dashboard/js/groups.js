var Modal = ReactBootstrap.Modal;
var Button = ReactBootstrap.Button;

var GroupEditModal = React.createClass({
  getInitialState: function() {
    return {
      group: {name: '', universities: []},
    };
  },

  componentDidMount: function() {
    this.setState({
      group: this.props.group,
    });
  },

  componentWillReceiveProps: function(nextProps) {
    this.setState({
      group: nextProps.group
    });
  },

  setName: function(e) {
    var editingGroup = $.extend(true, {}, this.state.group);
    editingGroup.title = e.target.value;
    this.setState({group: editingGroup});
  },

  toggleUniversity: function(university) {
    var selected = false;
    var editingGroup = $.extend(true, {}, this.state.group);
    var selectedUniversities = editingGroup.universities;

    for (var i=0; i < selectedUniversities.length; i++) {
      var selectedUniversity = selectedUniversities[i];
      if (selectedUniversity == university.id) {
        selected = true;
        selectedUniversities.splice(i, 1);
        break;
      }
    }

    if (!selected) {
      selectedUniversities.push(university.id);
    }

    editingGroup.universities = selectedUniversities;
    this.setState({group: editingGroup});
  },

  getSelectedUniversities: function() {
    var selectedUniversities = [];
    if (this.state.group) {
      selectedUniversities = this.state.group.universities;
    }
    return selectedUniversities;
  },

  renderUniversityList: function() {
    var selectedUniversities = this.getSelectedUniversities();
    return (
      <table className="universityList table table-bordered table-hover table-condensed">
        {this.props.universities.map(function(university) {
          var selected = false;
          for (var i=0; i < selectedUniversities.length; i++) {
            var selectedUniversity = selectedUniversities[i];
            if (selectedUniversity == university.id) {
              selected = true;
              break;
            }
          }

          var selectUniversity = function() {
            this.toggleUniversity(university);
          }.bind(this);

          var rowClass;
          if (selected) {
            rowClass = 'info';
          }

          return (
            <tr key={university.id} onClick={selectUniversity} className={rowClass}>
              <td>
                {university.name}
              </td>
              <td>
                <input type="checkbox" checked={selected} onChange={selectUniversity} />
              </td>
            </tr>
          );
        }.bind(this))}
      </table>
    );
  },

  renderHeader: function() {
    return (
      <Modal.Header closeButton>
        <Modal.Title>
          Edit Group
        </Modal.Title>
      </Modal.Header>
    );
  },

  renderFooter: function() {
    var selectedUniversities = this.getSelectedUniversities();
    var name;
    if (this.state.group) {
      name = this.state.group.title;
    }
    
    var canSave = (!((name === '') || (selectedUniversities.length === 0)));

    var save = function() {
      this.props.save(this.state.group);
    }.bind(this);

    var deleteAction = function() {
      this.props.delete(this.state.group);
    }.bind(this);
    return (
      <Modal.Footer>
        <Button onClick={this.props.cancel}>Cancel</Button>
        <Button onClick={deleteAction}>Delete</Button>
        <Button onClick={save} disabled={!canSave}>Save</Button>
      </Modal.Footer>
    );
  },

  renderBody: function() {
    var name;
    if (this.state.group) {
      name = this.state.group.title;
    }

    return (
      <Modal.Body>
        <div className="row">
          <div className="col-xs-6">
            <label htmlFor="editGroupName">Name</label>
            <input type="text" className="form-control" id="editGroupName" value={name} onChange={this.setName} />
          </div>
          <div className="col-xs-6">
            <label>Universities</label>
            {this.renderUniversityList()}
          </div>
        </div>
      </Modal.Body>
    );
  },

  render: function() {
    return (
      <Modal
        show={this.props.open}
        onHide={this.props.close}>
        {this.renderHeader()}
        {this.renderBody()}
        {this.renderFooter()}
      </Modal>
    );
  }
});

var GroupAddModal = React.createClass({
  renderUniversity: function(university) {
    var selected = false;
    for (var i=0; i < this.props.selectedUniversities.length; i++) {
      var selectedUniversity = this.props.selectedUniversities[i];
      if (selectedUniversity.id == university.id) {
        selected = true;
        break;
      }
    }

    var selectUniversity = function() {
      this.props.toggleUniversity(university);
    }.bind(this);

    var rowClass;
    if (selected) {
      rowClass = 'info';
    }

    return (
      <tr key={university.id} onClick={selectUniversity} className={rowClass}>
        <td>
          {university.name}
        </td>
        <td>
          <input type="checkbox" checked={selected} onChange={selectUniversity} />
        </td>
      </tr>
    );
  },

  renderHeader: function() {
    return (
      <Modal.Header closeButton>
        <Modal.Title>
          Add Group
        </Modal.Title>
      </Modal.Header>
    );
  },

  renderFooter: function() {
    var canSubmit = (!((this.props.name === '') || (this.props.selectedUniversities.length === 0)));
    return (
      <Modal.Footer>
        <Button onClick={this.props.cancelAdding}>Cancel</Button>
        <Button onClick={this.props.submit} disabled={!canSubmit}>Submit</Button>
      </Modal.Footer>
    );
  },

  renderBody: function() {
    var universityList = (
      <table className="universityList table table-bordered table-hover table-condensed">
        <tbody>
        {this.props.universities.map(function(university) {
          return this.renderUniversity(university);
        }.bind(this))}
        </tbody>
      </table>
    );

    return (
      <Modal.Body>
        <div className="row">
          <div className="col-xs-6">
            <label htmlFor="name">Name</label>
            <input type="text" className="form-control" id="name" defaultValue={this.props.name} onChange={this.props.setName} />
          </div>
          <div className="col-xs-6">
            <label>Universities</label>
            {universityList}
          </div>
        </div>
      </Modal.Body>
    );
  },

  render: function() {
    return (
      <div>
        <Button
          bsStyle="primary"
          bsSize="large"
          onClick={this.props.startAdding}
          disabled={this.props.universities.length === 0}
        >
          Add Group
        </Button>

        <Modal
          show={this.props.open}
          onHide={this.props.cancelAdding}
        >
          {this.renderHeader()}
          {this.renderBody()}
          {this.renderFooter()}
        </Modal>
      </div>
    );
  },
});

var GroupDashboard = React.createClass({
  getInitialState: function() {
    return {
      universities: [],
      selectedUniversities: [],
      groups: [],
      currentlyAddingGroup: false,
      currentlyEditingGroup: false
    };
  },

  componentDidMount: function() {
    this.fetchUniversities();
    this.fetchGroups();
  },

  fetchUniversities: function() {
    $.ajax({
      url: this.props.universitiesUrl,
      dataType: 'json',
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      type: 'GET',
      contentType: 'application/json',
      success: function(data) {
        this.setState({
          universities: data
        });
      }.bind(this),
      error: function(xhr, status, err) {
        console.error('xhr', xhr);
        console.error('status', status);
        console.error('err', err);
      }.bind(this)
    });
  },

  fetchGroups: function() {
    $.ajax({
      url: this.props.groupsUrl,
      dataType: 'json',
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      type: 'GET',
      contentType: 'application/json',
      success: function(data) {
        this.setState({
          groups: data
        });
      }.bind(this),
      error: function(xhr, status, err) {
        console.error('xhr', xhr);
        console.error('status', status);
        console.error('err', err);
      }.bind(this)
    });
  },

  toggleUniversity: function(university) {
    var selected = false;
    var selectedUniversities = this.state.selectedUniversities;

    for (var i=0; i < selectedUniversities.length; i++) {
      var selectedUniversity = selectedUniversities[i];
      if (selectedUniversity.id == university.id) {
        selected = true;
        selectedUniversities.splice(i, 1);
        break;
      }
    }

    if (!selected) {
      selectedUniversities.push(university);
    }

    this.setState({selectedUniversities: selectedUniversities});
  },

  setName: function(e) {
    this.setState({name: e.target.value});
  },

  editGroup: function(group) {
    var editingGroup = $.extend(true, {}, group);
    this.setState({
      editingGroup: editingGroup,
      currentlyEditingGroup: true,
    });
  },

  saveGroup: function(group) {
    $.ajax({
      url: '/dashboard/api/groups/update/' + group.id + '/',
      dataType: 'json',
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      type: 'PUT',
      data: JSON.stringify({title: group.title, universities: group.universities}),
      contentType: 'application/json',
      success: function(data) {
        this.fetchGroups();
        this.setState({currentlyEditingGroup: false});
      }.bind(this),
      error: function(xhr, status, err) {
        console.error('xhr', xhr);
        console.error('status', status);
        console.error('err', err);
      }.bind(this)
    });
  },

  deleteGroup: function(group) {
    $.ajax({
      url: '/dashboard/api/groups/delete/' + group.id + '/',
      dataType: 'json',
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      type: 'DELETE',
      data: JSON.stringify({title: group.title, universities: group.universities}),
      contentType: 'application/json',
      success: function(data) {
        this.fetchGroups();
        this.setState({currentlyEditingGroup: false});
      }.bind(this),
      error: function(xhr, status, err) {
        console.error('xhr', xhr);
        console.error('status', status);
        console.error('err', err);
      }.bind(this)
    });
  },

  cancelEditingGroup: function() {
    this.setState({
      editingGroup: null,
      currentlyEditingGroup: false
    });
  },

  submit: function() {
    var selectedUniversityIds = this.state.selectedUniversities.map(function(university) {
      return university.id;
    });

    $.ajax({
      url: this.props.createGroupUrl,
      dataType: 'json',
      headers: {
        'X-CSRFToken': WG.utils.getCookie('csrftoken')
      },
      type: 'POST',
      data: JSON.stringify({name: this.state.name, universities: selectedUniversityIds}),
      contentType: 'application/json',
      success: function(data) {
        this.fetchGroups();
        this.setState({
          currentlyAddingGroup: false,
          name: '',
          selectedUniversities: []
        });
      }.bind(this),
      error: function(xhr, status, err) {
        console.error('xhr', xhr);
        console.error('status', status);
        console.error('err', err);
      }.bind(this)
    });
  },

  startAdding: function() {
    this.setState({currentlyAddingGroup: true});
  },

  cancelAdding: function() {
    this.setState({currentlyAddingGroup: false});
  },

  renderGroups: function() {
    var universities = this.state.universities;
    return (
      <table className="table table-striped table-bordered">
        <thead>
          <tr><th>Group Name</th><th>Universities</th><th></th></tr>
        </thead>
        <tbody>
          {this.state.groups.map(function(group) {
            var edit = function() {
              this.editGroup(group);
            }.bind(this);
            return (
              <tr key={group.id}>
                <td>{group.title}</td>
                <td>
                  <ul>
                  {group.universities.map(function(university_id) {
                    for (var i=0; i < universities.length; i++) {
                      var university = universities[i];
                      if (university.id === university_id) {
                        return (
                          <li key={university.id}>{university.name}</li>
                        );
                      }
                    }
                    return (
                      <li key={university_id}>{university_id}</li>
                    );
                  })}
                  </ul>
                </td>
                <td>
                  <a href="#" onClick={edit}>Edit</a>
                </td>
              </tr>
            );
          }.bind(this))}
        </tbody>
      </table>
    );
  },

  render: function() {
    var addGroup = (
      <GroupAddModal
        open={this.state.currentlyAddingGroup}
        startAdding={this.startAdding}
        cancelAdding={this.cancelAdding}
        universities={this.state.universities}
        selectedUniversities={this.state.selectedUniversities}
        name={this.state.name}
        setName={this.setName}
        toggleUniversity={this.toggleUniversity}
        submit={this.submit} />
    );
    var editGroup = (
      <GroupEditModal
        universities={this.state.universities}
        group={this.state.editingGroup}
        delete={this.deleteGroup}
        open={this.state.currentlyEditingGroup}
        save={this.saveGroup}
        cancel={this.cancelEditingGroup} />
    );

    return (
      <div className="row">
        <div className="col-xs-6">
          {addGroup}
          {editGroup}
          <br />
          {this.renderGroups()}
        </div>
      </div>
    );
  }
});

$(document).ready(function() {
  ReactDOM.render(
    <GroupDashboard
      universitiesUrl="/dashboard/api/universities/"
      groupsUrl="/dashboard/api/groups/"
      createGroupUrl="/dashboard/api/groups/create/" />,
    $("#parent")[0]
  );
});
