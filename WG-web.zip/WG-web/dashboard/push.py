from django.contrib.gis.measure import D
from django.db.models import Q
from api.utils import KM_DISTANCE_FILTER
from api.notifications import send_push_notification
from datetime import date, timedelta
import itertools
# DO NOT IMPORT SPECIFIC whatsgoodly.models HERE, circular
import whatsgoodly.models

class CustomPush:
  BATCH_SIZE = 1000

  def __init__(self, notification_title=None, notification_copy=None,
      poll_id=None, poll_instance_id=None, user_ids=[],
      user_filter=None, include_nearby=False,
      include_nearby_timeframe=None, university_ids=[],
      notification_type=0):

    self.notification_title = notification_title
    self.notification_copy = notification_copy
    self.poll_id = poll_id
    self.poll_instance_id = poll_instance_id
    self.user_ids = user_ids
    self.user_filter = user_filter
    self.include_nearby = include_nearby
    self.include_nearby_timeframe = include_nearby_timeframe
    self.university_ids = university_ids
    self.notification_type = notification_type

  def send(self):
    if self.poll_id:
      poll = whatsgoodly.models.Poll.objects.get(pk=self.poll_id)
      self._send_poll(poll)
    elif self.poll_instance_id:
      poll_instance = whatsgoodly.models.PollInstance.objects.get(pk=self.poll_instance_id)
      self._send_poll_instance(poll_instance)
    else:
      self._send_plain_notification()

  def recipient_queryset(self):
    User = whatsgoodly.models.User

    if self.include_nearby:
      timeframe = date.today() - timedelta(weeks=self.include_nearby_timeframe)
      nearby_user_ids = self._nearby_user_ids(timeframe=timeframe, university_ids=self.university_ids)
    else:
      nearby_user_ids = []

    user_filter = self._make_queryset_filters(user_filter=self.user_filter)

    if self.user_ids:
      queryset = User.objects.filter(Q(**user_filter)).filter(
          Q(pk__in=self.user_ids) | Q(pk__in=nearby_user_ids)
        )

    elif self.university_ids:
      required = Q(**user_filter)
      nearby = Q(pk__in=nearby_user_ids)
      uni_connected=Q(university_id__in=self.university_ids)
      queryset = User.objects.filter(required).filter(nearby | uni_connected)
    
    else:
      queryset = User.objects.filter(**user_filter)

    return queryset.only('id').filter(is_active=True)

  def _send_plain_notification(self):
    notifications = [
      self._build_notification_for_user(user_id=user_id)
      for user_id in self.recipient_queryset().values_list('id', flat=True)
    ]
    self._create_and_send_notifications(notifications)

  def _send_poll_instance(self, poll_instance):    
    notifications = [
      self._build_notification_for_user(
          user_id=user_id, options={"poll_instance": poll_instance}
        )
      for user_id in self.recipient_queryset().values_list('id', flat=True)
    ]
    self._create_and_send_notifications(notifications)

  def _send_poll(self, poll):
    """
    Send a local notification; this does not support the 'nearby user' filter.
    Given a poll ID, find the poll instances for the selected universities.
    """
    university_ids = self.university_ids
    universities = whatsgoodly.models.University.objects.filter(pk__in=university_ids)

    for university in universities:
      poll_instance = whatsgoodly.models.PollInstance.objects.get(
          poll=poll, location=university.location)

      self._send_poll_instance(poll_instance)

  def _build_notification_for_user(self, user_id, options={}):
    options["user_id"] = user_id
    options["title"] = self.notification_title
    options["body"] = self.notification_copy
    options["notification_type"] = self.notification_type
    return whatsgoodly.models.Notification(**options)

  def _create_and_send_notifications(self, notifications):
    whatsgoodly.models.Notification.objects.bulk_create(notifications, self.BATCH_SIZE)
    for notification in notifications:
      send_push_notification(notification)

  def _nearby_user_ids(self, timeframe, university_ids):
    locations = whatsgoodly.models.University.objects\
      .filter(pk__in=self.university_ids)\
      .values_list('location', flat=True)
    location_filter = Q()
    for location in locations:
      location_filter = location_filter | Q(location__distance_lte=(location, D(km=KM_DISTANCE_FILTER * 2)))

    return whatsgoodly.models.Response.objects.filter(
        created_date__gte=timeframe
      ).filter(location_filter)\
        .values_list('user_id', flat=True)

  def _make_queryset_filters(self, user_filter=''):
    filters = {}
    if user_filter == 'male':
      filters["gender"] = 0
    elif user_filter == 'female':
      filters["gender"] = 1
    elif user_filter == 'university-registered':
      filters["verified_university"] = True
    return filters
