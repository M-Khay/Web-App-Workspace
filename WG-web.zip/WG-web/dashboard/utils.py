from django.contrib.gis.measure import D
from django.utils.timezone import make_aware
from api.utils import KM_DISTANCE_FILTER
import datetime
import json
import whatsgoodly.models

def calc_monitoring_tier(poll_instance):
    PollInstance = whatsgoodly.models.PollInstance

    recent_nearby_polls = PollInstance.objects.filter(location__distance_lte=(poll_instance.location, 
        D(km=KM_DISTANCE_FILTER)), created_date__gte=make_aware(datetime.datetime.now()) - datetime.timedelta(days=1))
    total_votes = 0
    for p in recent_nearby_polls:
        total_votes += p.get_vote_total()
        votes_per_poll = float(total_votes / float(recent_nearby_polls.count()))

    # TODO: Come up with final thresholds
    if votes_per_poll <= 50:
        return 0
    elif votes_per_poll <= 125:
        return 1
    return 2
