from api.serializers import OptionsField, VoteCountsField, KnownUserSerializer, UniversitySerializer, PollBreakdownSerializer
from whatsgoodly.serializers import PollBreakdownExportSerializer, PollSerializer
from rest_framework import serializers
from whatsgoodly.models import *
import json


class CommentSerializer(serializers.ModelSerializer):
  report_count = serializers.SerializerMethodField()

  def get_report_count(self, comment):
    return Report.objects.filter(comment=comment).count()

  class Meta:
    model = Comment
    fields = ( 'id', 'text', 'user', 'vote_aggregate', 'deleted', 'report_count', )

class FeedSerializer(serializers.ModelSerializer):
  level_display = serializers.CharField(source='get_level_display')

  class Meta:
    model = Feed
    fields = ( 'id', 'name', 'active', 'level_display', 'image_source', 'category')

class PollInstanceSerializer(serializers.ModelSerializer):
  feed = serializers.PrimaryKeyRelatedField(queryset=Feed.objects.all(), required=True)
  question = serializers.CharField(source='get_question')
  picture_question = serializers.CharField(source='get_question_picture_url')
  options = OptionsField(source='get_options') 
  option_counts = VoteCountsField(source='vote_counts')
  gender = serializers.IntegerField(source='get_gender')
  location = serializers.SerializerMethodField()
  auto_censored = serializers.BooleanField(source='get_auto_censored')
  censor_level = serializers.IntegerField(source='poll.censor_level')
  report_count = serializers.SerializerMethodField()
  recycled = serializers.SerializerMethodField()
  deleted = serializers.BooleanField(source='get_deleted')
  parent_poll_id = serializers.SerializerMethodField()
  poll_tags = serializers.SerializerMethodField()

  def get_report_count(self, poll_instance):
    if hasattr(poll_instance, 'reports'):
      return len(poll_instance.reports)
    return 0

  def get_location(self, poll):
    try:
      return {
        'lng': poll.location[0],
        'lat': poll.location[1]
      }
    except TypeError:
      return None

  def get_recycled(self, poll_instance):
    return poll_instance.user_id != poll_instance.poll.user_id

  def get_parent_poll_id(self, poll_instance):
    return poll_instance.poll.id

  def get_poll_tags(self, poll_instance):
    if hasattr(poll_instance, 'poll_tags'):
      tags = poll_instance.poll_tags
    else:
      tags = poll_instance.poll.tags.all()
    return PollTagSerializer(tags, many=True).data 

  class Meta:
    model = PollInstance
    fields = ( 'id', 'question', 'options', 'option_counts', 'gender', 'picture_question',
            'location', 'user', 'auto_censored', 'deleted', 'deleted_by_admin', 'verified', 'feed',
            'comment_count', 'favorite_count', 'report_count',
            'banner', 'created_date', 'recycled', 'tag_count', 'censor_level',
            'rejected', 'parent_poll_id', 'vote_aggregate', 'auto_verified',
            'poll_tags')

class PollInstanceSimpleSerializer(serializers.ModelSerializer):
  question = serializers.CharField(source='get_question')
  options = OptionsField(source='get_options') 
  gender = serializers.IntegerField(source='get_gender')

  class Meta:
    model = PollInstance
    fields = ( 'id', 'question', 'options', 'gender',
            'user', 'deleted', 'verified', 'feed',
            'banner', 'created_date',
            'vote_aggregate')

class PollTagSerializer(serializers.ModelSerializer):
  category = serializers.CharField(source='get_category')

  class Meta:
    model = PollTag
    fields = ( 'id', 'label_lower', 'category', )

class UserSerializer(KnownUserSerializer):
  class Meta(KnownUserSerializer.Meta):
    pass

class ResponseSerializer(serializers.ModelSerializer):
  poll = PollInstanceSimpleSerializer(source='poll_instance')
  feed = serializers.SerializerMethodField()
  rating = serializers.SerializerMethodField()

  def get_feed(self, response):
    return FeedSerializer(response.poll_instance.feed).data

  def get_rating(self, response):
    favs_cache = self.context.get('favs')
    removals_cache = self.context.get('removals')
    if favs_cache is not None:
      has_fav = [fav for fav in favs_cache
                  if fav.poll_instance_id == response.poll_instance_id]
      if has_fav:
        return 1
    if removals_cache is not None:
      has_removal = [removal for removal in removals_cache
                  if removal.poll_instance_id == response.poll_instance_id]
      if has_removal:
        return 0

  class Meta:
    model = Response
    fields = ('id', 'poll', 'user', 'response', 'feed', 'rating',
      'created_date' )

class UniversityGroupSerializer(serializers.ModelSerializer):
  class Meta:
    model = Group
    fields = ( 'id', 'title', 'universities' )

class UniversitySerializer(serializers.ModelSerializer):
  longitude = serializers.FloatField(required=True, source='get_longitude')
  latitude = serializers.FloatField(required=True, source='get_latitude')
  fraternities = OptionsField(required=False) 
  sororities = OptionsField(required=False) 

  def get_longitude(self, university):
    return university.location.x

  def get_latitude(self, university):
    return university.location.y

  class Meta:
    model = University
    fields = ( 'id', 'name', 'name_short', 'email_domain', 'longitude',
      'latitude', 'radius', 'fraternities', 'sororities', )
