from django.contrib.gis.db import models


class District(models.Model):
    """
    Model that describes a district for the dashboard. A distrcit is a point of
    interest, and provides the center location.
    """
    name = models.CharField(max_length=30)
    location = models.PointField()

    created_date = models.DateTimeField(auto_now_add=True)
    modified_date = models.DateTimeField(auto_now=True)

    def __unicode__(self):
        """
        Human readable encoding of the object
        """
        return self.name
