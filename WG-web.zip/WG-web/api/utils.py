# -*- coding: utf-8 -*-

from django.contrib.gis import geos
from django.contrib.auth import login
from api.censor_list import delete_list, flag_list, name_whitelist
from django.core.mail import EmailMultiAlternatives, send_mail
from math import acos, cos, degrees, radians, sin
from rest_framework import response
import re
import grequests
import json
import nltk
import wikipedia
import string
from django.conf import settings
from datetime import datetime
# DO NOT IMPORT SPECIFIC whatsgoodly.models HERE
# import whatsgoodly.models

KM_DISTANCE_FILTER = 9
FEED_KM_DISTANCE_FILTER = 100*KM_DISTANCE_FILTER

WG_APP_AUTH_HEADER = "Q~cZL>%&A3RZZz?eA?{zuReRv"
WG_WEB_AUTH_HEADER = "I3m,]uUd&9d)@nmsdox4$5|fc"
SLACK_WEBHOOK_URL = "https://hooks.slack.com/services/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"

# TODO: teleport banned users to Lake Shastaaaaa?
# EXILED_USER_LAT_LON = 40.7641951, -122.3825363

WEB_USER_SESSION_EXP = 60*60*24*365*20 # 20 years

class CENSOR_LEVELS:
  NONE, DELETE, LANG_FLAG, NAME_FLAG = range(4)
  ALLOWED = (NONE, LANG_FLAG)
  CHOICES = (
    (NONE, 'None'),
    (DELETE, 'Auto-Deleted'),
    (LANG_FLAG, 'Language'),
    (NAME_FLAG, 'Names'),
  )

# View helpers
################

# Sends a poll back saying update required
def update_required(request):
  from whatsgoodly.models import Feed, Poll, PollInstance
  from api.serializers import PollInstanceSerializer

  context = { 'request' : request }
  user = request.user

  opts = [
    'To view this feed, you need a newer version',
    '📲 Go to the App Store to update it'
  ]
  counts = [0, 0]
  feed = Feed.objects.get(category=Feed.LOCAL)
  poll = Poll(
    question="Update Whatsgoodly!",
    options=json.dumps(opts)
  )
  poll_instance = PollInstance(
    poll=poll, user_id=4110,
    feed=feed, vote_counts=json.dumps(counts)
  )

  poll_data = PollInstanceSerializer([poll_instance], many=True, context=context).data
  return response.Response(poll_data, status=200)


# Network helpers
#################

def send_slack_message(message, user=None, event_name=None, emoji=None, channel=None):
  if settings.DEBUG:
    # Disable sending on dev server
    print u"DEBUG on, not sending \"{}\"".format(message)
    return

  if user:
    if user.is_staff:
      print "STAFF user, not sending \"{0}\"".format(message)
      return
    message = u"{} {}".format(user, message)
    
  # Linkify occurrences of "User 2131221"
  message = re.sub(r"\b(User ([0-9]+))\b",
    r"<https://whatsgoodly.com/dashboard/profiles/\2/|\1>",
    message)
  username = "{0}WG API{1}".format(
    "(DEV SERVER) " if settings.DEBUG else "",
    ": " + event_name if event_name else "")
  data = {
    "icon_emoji": emoji if emoji else ":dog:",
    "text": message,
    "username": username
  }
  if channel:
    data["channel"] = channel
    
  req = [grequests.post(
          url=SLACK_WEBHOOK_URL,
          data=json.dumps(data),
          headers={"Content-type": "application/json"},
          verify=True)]
  grequests.map(req)

def send_smyte_message(data, event_name, request):
  regex = re.compile('^HTTP_')
  headers = dict((regex.sub('', header), value)
      for (header, value) in request.META.items()
      if header.startswith('HTTP_'))
  request_payload = {
    'name': event_name,
    'timestamp': str(datetime.now()),
    'data': data,
    'http_request': {
      'headers': headers
    }
  }
  req = [grequests.post(
    url='https://api.smyte.com/v2/action',
    auth=(settings.SMYTE_API_KEY, settings.SMYTE_SECRET_KEY),
    json=request_payload,
    headers={"Content-type": "application/json"},
    verify=True
  )]
  grequests.map(req)

def login_web_user(request, user):
  """
  Save user in session for web poll bootstrapping
  """
  request.session.set_expiry(WEB_USER_SESSION_EXP)
  # See http://stackoverflow.com/questions/2787650/manually-logging-in-a-user-without-password
  user.backend = 'django.contrib.auth.backends.ModelBackend'
  login(request, user)

def get_ip_address(request):
  """
  Returns the IP address from a request object. The HTTP_X_REAL_IP is forwarded
  by the nginx server to the gunicorn app. REMOTE_ADDR doesn't necessarily
  work, because technically that is localhost.
  """
  ip_addr = request.META.get('HTTP_X_REAL_IP', None)
  if not ip_addr:
    ip_addr = request.META.get('REMOTE_ADDR', None)
  return ip_addr

def is_app_session(request):
  auth_token = request.META.get('HTTP_WG_AUTH')
  return auth_token == WG_APP_AUTH_HEADER

def is_web_session(request):
  auth_token = request.META.get('HTTP_WG_AUTH')
  return auth_token == WG_WEB_AUTH_HEADER

def is_android(request):
  return " Android " in request.META.get('HTTP_USER_AGENT', '')

def is_ios(request):
  return " iOS " in request.META.get('HTTP_USER_AGENT', '')

def is_v3(request):
  # Only works on iOS
  return "WhatsGoodly/3." in request.META.get('HTTP_USER_AGENT', "")

def send_delete_poll_email(poll_id, source):
  msg = EmailMultiAlternatives(
    subject="Poll deleted by %s" % source,
    body="%s" % poll_id,
    from_email="noreply@whatsgoodly.com",
    to=["alex@whatsgoodly.com"]
  )
  msg.async = True
  msg.send()

def send_email_verification(token, email):
  """
  Helper function that sends verification email
  """
  msg = EmailMultiAlternatives(
    subject="Whatsgoodly Email Verification",
    body="Whatsgoodly Verification Code: %s" % token,
    from_email="noreply@whatsgoodly.com",
    to=[email]
  )
  msg.async = True
  msg.send()

def calc_dist(lat_a, long_a, lat_b, long_b):
  """
  Helper function that calculates geographic distance between two lat/lons in km
  """
  lat_a = radians(lat_a)
  lat_b = radians(lat_b)
  long_diff = radians(long_a - long_b)
  distance = (sin(lat_a) * sin(lat_b) + cos(lat_a) * cos(lat_b) * cos(long_diff))
  resToMile = degrees(acos(distance)) * 69.09
  resToMt = resToMile / 0.00062137119223733
  return resToMt/1000

def percent_change(new_val, base):
  decimal = (new_val - base) * 100.0 / (base or 1)
  return int(round(decimal))

def in_email_domain(email, uni_domain):
  """
  Helper function that validates email domain
  """
  regex = r'[.@]\s*'
  email_split = re.split(regex, email)
  domain_split = re.split(regex, uni_domain)
  return (domain_split[-2] == email_split[-2]) and (domain_split[-1] == email_split[-1])

def check_censored(serializer):
  """
  Helper function that checks for censored words. Returns 1 if object gets auto-deleted by the
  function, 2 if the object gets auto-flagged by the function, and 0 otherwise.
  """
  data = serializer.validated_data
  serializer_type = serializer.__class__.__name__
  text = ''
  words = []
  if serializer_type == 'PollInstanceCreateSerializer':
    text = data['poll']['question'].lower() + ' ' + data['poll']['options'].lower()
    text = "".join(c for c in text if c not in string.punctuation)
    words = text.split()
    opts = json.loads(data['poll']['options'])
    nlp_text = u"{} Is it '{}'".format(data['poll']['question'], "', '".join(opts)) 
  elif serializer_type == 'CommentCreateSerializer':
    text = data['text'].lower()
    text = "".join(c for c in text if c not in string.punctuation)
    words = text.split()
    nlp_text = data['text']

  count = 0

  # Check for any auto-delete words
  for d in delete_list:
    needle = d.lower()
    haystack = text if " " in needle else words
    if needle in haystack:
      count += text.count(needle)
      return (CENSOR_LEVELS.DELETE, count)

  # Check for names not in Wikipedia
  for sent in nltk.sent_tokenize(nlp_text):
    for chunk in nltk.ne_chunk(nltk.pos_tag(nltk.word_tokenize(sent))):
      if hasattr(chunk, 'label') and chunk.label() == 'PERSON':
        # Note: this ^ is a greedy algo, tons of false positives
        name = " ".join([word for word, pos in chunk.leaves()])
        # TODO better whitelist:
        # name = name.lower()
        # whitelist_hit = False
        # for w in name_whitelist:
        #   if w.lower() in name:
        #     whitelist_hit = True
        #     break
        # if not whitelist_hit:
        try:
          wikipedia.page(name, auto_suggest=False)
        except wikipedia.exceptions.WikipediaException:
          count += nlp_text.count(name)
          return (CENSOR_LEVELS.NAME_FLAG, count)
        except:
          # Could be ConnectionError, ValueError...
          from raven import Client
          client = Client(settings.RAVEN_CONFIG['dsn'])
          client.captureException()

  # Check for any flagged words
  for f in flag_list:
    needle = f.lower()
    haystack = text if " " in needle else words
    if needle in haystack:
      count += text.count(needle)
      
  if count > 0:
    return (CENSOR_LEVELS.LANG_FLAG, count)

  return (CENSOR_LEVELS.NONE, count)

def truncate_text(text, length=40):
  if len(text) > length:
    return u"{0}...".format( text[:length].strip() )
  return text

def convert_to_point(latitude, longitude):
  latitude = float(latitude)
  longitude = float(longitude)
  return geos.fromstr('POINT(%s %s)' % (str(longitude), str(latitude)))

def poll_page_sort(user):
  ALL_GENDERS = 2
  UNDEFINED_GENDER = -1
  
  def sort(poll_data):
    qualifies = poll_data['gender'] == ALL_GENDERS \
             or poll_data['gender'] == user.gender \
             or user.gender == UNDEFINED_GENDER
    can_vote = not poll_data['response'] and qualifies
    owns_poll = poll_data['user']['id'] == user.id
    # favorited = bool(poll_data['favorite'])

    if can_vote or owns_poll:
      return 0
    else:
      return 1

  return sort

def unique(seq, key='id'):
  seen = set()
  seen_add = seen.add
  return [x for x in seq if not (x[key] in seen or seen_add(x[key]))]
