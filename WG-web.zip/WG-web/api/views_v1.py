from api.throttles import *
from api.utils import *
from api import querysets
from django.core.mail import send_mail
from django.db.models import Prefetch
from django.http import Http404
from django.shortcuts import get_object_or_404, render
from django.utils.crypto import get_random_string
from rest_framework import generics, permissions, response, throttling, views
from rest_framework.decorators import api_view, permission_classes, throttle_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from serializers import *
from whatsgoodly.models import *
import re

POLL_FEED_ORDER = querysets.POLL_FEED_ORDER

@api_view(['POST'])
@permission_classes((AllowAny, ))
@throttle_classes([UserAuthenticationThrottle])
def create_user(request):
  password = User.objects.make_random_password()
  ip_address = get_ip_address(request)
  serializer = UserCreateSerializer(data=request.data, context={'request': request})
  if serializer.is_valid(raise_exception=True):
    serializer.save(ip_address=ip_address, password=password)
    return response.Response(serializer.data, status=201)
  else:
    return response.Response(serializer.errors, status=400)


@api_view(['PATCH'])
@permission_classes((IsAuthenticated, ))
def update_user(request):
  user_serializer = UserUpdateSerializer(request.user, data=request.data, partial=True, context={'request': request})
  if user_serializer.is_valid(raise_exception=True):
    user = user_serializer.save()
    return response.Response(user_serializer.data, status=200)
  return response.Response(user_serializer.errors, status=403)


@api_view(['PATCH'])
@permission_classes((IsAuthenticated, ))
def update_user_university(request):
  context = { 'request' : request }
  email = request.data.get('email', None)
  lat = request.data.get('latitude', None)
  lon = request.data.get('longitude', None)
  verification_token = request.data.get('verification_token', None)
  if verification_token:
    if request.user.university is None:
      return response.Response("Bad request", status=400)
    request.data['university'] = request.user.university.id
  serializer = UserUniversityUpdateSerializer(data=request.data, context=context)
  if verification_token or (lat is not None and lon is not None):
    if serializer.is_valid(raise_exception=True):
      if lat and lon:
        request.user.university = serializer.validated_data['university']
      request.user.verified_university = True
      request.user.save()
      return response.Response(serializer.data, status=200)
    return response.Response(serializer.errors, status=403)
  elif email:
    if serializer.is_valid(raise_exception=True):
      token = get_random_string(length=4, allowed_chars="0123456789")
      request.user.verification_token = token
      request.user.university = serializer.validated_data['university']
      request.user.save()
      send_email_verification(token, email);
      return response.Response(serializer.data, status=200)
    return response.Response(serializer.errors, status=403)
  return response.Response("Bad request", status=400)


@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_user_profile(request):
  user = request.user
  context = { 'request': request }
  user.last_user_agent = request.META.get('HTTP_USER_AGENT')
  user.save(update_fields=["last_user_agent"])
  my_polls_queryset = querysets.poll_instances_queryset(user=user, order=POLL_FEED_ORDER.RECENT, feed_category=Feed.USER_POLLS, feed=None)
  my_polls_count = my_polls_queryset.count()
  my_polls = querysets.poll_instances_paginated_for_queryset(my_polls_queryset, 1)
  my_polls_serializer = PollInstanceSerializer(my_polls, many=True, context=context )
  my_commented_polls_queryset = querysets.poll_instances_queryset(user=user, order=POLL_FEED_ORDER.RECENT, feed_category=Feed.USER_COMMENTS, feed=None)
  my_commented_polls_count = my_commented_polls_queryset.count()
  my_commented_polls = querysets.poll_instances_paginated_for_queryset(my_commented_polls_queryset, 1)
  my_commented_polls_serializer = PollInstanceSerializer(my_commented_polls, many=True, context=context)
  user_info = UserSerializer(user, context=context).data.copy()
  user_info.update({'comment_count': my_commented_polls_count,
                    'poll_count': my_polls_count })

  response_dict = { 'user_polls': my_polls_serializer.data,
                    'user_comment_polls': my_commented_polls_serializer.data,
                    'user_info': user_info }
  return response.Response(response_dict, status=200)

@api_view(['GET', 'POST'])
@permission_classes((IsAuthenticated, ))
def get_or_post_polls(request, get_all_polls=False):
  if request.method == 'POST':
    user = request.user
    context = { 'request': request }
    data = request.data.copy()
    if data.get("feed", None) is None:
      data['feed'] = Feed.objects.get(category=Feed.LOCAL).id
    poll_instance_serializer = PollInstanceCreateSerializer(data=data, context=context)
    if poll_instance_serializer.is_valid(raise_exception=True):
      is_university_poll = data.get('is_university_poll', False) in (True, '1', 1, 'true', 'True')
      if is_university_poll:
        if not user.verified_university:
          return response.Response('Not authorized to post', status=403)
        location = user.university.location
        community = user.university
      else:
        community = None
        location = convert_to_point(data.get('latitude', None), data.get('longitude', None))
      poll_instance = poll_instance_serializer.save(user=user, ip_address=get_ip_address(request),
                                                    location=location, community=community)
      return response.Response(poll_instance_serializer.data, status=201)
    return response.Response(status=403)
  elif request.method == 'GET':
    params = request.query_params
    lat = params.get('latitude', None)
    lon = params.get('longitude', None)
    page = params.get('page', 1)

    if not get_all_polls:
      should_return_top = params.get('top', False) in (True, '1', 1, 'true', 'True')
      if should_return_top:
        order = POLL_FEED_ORDER.TOP
      else:
        order = POLL_FEED_ORDER.RECENT
    else:
      order = None

    poll_filter = params.get('filter', None)
    feed_category = None
    if poll_filter == None:
      feed_category = Feed.LOCAL
    elif poll_filter == 'universal' or poll_filter == 'featured':
      feed_category = Feed.GLOBAL
    elif poll_filter == 'favorites':
      feed_category = Feed.USER_FAVORITES
    elif poll_filter == 'comments':
      feed_category = Feed.USER_COMMENTS
    elif poll_filter == 'recent':
      feed_category = Feed.USER_POLLS
    elif poll_filter == 'university' and request.user.verified_university:
      feed_category = Feed.LOCAL
      lat = request.user.university.get_latitude()
      lon = request.user.university.get_longitude()

    page = int(page)
    context = { 'request': request }
    if feed_category == Feed.GLOBAL:
      feed = Feed.objects.get(category=Feed.GLOBAL)
      queryset = querysets.poll_instances_paginated(page=page, user=request.user, order=POLL_FEED_ORDER.RECENT,
        feed=feed, feed_category=Feed.GLOBAL, lat=lat, lon=lon)
      serializer = PollInstanceSerializer(queryset, many=True, context=context)
      return response.Response(serializer.data, status=200)
    elif order is None: # load first page of top and recent if no order specified
      feed = Feed.objects.get(category=Feed.LOCAL)
      recent_polls = querysets.poll_instances_paginated(page=1, user=request.user, order=POLL_FEED_ORDER.RECENT,
        feed=feed, feed_category=Feed.LOCAL, lat=lat, lon=lon)
      top_polls = querysets.poll_instances_paginated(page=1, user=request.user, order=POLL_FEED_ORDER.TOP,
        feed=feed, feed_category=Feed.LOCAL, lat=lat, lon=lon)
      recent_serializer = PollInstanceSerializer(recent_polls, many=True, context=context)
      top_serializer = PollInstanceSerializer(top_polls, many=True, context=context)
      response_dict = { 'recent_polls': recent_serializer.data, 'top_polls': top_serializer.data }
      return response.Response(response_dict, status=200)
    else: # load a page of a specific feed of a specific order
      feed = Feed.objects.get(category=Feed.LOCAL)
      queryset = querysets.poll_instances_paginated(page=page, user=request.user, order=order,
        feed=feed, feed_category=Feed.LOCAL, lat=lat, lon=lon)
      serializer = PollInstanceSerializer(queryset, many=True, context=context)
      return response.Response(serializer.data, status=200)


@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_poll(request, pk):
  context = { 'request': request }
  poll_instance = querysets.poll_instance_prefetch(pk=pk, user=request.user)
  if poll_instance.count() == 0:
    raise Http404('Poll not found')
  serializer = PollInstanceSerializer(poll_instance[0], context=context)
  return response.Response(serializer.data, status=200)


@api_view(['POST' ,'DELETE'])
@permission_classes((IsAuthenticated, ))
def delete_poll(request, pk):
  user = request.user
  context = { 'request': request }
  poll_instance = get_object_or_404(PollInstance, pk=pk)
  if user != poll_instance.user:
    return response.Response("Not authorized to delete poll", status=401)
  if poll_instance.get_deleted():
    return response.Response("Poll already deleted", status=204)
  poll_instance.deleted = True
  poll_instance.deleted_by_creator = True
  poll_instance.save()
  serializer = PollInstanceSerializer(poll_instance, context=context)
  return response.Response(serializer.data, status=200)


@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([ResponseCreationThrottle])
def create_response(request):
  context = { 'request': request }
  data = request.data.copy()
  poll_instance_id = int(data.get('poll', None))
  data['poll_instance'] = poll_instance_id
  serializer = ResponseSerializer(data=data, context=context)
  if serializer.is_valid(raise_exception=True):
    serializer.save(user=request.user)
    return response.Response(serializer.data, status=200)
  else:
    return response.Response(serializer.errors, status=400)


@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([FavoriteThrottle])
def favorite_poll(request):
  context = { 'request': request }
  data = request.data.copy()
  poll_instance_id = int(data.get('poll', None))
  data['poll_instance'] = poll_instance_id
  serializer = FavoriteSerializer(data=data, context=context)
  if serializer.is_valid(raise_exception=True):
    serializer.save(user=request.user)
    return response.Response(serializer.data, status=200)
  return response.Response(serializer.errors, status=400)


@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([ReportCreationThrottle])
def report_poll_or_comment(request):
  context = { 'request' : request }
  user = request.user
  data = request.data.copy()
  poll_instance_id = data.get('poll', None)
  comment_id = data.get('comment', None)
  if poll_instance_id is not None:
    data['poll_instance'] = int(poll_instance_id)
  elif comment_id is not None:
    data['comment'] = int(comment_id)
  serializer = ReportSerializer(data=data, context=context)
  if serializer.is_valid(raise_exception=True):
    serializer.save(user=request.user)
    return response.Response(serializer.data, status=201)
  return response.Response(serializer.errors, status=403)

@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([CommentCreationThrottle])
def create_comment(request):
  user = request.user
  context = { 'request': request }
  data = request.data.copy()
  poll_instance_id = int(request.data.get('poll', None))
  data['poll_instance'] = poll_instance_id
  serializer = CommentCreateSerializer(data=data, context=context)
  if serializer.is_valid(raise_exception=True):
    if serializer.validated_data['poll_instance'].get_deleted():
      return response.Response("Poll does not exist", status=404)
    ip_address = get_ip_address(request)
    serializer.save(user=user, ip_address=ip_address)
    return response.Response(serializer.data, status=201)
  return response.Response(serializer.errors, status=403)


@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_comments_from_poll(request, pk):
  context = { 'request': request }
  poll_instance = get_object_or_404(PollInstance, pk=pk)
  if poll_instance.get_deleted():
    return response.Response("Poll does not exist", status=404)
  comments = Comment.objects.filter(poll_instance=poll_instance, deleted=False).order_by('created_date')
  serializer = DEP_CommentSerializer(comments, context=context, many=True)
  return response.Response(serializer.data, status=200)


@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([CommentVoteCreationThrottle])
def create_comment_vote(request):
  context = { 'request': request }
  data = request.data.copy()
  data['comment'] = int(request.data.get('comment', None))
  serializer = CommentVoteSerializer(data=data, context=context)
  if serializer.is_valid(raise_exception=True):
    serializer.save(user=request.user)
    return response.Response(serializer.data, status=200)
  else:
    return response.Response(serializer.errors, status=403)


@api_view(['POST', 'DELETE'])
@permission_classes((IsAuthenticated, ))
def delete_comment(request, pk):
  user = request.user
  context = { 'request': request }
  comment = get_object_or_404(Comment, pk=pk)
  if user != comment.user:
    return response.Response("Not authorized to delete comment", status=401)
  elif comment.deleted:
    return response.Response("Comment already deleted", status=204)
  else:
    comment.deleted=True
    comment.deleted_by_creator = True
    comment.save()
    serializer = CommentSerializer(comment, context=context)
    return response.Response(serializer.data, status=200)


@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([ContactFormCreationThrottle])
def contact(request):
  name = request.data.get('name', None)
  email = request.data.get('email', None)
  message = request.data.get('message', None)
  user_id = request.user.id
  if name and email:
    email_body = 'User ID: %d; Name: %s; Message: %s' % (user_id, name, message)
  else:
    email = re.search(r'[\w\.-]+@[\w\.-]+', message).group(0)
    email_body = 'User ID: %d; Message: %s' % (user_id, message)
  send_mail('Contact Form', email_body, email,
    ['support@whatsgoodly.zendesk.com'], fail_silently=False)
  return response.Response({ 'message': message }, status=200)


@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_universities(request):
  queryset = University.objects.all().order_by('name')
  serializer = UniversitySerializer(queryset, many=True)
  return response.Response(serializer.data, status=200)


@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_notifications(request):
  queryset = Notification.objects.filter(user=request.user).order_by('-id')
  serializer = DEP_NotificationSerializer(queryset, many=True)
  return response.Response(serializer.data)


class UserRetrieve(generics.ListAPIView):
  """
  @author: Ayush
  @desc: Serializer for the user object. This allows you to view a particular
  user. Used to get the user's stats.
  """
  serializer_class = DEP_UserInfoSerializer
  permission_classes = ( permissions.IsAuthenticated, )

  def get_queryset(self):
    return [User.objects.get(id=self.request.user.id)]

class DEP_ReportCreate(views.APIView):
  permission_classes = ( permissions.IsAuthenticated, )
  throttle_scope = 'reports'

  def post(self, request, pk, *args, **kwargs):
    user = self.request.user
    poll_instance = querysets.poll_instance_prefetch(pk=pk, user=user)[0]
    context = { 'request': request }
    # Fail silently if the user has reported this poll already
    if Report.objects.filter(poll_instance=poll_instance, user=user).count() > 0:
      return response.Response(PollInstanceSerializer(poll_instance, context=context).data)

    report = Report(poll_instance=poll_instance, user=user)
    report.save()
    report_count = Report.objects.filter(poll_instance=poll_instance).count()

    if report_count >= 5 and not poll_instance.get_verified() and not poll_instance.get_deleted():
      poll_instance.deleted = True
      poll_instance.save()

    return response.Response(PollInstanceSerializer(poll_instance, context=context).data)
