from rest_framework import permissions
from django.contrib.auth import REDIRECT_FIELD_NAME
from django.contrib.auth.decorators import user_passes_test

def can_view_survey(user, survey):
    if not survey.account_id:
        return True
    return can_view_account(user, survey.account)

def can_edit_survey(user, survey):
    if not survey.account_id:
        return False
    if survey.account.is_public:
        return False
    return can_view_account(user, survey.account)

def can_view_account(user, account):
    try:
        if account.is_public:
            return True
        if user.is_staff:
            return True
        return account.id == user.account_id
    except AttributeError:
        return False

def account_required(view_func=None, redirect_field_name=REDIRECT_FIELD_NAME,
                     login_url=None):
    """
    Decorator for views that checks that the user is logged in and has an account,
    redirecting to the login page if necessary.
    """
    actual_decorator = user_passes_test(
        lambda u: u.is_active and (u.account_id or u.is_staff),
        login_url=login_url,
        redirect_field_name=redirect_field_name
    )
    if view_func:
        return actual_decorator(view_func)
    return actual_decorator

class UserHasAccount(permissions.BasePermission):
    """
    Suspended users can't do anything.
    Everyone else can do anything and gets 403 Forbidden
    """
    # TODO: message doesn't show up for some reason
    message = "You don't have access! Contact support@whatsgoodly.com"

    def has_permission(self, request, view):
        user = request.user
        if (user.account_id or user.is_staff) and user.is_active:
            return True
        else:
            return False

class UserCanPost(permissions.BasePermission):
    """
    Suspended users can't do anything.
    Everyone else can do anything and gets 403 Forbidden
    """
    # TODO: message doesn't show up for some reason
    message = 'Posting previleges suspended! Contact support@whatsgoodly.com.'

    def has_permission(self, request, view):
        user = request.user
        if (not user.posting_suspended) and user.is_active:
            return True
        else:
            return False

# TODO find a place to use this
class UserVerifiedUniversity(permissions.BasePermission):
    """
    University users can do anything.
    Everyone else can't do anything and gets 403 Forbidden
    """
    # TODO: message doesn't show up for some reason
    message = "You haven't verified your school yet!"
    
    def has_permission(self, request, view):
        user = request.user
        if user.verified_university:
            return True
        else:
            return False

# OLD permissions handling
# error_dict = {
#   420: "User suspended from posting",
# }

# def custom_exception_handler(exc, context):
#   response = views.exception_handler(exc, context)
#   if hasattr(exc, 'detail'):
#     error = None
#     if isinstance(exc.detail, list):
#       error = exc.detail[0].get('non_field_errors', None)
#     elif isinstance(exc.detail, dict):
#       error = exc.detail.get('non_field_errors', None)
#     if error is not None:
#       try:
#         error = int(error[0])
#         if error in error_dict:
#           response.data['status_code'] = error
#           response.data['error_message'] = error_dict[error]
#           del response.data['non_field_errors']
#       except ValueError:
#         pass
#   return response

# class ExceptionMiddleware(object):
#   def process_exception(self, request, exception):
#     return response.Response({'error': True, 'content': exception},
#       status=status.HTTP_500_INTERNAL_SERVER_ERROR)