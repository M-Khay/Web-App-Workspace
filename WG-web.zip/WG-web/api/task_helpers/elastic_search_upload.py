from whatsgoodly.es_models import *
import json

GENDERS = ["Male", "Female", None]

# adds an ETAg for `tag` and all its ancestors to `results`
def make_etags_recursive(results, tag):
    level = 1
    ancestors = []
    parent_tag = tag

    while parent_tag.parent_id:
        parent_tag = parent_tag.parent
        if parent_tag.label_lower not in [t['value'] for t in results]:
            make_etags_recursive(results, parent_tag)
        level += 1
        ancestors = [parent_tag.label_lower] + ancestors
        
    etag = {'value': tag.label_lower, 'level': level, 'ancestors': ancestors}
    results.append(etag)

def make_epoll(p):
    etags = []
    for tag in p.tags.select_related('parent').all():
        make_etags_recursive(etags, tag)

    poll = EPoll(
        meta={'id': p.id},
        question=p.question,
        options=json.loads(p.options),
        tags=etags,
        created_date=p.created_date
    )
    if GENDERS[p.gender]:
        poll.targeting = GENDERS[p.gender]
    # print poll.question
    # print etags
    return poll

def make_ebreakdown(pb):
    from whatsgoodly.models import PollBreakdown

    poll_gender = GENDERS[pb.poll.gender]

    breakdown = dict(
        total=pb.total,
        abnormality=int(round(pb.significance*100)),
        breakdown_type=pb.breakdown_type,
        promotion=pb.promotion,
        vote_counts=json.loads(pb.json)
    )
    breakdown_gender = GENDERS[pb.gender] or poll_gender
    if breakdown_gender:
        breakdown['gender'] = breakdown_gender

    if pb.breakdown_type == PollBreakdown.TYPES.SEGMENT:
        segmenter = dict(
            pk=pb.segmenter.pk,
            question=pb.segmenter.question,
            options=json.loads(pb.segmenter.options),
            segment_option=pb.segment_option,
            segment_label=pb.segmenter.get_segment_label_short(pb.segment_option),
            created_date=pb.segmenter.created_date
        )
        if GENDERS[pb.segmenter.gender]:
            segmenter['targeting'] = GENDERS[pb.segmenter.gender]
        breakdown['segmenter'] = segmenter

    elif pb.breakdown_type == PollBreakdown.TYPES.UNIVERSITY:
        community = dict(
            pk=pb.university.pk,
            types=[pb.university.get_level_display()],
            name=pb.university.name,
            name_short=pb.university.name_short,
            location={
                "lat": pb.university.location.y,
                "lon": pb.university.location.x
            }
        )
        breakdown['community'] = community

    return breakdown

