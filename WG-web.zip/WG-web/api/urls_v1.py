from api import views_v1 as views
from django.conf.urls import patterns, url

urlpatterns = patterns('',
    url(r'^polls/$', views.get_or_post_polls),
    url(r'^polls/(?P<pk>[0-9]+)/report/$', views.DEP_ReportCreate.as_view()),
    url(r'^polls/reports/$', views.report_poll_or_comment),
    url(r'^polls/responses/$', views.create_response),
    url(r'^polls/favorites/$', views.favorite_poll),
    url(r'^polls/(?P<pk>[0-9]+)/deletes/$', views.delete_poll),
    url(r'^polls/all/$', views.get_or_post_polls, {'get_all_polls':True}),
    url(r'^polls/(?P<pk>[0-9]+)/$', views.get_poll),

    url(r'^polls/comments/$', views.create_comment),
    url(r'^polls/(?P<pk>[0-9]+)/comments/$', views.get_comments_from_poll),
    url(r'^polls/comments/votes/$', views.create_comment_vote),
    url(r'^polls/comments/(?P<pk>[0-9]+)/deletes/$', views.delete_comment),

    url(r'^users/$', views.create_user),
    url(r'^users/update/university/$', views.update_user_university),
    url(r'^users/update/$', views.update_user),
    url(r'^users/info/$', views.UserRetrieve.as_view()),
    url(r'^users/profile/$', views.get_user_profile),
    url(r'^users/notifications/$', views.get_notifications),

    url(r'^contact/$', views.contact),

    url(r'^universities/$', views.get_universities),
)
