from base64 import b64encode
from whatsgoodly.celery import app as celery_app
import api.notifications
import requests
import random
import json
import whatsgoodly.models
from django.db import IntegrityError, transaction
from django.db.models import Q, F, Count, Max
from django.conf import settings
from api.utils import send_slack_message, percent_change, truncate_text
from datetime import datetime, timedelta
from itertools import groupby
from django.forms import model_to_dict
import string

ANONYMOUS_TAGGER_THRESHOLD = 5
MIN_VOTE_COUNT_FOR_REWARD = 30
BATCHSIZE = 1000
REMOVE_PUNC_FROM_TAGGING = "?!\"':;#(),.[]"

@celery_app.task(name='tasks.log_engagement_metrics')
def log_engagement_metrics(yesterday=False, last_week=False, last_month=False):
  from whatsgoodly.models import *
  local_feed = Feed.objects.get(category=Feed.LOCAL)
  wg_id = dict(settings.ADMIN_IDS).get('Whatsgoodly')

  if yesterday:
    start = datetime.now().date() - timedelta(1)
    end = datetime.now().date()
    previous_start = start - timedelta(7)
    previous_end = end - timedelta(7)
    time_type = "Daily"
  elif last_month:
    start = datetime.now().date() - timedelta(30)
    end = datetime.now().date()
    previous_start = start - timedelta(30)
    previous_end = end - timedelta(30)
    time_type = "Monthly"
  elif last_week:
    # TODO
    raise NotImplementedError

  # Do new users
  users = User.objects.filter(date_joined__range=[start, end]).count()
  last_users = User.objects.filter(date_joined__range=[previous_start, previous_end]).count()
  message, emoji = _make_analytics_message_and_emoji(users, last_users, yesterday)
  send_slack_message(message, event_name=time_type+" New Users",
    emoji=emoji, channel="#analytics")

  # Do active voters
  actives = Response.objects.filter(created_date__range=[start, end])\
              .values('user').distinct().count()
  last_actives = Response.objects.filter(created_date__range=[previous_start, previous_end])\
              .values('user').distinct().count()
  message, emoji = _make_analytics_message_and_emoji(actives, last_actives, yesterday)
  send_slack_message(message, event_name=time_type+" Active Voters",
    emoji=emoji, channel="#analytics")

  recycle_poll_ids = PollInstance.objects.exclude(user_id=wg_id).values('poll_id').annotate(c=Count('poll_id')).filter(c__gt=1).values('poll_id')

  # Do content created
  responses = Response.objects.filter(created_date__range=[start, end]).count()
  responses_per_user = int(round(responses / float(actives or 1)))
  local_polls = PollInstance.objects.exclude(user_id=wg_id).filter(feed=local_feed, created_date__range=[start, end]).count()
  comments = Comment.objects.exclude(user_id=wg_id).filter(created_date__range=[start, end]).count()
  favorites = Favorite.objects.exclude(user_id=wg_id).filter(created_date__range=[start, end]).count()
  recycles = PollInstance.objects.filter(poll_id__in=recycle_poll_ids).filter(created_date__range=[start, end]).count()
  tags = Tag.objects.filter(created_date__range=[start, end]).count()
  searches = SearchQuery.objects.filter(created_date__range=[start, end]).count()

  last_responses = Response.objects.filter(created_date__range=[previous_start, previous_end]).count()
  last_responses_per_user = int(round(last_responses / float(last_actives or 1)))
  last_local_polls = PollInstance.objects.exclude(user_id=wg_id).filter(feed=local_feed, created_date__range=[previous_start, previous_end]).count()
  last_comments = Comment.objects.exclude(user_id=wg_id).filter(created_date__range=[previous_start, previous_end]).count()
  last_favorites = Favorite.objects.exclude(user_id=wg_id).filter(created_date__range=[previous_start, previous_end]).count()
  last_recycles = PollInstance.objects.filter(poll_id__in=recycle_poll_ids).filter(created_date__range=[previous_start, previous_end]).count()
  last_tags = Tag.objects.filter(created_date__range=[previous_start, previous_end]).count()
  last_searches = SearchQuery.objects.filter(created_date__range=[previous_start, previous_end]).count()

  message, emoji = _make_analytics_message_and_emoji(responses_per_user, last_responses_per_user, yesterday, prefix="*Avg responses per voter:* ")
  message += "\n"
  message += "\n".join([
    "*Responses:* {:,} ({}% change)".format(responses, percent_change(responses, last_responses)),
    "*Local polls:* {:,} ({}% change)".format(local_polls, percent_change(local_polls, last_local_polls)),
    "*Comments:* {:,} ({}% change)".format(comments, percent_change(comments, last_comments)),
    "*Favorites:* {:,} ({}% change)".format(favorites, percent_change(favorites, last_favorites)),
    "*Poll Recycles:* {:,} ({}% change)".format(recycles, percent_change(recycles, last_recycles)),
    "*Tags:* {:,} ({}% change)".format(tags, percent_change(tags, last_tags)),
    "*Searches:* {:,} ({}% change)".format(searches, percent_change(searches, last_searches)),
  ])

  send_slack_message(message, event_name=time_type+" Engagement",
    emoji=emoji, channel="#analytics")

@celery_app.task(name='tasks.regex_tag_polls')
def regex_tag_polls(tag_ids, poll_filters={}):
  from whatsgoodly.models import Poll, PollTag

  for tag_id in tag_ids:
    tag = PollTag.objects.get(pk=tag_id)
    query = Q()
    if not tag.flag_terms:
      continue
    try:
      terms = json.loads(tag.flag_terms)
    except ValueError as e:
      raise Exception("Bad tag terms: {} on {} ({})".format(tag.flag_terms, tag, e))
    for term in terms:
      needle = term.lower()
      if " " in needle:
        query = query | Q(question__icontains=needle) | Q(options__icontains=needle)
      else:
        # Postgres uses \y instead of \b
        regex = r'\y{}\y'.format(needle)
        query = query | Q(question__iregex=regex) | Q(options__iregex=regex)

    for poll in Poll.objects.all().filter(**poll_filters).filter(query):
      # poll will be auto-indexed in m2m signal
      poll.tags.add(tag)

    # TODO feeds
    
    # Note: this doesn't index the polls
    # poll_ids = queryset.values_list('id', flat=True)
    # PollTagRelation.objects.bulk_create([
    #   PollTagRelation(tag_id=tag_id, poll_id=poll_id)
    #   for poll_id in poll_ids
    # ])

@celery_app.task(name='tasks.auto_tag_polls')
def auto_tag_polls(poll_ids, tag_filters={}):
  from whatsgoodly.models import Poll, PollInstance, PollTag, Feed

  themed_feed_ids = list(Feed.objects.filter(
      category__in=Feed.THEMED_CATEGORIES
    ).values_list('id', flat=True))

  # Build flag term cache
  term_map = {}
  for tag in PollTag.objects.filter(**tag_filters).exclude(flag_terms=None):
    if not tag.flag_terms:
      continue
    try:
      terms = json.loads(tag.flag_terms)
    except ValueError as e:
      raise Exception("Bad tag terms: {} on {} ({})".format(tag.flag_terms, tag, e))
    for term in terms:
      needle = term.lower()
      term_map[needle] = term_map.get(needle, [])
      term_map[needle].append(tag.id)
    
  for poll in Poll.objects.filter(pk__in=poll_ids, deleted=False).only('question', 'options'):
    themed_instance = PollInstance.objects.filter(poll=poll, feed_id__in=themed_feed_ids).first()
    feed_name = (themed_instance.feed.name + ' ') if themed_instance else ''
    text = feed_name + poll.question.lower() + ' ' + poll.options.lower()
    text = "".join(c for c in text if c not in REMOVE_PUNC_FROM_TAGGING)
    words = text.split()
    for needle, tag_ids in term_map.iteritems():
      haystack = text if " " in needle else words
      needle_plural_possessive = needle + "s"
      if needle in haystack or needle_plural_possessive in haystack:
        poll.tags.add(*tag_ids)
        # print poll
        # print poll.tags.all()

@celery_app.task(name='tasks.elasticsearch_index_breakdowns')
def elasticsearch_index_breakdowns():
  from whatsgoodly.models import Poll, PollBreakdown
  from whatsgoodly.es_models import EPoll
  BATCHSIZE = 500

  max_pk = Poll.objects.aggregate(Max('pk'))['pk__max']
  opts = dict(event_name="Indexing All Polls", emoji=":palm_tree:", channel="#progress")
  send_slack_message("Indexing {} polls in Elastic Search".format(max_pk), **opts)

  try:
    # Update EPoll schema in elasticsearch
    EPoll.init()

    for offset in range(0, max_pk+1, BATCHSIZE):
      # print "OFFSET {}".format(offset)
      for p in Poll.objects.filter(
          pk__in=PollBreakdown.objects.all().values('poll_id'),
          pk__gte=offset,
          pk__lt=offset+BATCHSIZE
        ):
        p.index()

  except Exception as e:
    message = "... failing with exception: {}".format(e)
    send_slack_message(message, **opts)
    raise e

  message = "... finished indexing {} polls".format(max_pk)
  send_slack_message(message, **opts)

@celery_app.task(name='tasks.recompute_breakdowns')
def recompute_breakdowns(poll_ids):
  from whatsgoodly.models import Poll
  poll_ids = sorted(poll_ids)
  message = "Starting for {0} poll ids between {1} and {2}...".format(
      len(poll_ids), poll_ids[0], poll_ids[-1]
    )
  opts = dict(event_name="Computing and Indexing Breakdowns", emoji=":bar_chart:", channel="#progress")
  send_slack_message(message, **opts)

  num_breakdowns = 0
  for poll in Poll.objects.filter(id__in=poll_ids, deleted=False):
    num_breakdowns += _recompute_breakdowns(poll)
    poll.index()

  message = "... finished computing and indexing {0} breakdowns".format(num_breakdowns)
  send_slack_message(message, **opts)

  return num_breakdowns

@celery_app.task(name='tasks.update_relationships')
def update_relationships(poll_ids, min_response_id=None):
  from whatsgoodly.models import Poll
  poll_ids = sorted(poll_ids)
  message = "Starting for {0} poll ids between {1} and {2}...".format(
      len(poll_ids), poll_ids[0], poll_ids[-1]
    )
  opts = dict(event_name="Updating Relationships", emoji=":love_hotel:", channel="#progress")
  send_slack_message(message, **opts)

  num_relationships = 0
  for poll in Poll.objects.filter(id__in=poll_ids, deleted=False):
    num_relationships += _create_missing_relationships(poll)

  message = "... finished creating {0} new relationships".format(num_relationships)
  send_slack_message(message, **opts)

  if min_response_id:
    num_relationships = 0

    for poll in Poll.objects.filter(id__in=poll_ids):
      num_relationships += _update_relationships(poll, min_response_id)
      
    message = "... finished updating {0} relationships".format(num_relationships)
    send_slack_message(message, **opts)

  return num_relationships

@celery_app.task(name='tasks.send_sms')
def send_sms(numbers, message):
  auth = b64encode(settings.TWILIO_ACCOUNT_SID + ':' + settings.TWILIO_AUTH_TOKEN).decode("ascii")
  headers = { 'Authorization' : 'Basic %s' %  auth }

  should_verify = not settings.DEBUG
  for n in numbers:
    requests.post(settings.TWILIO_SMS_URL, data={
        'To': n,
        'From': settings.TWILIO_NUMBER,
        'Body': message
      }, headers=headers, verify=should_verify)

@celery_app.task(name='tasks.import_friends')
def import_friends(user_id, contacts=[]):
  from whatsgoodly.models import *

  for contact in contacts:
    number = contact.get('phone_number')
    friend_name = contact.get('display_name', None)
    friend_name_utf8 = friend_name.encode('utf-8') if friend_name else None

    Friendship.objects.update_or_create(
        user_id=user_id,
        friend_phone_number=number,
        defaults={'friend_name': friend_name_utf8}
      )

@celery_app.task(name='tasks.send_tags')
def send_tags(tag_ids, deep_link=None, message=None):
  tags = whatsgoodly.models.Tag.objects.filter(
      id__in=tag_ids
    ).select_related('friendship')
  if not tags.exists():
    raise Exception("Invalid tag ids")

  tag_denoting_user_and_poll_instance = tags.first()
  user = tag_denoting_user_and_poll_instance.friendship.user
  sms_tagger_label = "Someone with your phone number"
  if user.full_name and tags.count() <= ANONYMOUS_TAGGER_THRESHOLD:
    sms_tagger_label = user.full_name
  feed_name = tag_denoting_user_and_poll_instance.poll_instance.feed.name

  if message:
    sms_feed_detail = u": \"{}\"".format(message)
  else:
    sms_feed_detail = u" in the \"{}\" feed".format(feed_name)
  sms_event_message = u"tagged you on a Whatsgoodly poll{}. Give your opinion at {} (opens up Whatsgoodly)"\
    .format(sms_feed_detail, deep_link)
  sms_numbers = []

  for tag in tags:
    tagged_friend_accounts = tag.friendship.friend_accounts()
    if not tagged_friend_accounts.exists():
      # Queue an SMS to invite
      sms_numbers.append(tag.friendship.friend_phone_number)
      continue

    # Create and send a push notification using tagged friend's label for current user
    tagged_friend = tagged_friend_accounts.filter(is_active=True).order_by('-id').first()

    # Skip users who deactivated all accounts
    if not tagged_friend:
      continue

    # If we want to text users who never enabled push in any account:
    # if not tagged_friend_accounts.filter(denied_push_notifications=False).exists():
      # tagger_label = _get_tagger_label_utf8(tag_denoting_user_and_poll_instance, sms_tagger_label)
      # sms_message = "{0} {1}. Tip: turn on push notifications in Settings so we can skip sending texts :)"\
      #   .format(tagger_label, sms_event_message)
      # send_sms([tagged_friend.phone_number], sms_message)

    _send_tag_push(tag, message=message)

  if sms_numbers:
    # Send SMS invites
    sms_invite_message = "{0} {1}".format(sms_tagger_label.encode('utf-8'), sms_event_message)
    send_sms(sms_numbers, sms_invite_message)

@celery_app.task(name='tasks.add_friends')
def add_friends(user_id):
  from whatsgoodly.models import *
  user = User.objects.get(pk=user_id)
  event_message = "joined Whatsgoodly! Send %s an anonymous poll" % user.pronoun()
  feed = Feed.objects.get(category=Feed.CAMPUS)
  notify_friends(user_id, event_message, feed_id=feed.id, make_poll=True)
  # friendships = Friendship.objects.filter(friend_phone_number=user.phone_number)
  # for friend_id in friendships.values_list('user_id', flat=True):
  #   UserRelationship.edges.update_or_create([user_id, friend_id], is_friend=True)

@celery_app.task(name='tasks.notify_friends')
def notify_friends(user_id, event_message="joined Whatsgoodly!", poll_instance_id=None, feed_id=None, make_poll=False):
  user = whatsgoodly.models.User.objects.get(pk=user_id)
  if user.is_staff:
    return
    
  friends = whatsgoodly.models.Friendship.objects.filter(friend_phone_number=user.phone_number)
  for friend in friends:
    friend_label = friend.friend_name
    if not friend_label:
      continue
    try:
      prefix_utf8 = "Your friend %s" % friend_label.encode('utf-8')
      message = "{0} {1}".format(prefix_utf8, event_message)
      create_and_send_notifs(
        notification_title=message,
        user_ids=[friend.user_id],
        poll_instance_id=poll_instance_id,
        notification_type=13,
        make_poll=make_poll,
        feed_id=feed_id
      )
    except BaseException as e:
      print u"Exception sending to {0}: {1}".format(friend_label, e)

@celery_app.task(name='tasks.create_and_send_notifs')
def create_and_send_notifs(user_ids=[],
                          notification_title=None, notification_copy=None,
                          poll_instance_id=None, notification_type=0,
                          feed_id=None, make_poll=False, from_id=None,
                          campaign_id=None,
                          send_to_unseen=False,
                          send_to_maus=False):
  # Prefer using NotificationCampaigns for send_to_maus
  from whatsgoodly.models import User, Notification, Response, NotificationCampaign

  if campaign_id:
    campaign = NotificationCampaign.objects.get(pk=campaign_id)
  else:
    campaign = None

  if not notification_type and campaign:
    notification_type = campaign.notification_type

  notif_dict = dict(
    title=notification_title,
    poll_instance_id=poll_instance_id,
    feed_id=feed_id,
    body=notification_copy,
    notification_type=notification_type,
    make_poll=make_poll,
    campaign_id=campaign_id
  )

  if not user_ids:
    # Compute user_ids from the campaign and/or parameters
    queryset = User.objects.active()
    if campaign:
      queryset = campaign.eligible_users(queryset=queryset)
    if send_to_maus:
      one_month_ago = datetime.now() - timedelta(days=30)
      active_ids = Response.objects.filter(created_date__gte=one_month_ago).values('user_id').distinct()
      queryset = queryset.filter(pk__in=active_ids)
    if send_to_unseen:
      voter_ids = Response.objects.filter(poll_instance_id=poll_instance_id).values('user_id').distinct()
      queryset = queryset.exclude(pk__in=voter_ids)
    user_ids = queryset.values_list('id', flat=True)

  for user_id in user_ids:
    attrs = notif_dict.copy()
    attrs['user_id'] = user_id
    if from_id:
      user = User.objects.get(pk=from_id)
      attrs['title'] = user.get_handle() + ' ' + attrs['title']
    if campaign and campaign.customization != NotificationCampaign.CUSTOMIZATIONS.NONE:
      user = User.objects.get(pk=user_id)
      campaign.customize(user, attrs)

    if notification_type in Notification.TYPES.CHOICES_ENFORCING_UNIQUENESS:
      n, created = Notification.objects.get_or_create(**attrs)
    else:
      created = True
      n = Notification.objects.create(**attrs)
    if created:
      api.notifications.send_push_notification(n)
  # TODO bulk: need sns support
  # for offset in range(0, len(user_ids), BATCHSIZE):
  #   offset_ids = user_ids[offset:offset+BATCHSIZE]
  #   notifs = [... for user_id in offset_ids]
  #   Notification.objects.bulk_create(notifs)
  #   api.notifications.bulk_send_push_notifications(notifs)

@celery_app.task(name='tasks.school_polls_of_the_week')
def school_polls_of_the_week(uni_ids = []):
  from whatsgoodly.models import PollInstance, Feed, University
  from whatsgoodly import analytics
  from api.slackbots import Gupta

  minimum_vote_count = 20

  if not uni_ids:
    unis = University.objects.all()
  else:
    unis = University.objects.filter(pk__in=uni_ids)

  one_week_ago = datetime.now() - timedelta(days=7)

  local_feed = Feed.objects.get(category=Feed.LOCAL)

  for u in unis:
    top_poll = PollInstance.objects.undeleted().filter(
        community=u, created_date__gte=one_week_ago,
        vote_weight__gte=minimum_vote_count,
        promotion__lte=PollInstance.PROMOTIONS.NONE
      ).order_by('-vote_weight').first()

    if top_poll:
      # Prompt slack for promo!
      title = "Top Poll this week for {}".format(u)
      body = "{} favorites\n{} comments\n{} weighted votes".format(
          top_poll.favorite_count, top_poll.comment_count,
          top_poll.vote_weight
      )
      Gupta(poll_instance=top_poll).promote(body, title=title, is_top_poll=True)

@celery_app.task(name='tasks.reward_poll_creator')
def reward_poll_creator(poll_id, recurse=True):
  from whatsgoodly.models import *

  poll = Poll.objects.get(id=poll_id)
  if poll.deleted:
    return

  pi = PollInstance.objects.filter(poll=poll).order_by('-vote_weight').first()
  vote_count = sum(json.loads(pi.vote_counts))
  if recurse and vote_count < MIN_VOTE_COUNT_FOR_REWARD:
    reward_poll_creator.apply_async(args=[poll.id, False], countdown=3600*48)
    return

  if vote_count < MIN_VOTE_COUNT_FOR_REWARD/2:
    # Don't award
    return

  user = poll.user
  user.credits += vote_count
  user.save()

  message = "It's payday! Your poll earned you {} coins".format(vote_count)
  body = truncate_text(poll.question)
  create_and_send_notifs(
    notification_title=message,
    notification_copy=body,
    poll_instance_id=pi.id,
    user_ids=[user.id],
    notification_type=5
  )

@celery_app.task(name='tasks.make_universally_local')
def make_universally_local(poll_id, campus_ids=[]):
  from whatsgoodly.models import *

  admin_id = dict(settings.ADMIN_IDS).get('Whatsgoodly')
  poll = Poll.objects.get(id=poll_id)
  feed = Feed.objects.get(category=Feed.LOCAL)
  new_unis = University.objects.exclude(
    location__in=poll.instances.values('location')
  )
  if campus_ids:
    new_unis = new_unis.filter(pk__in=campus_ids)

  for uni in new_unis:
    PollInstance.objects.create(
      user_id=admin_id, poll=poll, feed=feed,
      location=uni.location, community=uni, verified=True
    )

@celery_app.task(name='tasks.remove_promotion')
def remove_promotion(poll_instance_id):
  PollInstance = whatsgoodly.models.PollInstance

  try:
    pi = PollInstance.objects.get(pk=poll_instance_id)
  except PollInstance.DoesNotExist:
    return

  if pi.promotion == PollInstance.PROMOTIONS.PINNED:
    pi.promotion = PollInstance.PROMOTIONS.PREVIOUSLY_PINNED
  elif pi.promotion == PollInstance.PROMOTIONS.HOT:
    pi.promotion = PollInstance.PROMOTIONS.PREVIOUSLY_HOT
  pi.save()

@celery_app.task(name='tasks.inflate_vote_counts')
def inflate_vote_counts(poll_instance_id):
  PollInstance = whatsgoodly.models.PollInstance
  cutoff = 4

  try:
    pi = PollInstance.objects.get(id=poll_instance_id)
    if pi.get_deleted() or pi.feed.approve_posts:
      return
  except PollInstance.DoesNotExist:
    return

  counts = json.loads(pi.vote_counts)
  # pi.tag_count += 1
  if sum(counts) >= cutoff:
    # pi.save()
    return

  inflated_counts = [2*c for c in counts]
  random_index = random.randrange(0, len(counts))
  inflated_counts[random_index] += 1
  pi.vote_counts = json.dumps(inflated_counts)
  pi.save()

  if sum(inflated_counts) < cutoff:
    inflate_vote_counts.apply_async(args=[pi.id], countdown=3600)

@celery_app.task(name='tasks.inflate_negative_poll_vote')
def inflate_negative_poll_vote(poll_instance_id):
  PollInstance = whatsgoodly.models.PollInstance

  poll_instance = PollInstance.objects.get(id=poll_instance_id)
  if poll_instance.get_deleted():
    return

  poll_instance.vote_aggregate += 1
  poll_instance.save()

  if poll_instance.vote_aggregate < 0:
    inflate_negative_poll_vote.apply_async(args=[poll_instance.id], countdown=3600)


@celery_app.task(name='tasks.add_missing_locations_to_responses')
def add_missing_locations_to_responses():
  from whatsgoodly.models import Feed, PollInstance

  local_feed = Feed.objects.get(category=0)

  max_pk = PollInstance.objects.aggregate(Max('pk'))['pk__max']

  opts = dict(event_name="Adding Missing Locations to Responses", emoji=":palm_tree:", channel="#progress")

  for offset in range(0, max_pk+1, BATCHSIZE*5):
      # print "OFFSET {}".format(offset)
      # Only do non-campus polls, because users may have teleported
      if offset % (BATCHSIZE*50) == 0:
        send_slack_message("PollInstance offset: {} / {}".format(offset, max_pk), **opts)
      # to campus to respond to campus polls
      for pi in PollInstance.objects.filter(
          community__isnull=True, feed=local_feed,
          pk__gte=offset,
          pk__lt=offset+BATCHSIZE
        ):
        pi.response_set.filter(location__isnull=True).update(location=pi.location)

"""
HELPERS
"""

def _make_analytics_message_and_emoji(new_count, last_count, add_week_notice=True, prefix=""):
  message = "{}{:,}".format(prefix, new_count)
  change = percent_change(new_count, last_count)
  if change > 0:
    emoji = ":chart_with_upwards_trend:"
    message += " - _increase of {0}%_".format(change)
  else:
    emoji = ":chart_with_downwards_trend:"
    message += " - _decrease of {0}%_".format(-1*change)
  if add_week_notice:
    message += " from previous week"
  return message, emoji

def _get_tagger_label_utf8(tag, default_tagger_label="One of your contacts"):
  user = tag.friendship.user
  tagged_friend_accounts = tag.friendship.friend_accounts()

  reverse_friendship = whatsgoodly.models.Friendship.objects.filter(
      user__in=tagged_friend_accounts, friend_phone_number=user.phone_number,
      friend_name__isnull=False
    ).first()
  if reverse_friendship:
    label = reverse_friendship.friend_name
  else:
    label = default_tagger_label

  return label.encode('utf-8')

def _send_tag_push(tag, message=None):
  tagged_friend_accounts = tag.friendship.friend_accounts().filter(is_active=True)
  feed_name = tag.poll_instance.feed.name
  tagger_label = _get_tagger_label_utf8(tag)
  message = truncate_text(message or tag.poll_instance.poll.question)
  
  title = "{0} tagged you on a {1} poll".format(tagger_label, feed_name)
  create_and_send_notifs(
    notification_title=title,
    notification_copy=message.encode('utf-8'),
    poll_instance_id=tag.poll_instance.pk,
    user_ids=tagged_friend_accounts.values_list('id', flat=True),
    notification_type=10
  )

def _update_relationships(poll, min_response_id):
  from whatsgoodly.models import Response, UserRelationship
  num_for_poll = 0
  options = json.loads(poll.options)
  for i in range(len(options)):
    users = Response.objects.filter(
        pk__gte=min_response_id,
        response=i,
        poll_instance__poll=poll
      ).values('user')
    num_for_poll += UserRelationship.edges.filter(
        left__in=users, right__in=users
      ).update(response_count = F('response_count') + 1)

  return num_for_poll

def _create_missing_relationships(poll):
  from whatsgoodly.models import Response, UserRelationship
  num_for_poll = 0
  options = json.loads(poll.options)

  for i in range(len(options)):
    respondents = Response.objects.filter(
        poll_instance__poll=poll,
        response=i
      ).values_list('user_id', flat=True).distinct()
    respondent_set = set(respondents)
    # print "{} respondents".format(len(respondent_set))

    existing = UserRelationship.edges.filter(
        left_id__in=respondent_set, right_id__in=respondent_set
      ).values('left_id', 'right_id')
    existing_left = {node: [edge['right_id'] for edge in edges]
                      for node, edges in groupby(
                          existing.order_by('left_id'),
                          lambda edge: edge['left_id']
                        )}
    existing_right = {node: [edge['left_id'] for edge in edges]
                      for node, edges in groupby(
                          existing.order_by('right_id'),
                          lambda edge: edge['right_id']
                        )}
    processed_set = set()

    # for offset in range(0, len(respondents), BATCHSIZE):
    #   offset_respondents = respondents[offset:offset+BATCHSIZE]
    for user_id in respondent_set:
      processed_set.add(user_id)
      existing_set = set(existing_left.get(user_id, [])) | set(existing_right.get(user_id, []))
      missing_relationships = [
        UserRelationship(left_id=user_id, right_id=other_user_id, response_count=1)
        for other_user_id in (respondent_set - processed_set - existing_set)
      ]
      # print "bulk creating {} rows...".format(len(missing_relationships))
      # try:
      UserRelationship.objects.bulk_create(missing_relationships, batch_size=BATCHSIZE)
      num_for_poll += len(missing_relationships)
      #   print "SUCCESS"
      # except IntegrityError as e:
      #   print "Integrity error: {} (on {})".format(e, user_id)

  return num_for_poll

# Rebuild all the poll's breakdowns
# Many lines commented out for performance! :)
def _recompute_breakdowns(poll):
  from whatsgoodly.models import *
  from whatsgoodly import analytics
  # if we wanna Quick exit if segment breakdowns were recently made
  # last_pb = poll.breakdowns.filter(breakdown_type=PollBreakdown.TYPES.SEGMENT).first()
  # if last_pb.created_date + timedelta(hours=1) > datetime.now():
  #   return 0

  # TODO profile this, maybe don't recompute simple breakdowns
  devices = analytics.device_breakdowns(poll)
  control = [dev
      for dev in devices
      if dev.breakdown_type == PollBreakdown.TYPES.MOBILE
    ][0]
  # genders = analytics.gender_breakdowns(poll, control)

  # Do simple breakdowns first because
  # segments take a long time, can invalidate earlier breakdowns
  # with transaction.atomic():
  #   poll.breakdowns.filter(breakdown_type__in=PollBreakdown.TYPES.SIMPLE).delete()
  #   poll.breakdowns.bulk_create(devices + genders)

  # Now do advanced breakdowns
  # universities = analytics.university_breakdowns(poll, control)
  segments = analytics.segment_breakdowns(poll, control)
  # with transaction.atomic():
  #   poll.breakdowns.exclude(breakdown_type__in=PollBreakdown.TYPES.SIMPLE).delete()
  #   poll.breakdowns.bulk_create(universities + segments)

  for pb in (devices + segments):
    poll.breakdowns.update_or_create(
        breakdown_type=pb.breakdown_type,
        gender=pb.gender,
        segmenter_id=pb.segmenter_id,
        segment_option=pb.segment_option,
        university_id=pb.university_id,
        defaults=model_to_dict(pb, fields=['json', 'total', 'significance'])
      )

  return len(devices) + len(segments)
