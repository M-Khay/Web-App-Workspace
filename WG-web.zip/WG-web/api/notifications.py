from api.constant_lists import congratulations_list
from apns import APNs, Payload
import grequests
import json
import random
from django.conf import settings
from django.contrib.gis.measure import D
from boto3.session import Session as AWSSession
from botocore.exceptions import ClientError
from api.utils import truncate_text, KM_DISTANCE_FILTER, send_slack_message
# DO NOT IMPORT SPECIFIC whatsgoodly.models HERE, circular
import whatsgoodly.models
import api.tasks

COMMENT_NOTIF_CONSOLIDATION_COUNT = 3

def update_aws_arns(user, should_save=True):
    user_token = None
    platform_arn = None

    if user.ios_apns_token:
        user_token = user.ios_apns_token
        platform_arn = settings.AWS_ARNS_IOS
    elif user.gcm_token:
        user_token = user.gcm_token
        platform_arn = settings.AWS_ARNS_ANDROID

    if not user_token:
        return

    aws_session = AWSSession(
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
        region_name=settings.AWS_REGION
    )
    sns = aws_session.client('sns')
    endpoint = sns.create_platform_endpoint(
        PlatformApplicationArn=platform_arn,
        Token=user_token,
    )
    endpoint_arn = endpoint['EndpointArn']
    sns.set_endpoint_attributes(
        EndpointArn=endpoint_arn,
        Attributes={'Enabled': 'true'}
    )
    user.aws_sns_arn_endpoint = endpoint_arn

    if should_save:
        user.save()

def send_push_notification(notification, should_save=True):
    user = notification.user
    user.notification_count += 1
    if should_save:
        user.save()

    # Can't send push notifs locally
    if not settings.NOTIFICATIONS_ENABLED:
        print u"Notifications disabled: not sending {0}".format(
            notification)
        return

    if not user.aws_sns_arn_endpoint:
        return

    aws_session = AWSSession(
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
        region_name=settings.AWS_REGION
    )
    sns = aws_session.client('sns')

    if notification.body:
        message = u"{}: \"{}\"".format( notification.title, notification.body )
    else:
        message = notification.title.encode('utf-8')

    apns_string = _make_sns_apns_message(notification, message)
    gcm_string = _make_sns_gcm_message(notification, message)

    payload = {
        'APNS': apns_string,
        'APNS_SANDBOX': apns_string,
        'GCM': gcm_string
    }
    payload_json = json.dumps(payload,ensure_ascii=False)

    try:
        sns.publish(
            TargetArn=user.aws_sns_arn_endpoint,
            Message=payload_json,
            MessageStructure='json'
        )
    except ClientError:
        user.aws_sns_arn_endpoint = None
        if should_save:
            user.save()
        # If we want to notify Slack of uninstallation:
        # slack_message = "Push notification failed for User {0}{1} (possibly uninstalled the app)".format(
        #         user.id,
        #         " at {0}".format(user.university.name) if user.university_id else ""
        #     )
        # send_slack_message(slack_message, event_name="Push Failure", emoji=":no_mobile_phones:")

def poll_of_the_week_notification(poll_instance, only_maus=True, university=None):
    from whatsgoodly.models import NotificationCampaign

    body = truncate_text(poll_instance.poll.question)
    # if poll_instance.poll.user.university:
    #   title = "Poll of the Week from {}".format(poll_instance.poll.user.university.name_short)
    # else:
    title = "Poll of the Week"

    setting = NotificationCampaign.CUSTOMIZATIONS.NONE
    if university:
        setting = NotificationCampaign.CUSTOMIZATIONS.PREFIX_UNIVERSITY

    user_filter = ""
    if university:
        user_filter = "Q(university_id={})".format(university.id)

    active_in_last_days = 30 if only_maus else 0

    campaign = NotificationCampaign.objects.create(
      name=u"{}: {}".format(title, body),
      notification_type=18,
      user_filter=user_filter,
      active_in_last_days=active_in_last_days,
      customization=setting
    )

    api.tasks.create_and_send_notifs.delay(
      notification_title=title,
      notification_copy=body,
      poll_instance_id=poll_instance.id,
      campaign_id=campaign.id,
      send_to_unseen=True
    )

    return campaign

def admin_check_poll_notification(poll_instance, prev_vote_count):
    Feed = whatsgoodly.models.Feed
    vote_count = poll_instance.get_vote_total()
    if vote_count == 0:
        return

    if poll_instance.feed.category == Feed.GLOBAL:
        if prev_vote_count % 1000 != 0 and vote_count % 1000 == 0:
            create_poll_notification(poll_instance, 2)
            return

    if prev_vote_count % 500 != 0 and vote_count % 500 == 0:
        create_poll_notification(poll_instance, 6)
    # elif prev_vote_count < 100 and vote_count >= 100:
    #     create_poll_notification(poll_instance, 5)
    elif prev_vote_count < 15 and vote_count >= 15:
        create_poll_notification(poll_instance, 1)

def check_poll_notification(poll_instance):
    Feed = whatsgoodly.models.Feed
    vote_count = poll_instance.get_vote_total()
    if vote_count == 0:
        return

    if poll_instance.feed.category == Feed.GLOBAL:
        if vote_count % 1000 == 0:
            create_poll_notification(poll_instance, 2)
            return

    if vote_count % 500 == 0:
        create_poll_notification(poll_instance, 6)
    # TODO coin notif
    # elif vote_count == 100:
    #     create_poll_notification(poll_instance, 5)
    elif vote_count in [5, 50]:
        create_poll_notification(poll_instance, 1)

def create_poll_notification(poll_instance, notification_type=0, made_global=False,
                            made_top=False, made_pinned=False, made_new_feed=False):
    Notification = whatsgoodly.models.Notification

    if _is_unsubscribed_to_poll(poll_instance.user_id, poll_instance.id):
        # User disabled notifs for poll
        return

    if made_global:
        title = "Congrats - your poll is on the Featured feed!"
        notification_type = 2
    elif made_top:
        title = "Your poll is hot!"
        notification_type = 12
    elif made_pinned:
        title = "Nice, your poll was pinned to the top of the {} feed!".format(poll_instance.feed.name)
        notification_type = 11
    elif made_new_feed:
        title = "Your poll was moved to the {} feed.".format(poll_instance.feed.name)
    else:
        Comment = whatsgoodly.models.Comment
        vote_count = poll_instance.get_vote_total()
        comment_count = poll_instance.comment_count
        if comment_count == 0:
            title = '%d votes on your poll' % ( vote_count, )
        elif comment_count == 1:
            title = '%d votes and 1 reply on your poll' % ( vote_count, )
        else:
            title = '%d votes and %d replies on your poll' % ( vote_count, comment_count, )

    body = truncate_text(poll_instance.poll.question)

    notification = Notification(
        user=poll_instance.user, title=title, poll_instance=poll_instance,
        body=body, notification_type=notification_type
    )
    notification.save()
    send_push_notification(notification)

def check_report_notification(poll=None, comment=None, warned=False, suspended=False):
    from whatsgoodly.models import Report

    obj = poll or comment

    title = "Result of your {} report".format(
        "poll" if poll else "comment"
    )

    if obj.verified:
        return
        # body = "It doesn't violate our terms of use, but thanks for reporting it!"
    elif obj.deleted:
        user_status = ""
        if warned:
            user_status = " and poster warned"
        elif suspended:
            user_status = " and poster suspended"
        body = "Content deleted{}. Thanks for the heads up!".format(user_status)
    else:
        raise Exception("Need decision on report object")

    if poll:
        reports = Report.objects.filter(poll_instance__poll=poll)
    elif comment:
        reports = Report.objects.filter(comment=comment)
    else:
        raise Exception("Need poll or comment to find reports")

    if not reports.exists():
        return

    user_ids = list(reports.values_list('user_id', flat=True))

    api.tasks.create_and_send_notifs.delay(
        notification_title=title,
        notification_copy=body,
        user_ids=user_ids,
        notification_type=20
    )

def local_poll_notification(poll_instance, title, campus_member_title=None, body=None):
    from whatsgoodly.models import *
    if not poll_instance.location or poll_instance.feed.category != Feed.LOCAL:
        return

    removal_user_ids = PollInstanceRemoval.objects.filter(poll_instance=poll_instance).values('user_id')
    respondent_ids = Response.objects.filter(poll_instance=poll_instance).values('user_id')
    body = body or truncate_text(poll_instance.poll.question)
    campus_member_ids = set()

    if campus_member_title and poll_instance.community:
        # Lookup and send to students at nearest university
        campus_member_ids = set(User.objects.active().exclude(
                pk=poll_instance.user_id
            ).exclude(
                id__in=removal_user_ids
            ).exclude(
                id__in=respondent_ids
            ).filter(
                university=poll_instance.community
            ).values_list('id', flat=True).distinct())
        if campus_member_ids:
            api.tasks.create_and_send_notifs.delay(
                list(campus_member_ids),
                campus_member_title, body,
                poll_instance.id, 12
            )

    # Send local notif to everyone else nearby
    nearby_user_ids = LocalChannel.objects.exclude(
            user_id__in=respondent_ids
        ).exclude(
            user_id__in=removal_user_ids
        ).filter(
            user__is_active=True,
            location__distance_lte=(poll_instance.location, D(km=KM_DISTANCE_FILTER))
        ).values_list('user_id', flat=True).distinct()
    other_user_ids = [uid
        for uid in nearby_user_ids
        if uid not in campus_member_ids]
    api.tasks.create_and_send_notifs.delay(
        other_user_ids,
        title, body,
        poll_instance.id, 12
    )
    

def friend_poll_notification(poll_instance, title, body=None):
    if not poll_instance.user.phone_number:
        return

    friendships_towards_poster = whatsgoodly.models.Friendship.objects.filter(
            friend_phone_number=poll_instance.user.phone_number
        )

    body = body or truncate_text(poll_instance.poll.question)

    # Send local notif to friends
    nearby_friend_ids = whatsgoodly.models.LocalChannel.objects.exclude(
            user_id=poll_instance.user_id
        ).filter(
            location__distance_lte=(poll_instance.location, D(km=KM_DISTANCE_FILTER)),
            user__friendship__in=friendships_towards_poster
        ).values_list('user_id', flat=True).distinct()

    api.tasks.create_and_send_notifs.delay(list(nearby_friend_ids), title, body, poll_instance.id, 14)

def check_favorite_notification(favorite):
    Favorite = whatsgoodly.models.Favorite

    poll_instance = favorite.poll_instance
    if not _is_subscribed_to_poll(poll_instance.user_id, poll_instance.id):
        # User disabled notifs for poll
        return

    if poll_instance.favorite_count == 5:
        title = '5 people favorited your poll'
        body = truncate_text(poll_instance.poll.question)

        Notification = whatsgoodly.models.Notification
        notification = Notification(user=poll_instance.user, title=title, poll_instance=poll_instance,
                body=body, notification_type=7)
        notification.save()

        send_push_notification(notification)

def check_comment_notification(comment):
    from whatsgoodly.models import PushSubscription, Mention, Comment
    poll_instance = comment.poll_instance
    # recipient_id = None

    comment_count = Comment.objects.filter(
            poll_instance=poll_instance, deleted=False
        ).count()

    if comment_count == 1 and \
            not _is_unsubscribed_to_poll(poll_instance.user_id, poll_instance.id) and \
            poll_instance.user_id != comment.user_id:
        body = truncate_text(poll_instance.poll.question)
        api.tasks.create_and_send_notifs.delay(
            notification_title='First reply to your poll',
            notification_copy=body,
            poll_instance_id=poll_instance.id,
            user_ids=[poll_instance.user_id],
            notification_type=3
        )
        return

    if comment_count % COMMENT_NOTIF_CONSOLIDATION_COUNT != 0:
        return

    recips = list(PushSubscription.objects.filter(
            poll_instance=poll_instance, disabled=False
        ).exclude(user_id=comment.user_id).exclude(
            user_id__in=Mention.objects.filter(comment=comment).values('user_id')
        ).values_list('user_id', flat=True))

    if recips:
        commenter_count = Comment.objects.filter(
                poll_instance=poll_instance, deleted=False
            ).values('user_id').distinct().count()
        body = truncate_text(poll_instance.poll.question)
        api.tasks.create_and_send_notifs.delay(
            notification_title='and {} others replied'.format(commenter_count-1),
            notification_copy=body,
            poll_instance_id=poll_instance.id,
            user_ids=recips,
            notification_type=3,
            from_id=comment.user_id
        )

def promoted_breakdown_notification(poll, title="Voters are divided"):
    from whatsgoodly.models import PushSubscription, Feed

    pis = poll.instances.all()
    if poll.recycle_count > 1:
        # TODO keep in sync with poll_breakdowns queryset
        pis = pis.exclude(feed__category__in=Feed.LOCAL_CATEGORIES)

    for pi in pis.only('id'):

        recips = list(PushSubscription.objects.filter(
                poll_instance_id=pi.id, disabled=False
            ).values_list('user_id', flat=True))

        if recips:
            body = truncate_text(poll.question)
            api.tasks.create_and_send_notifs.delay(
                notification_title=title,
                notification_copy=body,
                poll_instance_id=pi.id,
                user_ids=recips,
                notification_type=16
            )

def check_mention_notification(mention):
    poll_instance = mention.comment.poll_instance
    # if not _is_subscribed_to_poll(mention.user_id, poll_instance.id):
        # User disabled notifs for poll
        # return

    body = truncate_text(poll_instance.poll.question)
    api.tasks.create_and_send_notifs.delay(
        notification_title='mentioned you in a comment',
        notification_copy=body,
        poll_instance_id=poll_instance.id,
        user_ids=[mention.user_id],
        notification_type=17,
        from_id=mention.comment.user_id
    )

def accepted_tag_notification(tag):
    poll_instance = tag.poll_instance
    response = tag.get_tagged_user_response()
    if not response:
        title = "%s viewed your vote" % tag.friendship.friend_name
    else:
        tagged_user = response.user
        if tagged_user.gender == 0:
            pronoun = 'his'
        elif tagged_user.gender == 1:
            pronoun = 'her'
        else:
            pronoun = 'their'
        title = "%s shared %s vote with you" % (tag.friendship.friend_name, pronoun)

    body = truncate_text(poll_instance.poll.question)

    Notification = whatsgoodly.models.Notification
    notification = Notification(user=tag.friendship.user, title=title, poll_instance=poll_instance,
                                body=body, notification_type=9)
    notification.save()

    send_push_notification(notification)

def check_comment_vote_notification(comment_vote):
    CommentVote = whatsgoodly.models.CommentVote

    comment = comment_vote.comment
    if not _is_subscribed_to_poll(comment.user_id, comment.poll_instance.id):
        # User disabled notifs for poll
        return

    count = CommentVote.objects.filter(comment=comment, vote=1).count()
    if comment_vote.user_id is not comment.user_id and count in [5, 15, 50, 100]:
        title = '{} people upvoted your comment'.format(count)
        body = truncate_text(comment.text)

        Notification = whatsgoodly.models.Notification
        notification = Notification(user=comment.user, title=title, poll_instance=comment.poll_instance,
                                                                body=body, notification_type=4)
        notification.save()

        send_push_notification(notification)

def check_university_recycle_notification(poll_instance):
    uni = poll_instance.community
    original_user = poll_instance.poll.user

    if not uni:
        return

    title = 'Someone at %s recycled your poll!' % uni.name

    body = truncate_text(poll_instance.poll.question)

    Notification = whatsgoodly.models.Notification
    notification = Notification(user=original_user, title=title, poll_instance=poll_instance,
                                                            body=body, notification_type=2)
    notification.save()

    send_push_notification(notification)

def branch_install_notification(user):
    from whatsgoodly.models import *

    congrats = random.choice(congratulations_list)
    reward = User.CREDIT_REWARDS.REFER_CONTACT
    title = 'Your referral joined Whatsgoodly... You got {} coins! {}'.format(
        reward, congrats)

    # If we wanna do raffles!
    # if Announcement.objects.filter(university=user.university, ).count() > 0:
    #     points = 1
    #     body = "You won a raffle ticket! %s" % congrats
    # else:
    body = None

    # user.karma += points
    user.credits += reward
    user.save()

    notification = Notification(user=user, title=title, body=body, notification_type=8)
    notification.save()

    send_push_notification(notification)


######### HELPERS ###########

def _is_subscribed_to_poll(user_id, poll_instance_id):
    PushSubscription = whatsgoodly.models.PushSubscription
    try:
        sub = PushSubscription.objects.get(
            user_id=user_id, poll_instance_id=poll_instance_id)
        return not sub.disabled
    except PushSubscription.DoesNotExist as error:
        return False

# Needed cause not all polls have corresponding subscriptions 
# for authors auto-created
def _is_unsubscribed_to_poll(user_id, poll_instance_id):
    PushSubscription = whatsgoodly.models.PushSubscription
    try:
        sub = PushSubscription.objects.get(
            user_id=user_id, poll_instance_id=poll_instance_id)
        return sub.disabled
    except PushSubscription.DoesNotExist as error:
        return False

def _make_sns_apns_message(notification, message):
    badge_count = notification.user.notification_count
    title = u"{} {}".format(notification.get_notification_type_display(), notification.get_emoji())

    apns_dict = {
        'aps': {
            'alert': {
                'title': title,
                'body': message
            },
            'badge': badge_count
        },
        'pollId': notification.poll_instance_id or None,
        'feedId': notification.feed_id or None,
        'makePoll': notification.make_poll,
        'notificationId': notification.id
    }
    return json.dumps(apns_dict,ensure_ascii=False)

def _make_sns_gcm_message(notification, message):
    gcm_dict = {
        'data': {
            'emoji': notification.get_emoji(),
            'title': notification.get_notification_type_display(),
            'body': message,
            'pollId': notification.poll_instance_id or None,
            'feedId': notification.feed_id or None,
            'makePoll': notification.make_poll,
            'notificationId': notification.id
        }
    }
    return json.dumps(gcm_dict,ensure_ascii=False)

# def _send_ios_notification(notification):
#     # TODO deprecate
#     notification.user.notification_count += 1
#     apns = APNs(use_sandbox=settings.APNS_SANDBOX, cert_file=settings.APNS_CERT,
#                             key_file=settings.APNS_KEY, enhanced=True)
#     message = '%s %s: \"%s\"' % ( notification.get_emoji(),
#         notification.title, notification.body, )
#     args = { 'pollID': None }
#     if notification.poll_instance is not None:
#         args['pollID'] = notification.poll_instance.id

#     if notification.user.badge_count_enabled:
#         badge_count = notification.user.notification_count
#     else:
#         badge_count = 0

#     payload = Payload(alert=message, sound='default', badge=badge_count, custom=args)

#     apns.gateway_server.send_notification(notification.user.ios_apns_token, payload)
#     notification.user.save()

# def _send_android_notification(notification):
#     # TODO deprecate
#     data = {
#         'emoji': notification.get_emoji(),
#         'title': notification.title,
#         'body': notification.body or ""
#     }

#     values = {
#         'registration_ids': [notification.user.gcm_token],
#         'collapse_key': 'message' ,
#         'data': data
#     }

#     headers = {
#         'UserAgent': 'GCM-Server',
#         'Content-Type': 'application/json',
#         'Authorization': 'key=' + settings.GCM_APIKEY,
#     }

#     req = [grequests.post(url='https://android.googleapis.com/gcm/send',
#                                              data=json.dumps(values),
#                                              headers=headers,
#                                              verify=True)]
#     grequests.map(req)

#     notification.user.notification_count += 1
#     notification.user.save()
