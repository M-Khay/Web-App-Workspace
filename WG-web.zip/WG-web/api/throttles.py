from rest_framework.throttling import UserRateThrottle

class UserAuthenticationThrottle(UserRateThrottle):
  rate = '5/day'

class PollCreationThrottle(UserRateThrottle):
  rate = '10/minute'

class CommentCreationThrottle(UserRateThrottle):
  rate = '10/minute'

class ResponseCreationThrottle(UserRateThrottle):
  rate = '100/minute'

class TaggingThrottle(UserRateThrottle):
  rate = '50/minute'

class CommentVoteCreationThrottle(UserRateThrottle):
  rate = '50/minute'

class PollInstanceVoteCreationThrottle(UserRateThrottle):
  rate = '50/minute'

class PollInstanceRemovalThrottle(UserRateThrottle):
  rate = '50/minute'

class FavoriteThrottle(UserRateThrottle):
  rate = '50/minute'

class SubscriptionThrottle(UserRateThrottle):
  rate = '50/minute'

class FeedPreferenceThrottle(UserRateThrottle):
  rate = '50/minute'

class ReportCreationThrottle(UserRateThrottle):
  rate = '50/minute'

class ContactFormCreationThrottle(UserRateThrottle):
  rate = '5/minute'