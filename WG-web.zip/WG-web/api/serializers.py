from api.notifications import branch_install_notification, update_aws_arns, check_comment_notification, check_university_recycle_notification
from api.utils import is_v3, CENSOR_LEVELS, check_censored, calc_dist, in_email_domain, convert_to_point, KM_DISTANCE_FILTER, is_app_session, is_web_session, send_slack_message
from api.formatters import phone_number_formatter, domain_formatter
from api import tasks
from api import querysets
from django.contrib.gis.measure import D
from django.db.models import Q
from django.db import transaction
from datetime import datetime, timedelta
from rest_framework import serializers
from rest_framework.authtoken.models import Token
from rest_framework.validators import UniqueValidator
from whatsgoodly.models import *
from whatsgoodly import segmentations
from api.slackbots import Winston, Cabo, Shasta
import json
import random
import math
import time

EMAIL_VERIFICATION_CODE = "doggonnit"
MIN_CENSOR_FLAG_WORDS = 3

class OptionsField(serializers.Field):
  def to_internal_value(self, obj):
    if len(obj) > 4 or len(obj) < 2:
      raise serializers.ValidationError("Invalid number of options")
    return json.dumps(obj)
  def to_representation(self, obj):
    return json.loads(obj or "[]")

class VoteCountsField(serializers.Field):
  def to_internal_value(self, obj):
    if len(obj) > 4 or len(obj) < 2:
      raise serializers.ValidationError("Invalid number of vote counts")
    return json.dumps(obj)
  def to_representation(self, obj):
    return json.loads(obj)

class TokenSerializer(serializers.ModelSerializer):
  class Meta:
    model = Token
    fields = ( 'key', )


class UniversitySerializer(serializers.ModelSerializer):
  longitude = serializers.FloatField(required=True, source='get_longitude')
  latitude = serializers.FloatField(required=True, source='get_latitude')
  color = serializers.SerializerMethodField()
  name_tab = serializers.SerializerMethodField()

  def get_name_tab(self, university):
    #   return university.name_short
    return "My Feeds"

  def get_color(self, university):
    if university.primary_color:
      return university.primary_color
    else:
      # University is stored in NSUserDefaults on old app, which can't accept
      # <null>
      return ""

  def to_representation(self, university):
    if self.context.get('verify_university'):
      # Don't serialize anything (return null) if user hasn't verified
      user = self.context['request'].user
      if not user.is_anonymous() and not user.verified_university:
        return None
    return super(UniversitySerializer, self).to_representation(university)

  class Meta:
    model = University
    fields = ( 'id', 'name', 'name_short', 'name_tab', 'email_domain', 'longitude',
      'latitude', 'radius', 'color')


class UserSerializer(serializers.ModelSerializer):
  university = UniversitySerializer(required=False)
  token = TokenSerializer(source='get_token', required=False)
  age = serializers.IntegerField(source='get_age', required=False)
  rank = serializers.IntegerField(source='get_rank', required=False)
  skip_moderation = serializers.BooleanField(source='can_auto_verify_polls', required=False)

  class Meta:
    model = User
    read_only_fields = ('id', 'verified_university', 'karma', 'credits', 'university',
      'gender', 'username', 'token', 'phone_number', 'verified_phone_number',
      'full_name', 'notification_count', 'age', 'email',
      'skip_moderation', 'is_staff', 'rank' )
    fields = read_only_fields

class PublicUserSerializer(serializers.ModelSerializer):
  university_short = serializers.SerializerMethodField()
  university_name = serializers.SerializerMethodField()
  university_color = serializers.SerializerMethodField()
  rank = serializers.IntegerField(source='get_rank')
  is_admin = serializers.SerializerMethodField()

  def get_is_admin(self, user):
    return user.is_staff

  def get_university_short(self, user):
    try:
      return user.university.name_short
    except AttributeError:
      return None

  def get_university_name(self, user):
    try:
      return user.university.name
    except AttributeError:
      return None

  def get_university_color(self, user):
    try:
      return user.university.primary_color
    except AttributeError:
      return None

  class Meta(UserSerializer.Meta):
    fields = ( 'id', 'gender', 'karma', 'university_short', 'university_name',
      'university_color', 'is_admin', 'rank'  )

class KnownUserSerializer(PublicUserSerializer):

  class Meta(PublicUserSerializer.Meta):
    fields = ( 'id', 'university_short', 'university_color', 'is_admin',
      'phone_number', 'full_name', 'gender', 'username',
      'karma', 'credits', 'rank' )

class UserCreateSerializer(serializers.ModelSerializer):
  token = TokenSerializer(source='get_token', required=False)
  username = serializers.CharField(required=False, max_length=30)
  rank = serializers.IntegerField(source='get_rank', required=False)
    # TODO figure out why some clients are sending usernames
    # validators=[UniqueValidator(queryset=User.objects.all(),
    # message='User with this Username already exists.')])

  def validate_phone_number(self, phone_number):
    return phone_number_formatter(phone_number)

  def validate_gender(self, gender):
    if gender not in [-1, 0, 1]:
      print "INVALID GENDER"
      raise serializers.ValidationError("Invalid gender")
    return gender

  def validate_username(self, username):
    if username:
      raise serializers.ValidationError("You're way out of date! Please update the app")
    return username

  def create(self, validated_data):
    attrs = validated_data
    request = self.context['request']
    
    # Make a generic username unless one exists
    username = attrs.pop('username',
      "_WG_{}".format(User.objects.make_random_password())
    )

    if is_app_session(request):
      attrs['app_session'] = True
    elif is_web_session(request):
      attrs['web_session'] = True
    attrs['last_user_agent'] = request.META.get('HTTP_USER_AGENT')

    user = User.objects.create_user(username, **attrs)
    update_aws_arns(user)

    return user

  class Meta:
    model = User
    read_only_fields = ('id', 'token', 'karma', 'credits', 'is_staff', 'rank' )
    fields = read_only_fields + ( 'username', 'phone_number', 'full_name',
      'gender', 'notification_count', 'ios_apns_token', 'gcm_token',
      'denied_push_notifications', 'email' )

class UserUpdateSerializer(UserCreateSerializer):
  age = serializers.IntegerField(source='get_age', required=False)
  skip_moderation = serializers.BooleanField(source='can_auto_verify_polls', required=False)
  university = UniversitySerializer(required=False)

  def validate_age(self, age):
    if age not in dict(segmentations.AgeLevel.CHOICES).keys():
      print "INVALID AGE"
      raise serializers.ValidationError("Invalid age")
    return age

  def validate(self, attr):
    if attr.get('email'):
      if not attr.get('code') == EMAIL_VERIFICATION_CODE:
        raise serializers.ValidationError("Invalid email verification token")
    return attr

  def update(self, instance, validated_data):
    request = self.context['request']
    if is_app_session(request):
      validated_data['app_session'] = True
    elif is_web_session(request):
      validated_data['web_session'] = True
    validated_data['last_user_agent'] = request.META.get('HTTP_USER_AGENT')

    setting_phone_number = False
    if not instance.phone_number and 'phone_number' in validated_data:
      setting_phone_number = True
      validated_data['credits'] = validated_data.get('credits', 0) + User.CREDIT_REWARDS.ADD_PHONE_NUMBER

    changing_email = False
    if 'email' in validated_data and instance.email != validated_data.get('email'):
      changing_email = True
      validated_data['verified_email'] = False

    disabling_push = False
    if not instance.denied_push_notifications and validated_data.get('denied_push_notifications', False):
      disabling_push = True

    enabling_push = False
    if instance.denied_push_notifications and not validated_data.get('denied_push_notifications', True):
      enabling_push = True

    if 'ios_apns_token' in validated_data or 'gcm_token' in validated_data:
      update_aws_arns(instance, should_save=False)

    # Update the instance!
    instance = super(UserUpdateSerializer, self).update(instance, validated_data)
    # INSTANCE UPDATED!

    if setting_phone_number:
      self.did_set_phone_number(instance)

    if changing_email:
      self.did_change_email(instance)

    if disabling_push:
      self.did_disable_push(instance)

    if enabling_push:
      self.did_enable_push(instance)

    if 'get_age' in validated_data:
      instance.set_segment_response(segmentations.AgeLevel.ID, validated_data['get_age'])

    return instance

  def did_change_email(self, user):
    slack_message = "{} changed {} email!\n@{}".format(
      user, user.possessive_pronoun(), user.email.split("@")[1])
    send_slack_message(slack_message, event_name="Email", emoji=":email:")

  def did_set_phone_number(self, user):
    event_message = "joined Whatsgoodly! Send %s an anonymous poll" % user.pronoun()
    tasks.add_friends.delay(user.id)
    slack_message = "User {0} added {1} phone number!".format(
      "{0} [{1} pts]".format(user.id, user.karma),
      user.possessive_pronoun())
    send_slack_message(slack_message, event_name="Phone number", emoji=":iphone:")

  def did_disable_push(self, user):
    slack_message = "turned off push notifications"
    send_slack_message(slack_message, user=user, event_name="Push Notifications Disabled", emoji=":no_bell:")

  def did_enable_push(self, user):
    slack_message = "turned on push notifications"
    send_slack_message(slack_message, user=user, event_name="Push Notifications Enabled", emoji=":bell:")

  class Meta(UserCreateSerializer.Meta):
    read_only_fields = UserCreateSerializer.Meta.read_only_fields + (
      'username', 'university', 'verified_university',
      'skip_moderation' )
    fields = UserCreateSerializer.Meta.fields + (
      'university', 'verified_university',
      'age', 'verified_phone_number', 'skip_moderation' )

class UserMergerSerializer(serializers.ModelSerializer):
  token_key = serializers.CharField(max_length=40, write_only=True)

  def validate(self, attr):
    token_key = attr['token_key']
    user = attr['user']
    merged_user = attr['merged_user']

    if user.id == merged_user.id:
      raise serializers.ValidationError("Already signed in as that user!")

    if not Token.objects.filter(user=merged_user, key=token_key).exists():
      raise serializers.ValidationError("Not authorized to merge that account")

    if UserMerger.objects.filter(
          Q(user=user, merged_user=merged_user) | Q(user=merged_user, merged_user=user)
        ).exists():
      raise serializers.ValidationError("Already merged these users")

    # TODO flag when genders are different?
    return attr

  def create(self, validated_data):
    return UserMerger.objects.create(
        user=validated_data['user'],
        merged_user=validated_data['merged_user'],
        ip_address=validated_data['ip_address']
      )

  class Meta:
    model = UserMerger
    fields = ('user', 'merged_user', 'token_key')

class FeedSerializer(serializers.ModelSerializer):
  new_polls = serializers.SerializerMethodField()
  name = serializers.SerializerMethodField()
  # category = serializers.SerializerMethodField()

  # def get_category(self, feed):
  #   # TODO hacky, remove after 3.1.2 update
  #   if feed.category == Feed.MY_FEATURED:
  #     return Feed.CAMPUS_SCENE
  #   return feed.category

  def get_name(self, feed):
    user = self.context['request'].user
    if feed.category == Feed.CAMPUS:
      if user.university_id:
        # if len(user.university.name_short) < 4:
        #   return "{} Feeds".format(user.university.name_short)
        # else:
        return user.university.name_short
      else:
        return "My Campus"
    return feed.name

  def get_new_polls(self, feed):
    if feed.category == Feed.LOCAL:
      return 0
    request = self.context.get('request')
    if request.query_params:
      last_seen_ids = request.query_params.get('last_seen_ids', None)
      if last_seen_ids:
        last_seen_poll_id = json.loads(last_seen_ids).get(str(feed.id), None)
        if last_seen_poll_id is not None:
          try:
            last_seen_poll = PollInstance.objects.get(pk=last_seen_poll_id)
            return PollInstance.objects.filter(feed=feed, verified=True, created_date__gt=last_seen_poll.created_date).count()
          except PollInstance.DoesNotExist:
            pass
        return PollInstance.objects.filter(feed=feed, verified=True).count()
    return 0

  class Meta:
    model = Feed
    read_only_fields = ( 'id', 'name', 'image_source', 'category',
      'approve_posts', 'new_polls', 'level',
      'allow_audio', 'allow_photos', 'allow_option_photos' )
    fields = read_only_fields

class FeedInlineSerializer(serializers.ModelSerializer):
  category = serializers.SerializerMethodField()

  def get_category(self, feed):
    user = self.context['request'].user
    if not user.is_anonymous() and user.university_id and feed.category == Feed.LOCAL:
      # TODO hacky, used for preventing commenter unis from showing
      return Feed.CAMPUS
    return feed.category

  class Meta(FeedSerializer.Meta):
    read_only_fields = ( 'id', 'name', 'image_source', 'category', 'level', 'approve_posts' )
    fields = read_only_fields

class FeedPreferenceSerializer(serializers.ModelSerializer):
  feed = serializers.PrimaryKeyRelatedField(
      queryset=Feed.objects.all())

  class Meta:
    model = FeedPreference
    read_only_fields = ( 'feed', 'modified_date' )
    fields = read_only_fields + ('rank', 'disabled', )

class PushSubscriptionSerializer(serializers.ModelSerializer):
  poll_instance = serializers.PrimaryKeyRelatedField(
      queryset=PollInstance.objects.all(), required=False)

  class Meta:
    model = PushSubscription
    read_only_fields = ( 'poll_instance', 'modified_date' )
    fields = read_only_fields + ( 'disabled', )

class PollArchetypeSerializer(serializers.ModelSerializer):
  options = OptionsField()

  class Meta:
    model = PollArchetype
    read_only_fields = ( 'id', 'question', 'options' )
    fields = read_only_fields

class PollInstanceSerializer(serializers.ModelSerializer):
  poll = serializers.PrimaryKeyRelatedField(queryset=Poll.objects.all())
  response = serializers.SerializerMethodField()
  vote = serializers.SerializerMethodField()
  favorite = serializers.SerializerMethodField()
  subscription = serializers.SerializerMethodField()
  recyclable = serializers.SerializerMethodField()
  deletable = serializers.SerializerMethodField()
  top_comment = serializers.SerializerMethodField()
  voting_friends = serializers.SerializerMethodField()
  tags = serializers.SerializerMethodField()
  comment_count = serializers.SerializerMethodField()
  skipped_moderation = serializers.BooleanField(source='auto_verified')
  question = serializers.CharField(source='get_question')
  picture_question = serializers.CharField(source='get_question_picture_url')
  gender = serializers.IntegerField(source='get_gender')
  deleted = serializers.BooleanField(source='get_deleted')
  recycle_count = serializers.IntegerField(source='get_recycle_count')
  options = OptionsField(source='get_options')
  option_ordering = serializers.SerializerMethodField()
  option_counts = VoteCountsField(source='vote_counts')
  filters = serializers.SerializerMethodField()
  recycled = serializers.SerializerMethodField()
  user = PublicUserSerializer(required=False)
  feed = FeedInlineSerializer(required=False)
  # TODO deprecate, needed for school names on commenters on Global
  universal = serializers.SerializerMethodField()
  banner = serializers.SerializerMethodField()
  has_picture_options = serializers.SerializerMethodField()
  audio_options = serializers.CharField(source='get_audio_options')

  def get_has_picture_options(self, poll_instance):
    # TODO
    return False

  def get_banner(self, poll_instance):
    user = self.context['request'].user
    banner_part = poll_instance.banner + " " if poll_instance.banner else ""
    # Note: will only be true if user owns the poll
    if poll_instance.get_deleted():
      return "(Not Approved)"
    if poll_instance.get_auto_censored():
      return "{}(Pending Approval: {})".format(
          banner_part, poll_instance.poll.get_censor_level_display()
        )
    return poll_instance.banner or None

  def get_option_ordering(self, poll_instance):
    num_options = len(json.loads(poll_instance.get_options()))
    if poll_instance.poll.randomize_options:
      return random.sample(range(num_options), num_options)
    else:
      return range(num_options)

  # TODO deprecate
  def get_universal(self, poll_instance):
    if poll_instance.feed.category == Feed.GLOBAL:
      return True
    return False

  def get_filters(self, poll_instance):
    try:
      # Manually prefetched
      all_breakdowns = self.context['breakdowns']
      poll_breakdowns = [pb for pb in all_breakdowns
                            if pb.poll_id == poll_instance.poll_id]
      data = PollBreakdownSerializer(poll_breakdowns, many=True, context=self.context).data
      return sorted(data, key=lambda pb: pb['cost'])
    except KeyError:
      return []

  def get_response(self, poll_instance):
    try:
      if len(poll_instance.user_response) > 0: # prefetched
        return ResponseSerializer(poll_instance.user_response[0]).data
    except AttributeError:
      pass
    return None

  # TODO deprecate
  def get_vote(self, poll_instance):
    try:
      if len(poll_instance.user_favorite) > 0: # prefetched
        return DEPFavAsPollInstanceVoteSerializer(poll_instance.user_favorite[0], context=self.context).data
    except AttributeError:
      pass
    return None

  def get_deletable(self, poll_instance):
    return self.context['request'].user.id == poll_instance.user_id

  def get_top_comment(self, poll_instance):
    try:
      if len(poll_instance.top_comments) > 0: # prefetched
        return TopCommentSerializer(poll_instance.top_comments[0], context=self.context).data
    except AttributeError:
      pass
    return None

  def get_comment_count(self, poll_instance):
    if hasattr(poll_instance, 'top_comments'): # prefetched
      return len(poll_instance.top_comments)
    return poll_instance.comment_count

  def get_tags(self, poll_instance):
    try:
      # prefetched
      return TagSerializer(poll_instance.user_tags, many=True, context=self.context).data
    except AttributeError:
      return []

  def get_voting_friends(self, poll_instance):
    try:
      # prefetched
      responses = poll_instance.friend_responses
      users = [response.user for response in responses]
      return KnownUserSerializer(users, many=True, context=self.context).data
    except AttributeError:
      return []

  def get_favorite(self, poll_instance):
    try:
      if len(poll_instance.user_favorite) > 0: # prefetched
        return FavoriteSerializer(poll_instance.user_favorite[0], context=self.context).data
    except AttributeError:
      pass
    return None

  def get_subscription(self, poll_instance):
    try:
      if len(poll_instance.user_subscription) > 0: # prefetched
        return PushSubscriptionSerializer(poll_instance.user_subscription[0], context=self.context).data
    except AttributeError:
      pass
    return None

  def get_recyclable(self, poll_instance):
    user = self.context['request'].user
    if poll_instance.feed.category == Feed.LOCAL:
      return False
    if not poll_instance.community_id:
      return True
    return user.university_id != poll_instance.community_id

  def get_recycled(self, poll_instance):
    try:
      if len(poll_instance.user_recycles) > 0: # prefetched
        return True
    except AttributeError:
      pass
    return False

  class Meta:
    model = PollInstance
    read_only_fields = (
        'id', 'user', 'feed', 'poll',
        'options', 'option_counts', 'option_ordering',
        'created_date', 'banner', 'comment_count', 'favorite_count',
        'tag_count', 'feed', 'question', 'picture_question', 'gender',
        'tags', 'voting_friends', 'promotion', 'skipped_moderation',
        'filters', 'deletable', 
        'response', 'vote', 'favorite', 'subscription',
        'recycle_count', 'deleted',
        'recyclable', 'top_comment', 'recycled', 'vote_aggregate', 'verified',
        'universal', 'has_picture_options', 'audio_options'
      )
    fields = read_only_fields

class TimelessPollInstanceSerializer(PollInstanceSerializer):
  # created_date = serializers.SerializerMethodField()

  # def get_created_date(self, poll_instance):
  #   if is_v3(self.context['request']):
  #     return None CRASHES
  #   return poll_instance.created_date

  class Meta(PollInstanceSerializer.Meta):
    read_only_fields = tuple(
        set(PollInstanceSerializer.Meta.read_only_fields) - \
        set(['created_date']) # NOTE: crashes on v2, don't use there
      )
    fields = read_only_fields

class SegmenterInstanceSerializer(TimelessPollInstanceSerializer):
  segment_type = serializers.IntegerField(source='get_segment_type')

  class Meta(PollInstanceSerializer.Meta):
    model = SegmenterInstance
    read_only_fields = TimelessPollInstanceSerializer.Meta.read_only_fields + (
      'segment_type', ) 
    fields = read_only_fields

class PollInstanceCreateSerializer(serializers.ModelSerializer):
  latitude = serializers.FloatField(required=False, write_only=True)
  longitude = serializers.FloatField(required=False, write_only=True)
  feed = serializers.PrimaryKeyRelatedField(queryset=Feed.objects.all(), required=True)
  community = serializers.PrimaryKeyRelatedField(queryset=University.objects.all(), required=False)
  suggestion = serializers.PrimaryKeyRelatedField(queryset=PollArchetype.objects.all(), required=False, source='poll.archetype')
  question = serializers.CharField(required=True, max_length=180, source='poll.question')
  gender = serializers.IntegerField(required=True, source='poll.gender')
  options = OptionsField(required=True, source='poll.options')
  randomize_options = serializers.BooleanField(required=False, source='poll.randomize_options')
  audio_options = OptionsField(required=False, source='poll.audio_options')

  def validate(self, attr):
    lat = attr.get('latitude', None)
    lon = attr.get('longitude', None)

    if lat and lon:
      attr['location'] = convert_to_point(lat, lon)
    elif attr['feed'].category == Feed.LOCAL:
      raise serializers.ValidationError("Invalid location given")

    if attr['feed'].category == Feed.GLOBAL:
      raise serializers.ValidationError("Can't post directly to Featured feed")
    
    return attr

  def create(self, validated_data):
    data = validated_data
    user = data['user']
    data['censor_level'], censor_count = check_censored(self)
    data['deleted'] = data['censor_level'] == CENSOR_LEVELS.DELETE or user.is_banned()
    data['auto_verified'] = user.can_auto_verify_polls()

    poll_instance = PollInstance.objects.create_poll(**data)

    if poll_instance.get_auto_censored() or \
        (poll_instance.poll.censor_level == CENSOR_LEVELS.LANG_FLAG and censor_count >= MIN_CENSOR_FLAG_WORDS):
      self.notify_winston(poll_instance)

    if user.pollinstance_set.count() == 1:
      self.notify_shasta(poll_instance)

    if poll_instance.feed.approve_posts:
      self.notify_cabo(poll_instance)

    if poll_instance.feed.name == "My Survey":
      slack_message = u"User {0} made a private poll: \"{1}\"".format(
        "{0} [{1} pts]".format(user.id, user.karma),
        poll_instance.poll.question)
      send_slack_message(slack_message, event_name="Personal Poll", emoji=":pencil2:")

    if poll_instance.poll.archetype_id:
      slack_message = "made a party hat poll: <https://whatsgoodly.com/esuohgod/whatsgoodly/poll/{}/|{}>\n(based on: <https://whatsgoodly.com/esuohgod/whatsgoodly/pollarchetype/{}/|{}>)".format(
        poll_instance.poll_id, poll_instance, poll_instance.poll.archetype.pk, poll_instance.poll.archetype)
      send_slack_message(slack_message, user=poll_instance.poll.user, event_name="Party Hat Poll", emoji=":confetti_ball:")

    return poll_instance

  def notify_winston(self, poll_instance):
    title = "Poll Flagged - {}".format(poll_instance.poll.get_censor_level_display())
    body = u"from {}".format(poll_instance.user)
    if poll_instance.get_auto_censored():
      emoji = ":person_frowning:"
      title = "CENSORED: " + title
    else:
      emoji = ":speak_no_evil:"
    Winston(poll=poll_instance.poll).moderate(body, title=title, emoji=emoji)

  def notify_shasta(self, poll_instance):
    title = "First poll by user! Support it!"
    body = u"from {}".format(poll_instance.user)
    emoji = ":baby:"
    Shasta(poll_instance=poll_instance).moderate(body, title=title, emoji=emoji, should_deep_link=True)

  def notify_cabo(self, poll_instance):
    Cabo(poll_instance=poll_instance).moderate()

  class Meta:
    model = PollInstance
    fields = ( 'id', 'feed', 'gender', 'options', 'audio_options', 'question',
      'latitude', 'longitude', 'randomize_options', 'suggestion', 'community' )

class PollInstanceRecycleSerializer(serializers.Serializer):
  latitude = serializers.FloatField(required=True, write_only=True)
  longitude = serializers.FloatField(required=True, write_only=True)
  origin_poll_instance = serializers.PrimaryKeyRelatedField(queryset=PollInstance.objects.all(),
    required=True, write_only=True)
  community = serializers.PrimaryKeyRelatedField(queryset=University.objects.all(), required=False)

  def make_banner(self, poll_instance):
    if poll_instance.community:
      banner = poll_instance.community.name_short
    else:
      banner = poll_instance.feed.name
    return banner

  def validate(self, attr):
    location = convert_to_point(attr['latitude'], attr['longitude'])
    origin_poll = attr['origin_poll_instance'].poll
    nearby_recycles = PollInstance.objects.filter(poll=origin_poll)
    if attr.get('community', None):
      nearby_recycles = nearby_recycles.filter(community=attr['community'])
    else:
      nearby_recycles = nearby_recycles.filter(location__distance_lte=(location, D(km=KM_DISTANCE_FILTER * 2)))
    if nearby_recycles.exists():
      raise serializers.ValidationError("Someone has already posted that poll in your area!")
    attr['location'] = location
    return attr

  def create(self, validated_data):
    origin_poll_instance = validated_data['origin_poll_instance']
    banner = origin_poll_instance.banner or self.make_banner(origin_poll_instance)
    copy_poll_instance = PollInstance.objects.create(
      user=self.context['request'].user,
      community=validated_data.get('community', None),
      poll_id=origin_poll_instance.poll_id,
      feed=Feed.objects.get(category=Feed.LOCAL),
      location=validated_data['location'],
      ip_address=validated_data['ip_address'],
      verified=False,
      banner=banner
    )

    check_university_recycle_notification(copy_poll_instance)

    slack_message = u"recycled a poll: <https://whatsgoodly.com/esuohgod/whatsgoodly/poll/{}/|{}>".format(
      copy_poll_instance.poll_id, copy_poll_instance)
    send_slack_message(slack_message, user=copy_poll_instance.user, event_name="Poll Recycle", emoji=":recycle:")

    return copy_poll_instance

class DEPFavAsPollInstanceVoteSerializer(serializers.ModelSerializer):
  poll_instance = serializers.PrimaryKeyRelatedField(queryset=PollInstance.objects.all())
  vote = serializers.SerializerMethodField()

  def get_vote(self, favorite):
    return 1

  class Meta:
    model = Favorite
    read_only_fields = ( 'user', )
    fields = ( 'id', 'poll_instance', 'vote' )

class ResponseSerializer(serializers.ModelSerializer):
  latitude = serializers.FloatField(required=False, write_only=True)
  longitude = serializers.FloatField(required=False, write_only=True)
  poll_instance = serializers.PrimaryKeyRelatedField(queryset=PollInstance.objects.all())
  referrer = serializers.PrimaryKeyRelatedField(queryset=Referrer.objects.all(), required=False)

  def validate(self, attr):
    request = self.context['request']
    user = request.user
    poll_instance = attr['poll_instance']
    response_option = attr['response']
    referring_url = attr.get('referring_url', request.META.get('HTTP_WG_REFERRER'))

    num_options = len(json.loads(poll_instance.poll.options))
    if response_option < 0 or response_option >= num_options:
      raise serializers.ValidationError("Invalid response option")

    response = Response.objects.filter(user=user, poll_instance=poll_instance)
    if response.exists():
      raise serializers.ValidationError("User can only have one response.")

    if poll_instance.poll.gender != Poll.GENDERS.ALL and poll_instance.poll.gender != user.gender:
      raise serializers.ValidationError("You cannot respond to this poll because of your gender.")
    
    if referring_url:
      host = domain_formatter(referring_url)
      referrer, created = Referrer.objects.get_or_create(host=host)
      attr['referring_url'] = referring_url
      attr['referrer'] = referrer

    return attr

  def create(self, validated_data):
    lat = validated_data.pop('latitude', None)
    lon = validated_data.pop('longitude', None)

    if lat and lon:
      validated_data['location'] = convert_to_point(lat, lon)

    return Response.objects.create(**validated_data)

  class Meta:
    model = Response
    read_only_fields = ( 'referrer', )
    fields = read_only_fields + ( 'id', 'poll_instance', 'response',
      'referring_url', 'latitude', 'longitude' )

class FriendshipSerializer(serializers.ModelSerializer):

  def validate_phone_number(self, phone_number):
    return phone_number_formatter(phone_number)

  class Meta:
    model = Friendship
    read_only_fields = ( 'user', )
    fields = ('id', 'user', 'friend_name', 'friend_phone_number', 'created_date')

class TagSerializer(serializers.ModelSerializer):
  poll_instance = serializers.PrimaryKeyRelatedField(queryset=PollInstance.objects.all())

  # user_response = ResponseSerializer(required=False, source='get_tagger_response')
  # tagged_user_response = ResponseSerializer(required=False, source='get_tagged_user_response')

  # user = KnownUserSerializer(required=False, source='get_tagger')
  phone_number = serializers.CharField(required=False, source='get_tagged_phone_number')
  name = serializers.CharField(required=False, source='get_tagged_name')

  class Meta:
    model = Tag
    read_only_fields = ('id', 'name', 'phone_number', 'poll_instance' )
    fields = read_only_fields + ( 'accepted', 'ignored', 'saw_response', )

class TagCreateSerializer(serializers.ModelSerializer):
  friendship = serializers.PrimaryKeyRelatedField(queryset=Friendship.objects.all())
  poll_instance = serializers.PrimaryKeyRelatedField(queryset=PollInstance.objects.all())

  class Meta:
    model = Tag
    fields = ('id', 'poll_instance', 'friendship')

class MentionSerializer(serializers.ModelSerializer):
  comment = serializers.PrimaryKeyRelatedField(queryset=Comment.objects.all())
  id = serializers.SerializerMethodField()

  def get_id(self, mention):
    return mention.user_id

  class Meta:
    model = Mention
    fields = ( 'handle', 'id', 'gender', 'comment' )

class CommentSerializer(serializers.ModelSerializer):
  vote = serializers.SerializerMethodField()
  poll_instance = serializers.PrimaryKeyRelatedField(queryset=PollInstance.objects.all())
  count = serializers.IntegerField(required=True, source='vote_aggregate')
  user = PublicUserSerializer(required=False)
  deletable = serializers.SerializerMethodField()
  mentions = serializers.SerializerMethodField()
  text = serializers.SerializerMethodField()

  def get_text(self, comment):
    user = self.context['request'].user
    # Only true when comment belongs to user
    if comment.deleted:
      return comment.text + " [not approved]"
    if comment.get_auto_censored():
      return comment.text + " [pending approval: {}]".format(
          comment.get_censor_level_display()
        )
    return comment.text

  def get_vote(self, comment):
    user = self.context['request'].user
    vote = None

    try:
      if len(comment.user_vote) > 0: # prefetched
        vote = comment.user_vote[0]
    except AttributeError:
      vote = CommentVote.objects.filter(comment=comment, user=user).first()

    if vote:
      return CommentVoteSerializer(vote, context=self.context).data

    return None

  def get_mentions(self, comment):
    if hasattr(comment, 'mentions'): # prefetched
      mentions = comment.mentions
    else:
      mentions = Mention.objects.filter(comment=comment)

    return MentionSerializer(mentions, many=True, context=self.context).data

  def get_deletable(self, comment):
    user = self.context['request'].user
    return user.id == comment.user_id

  class Meta:
    model = Comment
    fields = ( 'id', 'text', 'vote', 'poll_instance', 'count', 'user',
      'created_date', 'deletable', 'mentions')

class CommentCreateSerializer(serializers.ModelSerializer):
  text = serializers.CharField(required=True, max_length=255)
  handles = serializers.ListField(
      child=serializers.DictField(), required=False, write_only=True
    )

  def create(self, validated_data):
    user_handles = validated_data.pop('handles', [])
    data = validated_data
    user = data['user']
    data['censor_level'], censor_count = check_censored(self)
    data['deleted'] = data['censor_level'] == CENSOR_LEVELS.DELETE or user.is_banned()
    comment = Comment.objects.create(**data)

    # Add mentions
    self.create_mentions(comment, user_handles=user_handles)

    if comment.get_auto_censored() or \
        (comment.censor_level == CENSOR_LEVELS.LANG_FLAG and censor_count >= MIN_CENSOR_FLAG_WORDS):
      self.notify_winston(comment)

    if user.comment_set.count() == 1:
      self.notify_shasta(comment)

    # Needs to go here, not signals, because needs to avoid double-mentioning
    # recipients
    check_comment_notification(comment)
    return comment

  def create_mentions(self, comment, user_handles=[]):
    for user_handle in user_handles:
      user_id = user_handle.get('id')
      phone_number = user_handle.get('phone_number')
      handle = user_handle['handle']
      if user_id:
        mentioned_user = User.objects.get(pk=user_id)
      elif phone_number:
        mentioned_user = User.objects.filter(phone_number=phone_number).order_by('-id').first()
      else:
        raise Exception("No user identifier sent in mention")
      if mentioned_user:
        Mention.objects.create(
            comment=comment, user=mentioned_user, handle=handle,
            gender=mentioned_user.gender
          )

  def notify_winston(self, comment):
    title = "Comment Flagged - {}".format(comment.get_censor_level_display())
    body = u"from {}".format(comment.user)
    if comment.censor_level == CENSOR_LEVELS.NAME_FLAG:
      emoji = ":person_frowning:"
      title = "CENSORED: " + title
    else:
      emoji = ":speak_no_evil:"
    Winston(comment=comment).moderate(body, title=title, emoji=emoji)

  def notify_shasta(self, comment):
    title = "First comment by user! Support it!"
    body = u"from {}".format(comment.user)
    emoji = ":baby:"
    Shasta(comment=comment).moderate(body, title=title, emoji=emoji, should_deep_link=True)

  class Meta:
    model = Comment
    fields = ('id', 'text', 'poll_instance', 'handles', )

class TopCommentSerializer(serializers.ModelSerializer):
  poll_instance = serializers.PrimaryKeyRelatedField(queryset=PollInstance.objects.all())
  user = PublicUserSerializer(required=False)

  class Meta(CommentSerializer.Meta):
    fields = ( 'id', 'text', 'poll_instance', 'user', 'created_date')

class FavoriteSerializer(serializers.ModelSerializer):
  poll_instance = serializers.PrimaryKeyRelatedField(queryset=PollInstance.objects.all())

  def validate(self, attr):
    user = self.context['request'].user
    poll_instance = attr['poll_instance']

    favorite = Favorite.objects.filter(user=user, poll_instance=poll_instance)
    if favorite.exists():
      raise serializers.ValidationError("User can only favorite a poll once.")

    return attr

  class Meta:
    model = Favorite
    read_only_fields = ( 'user', )
    fields = ( 'id', 'poll_instance' )

class PollInstanceRemovalSerializer(serializers.ModelSerializer):
  poll_instance = serializers.PrimaryKeyRelatedField(queryset=PollInstance.objects.all())

  def validate(self, attr):
    user = self.context['request'].user
    poll_instance = attr['poll_instance']

    removal = PollInstanceRemoval.objects.filter(user=user, poll_instance=poll_instance)
    if removal.exists():
      raise serializers.ValidationError("User can only remove a poll once.")

    return attr

  def create(self, validated_data):
    poll_instance = validated_data['poll_instance']
    user = validated_data['user']
    if poll_instance.poll.gender != Poll.GENDERS.ALL or \
        poll_instance.poll.gender != user.gender:
      is_downvote = False
      # TODO handle already-Responded case
    else:
      is_downvote = True
    validated_data['is_downvote'] = is_downvote
    return PollInstanceRemoval.objects.create(**validated_data)

  class Meta:
    model = PollInstanceRemoval
    read_only_fields = ( 'user', )
    fields = ( 'id', 'poll_instance' )

class CommentVoteSerializer(serializers.ModelSerializer):
  comment = serializers.PrimaryKeyRelatedField(queryset=Comment.objects.all())

  def validate(self, attr):
    user = self.context['request'].user
    comment = attr['comment']

    existing_vote = CommentVote.objects.filter(
      user=user,
      comment=comment,
      vote=attr['vote']
    )
    if existing_vote.count() > 0:
      raise serializers.ValidationError("Duplicate comment vote")

    return attr

  class Meta:
    model = CommentVote
    read_only_fields = ( 'user', )
    fields = ( 'id', 'comment', 'vote' )

class NotificationSerializer(serializers.ModelSerializer):
  emoji = serializers.CharField(source='get_emoji')

  class Meta:
    model = Notification
    read_only_fields = ('id', 'poll_instance', 'feed', 'title', 'body', 'notification_type',
      'created_date', 'emoji', 'make_poll' )
    fields = read_only_fields + ('is_read', 'opened_from_push')

class UserUniversityUpdateSerializer(serializers.ModelSerializer):
  university = serializers.PrimaryKeyRelatedField(queryset=University.objects.all())

  def validate(self, attr):
    request = self.context['request']
    user = request.user

    if user.verified_university:
      raise serializers.ValidationError("User already verified.")

    # token verification
    verification_token = request.data.get('verification_token', None)
    if verification_token:
      if not user.verification_token:
        raise serializers.ValidationError("No token exists to verify")
      if user.verification_token != verification_token:
        raise serializers.ValidationError("Invalid token")
      attr['verified_university'] = True
      attr['verified_email'] = True
      return attr

    # geographic verification
    # lat = request.data.get('latitude', None)
    # lon = request.data.get('longitude', None)
    # if lat and lon:
    #   try:
    #     lat = float(lat)
    #     lon = float(lon)
    #   except ValueError, e:
    #     raise serializers.ValidationError("Invalid location")

    #   chosen_uni = attr.get('university', None)
    #   if not chosen_uni:
    #     raise serializers.ValidationError("University required")

    #   uni_lon = chosen_uni.location.x
    #   uni_lat = chosen_uni.location.y
    #   if calc_dist(lat, lon, uni_lat, uni_lon) <= chosen_uni.radius:
    #     attr['verified_university'] = True
    #     # raise serializers.ValidationError("Not permitted to join school feed given location")
    #   return attr

    # email verification to start token verification
    email = attr.get('email', None)
    if email:
      chosen_uni = attr.get('university', None)
      if not chosen_uni:
        raise serializers.ValidationError("University required")

      uni_domain = chosen_uni.email_domain
      if not in_email_domain(email, uni_domain):
        raise serializers.ValidationError("Not permitted to join school feed given email")

      slack_message = "{} added {} email!\n@{}".format(
        user, user.possessive_pronoun(), email.split("@")[1])
      send_slack_message(slack_message, event_name="Email", emoji=":email:")
      return attr

    # Optimization for when posting
    is_posting = request.data.get('is_posting', False)
    if is_posting and is_v3(request):
      # v3 let ios users join from posting screen
      # TODO deprecate
      attr['verified_university'] = True
      return attr

    raise serializers.ValidationError("Invalid update format")

  def update(self, instance, validated_data):

    instance = super(UserUniversityUpdateSerializer, self).update(instance, validated_data)

    if instance.verified_university:
      age_level = University.LEVELS.to_age_level(instance.university.level)
      instance.set_segment_response(
        segmentations.AgeLevel.ID, age_level, changeable=False
      )

    slack_message = "User {} at *{}* {} {} school!".format(
      "{} [{} pts]".format(instance.id, instance.karma),
      instance.university.name,
      "verified" if instance.verified_university else "selected",
      instance.possessive_pronoun())
    send_slack_message(slack_message, event_name="School Connection", emoji=":school:")

    return instance

  class Meta:
    model = User
    read_only_fields = ('verified_university', )
    fields = ('university', 'email', 'verified_university')

class ReportSerializer(serializers.ModelSerializer):
  poll_instance = serializers.PrimaryKeyRelatedField(queryset=PollInstance.objects.all(), required=False)
  comment = serializers.PrimaryKeyRelatedField(queryset=Comment.objects.all(), required=False)

  def validate(self, attr):
    user = self.context['request'].user
    poll_instance = attr.get('poll_instance', None)
    comment = attr.get('comment', None)

    if poll_instance:
      report = Report.objects.filter(user=user, poll_instance=poll_instance)
      if report.count() > 0:
        raise serializers.ValidationError("User can only report a poll once.")
      return attr

    elif comment:
      report = Report.objects.filter(user=user, comment=comment)
      if report.count() > 0:
        raise serializers.ValidationError("User can only report a comment once.")
      return attr

    else:
      raise serializers.ValidationError("Must provide either a poll or comment to report.")

  def create(self, validated_data):
    request = self.context['request']
    if is_v3(request):
      # Fix report options
      validated_data['report_type'] = validated_data['report_type'] - 1
      if validated_data['report_type'] < 0:
        validated_data['report_type'] = 4

    report = super(ReportSerializer, self).create(validated_data)
    self.notify_winston(report)
    return report

  def notify_winston(self, report):
    body = u"reported by {}".format(report.user)
    if report.poll_instance:
      title = "REPORTED: Poll - {}".format(report.get_report_type_display())
      Winston(poll=report.poll_instance.poll).moderate(body, title=title)
    elif report.comment:
      title = "REPORTED: Comment - {}".format(report.get_report_type_display())
      Winston(comment=report.comment).moderate(body, title=title)

  class Meta:
    model = Report
    read_only_fields = ( 'user', )
    fields = ( 'id', 'poll_instance', 'comment', 'report_type' )


class PeekFeedSerializer(serializers.ModelSerializer):
  class Meta:
    model = PeekFeed
    read_only_fields = ( 'id', 'name', 'name_short', )
    fields = ( 'id', 'name', 'name_short', )


class AnnouncementSerializer(serializers.ModelSerializer):
  class Meta:
    model = Announcement
    fields = ( 'id', 'message', 'show_invite_button', 'image_url',
      'feed', 'university' )


class PollBreakdownSerializer(serializers.ModelSerializer):
  color = serializers.CharField(source='get_color')
  label = serializers.SerializerMethodField()
  label_short = serializers.SerializerMethodField()
  cost = serializers.SerializerMethodField()
  option_counts = VoteCountsField(source='json')
  # TODO let users vote to see results
  # segmenter = SegmenterSerializer(required=False)

  def get_cost(self, pb):
    user = self.context['request'].user
    try:
      if pb.unlocked: # prefetched
        return 0
    except AttributeError:
      pass
    return pb.get_locked_cost(user)

  def get_label(self, pb):
    t = PollBreakdown.TYPES
    switch = {
      t.UNIVERSITY: lambda: pb.university.name,
      t.SEGMENT: lambda: pb.segmenter.get_segment_label(pb.segment_option),
      t.GENDER: lambda: ["Male voters", "Female voters"][pb.gender],
      t.MOBILE: lambda: "Global results"
    }
    try:
      return switch[pb.breakdown_type]()
    except KeyError:
      return pb.get_breakdown_type_display()

  def get_label_short(self, pb):
    t = PollBreakdown.TYPES
    switch = {
      t.UNIVERSITY: lambda: pb.university.name_short,
      t.SEGMENT: lambda: pb.segmenter.get_segment_label_short(pb.segment_option),
      t.GENDER: lambda: ["Guys", "Girls"][pb.gender],
      t.MOBILE: lambda: "Global"
    }
    try:
      return switch[pb.breakdown_type]()
    except KeyError:
      return pb.get_breakdown_type_display()

  class Meta:
    model = PollBreakdown
    fields = ( 'id', 'option_counts', 'color', 'gender', 'label', 'label_short',
      'cost', 'total', 'significance' )

class PollBreakdownUnlockSerializer(serializers.Serializer):
  poll_breakdown = serializers.PrimaryKeyRelatedField(
    queryset=PollBreakdown.objects.all(),
    required=True, write_only=True)

  def validate(self, attr):
    user = self.context['request'].user
    pb = attr['poll_breakdown']

    if PollBreakdownUnlock.objects.filter(user=user, poll_id=pb.poll_id).exists():
      raise serializers.ValidationError("Already unlocked filters for poll")

    if user.credits < pb.get_locked_cost(user):
      remaining = pb.get_locked_cost(user) - user.credits
      if remaining < 5:
        # Suggest that they vote
        votes_needed = int(math.ceil(remaining/float(User.CREDIT_REWARDS.VOTE)))
        suggestion = "Vote on {} more {}!".format(
            votes_needed, ("poll" if votes_needed == 1 else "polls")
          )
      else:
        # Suggest that they tag
        tags_needed = int(math.ceil(remaining/float(User.CREDIT_REWARDS.TAG_CONTACT)))
        suggestion = "Fastest way is to tag {} more {}!".format(
          tags_needed, ("friend" if tags_needed == 1 else "friends")
        )
      raise serializers.ValidationError("You need more coins :(\n{}".format(suggestion))

    return attr

  def create(self, validated_data):
    user = self.context['request'].user
    pb = validated_data['poll_breakdown']
    user.credits -= pb.get_locked_cost(user)
    pb_unlock = PollBreakdownUnlock(user=user, poll_id=pb.poll_id)

    with transaction.atomic():
      user.save()
      pb_unlock.save()

    return pb

class FirebasePollInstanceSerializer(serializers.ModelSerializer):
  WG = serializers.SerializerMethodField()
  question = serializers.SerializerMethodField()
  options = serializers.SerializerMethodField()
  domain = serializers.SerializerMethodField()
  createdAt = serializers.SerializerMethodField()
  location = serializers.SerializerMethodField()

  def get_WG(self, poll_instance):
    return {
      'id': poll_instance.id,
      'pollID': poll_instance.poll_id,
      'userID': poll_instance.user_id,
    }

  def get_domain(self, poll_instance):
    if poll_instance.community_id:
      domain = poll_instance.community.email_domain
      if domain[0] == "@":
        domain = domain[1:]
      return domain
    return None

  def get_question(self, poll_instance):
    return poll_instance.poll.question

  def get_options(self, poll_instance):
    return [
      {'index': i, 'name': option, 'votes': 0}
      for i, option in enumerate(
          json.loads(poll_instance.poll.options)
      )
    ]

  def get_createdAt(self, poll_instance):
    return time.mktime(poll_instance.created_date.timetuple())

  def get_location(self, poll_instance):
    return {
      'latitude': poll_instance.location.y,
      'longitude': poll_instance.location.x
    }

  class Meta:
    model = PollInstance
    fields = ('WG', 'domain', 'createdAt', 'location', 'options', 'question',)

"""
TO DEPRECATE
"""

class DEP_NotificationSerializer(serializers.ModelSerializer):
  emoji = serializers.CharField(source='get_emoji')
  poll = serializers.SerializerMethodField()

  def get_poll(self, notification):
    if notification.poll_instance is not None:
      return notification.poll_instance.id
    return None

  class Meta:
    model = Notification
    read_only_fields = ()
    fields = ( 'id', 'poll_instance', 'title', 'body', 'notification_type',
      'created_date', 'emoji', 'poll', )

"""
Passes auth token and karma to support legacy /user/info endpoint
"""
class DEP_UserInfoSerializer(serializers.ModelSerializer):
  token = TokenSerializer(source='get_token', required=False)
  university = UniversitySerializer(required=False)
  poll_count = serializers.SerializerMethodField()
  comment_count = serializers.SerializerMethodField()
  username = serializers.CharField(required=True)

  def get_poll_count(self, user):
    return PollInstance.objects.undeleted().filter(user=user).count()

  def get_comment_count(self, user):
    return Comment.objects.filter(user=user, deleted=False, poll_instance__deleted=False).count()

  class Meta:
    model = User
    read_only_fields = ('verified_university',)
    fields = read_only_fields + ( 'id', 'username', 'token', 'gender', 'karma', 'credits',
           'ios_apns_token', 'gcm_token', 'notification_count', 'university',
           'poll_count', 'comment_count' )

class DEP_CommentSerializer(serializers.ModelSerializer):
  vote = serializers.SerializerMethodField()
  poll = serializers.SerializerMethodField()
  count = serializers.IntegerField(required=True, source='vote_aggregate')
  user = PublicUserSerializer(required=False)
  deletable = serializers.SerializerMethodField()

  def get_vote(self, comment):
    user = self.context['request'].user

    try:
      vote = CommentVote.objects.filter(comment=comment, user=user)
      if vote.count() > 0:
        return CommentVoteSerializer(vote[0]).data
    except CommentVote.DoesNotExist:
      pass
    return None

  def get_deletable(self, comment):
    user = self.context['request'].user
    return user.id == comment.user_id

  def get_poll(self, comment):
    return comment.poll_instance.id

  class Meta:
    model = Comment
    fields = ( 'id', 'text', 'vote', 'poll', 'count', 'user',
      'created_date', 'deletable')
