######## NOTE #########
# These functions should NOT hit the database, only
# build QuerySets, without evalutating them!

from django.db.models import Count, F, Q, Max, Sum, Prefetch, Value, BooleanField, CharField, Case, When, ExpressionWrapper, IntegerField, Func
from django.db.models.expressions import RawSQL
from django.contrib.gis import geos
from django.contrib.gis.measure import D
from django.conf import settings
from django.utils import timezone
from datetime import datetime, timedelta
from api.utils import CENSOR_LEVELS, KM_DISTANCE_FILTER, FEED_KM_DISTANCE_FILTER, calc_dist, convert_to_point
from api.constant_lists import stop_words
from whatsgoodly.models import *
from whatsgoodly.utils import decayed_score_sql, CastToString
from whatsgoodly import analytics
from whatsgoodly import segmentations
import pytz

POLL_PAGE_SIZE = 20
FILTERS = dict(all=None, guys=0, girls=1, user_made=3, favorited=4)

class POLL_FEED_ORDER:
    # TODO handle favorited
    UNVOTED, VOTED, RECENT, TOP, RECENT_TOP, FAVORITED = range(6)

class FEED_ORDER:
    RECENT, FEATURED_FEEDS, CAMPUS_SCENES = range(3)

# TODO ordering
def search_poll_instances(query, queryset = None):
    queryset = queryset if queryset is not None else PollInstance.objects.undeleted()
    for word in query.split():
        if word in stop_words:
            continue
        if word[0] == "#":
            tag = word[1:]
            queryset = queryset.filter(
                Q(poll__tags__label_lower__istartswith=tag) |
                Q(poll__tags__parent__label_lower__istartswith=tag)
            )
        else:
            queryset = queryset.filter(
                Q(poll__question__icontains=word) |
                Q(poll__options__icontains=word) |
                Q(community__name__icontains=word) |
                Q(community__name_short__icontains=word)
            )
    return queryset

def search_poll_instances_queryset(user, query, feed_category, order=POLL_FEED_ORDER.TOP):
    queryset = PollInstance.objects.allowed(user)

    if feed_category in Feed.CAMPUS_ONLY_CATEGORIES:
      if not user.university_id or user.university_id in DISABLED_UNIVERSITY_IDS:
        return PollInstance.objects.none()
      queryset = queryset.filter(
          Q(community=user.university) | Q(location__distance_lte=(user.university.location, D(km=FEED_KM_DISTANCE_FILTER)))
        ).filter(
          feed__category__in=Feed.LOCAL_CATEGORIES,
        ).filter(
          Q(poll__censor_level__in=CENSOR_LEVELS.ALLOWED) | Q(verified=True) | Q(user=user)
        )
    else:
      queryset = queryset.filter(
          feed__category__in=Feed.EXPLORE_CATEGORIES
        ).filter(
          Q(verified=True) | Q(auto_verified=True) | Q(user=user)
        )
      
    queryset = search_poll_instances(query, queryset)

    if order == POLL_FEED_ORDER.TOP:
        queryset = queryset.order_by(
                '-vote_weight', 'poll_id'
            ).distinct('vote_weight', 'poll_id')
    else:
        raise Exception("Ordering not implemented: {0}".format(order))

    return queryset

def notifications(user):
    queryset = Notification.objects.filter(user=user).filter(
        Q(poll_instance__deleted=False, poll_instance__poll__deleted=False) |
        Q(poll_instance__isnull=True)
    ).order_by('-id')

    return queryset

def poll_instance_prefetch(pk, user):
    query = SegmenterInstance.objects.filter(pk=pk)
    if not query.exists():
        query = PollInstance.objects.filter(pk=pk)
        
    query = query.filter(
        Q(deleted=False, poll__deleted=False) |
        Q(user=user, deleted_by_creator=False)
    )

    query = poll_instance_user_related(query, user)

    return query

def should_include_pinned_polls(feed_category, filtering, order):
    return not filtering and \
      order in (POLL_FEED_ORDER.UNVOTED, POLL_FEED_ORDER.RECENT) and \
      feed_category >= 0

def poll_instances_queryset(user, order, feed_category, feed, other_user_id=None, lat=None, lon=None, filtering=None):
    location = convert_to_point(lat, lon) if lat and lon else None
    admin_id = dict(settings.ADMIN_IDS).get('Whatsgoodly')

    user_removed = PollInstanceRemoval.objects.filter(
            Q(user=user) | Q(user_id=other_user_id)
        ).values('poll_instance_id')

    queryset = PollInstance.objects.allowed(user)

    if feed_category != Feed.USER_POLLS:
        queryset = queryset.exclude(
            id__in=user_removed
        )

    if should_include_pinned_polls(feed_category, filtering, order):
        # Include in a separate query afterwards
        queryset = queryset.exclude(
            promotion__in=[PollInstance.PROMOTIONS.PINNED, PollInstance.PROMOTIONS.POLL_OF_WEEK] #, PollInstance.PROMOTIONS.HOT, SPONSORED
        ).exclude(
            segmenterinstance__isnull=False
        )

    if user.university_id in UNIVERSITY_IDS_WITH_NAME_CENSORSHIP:
        queryset = queryset.filter(
            Q(poll__censor_level__in=CENSOR_LEVELS.ALLOWED) | Q(poll__verified=True) | Q(verified=True) | Q(user=user)
        )

    if feed_category in Feed.LOCAL_CATEGORIES:
        queryset = queryset.exclude(community_id__in=DISABLED_UNIVERSITY_IDS)

    queryset = _filter_poll_instances(queryset, user, filtering)

    if feed_category == Feed.LOCAL:
        queryset = queryset.filter(
            feed=feed,
            location__distance_lte=(location, D(km=KM_DISTANCE_FILTER))
        )

    elif feed_category == Feed.CAMPUS:
        queryset = queryset.filter(
            feed=feed,
            community_id=user.university_id
        )

    elif feed_category in [Feed.CAMPUS_SCENE, Feed.CAMPUS_PEEK]:
        queryset = queryset.filter(
            feed=feed
        )

    elif feed_category == Feed.GLOBAL:
        queryset = queryset.filter(feed=feed)

    elif feed_category in [Feed.FEATURED, Feed.MY_FEATURED]:
        queryset = queryset.filter(feed=feed)
        if feed.approve_posts:
            # SHADOW APPROVAL: Show user their own polls even if not verified
            queryset = queryset.filter(
                Q(verified=True) | Q(poll__verified=True) | Q(auto_verified=True) | Q(user=user)
            )

    # elif feed.name == "My Survey":
    #     one_week_ago = datetime.now() - timedelta(days=7)
    #     queryset = queryset.filter(
    #             feed=feed,
    #             user_id=(other_user_id or user.id)
    #             # If we wanna include tags | Q(
    #             #     tag__friendship__friend_phone_number__isnull=False,
    #             #     tag__friendship__friend_phone_number=user.phone_number
    #             # )
    #     queryset = _order_poll_instances(queryset, order, user, feed_category)

    elif feed_category == Feed.USER_POLLS:
        queryset = queryset.filter(user=user)

    elif feed_category == Feed.USER_COMMENTS:
        queryset = queryset.filter(
                id__in=Comment.objects.filter(user=user, deleted_by_creator=False).values('poll_instance_id')
            )

    elif feed_category == Feed.USER_FAVORITES:
        queryset = queryset.filter(
                id__in=Favorite.objects.filter(user=user).values('poll_instance_id')
            ) # .order_by('-favorite__id')
    else:
        raise Exception("Unrecognized feed category: {0}".format(feed_category))

    queryset = _order_poll_instances(queryset, order, user, feed_category)
    queryset = poll_instance_user_related(queryset, user, feed_category=feed_category)
    return queryset

def segmentation_instances_queryset(user, feed):
    # NOTE: Only shows local segmenters if user's karma isn't low
    # and if user has connected a university

    if user.karma < User.MIN_KARMA_FOR_SEGMENTATIONS:
        return SegmenterInstance.objects.none()

    queryset = SegmenterInstance.objects.allowed(user).filter(
            feed=feed
        ).exclude(
            Q(poll__in=Response.objects.filter(user=user).values('poll_instance__poll')) |
            Q(poll__in=PollInstanceRemoval.objects.filter(user=user).values('poll_instance__poll'))
        )

    if feed.category in Feed.LOCAL_CATEGORIES:
        queryset = queryset.filter(community_id=user.university_id)

    # Remove polls where user is ineligible
    conditions = PollCondition.objects.filter(dependent_poll__in=queryset.values('poll'))
    ineligible_poll_ids = [
        condition.dependent_poll_id
        for condition in conditions
        if not condition.is_eligible(user) ]
    queryset = queryset.exclude(poll_id__in=ineligible_poll_ids)

    # Reverse ordering so that primary and secondary tabs
    # dont show the same poll for polls posted to both
    # (unless it's the last one)
    if feed.category == Feed.LOCAL:
        queryset = queryset.order_by('segmenter__segment_type')
    else:
        queryset = queryset.order_by('-segmenter__segment_type')

    queryset = poll_instance_user_related(queryset, user, feed_category=feed.category)
    return queryset

def pinned_poll_instances_queryset(user, feed, include_sponsored=False):
    promos = PollInstance.PROMOTIONS

    promotion_filters = Q(promotion__in=[promos.PINNED, promos.POLL_OF_WEEK])
    if include_sponsored:
        promotion_filters |= Q(promotion=promos.SPONSORED)

    queryset = PollInstance.objects.allowed(user).filter(promotion_filters).filter(
            feed=feed
        ).exclude(
            Q(poll__in=Response.objects.filter(user=user).values('poll_instance__poll')) |
            Q(poll__in=PollInstanceRemoval.objects.filter(user=user).values('poll_instance__poll'))
        )

    if feed.category in Feed.LOCAL_CATEGORIES:
        queryset = queryset.filter(community_id=user.university_id)

    if include_sponsored:
        # Remove polls where user is ineligible
        conditions = PollCondition.objects.filter(dependent_poll__in=queryset.values('poll'))
        ineligible_poll_ids = [
            condition.dependent_poll_id
            for condition in conditions
            if not condition.is_eligible(user) ]
        queryset = queryset.exclude(poll_id__in=ineligible_poll_ids)

    queryset = poll_instance_user_related(queryset, user, feed_category=feed.category)
    return queryset

def fire_poll_instances_queryset(user, feed, lat=None, lon=None):
    queryset = PollInstance.objects.allowed(user).filter(
            feed=feed,
            promotion=PollInstance.PROMOTIONS.HOT
        ).filter(
            Q(poll__gender=Poll.GENDERS.ALL) | Q(poll__gender=user.gender)
        )

    if feed.category in Feed.LOCAL_CATEGORIES:
        if lat and lon and feed.category == Feed.LOCAL:
            location = convert_to_point(lat, lon)
            queryset = queryset.filter(location__distance_lte=(location, D(km=KM_DISTANCE_FILTER)))
        else:
            queryset = queryset.filter(community_id=user.university_id)

    # Fire polls disappear once you vote on them
    queryset = queryset.exclude(
        Q(poll__in=Response.objects.filter(user=user).values('poll_instance__poll')) |
        Q(poll__in=PollInstanceRemoval.objects.filter(user=user).values('poll_instance__poll'))
    ).order_by('-id')

    queryset = poll_instance_user_related(queryset, user, feed_category=feed.category)
    return queryset

def prefetch_and_paginate(page, queryset, user):
    queryset = poll_instance_user_related(queryset, user)
    return poll_instances_paginated_for_queryset(queryset, page)

def poll_instances_paginated(page, *args, **kwargs):
    queryset = poll_instances_queryset(*args, **kwargs)
    return poll_instances_paginated_for_queryset(queryset, page)

def poll_instances_paginated_for_queryset(queryset, page=1):
    page = int(page) or 1
    start = POLL_PAGE_SIZE * (page - 1)
    end = POLL_PAGE_SIZE * page
    return queryset[start:end]

def comments(user, poll_instance):
    queryset = Comment.objects.filter(poll_instance=poll_instance)

    if poll_instance.feed.category in Feed.LOCAL_CATEGORIES and \
            user.university_id in UNIVERSITY_IDS_WITH_NAME_CENSORSHIP:
        queryset = queryset.filter(
            Q(censor_level__in=CENSOR_LEVELS.ALLOWED) | Q(verified=True) | Q(user=user)
        )

    # My featured feed fix:
    # if poll_instance.feed.category == Feed.MY_FEATURED and user.university:
    #     queryset = queryset.filter(
    #             user__university__level=user.university.level
    #         )

    # SHADOW BANNING: Include user's comments
    queryset = queryset.filter(
        Q(deleted=False) | Q(user=user, deleted_by_creator=False)
    ).order_by('id')

    queryset = comment_user_related(queryset, user)
    return queryset

def feeds(user, order=FEED_ORDER.CAMPUS_SCENES, level=Feed.LEVELS.COLLEGE,
          exclude_peek=False, location=None, included_feed_ids=[]):
    queryset = Feed.objects.filter(active=True)
    # TODO: post-college
    if level not in (Feed.LEVELS.HIGH_SCHOOL, Feed.LEVELS.COLLEGE):
        level = Feed.LEVELS.COLLEGE
    # Level filter
    queryset = queryset.filter(
        Q(level=level) | Q(level=Feed.LEVELS.ALL_SCHOOL) | Q(level=Feed.LEVELS.ALL_AGES)
    )
    # Location filter
    if location:
        queryset = queryset.filter(
            Q(location=None) | Q(location__distance_lte=(location, D(km=FEED_KM_DISTANCE_FILTER)))
        )
    if location and user.university:
        # Exclude Local feed if near school
        dist_from_school = calc_dist(
                location.y, location.x,
                user.university.location.y, user.university.location.x
            )
        if dist_from_school < KM_DISTANCE_FILTER:
            queryset = queryset.exclude(category=Feed.LOCAL)

    # TODO remove:
    if user.last_user_agent and "3.2.2 (iPhone" in user.last_user_agent:
        queryset = queryset.exclude(category=Feed.LOCAL)

    # Campus Scene filter
    if not user.university:
        queryset = queryset.exclude(category=Feed.CAMPUS_SCENE)
    else:
        queryset = queryset.exclude(
                Q(category=Feed.CAMPUS_SCENE) & ~Q(id__in=user.university.local_feeds.values('id'))
            )

    if exclude_peek:
        queryset = queryset.exclude(category__in=[Feed.CAMPUS_PEEK])

    # Lastly, remove feeds where user is ineligible
    conditions = FeedCondition.objects.filter(feed__in=queryset)
    ineligible_feed_ids = [
        condition.feed_id
        for condition in conditions
        if not condition.is_eligible(user)
    ]
    # TODO remove included_feed_ids, auto-add user to the feedcondition before this func
    queryset = queryset.exclude(
        Q(id__in=ineligible_feed_ids) & ~Q(id__in=included_feed_ids)
    )

    # Use LA's day change
    now = timezone.localtime(timezone.now(), timezone=pytz.timezone("America/Los_Angeles"))
    one_week_ago = now - timedelta(days=7)

    if order == FEED_ORDER.RECENT:
        ordering = ('category', '-id', )

    elif order == FEED_ORDER.CAMPUS_SCENES:

        queryset = queryset.annotate(
            user_rank=RawSQL("""
                SELECT rank FROM whatsgoodly_feedpreference
                WHERE whatsgoodly_feedpreference.feed_id = whatsgoodly_feed.id
                    AND whatsgoodly_feedpreference.user_id = %s
                """, [user.id]),
            
            category_rank=Case(
                # First tab
                When(category=Feed.CAMPUS, then=Value(0)),
                When(category=Feed.CAMPUS_SCENE, then=Value(1)),
                When(category=Feed.MY_FEATURED, then=Value(2)),

                # Second tab
                When(category=Feed.GLOBAL, then=Value(0)),
                When(category=Feed.LOCAL, then=Value(1)),
                When(category=Feed.CAMPUS_PEEK, then=Value(2)),

                default=Value(10),
                output_field=IntegerField()
            ),

            is_recent=Case(
                When(created_date__gte=one_week_ago, then=Value(True)),
                default=Value(False),
                output_field=BooleanField()
            )
        )

        ordering = ('user_rank', 'category_rank', '-is_recent', 'id')

    elif order == FEED_ORDER.FEATURED_FEEDS:

        queryset = queryset.annotate(
            user_vote_count=RawSQL("""
                SELECT COUNT(*) FROM whatsgoodly_response
                INNER JOIN whatsgoodly_pollinstance ON whatsgoodly_pollinstance.id = whatsgoodly_response.poll_instance_id
                WHERE whatsgoodly_pollinstance.feed_id = whatsgoodly_feed.id
                    AND whatsgoodly_response.user_id = %s
                """, [user.id])
            
        )

        today = Feed.PROMOTION_DAYS.from_day(now)
        queryset = queryset.annotate(
            is_promoted=Case(
                When(promotion_day=today, then=Value(True)),
                default=Value(False),
                output_field=BooleanField()
            ),
            is_recent=Case(
                When(created_date__gte=one_week_ago, then=Value(True)),
                default=Value(False),
                output_field=BooleanField()
            )
        )
        ordering = ('-is_promoted', 'category',
            '-is_recent', '-user_vote_count')

    else:
        raise Exception("Unrecognized feed ordering: %s" % order)

    queryset = queryset.order_by(*ordering)
    return queryset

def poll_instance_user_related(queryset, user, feed_category=None):
    friends_numbers = Friendship.objects.filter(user=user)\
        .values_list('friend_phone_number', flat=True)

    comments = Comment.objects.filter(deleted=False)\
                    .select_related('user', 'user__university')\
                    .order_by('-vote_aggregate')
                    # TODO this is returning the full set, dunno why
                    # .annotate(max_va=Max('vote_aggregate'))\
                    # .filter(vote_aggregate=F('max_va'))\

    # My featured feed fix:
    # if user.university and feed_category == Feed.MY_FEATURED:
    #     comments = comments.filter(user__university__level=user.university.level)

    return queryset.select_related(
            'feed', 'poll', 'user', 'user__university'
        ).prefetch_related(
            Prefetch(
                'favorite_set',
                queryset=Favorite.objects.filter(user=user),
                to_attr='user_favorite'
            ),
            Prefetch(
                'pushsubscription_set',
                queryset=PushSubscription.objects.filter(user=user),
                to_attr='user_subscription'
            ),
            Prefetch(
                'response_set',
                queryset=Response.objects.filter(user=user),# , status=Response.STATUSES.NONE),
                to_attr='user_response'
            ),
            Prefetch(
                'comment_set',
                queryset=comments,
                to_attr='top_comments'
            ),
            # for getting friend responses
            # Prefetch(
            #     'response_set',
            #     queryset=Response.objects.filter(
            #             user__phone_number__in=friends_numbers
            #         ).select_related('user', 'user__university'),
            #     to_attr='friend_responses'
            # ),

            # For prefetching recycles (unnecessary)
            # Prefetch(
            #     'poll__instances',
            #     queryset=PollInstance.objects.filter(user=user),
            #     to_attr='user_recycles'
            # ),

            # For getting previous tags
            # Prefetch(
            #     'tag_set',
            #     queryset=Tag.objects.filter(
            #             friendship__user=user
            #         ).select_related('friendship'),
            #     to_attr='user_tags'
            # ),

            # For comparing votes
            # Prefetch(
            #     'tag_set',
            #     queryset=Tag.objects.select_related(
            #             'friendship', 'friendship__user', 'friendship__user__university'
            #         ).filter(
            #             accepted=False, ignored=False,
            #             friendship__friend_phone_number=user.phone_number
            #         ).order_by('-id'),
            #     to_attr='tagged_me'
            # ),
            # Prefetch(
            #     'tag_set',
            #     queryset=Tag.objects.select_related(
            #             'friendship', 'friendship__user', 'friendship__user__university'
            #         ).filter(
            #             accepted=True, saw_response=False,
            #             friendship__user=user
            #         ).order_by('-id'),
            #     to_attr='accepted_tags'
            # )
        )

# Removed this from Prefetch in poll_instance_user_related
# cause Django wasn't adding breakdowns to the to_attr
# NOTE: will evaluate poll_instance_list if it's a QuerySet!
def poll_breakdowns(poll_instance_list, user, feed=None):
    if not poll_instance_list:
        return PollBreakdown.objects.none()

    breakdowns = PollBreakdown.objects.filter(
        poll_id__in=[p.poll_id for p in poll_instance_list]
    ).exclude(
        Q(breakdown_type=PollBreakdown.TYPES.WEB) |
        Q(segmenter__deleted=True)
    )

    threshold = analytics.MIN_SAMPLE_SIZE / 2
    friend_threshold = analytics.MIN_SAMPLE_SIZE_FRIENDS

    if feed:
        breakdowns = breakdowns.annotate(
            opt=CastToString('segment_option')
        ).exclude(
            Q(segmenter__isnull=False) &
            (~Q(segmenter__in=feed.allowed_breakdowns.all()) |
              Q(segmenter__option_indices_excluded_from_breakdowns__contains=F('opt'))
            )
        )
        
        if feed.category in Feed.LOCAL_CATEGORIES:
            # CAMPUS FEEDs
            # Exclude on non-unique instances and global filter
            breakdowns = breakdowns.exclude(
                Q(poll__recycle_count__gt=1) |
                Q(breakdown_type=PollBreakdown.TYPES.MOBILE)
            ).filter(
                Q(total__gte=threshold) |
                Q(breakdown_type=PollBreakdown.TYPES.UNIVERSITY,
                  university_id=user.university_id,
                  total__gte=friend_threshold)
            )
        else:
            # EXPLORE FEEDs
            # or singleton poll (feed_category is None)
            # Exclude global results
            breakdowns = breakdowns.exclude(
                breakdown_type=PollBreakdown.TYPES.MOBILE
            ).filter(
                # (~Q(breakdown_type__in=[PollBreakdown.TYPES.GENDER, PollBreakdown.TYPES.SEGMENT]) &
                Q(total__gte=threshold) # ) |
                # Q(segment_total__gte=threshold)
            )

    breakdowns = breakdowns.annotate(
        # segment_total=RawSQL("""
        #     SELECT MIN(total) FROM whatsgoodly_pollbreakdown AS pb
        #     WHERE pb.poll_id = whatsgoodly_pollbreakdown.poll_id
        #       AND pb.segmenter_id = whatsgoodly_pollbreakdown.segmenter_id
        #       AND pb.gender = whatsgoodly_pollbreakdown.gender
        #       AND pb.breakdown_type IN (%s, %s)
        #     """, [PollBreakdown.TYPES.GENDER, PollBreakdown.TYPES.SEGMENT]),

        unlocked=RawSQL("""
            SELECT EXISTS(SELECT 1 FROM whatsgoodly_pollbreakdownunlock
            WHERE whatsgoodly_pollbreakdownunlock.poll_id = whatsgoodly_pollbreakdown.poll_id
              AND whatsgoodly_pollbreakdownunlock.user_id = %s)
            """, [user.id]),

        type_order=Case(
            # Move custom segs to front
            When(Q(segmenter__segment_type=0, segment_option__lte=1), then=Value(True)),
            # Move global, gender to front
            When(breakdown_type__in=[PollBreakdown.TYPES.MOBILE, PollBreakdown.TYPES.GENDER], then=Value(True)),
            default=Value(False),
            output_field=BooleanField()
        )
    )

    # TODO
    # merge segment breakdowns with same short_label!

    return breakdowns.select_related(
            'segmenter', 'university', 'poll'
        ).order_by(
            '-promotion', '-type_order', 'breakdown_type', '-gender', 'segmenter__segment_type', 'segmenter_id', 'segment_option'
        )

# Removed this from Prefetch in poll_instance_web_user_related
# cause Django wasn't adding breakdowns to the to_attr
def poll_breakdowns_web(poll_instance_list, user=None):
    breakdowns = PollBreakdown.objects.filter(
            breakdown_type__in=[PollBreakdown.TYPES.MOBILE, PollBreakdown.TYPES.WEB],
            poll_id__in=[p.poll_id for p in poll_instance_list]
        ).select_related(
            'segmenter', 'university', 'poll'
        ).order_by('breakdown_type')
    return breakdowns

def survey_polls_web(survey):
    return survey.polls.annotate(
            total_comment_count=Sum('instances__comment_count')
        ).prefetch_related(
            Prefetch(
                'breakdowns',
                queryset=PollBreakdown.objects.order_by('breakdown_type'),
                to_attr='web_breakdowns'
            )
        ).order_by('id')

def poll_instance_web_user_related(queryset, user=None):
    queryset = queryset.select_related(
            'poll', 'user', 'user__university'
        )
    if user and user.is_authenticated():
        response_filter = Q(user=user) #, status=Response.STATUSES.NONE)
        merger = UserMerger.objects.filter(merged_user=user).first()
        if merger:
            # Add in responses from corresponding mobile user
            response_filter = response_filter | Q(user=merger.user)

        queryset = queryset.prefetch_related(
            Prefetch(
                'response_set',
                queryset=Response.objects.filter(response_filter),
                to_attr='user_response'
            )
        )
    return queryset

def poll_instance_dashboard_related(queryset):
    return queryset.select_related('poll').prefetch_related(
        Prefetch(
            'report_set',
            queryset=Report.objects.all(),
            to_attr='reports'
        ),
        Prefetch(
            'poll__tags',
            queryset=PollTag.objects.all(),
            to_attr='poll_tags'
        )
    )

def comment_user_related(queryset, user):
    return queryset.select_related('user', 'user__university').prefetch_related(
        Prefetch(
            'mention_set',
            queryset=Mention.objects.all(),
            to_attr='mentions'
        ),
        Prefetch(
            'commentvote_set',
            queryset=CommentVote.objects.filter(user=user),
            to_attr='user_vote'
        )
    )

def _filter_poll_instances(queryset, user, filtering):
    # TODO index gender if gender filtering is frequent
    # TODO allow multiple filters
    if filtering == FILTERS['guys']:
        queryset = queryset.filter(user__gender=0)

    elif filtering == FILTERS['girls']:
        queryset = queryset.filter(user__gender=1)

    elif filtering == FILTERS['user_made']:
        admin_id = dict(settings.ADMIN_IDS).get('Whatsgoodly')
        queryset = queryset.exclude(user_id=admin_id)

    elif filtering == FILTERS['favorited']:
        queryset = queryset.filter(
                id__in=Favorite.objects.filter(user=user).values('poll_instance_id')
            )

    elif filtering is not None:
        raise Exception("Unrecognized poll filter: %s" % filtering)

    return queryset

def _order_poll_instances(queryset, order, user, feed_category):

    if order in (POLL_FEED_ORDER.RECENT, POLL_FEED_ORDER.UNVOTED):
        return queryset.order_by('-created_date')

    elif order == POLL_FEED_ORDER.VOTED:
        return queryset.filter(
                pk__in=Response.objects.filter(user=user).values('poll_instance_id')
            ).order_by('-response__id')

    elif order == POLL_FEED_ORDER.TOP:
        # TODO sort by favorite_count
        return queryset.order_by('-vote_weight')

    elif order == POLL_FEED_ORDER.RECENT_TOP:
        # TODO sort by favorite_count
        this_month = datetime.now().date() - timedelta(30)
        return queryset.filter(
                created_date__gte=this_month
            ).order_by('-vote_weight')

    else:
        raise Exception("Unrecognized poll ordering: %s" % order)

