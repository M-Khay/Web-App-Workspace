# -*- coding: utf-8 -*-

# A slackbot is a good boy

import grequests
import json
import re
from django.conf import settings
from django.utils import timezone
from api import notifications, utils, tasks
from dashboard.push import CustomPush

BRANCH_URL = "https://api.branch.io/v1/url"
HOURS_TO_PIN = 24
# Needs to be generated via oauth flow
WINSTON_SLACK_WEBHOOK_URL = "https://hooks.slack.com/services/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"
SHASTA_SLACK_WEBHOOK_URL = "https://hooks.slack.com/services/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"
GUPTA_SLACK_WEBHOOK_URL = "https://hooks.slack.com/services/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"
CABO_SLACK_WEBHOOK_URL = "https://hooks.slack.com/services/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"
# TODO what's this for?
WINSTON_SLACK_ACCESS_TOKEN = "xoxp-3996905789-19607748769-95750071685-fe5e4a4057ecee44da91f67ffe1ebe59"
SHASTA_SLACK_ACCESS_TOKEN = "xoxp-3996905789-19607748769-137050544262-cf2191930367219b638e36f99d1cb212"
GUPTA_SLACK_ACCESS_TOKEN = "xoxp-3996905789-19607748769-97872898610-7078e8054ea2b1ce3aed869bad1f223a"
CABO_SLACK_ACCESS_TOKEN = "xoxp-3996905789-19607748769-117534683456-069f36b132ef988255106f07e74e7b55"

UNIVERSAL_NOTIFICATION_ID = 0

class BaseSlackbot:

  def __init__(self, poll=None, comment=None, poll_instance=None):
    self.poll = poll
    self.poll_instance = poll_instance
    if self.poll_instance:
      self.poll = self.poll_instance.poll
    self.comment = comment

  def get_actions(self):
    # SUBCLASS impl
    return []

  def get_url(self):
    # SUBCLASS impl
    return None

  # Not reliable, Branch...
  def _async_deep_link(self, poll_instance_id, hooks):
    req = grequests.post(
      url=BRANCH_URL,
      data=json.dumps({
        'branch_key': settings.BRANCH_KEY,
        'channel': 'slack',
        'data': { 'pollID': poll_instance_id }
      }),
      hooks=hooks,
      headers={'Content-Type': 'application/json'})
    
    grequests.send(req, grequests.Pool(1))

  def _send(self, payload, hooks=None):
    if settings.DEBUG:
      print "Dev environment, not sending {}".format(payload)
      return
      
    req = [grequests.post(
            url=self.get_url(),
            data=json.dumps(payload),
            headers={"Content-type": "application/json"},
            hooks=hooks,
            verify=True)]
    grequests.map(req)

  def _options_string(self, option_field):
    return option_field
    # options = json.loads(option_field)
    # return u"[\"{}\"]".format("\", \"".join(options))

  def _make_tag_editor(self):
    return u"<https://whatsgoodly.com/esuohgod/whatsgoodly/poll/{}/|Edit Tags ✏️>: #{}".format(
        self.poll.id, ", #".join(self.poll.tags.values_list('label_lower', flat=True))
      )

  def _make_payload(self, title, message, callback_id=None, color="#3AA3E3"):
    # Linkify occurrences of "User 2131221"
    message = re.sub(r"\b(User ([0-9]+))\b",
      r"<https://whatsgoodly.com/dashboard/profiles/\2/|\1>",
      message
    )

    if self.poll:
      gender = ["GUYS: ", "GIRLS: ", ""][self.poll.gender]
      message = u"\"<https://whatsgoodly.com/esuohgod/whatsgoodly/poll/{}/|{}{}>\"\n{}\n".format(
          self.poll.id, gender, self.poll.question,
          self._options_string(self.poll.options)
        ) + message
      # poll_instance_id = self.poll.pollinstance_set.order_by('-vote_weight').first().id
    elif self.comment:
      message = u"\"<https://whatsgoodly.com/esuohgod/whatsgoodly/comment/{}/|{}>\"\ncommenting on \"{}\" {} {}\n".format(
          self.comment.id, self.comment.text,
          self.comment.poll_instance.poll.question, self._options_string(self.comment.poll_instance.poll.options),
          "<https://whatsgoodly.com/esuohgod/whatsgoodly/comment/?poll_instance_id={}|View thread>".format(
              self.comment.poll_instance_id
            )
        ) + message

    if self.poll_instance:
      title = u"{}  <{}|Edit Instance>".format(
          title, "https://whatsgoodly.com/esuohgod/whatsgoodly/pollinstance/{}/".format(self.poll_instance.id)
        )

    attachment = {
      "title": title,
      "text": message,
      "fallback": u"*{}:* {}".format(title, message),
      "color": color,
      "attachment_type": "default",
      "actions": self.get_actions()
    }
    if callback_id:
      attachment["callback_id"] = callback_id

    return {
      'attachments': [attachment]
    }



class Winston(BaseSlackbot):

  def get_actions(self):
    return [
      {
          "name": "decision",
          "text": "Verify",
          "style": "primary",
          "type": "button",
          "value": "verify"
      },
      {
          "name": "decision",
          "text": "Delete",
          "style": "danger",
          "type": "button",
          "value": "delete"
      }
    ]

  def get_url(self):
    return WINSTON_SLACK_WEBHOOK_URL

  # TODO emojis?
  def moderate(self, message, title, emoji=None, should_deep_link=False):
    deep_link_pid = None
    
    if self.poll_instance:
      deep_link_pid = self.poll_instance.id
      callback_id="poll_instance_{}".format(self.poll_instance.id)
    elif self.poll:
      callback_id="poll_{}".format(self.poll.id)
    elif self.comment:
      deep_link_pid = self.comment.poll_instance_id
      callback_id="comment_{}".format(self.comment.id)
    else:
      raise Exception("Need a valid content object to moderate")

    data = self._make_payload(
      title, message, callback_id=callback_id, color="#8A14CC",
    )
    if deep_link_pid and should_deep_link:
      def on_deep_link(res, **kwargs):
        deep_link = res.json().get('url', None)
        if deep_link:
          att = data['attachments'][0]
          att['title'] = u"{} 📲 <{}|OPEN IN APP>".format(att['title'], deep_link)
        self._send(data)
      self._async_deep_link(deep_link_pid, dict(response=on_deep_link))
    else:
      self._send(data)
    return self

  # Get synchronous response to slack payload sent to webhook
  def respond(self, slack_payload):
    username = slack_payload.get('user', {}).get('name', None)
    obj = self.poll or self.comment
    action = slack_payload.get('actions')[0]
    if not action['name'] in ['decision', 'pin']:
      raise Exception("Unknown action name")

    if action['name'] == 'pin':
      obj.verified = True
      self.poll_instance.promotion = PollInstance.PROMOTIONS.PINNED
      self.poll_instance.save()
      notifications.create_poll_notification(self.poll_instance, made_pinned=True)
      tasks.remove_promotion.apply_async(args=[self.poll_instance.id],
        countdown=3600*HOURS_TO_PIN)
      result = u"📌 @{} verified and pinned to {} for {} hours".format(
        username, self.poll_instance.feed, HOURS_TO_PIN
      )

    elif action['value'] == 'delete':
      obj.deleted = True
      result = u"⛔️ @{} deleted".format(username)
    elif action['value'] == 'verify':
      obj.verified = True
      result = u"✅ @{} verified".format(username)
    else:
      raise Exception("Unknown action value")

    obj.save()

    if obj == self.poll:
      notifications.check_report_notification(poll=obj)
    else:
      notifications.check_report_notification(comment=obj)

    return result

class Shasta(Winston):

  def get_actions(self):
    from whatsgoodly.models import Feed

    actions = [
      {
          "name": "decision",
          "text": "Verify",
          "type": "button",
          "value": "verify"
      },
      {
          "name": "decision",
          "text": "Delete",
          "style": "danger",
          "type": "button",
          "value": "delete"
      }
    ]
    if self.poll_instance:

      feed = self.poll_instance.feed

      if feed.category == Feed.LOCAL and \
          self.poll_instance.community:
        label = self.poll_instance.community.name_short
        actions = [{
            "name": "pin",
            "text": "Pin to {}".format(label),
            "type": "button",
            "value": feed.id
          }] + actions

      if feed.category != Feed.LOCAL:
        actions = [{
            "name": "pin",
            "text": "Pin to {}".format(feed.name),
            "type": "button",
            "value": feed.id
          }] + actions

    return actions

  def get_url(self):
    return SHASTA_SLACK_WEBHOOK_URL


class Gupta(BaseSlackbot):

  # NOTE: limited by Slack to 5
  def get_actions(self):
    from whatsgoodly.models import Feed, PollInstance

    pinning_feeds = Feed.objects.filter(
        pk__in=self.poll.instances.exclude(
            promotion__in=[
              PollInstance.PROMOTIONS.PINNED,
              PollInstance.PROMOTIONS.PREVIOUSLY_PINNED
            ]
          ).values('feed_id'),
        active=True
      ).exclude(
        category=Feed.GLOBAL
      ).order_by('id')

    global_instance = self.poll.instances.filter(feed__category=Feed.GLOBAL).first()
    actions = []

    if self.poll_instance and self.poll_instance.community and \
        self.poll_instance.promotion <= PollInstance.PROMOTIONS.NONE:
      u = self.poll_instance.community
      actions = actions + [{
        "name": "notify",
        "text": "Push to {}".format(u.name_short),
        "style": "primary",
        "type": "button",
        "value": u.id
      }]

    for feed in pinning_feeds[:3]:
      if feed.category == Feed.LOCAL:
        pis = self.poll.instances.filter(feed=feed, community__isnull=False)
        if pis.count() == 0:
          label = "Posted Area"
        elif pis.count() > 1:
          label = "{} Campuses".format(pis.count())
        else:
          pi = pis.first()
          label = pi.community.name_short
        actions = actions + [{
            "name": "pin",
            "text": "Pin to {}".format(label),
            "type": "button",
            "value": feed.id
          }]
      else:
        actions = actions + [{
            "name": "pin",
            "text": "Pin to {}".format(feed.name),
            "type": "button",
            "value": feed.id
          }]

    if self.poll.recycle_count < 10 and not global_instance:
      actions = actions + [{
          "name": "propagation",
          "text": "Universally Local",
          "style": "primary",
          "type": "button",
          "value": "local"
        }]

    if not global_instance:
      actions = actions + [{
          "name": "propagation",
          "text": "Global",
          "type": "button",
          "value": "global"
        }]
    elif global_instance.promotion != PollInstance.PROMOTIONS.POLL_OF_WEEK:
      actions = actions + [{
        "name": "notify",
        "text": "Poll of the Week",
        "style": "primary",
        "type": "button",
        "value": UNIVERSAL_NOTIFICATION_ID
      }]

    return actions + [{
        "name": "decision",
        "text": "Pass",
        "type": "button",
        "value": "pass"
      }]

  def get_url(self):
    return GUPTA_SLACK_WEBHOOK_URL

  # TODO emojis?
  def promote(self, message, title, is_fire=False, is_political=False, is_top_poll=False):
    color = "#1189FB" # blue
    if is_fire:
      color = "#FF6399" # pink
    elif is_political:
      color = "#FF5044" # red
    elif is_top_poll:
      color = "#5954FF" # purple

    if self.poll_instance:
      callback_id="poll_instance_{}".format(self.poll_instance.id)
    elif self.poll:
      callback_id="poll_{}".format(self.poll.id)
    elif self.comment:
      callback_id="comment_{}".format(self.comment.id)
    else:
      raise Exception("Need a valid content object to promote")

    data = self._make_payload(title, message, color=color, callback_id=callback_id)
    self._send(data)
    return self

  # Get response to slack payload sent to webhook
  def respond(self, slack_payload):
    from whatsgoodly.models import *

    moderator_handle = slack_payload.get('user', {}).get('name', None)
    poll = self.poll
    user = poll.user
    action = slack_payload.get('actions')[0]
    if not action['name'] in ['decision', 'pin', 'propagation', 'notify']:
      raise Exception("Unknown action name")

    if action['name'] == 'decision' and action['value'] == 'pass':
      result = u"🙄 @{} passed".format(moderator_handle)

    elif action['name'] == 'pin':
      feed = Feed.objects.get(pk=action['value'])
      for pi in poll.instances.filter(feed=feed):
        pi.promotion = PollInstance.PROMOTIONS.PINNED
        pi.save()
        notifications.create_poll_notification(pi, made_pinned=True)
        tasks.remove_promotion.apply_async(args=[pi.id], countdown=3600*HOURS_TO_PIN)
      result = u"📌 @{} pinned to {} for {} hours".format(
        moderator_handle, feed, HOURS_TO_PIN
      )

    elif action['name'] == 'notify' and action['value'] == UNIVERSAL_NOTIFICATION_ID:

      pi = self.poll.instances.get(feed__category=Feed.GLOBAL)
      
      campaign = notifications.poll_of_the_week_notification(pi, only_maus=True)

      result = u"🔵 <!channel> @{} created campaign {}\nand scheduled pushes to <{}|active users who haven't seen it>".format(
        moderator_handle,
        '<https://whatsgoodly.com/esuohgod/whatsgoodly/notificationcampaign/{}|"{}">'.format(
          campaign.id,
          campaign.name
        ),
        "https://whatsgoodly.com/esuohgod/whatsgoodly/notification/?notification_type=18&poll_instance_id={}".format(pi.id)
      )

      pi.promotion = PollInstance.PROMOTIONS.POLL_OF_WEEK
      pi.save()

    elif action['name'] == 'notify':

      # Could also use self.poll_instance.community
      pi = self.poll.instances.get(feed__category=Feed.LOCAL, community_id=action['value'])
      
      campaign = notifications.poll_of_the_week_notification(
        pi, only_maus=True, university=pi.community
      )

      result = u"🔵 <!channel> @{} created campaign {}\nand scheduled pushes to <{}|active users who haven't seen it>".format(
        moderator_handle,
        '<https://whatsgoodly.com/esuohgod/whatsgoodly/notificationcampaign/{}|"{}">'.format(
          campaign.id,
          campaign.name
        ),
        "https://whatsgoodly.com/esuohgod/whatsgoodly/notification/?notification_type=18&poll_instance_id={}".format(pi.id)
      )

      pi.promotion = PollInstance.PROMOTIONS.POLL_OF_WEEK
      pi.save()

    # Process propagations

    elif action['value'] == 'global':
      feed = Feed.objects.get(category=Feed.GLOBAL)
      location = utils.convert_to_point(0,0)
      banner = user.university.name_short if user.university else None
      poll_instance = PollInstance(user=poll.user, poll=poll, feed=feed, banner=banner, location=location, verified=True)
      poll_instance.save()
      notifications.create_poll_notification(poll_instance, made_global=True)
      result = u"🌎 <!channel> @{} globalled".format(moderator_handle)

    elif action['value'] == 'local':
      tasks.make_universally_local.delay(self.poll.id)
      result = u"👯 @{} scheduled for universally local".format(moderator_handle)

    else:
      raise Exception("Unknown action value")

    result += u"\n{}".format(self._make_tag_editor())

    return result

class Cabo(BaseSlackbot):
  # NOTE: limited by Slack to 5
  def get_actions(self):
    
    actions = [{
        "name": "decision",
        "text": "Reject",
        "style": "danger",
        "type": "button",
        "value": "delete"
      }, {
        "name": "propagation",
        "text": "Global",
        "type": "button",
        "value": "global"
      }, {
        "name": "message",
        "text": "Refresh",
        "type": "button",
        "value": "refresh"
      }]

    if not self.poll_instance.auto_verified:
      actions = [{
          "name": "decision",
          "text": "Accept",
          "style": "primary",
          "type": "button",
          "value": "verify"
        }] + actions

    return actions

  def get_url(self):
    return CABO_SLACK_WEBHOOK_URL

  def moderate(self):
    title = "{}".format(self.poll_instance.feed)
    message = ""
    color = "#FB9B43" # orange
    if self.poll_instance.auto_verified:
      message = u"*Skipped moderation* ({})".format(self.poll.user)
      color = "#52FF38" # green

    callback_id="poll_instance_{}".format(self.poll_instance.id)

    data = self._make_payload(title, message, color=color, callback_id=callback_id)
    self._send(data)
    return self

  # Get response to slack payload sent to webhook
  def respond(self, slack_payload):
    from whatsgoodly.models import *

    moderator_handle = slack_payload.get('user', {}).get('name', None)
    user = self.poll_instance.user
    action = slack_payload.get('actions')[0]
    finished_acting = True

    if not action['name'] in ['decision', 'propagation', 'message']:
      raise Exception("Unknown action name")

    if action['name'] == 'decision':
      if action['value'] == 'delete':
        self.poll.deleted = True
        self.poll_instance.deleted = True
        self.poll_instance.deleted_by_admin = True
        result = u"⛔️ @{} rejected".format(moderator_handle)

      elif action['value'] == 'verify':
        self.poll.verified = True
        self.poll_instance.verified = True
        self.poll_instance.created_date = timezone.now()
        p = CustomPush(
          notification_title="Poll Accepted",
          notification_copy="Congrats! Your poll was featured!",
          poll_instance_id=self.poll_instance.id,
          user_ids=[user.id]
        )
        p.send()
        broadcaster.broadcast_poll_instance(self.poll_instance)
        result = u"✅ @{} accepted".format(moderator_handle)

    # Process propagations

    elif action['name'] == 'propagation' and action['value'] == 'global':
      feed = Feed.objects.get(category=Feed.GLOBAL)
      location = utils.convert_to_point(0,0)
      banner = user.university.name_short if user.university else None
      poll_instance = PollInstance(user=self.poll.user, poll=self.poll, feed=feed, banner=banner, location=location, verified=True)
      poll_instance.save()
      notifications.create_poll_notification(poll_instance, made_global=True)
      result = u"🌎 <!channel> @{} globalled".format(moderator_handle)

    elif action['name'] == 'message' and action['value'] == 'refresh':
      finished_acting = self.poll_instance.verified or self.poll_instance.deleted
      if finished_acting:
        wg_moderator = self.poll_instance.verified_by.username if self.poll_instance.verified_by else "staff"
        decision = "verified" if self.poll_instance.verified else "deleted"
        result = u"✔︎ {} {} on dashboard".format(wg_moderator, decision)
      else:
        result = u"Updated."

    else:
      raise Exception("Unknown action value")

    if action['name'] != 'message':
      self.poll.save()
      self.poll_instance.save()

    result += u"\n{}".format(self._make_tag_editor())

    return result, finished_acting
