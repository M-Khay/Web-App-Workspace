from rest_framework import serializers
import phonenumbers
from urlparse import urlparse

def phone_number_formatter(phone_number):
    if not phone_number:
        raise serializers.ValidationError("Phone number is blank")
    try:
        phone_data = phonenumbers.parse(phone_number, None)
    except phonenumbers.phonenumberutil.NumberParseException:
        try:
            phone_data = phonenumbers.parse(phone_number, 'US')
        except phonenumbers.phonenumberutil.NumberParseException:
            raise serializers.ValidationError("Couldn't parse phone number")

    # TODO: check and raise on not is_valid_number ?
    if not phonenumbers.is_possible_number(phone_data):
        raise serializers.ValidationError("Invalid phone number")

    formatted_num = phonenumbers.format_number(phone_data, phonenumbers.PhoneNumberFormat.E164)

    return formatted_num

def domain_formatter(url):
    parsed_uri = urlparse(url)
    if not parsed_uri.scheme or not parsed_uri.netloc:
        raise serializers.ValidationError("Invalid url")

    domain = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
    return domain