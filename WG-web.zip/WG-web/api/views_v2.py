from api.throttles import *
from api.utils import *
from api.notifications import branch_install_notification
from api import tasks
from api import querysets
from api.formatters import phone_number_formatter
from api.permissions import UserCanPost
from django.core.mail import send_mail
from django.db.models import Q
from django.http import Http404
from django.shortcuts import get_object_or_404, render
from django.utils.crypto import get_random_string
from django.utils.timezone import make_aware
from django.contrib.gis.measure import D
from rest_framework import response
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view, permission_classes, throttle_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from serializers import *
from whatsgoodly.models import *
from whatsgoodly import analytics
from whatsgoodly.utils import random_object
import re

POLL_FEED_ORDER = querysets.POLL_FEED_ORDER
FEED_ORDER = querysets.FEED_ORDER
CAMPUS_CONNECTED_USER_RATIO = 4 # 25% of users have a university
FILTERS = querysets.FILTERS

@api_view(['POST'])
@permission_classes((AllowAny, ))
@throttle_classes([UserAuthenticationThrottle])
def create_user(request):
  password = User.objects.make_random_password()
  ip_address = get_ip_address(request)
  serializer = UserCreateSerializer(data=request.data, context={'request': request})
  if serializer.is_valid(raise_exception=True):
    user = serializer.save(ip_address=ip_address, password=password)
    log_user('signup', serializer.data, request)
    if user.web_session:
      login_web_user(request, user)
    return response.Response(serializer.data, status=201)
  return response.Response(serializer.errors, status=400)

@api_view(['PATCH'])
@permission_classes((AllowAny, ))
@throttle_classes([UserAuthenticationThrottle])
def auth_user(request):
  context = {'request': request}
  ip_address = get_ip_address(request)
  user = get_object_or_404(User, pk=request.data.get('user_id'))
  token_key = request.data.get('token_key')
  if not Token.objects.filter(user=user, key=token_key).exists():
    response.Response("Can't login as that user", status=401)
  # run an update if we're authenticated
  serializer = UserUpdateSerializer(user, data=request.data, partial=True, context=context)
  if serializer.is_valid(raise_exception=True):
    serializer.save(ip_address=ip_address)
    log_user('login', serializer.data, request)
    return response.Response(serializer.data, status=200)
  return response.Response(serializer.errors, status=400)

@api_view(['PATCH'])
@permission_classes((AllowAny, ))
@throttle_classes([UserAuthenticationThrottle])
def auth_with_digits(request):
  context = {'request': request}
  ip_address = get_ip_address(request)
  phone_number = phone_number_formatter(request.data.get('phone_number'))
  auth_headers = request.data.get('auth_headers')
  # TODO handle headers
  data = {'phone_number': phone_number, 'verified_phone_number': True}
  if request.user.is_anonymous():
    user = User.objects.filter(phone_number=phone_number, is_active=True).order_by('-id').first()
  else:
    user = request.user
  if not user:
    return response.Response("User not found", status=401)

  serializer = UserUpdateSerializer(user, data=data, partial=True, context=context)
  if serializer.is_valid(raise_exception=True):
    serializer.save(ip_address=ip_address)
    return response.Response(serializer.data, status=200)
  return response.Response(serializer.errors, status=400)

@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([UserAuthenticationThrottle])
def merge_user(request):
  user = request.user
  context = {'request': request}
  data = request.data.copy()
  data['user'] = user.id
  ip_address = get_ip_address(request)
  serializer = UserMergerSerializer(data=data, context=context)
  if serializer.is_valid(raise_exception=True):
    merger = serializer.save(ip_address=ip_address)
    user_serializer = UserSerializer(merger.user)
    return response.Response(user_serializer.data, status=201)
  return response.Response(serializer.errors, status=400)

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_user_profile(request):
  params = request.query_params
  page = params.get('page', 1)
  user = request.user
  context = { 'request': request }
  my_polls_queryset = querysets.poll_instances_queryset(user=user, order=POLL_FEED_ORDER.RECENT, feed_category=Feed.USER_POLLS, feed=None)
  my_polls_count = my_polls_queryset.count()
  my_polls = querysets.poll_instances_paginated_for_queryset(my_polls_queryset, page)
  my_polls_serializer = PollInstanceSerializer(my_polls, many=True, context=context )
  my_commented_polls_queryset = querysets.poll_instances_queryset(user=user, order=POLL_FEED_ORDER.RECENT, feed_category=Feed.USER_COMMENTS, feed=None)
  my_commented_polls_count = my_commented_polls_queryset.count()
  my_commented_polls = querysets.poll_instances_paginated_for_queryset(my_commented_polls_queryset, page)
  my_commented_polls_serializer = PollInstanceSerializer(my_commented_polls, many=True, context=context)
  user_serializer = UserSerializer(user)
  user_info = user_serializer.data.copy()
  # TODO deprecate (for Android)
  user_info.update({'comment_count': my_commented_polls_count,
                    'poll_count': my_polls_count })
  response_dict = { 'user_polls': my_polls_serializer.data,
                    'user_polls_count': my_polls_count,
                    'user_comment_polls': my_commented_polls_serializer.data,
                    'user_comment_polls_count': my_commented_polls_count,
                    'user_info': user_info }
  return response.Response(response_dict, status=200)

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_user_info(request):
  context = { 'request': request }
  user = request.user
  user.last_user_agent = request.META.get('HTTP_USER_AGENT')
  user.save(update_fields=["last_user_agent"])
  serializer = UserSerializer(user, context=context)
  return response.Response(serializer.data, status=200)

@api_view(['POST'])
@permission_classes((IsAuthenticated, UserCanPost))
@throttle_classes([PollCreationThrottle])
def create_local_poll(request):
  user = request.user
  context = { 'request': request }
  local_feed = Feed.objects.get(category=Feed.LOCAL)
  data = request.data.copy()
  data['feed'] = local_feed.id
  poll_instance_serializer = PollInstanceCreateSerializer(data=data, context=context)
  if poll_instance_serializer.is_valid(raise_exception=True):
    poll_instance = poll_instance_serializer.save(user=user, ip_address=get_ip_address(request))
    serialized_data = poll_instance_serializer.data
    log_content_created('poll', serialized_data, request)
    return response.Response(serialized_data, status=201)
  return response.Response(poll_instance_serializer.errors, status=400)

@api_view(['POST'])
@permission_classes((IsAuthenticated, UserCanPost))
@throttle_classes([PollCreationThrottle])
def create_feature_poll(request, pk):
  user = request.user
  ip_address = get_ip_address(request)
  context = { 'request': request }
  data = request.data.copy()
  data['feed'] = pk
  poll_instance_serializer = PollInstanceCreateSerializer(data=data, context=context)
  if poll_instance_serializer.is_valid(raise_exception=True):
    poll_instance = poll_instance_serializer.save(user=user, ip_address=ip_address)
    if data.get('copy_to_local'):
      data['origin_poll_instance'] = poll_instance.id
      recycle_serializer = PollInstanceRecycleSerializer(data=data, context=context)
      if recycle_serializer.is_valid(raise_exception=True):
        recycle_serializer.save(ip_address=ip_address)
    serialized_data = poll_instance_serializer.data
    log_content_created('poll', serialized_data, request)
    return response.Response(serialized_data, status=201)
  return response.Response(poll_instance_serializer.errors, status=400)

@api_view(['POST'])
@permission_classes((IsAuthenticated, UserCanPost))
@throttle_classes([PollCreationThrottle])
def create_private_poll(request):
  user = request.user
  context = { 'request': request }
  private_feed = Feed.objects.get(name="My Survey")
  data = request.data.copy()
  data['feed'] = private_feed.id
  poll_instance_serializer = PollInstanceCreateSerializer(data=data, context=context)
  if poll_instance_serializer.is_valid(raise_exception=True):
    poll_instance = poll_instance_serializer.save(user=user, ip_address=get_ip_address(request))
    serialized_data = poll_instance_serializer.data
    log_content_created('private_poll', serialized_data, request)
    return response.Response(serialized_data, status=201)
  return response.Response(poll_instance_serializer.errors, status=400)

@api_view(['POST'])
@permission_classes((IsAuthenticated, UserCanPost))
@throttle_classes([PollCreationThrottle])
def create_university_poll(request):
  user = request.user
  context = { 'request': request }
  uni = user.university
  data = request.data.copy()
  data['latitude'] = uni.get_latitude()
  data['longitude'] = uni.get_longitude()
  # TODO stop changing location posted, once more users connect school
  data['community'] = uni.id
  data['feed'] = Feed.objects.get(category=Feed.LOCAL).pk
  poll_instance_serializer = PollInstanceCreateSerializer(data=data, context=context)
  if poll_instance_serializer.is_valid(raise_exception=True):
    poll_instance = poll_instance_serializer.save(user=user, ip_address=get_ip_address(request))
    serialized_data = poll_instance_serializer.data
    log_content_created('school_poll', serialized_data, request)
    return response.Response(serialized_data, status=201)
  return response.Response(poll_instance_serializer.errors, status=400)

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_polls_from_feed(request, feed_identifier, filter_type=None, order=None):
  context = { 'request': request }
  params = request.query_params
  page = params.get('page', 1)
  page = int(page)
  lat = params.get('latitude')
  lon = params.get('longitude')
  level = params.get('level', Feed.LEVELS.COLLEGE)
  level = int(level)
  filtering = FILTERS.get(filter_type)
  if feed_identifier == 'local' or feed_identifier == '0':
    if lat == None or lon == None:
      return response.Response("No location given", status=400)
    feed = Feed.objects.filter(category=Feed.LOCAL).first()
  elif feed_identifier == 'global':
    feed = Feed.objects.filter(category=Feed.GLOBAL).first()
    order = POLL_FEED_ORDER.RECENT # TODO no recent order for global feeds?
  elif feed_identifier == 'university':
    try:
      lat = request.user.university.get_latitude()
      lon = request.user.university.get_longitude()
    except AttributeError:
      return response.Response("Could not retrieve user's university", status=400)
    feed = Feed.objects.filter(category=Feed.LOCAL).first()
  elif feed_identifier == 'private':
    feed = Feed.objects.filter(category=Feed.MY_FEATURED, active=True).first()
  else:
    feed = Feed.objects.get(id=feed_identifier)
  if feed is None:
    raise Http404('Feed not found')
  return get_ordered_polls(request=request, feed=feed, page=page, order=order, lat=lat, lon=lon, filtering=filtering)

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_peek_polls(request, pk, filter_type="user_made", order=None):
  # NOTE: user_made isn't getting used
  context = { 'request': request }
  params = request.query_params
  page = params.get('page', 1)
  peek_feed = PeekFeed.objects.get(pk=pk)
  feed = Feed.objects.get(category=Feed.LOCAL)
  filtering = FILTERS.get(filter_type)
  return get_ordered_polls(request=request, feed=feed, page=page, order=order,
    lat=peek_feed.location.y, lon=peek_feed.location.x, filtering=filtering)

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_user_favorites(request):
  user = request.user
  params = request.query_params
  page = params.get('page', 1)
  page = int(page)
  context = { 'request' : request }
  queryset = querysets.poll_instances_paginated(page=page, user=user,
      order=POLL_FEED_ORDER.RECENT, feed_category=Feed.USER_FAVORITES, feed=None)
  serializer = PollInstanceSerializer(queryset, many=True, context=context)
  return response.Response(serializer.data, status=200)

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_user_comment_polls(request):
  user = request.user
  params = request.query_params
  page = params.get('page', 1)
  page = int(page)
  context = { 'request' : request }
  my_commented_polls = querysets.poll_instances_paginated(page=page, user=user,
      order=POLL_FEED_ORDER.RECENT, feed_category=Feed.USER_COMMENTS, feed=None)
  my_commented_polls_serializer = PollInstanceSerializer(my_commented_polls, many=True, context=context)
  return response.Response(my_commented_polls_serializer.data, status=200)

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_user_polls(request):
  user = request.user
  params = request.query_params
  page = params.get('page', 1)
  page = int(page)
  context = { 'request' : request }
  my_polls = querysets.poll_instances_paginated(page=page, user=user, order=POLL_FEED_ORDER.RECENT, feed_category=Feed.USER_POLLS, feed=None)
  my_polls_serializer = PollInstanceSerializer(my_polls, many=True, context=context )
  return response.Response(my_polls_serializer.data, status=200)

# TODO deprecate in v3
# Gets recent and top polls in two separate queries, probably slow
def get_recent_top_polls(request, feed, lat=None, lon=None):
  context = { 'request' : request }
  user = request.user
  recent_polls = querysets.poll_instances_paginated(page=1, user=user, order=POLL_FEED_ORDER.RECENT,
    feed_category=feed.category, feed=feed, lat=lat, lon=lon)
  top_polls = querysets.poll_instances_paginated(page=1, user=user, order=POLL_FEED_ORDER.TOP,
    feed_category=feed.category, feed=feed, lat=lat, lon=lon)
  recent_serializer = PollInstanceSerializer(recent_polls, many=True, context=context)
  top_serializer = PollInstanceSerializer(top_polls, many=True, context=context)
  response_dict = { 'recent_polls': recent_serializer.data, 'top_polls': top_serializer.data }
  return response.Response(response_dict, status=200)

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_local_channel(request):
  params = request.query_params
  lat = params.get('latitude', None)
  lon = params.get('longitude', None)
  channel_name = "local-{0};{1}_{2}".format(request.user.id, lat, lon)
  return response.Response({'localChannel': channel_name}, status=200)

@api_view(['GET'])
@permission_classes((AllowAny, ))
def get_gender_ratio(request):
  if not is_app_session(request):
    return response.Response("Not authorized", status=403)
  params = request.query_params
  lat = params.get('latitude', None)
  lon = params.get('longitude', None)
  try:
    location = convert_to_point(lat, lon)
  except:
    return response.Response("Invalid location", status=400)

  university = University.objects.filter(
      location__distance_lte=(location, D(km=50))
    ).distance(location)\
    .order_by('distance').first()
  if not university:
    return response.Response("Not near a campus", status=400)

  male, female, other = analytics.campus_users_by_gender(university)
  if not male or not female:
    return response.Response("No data for campus", status=400)

  response_dict = {
    'male': (male+1)*CAMPUS_CONNECTED_USER_RATIO,
    'female': (female+1)*CAMPUS_CONNECTED_USER_RATIO,
    'name_short': university.name_short
  }
  return response.Response(response_dict, status=200)

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_poll(request, pk):
  user = request.user
  context = { 'request': request }
  query = querysets.poll_instance_prefetch(pk=pk, user=user)
  if not query:
    raise Http404('Poll not found')
  serializer = PollInstanceSerializer(query[0], context=context)
  return response.Response(serializer.data, status=200)

@api_view(['POST' ,'DELETE'])
@permission_classes((IsAuthenticated, ))
def delete_poll(request, pk):
  user = request.user
  context = { 'request' : request }
  query = querysets.poll_instance_prefetch(pk=pk, user=user)
  if query.count() == 0:
    raise Http404('Poll not found')
  poll_instance = query[0]
  if user.id != poll_instance.user_id:
    return response.Response("Not authorized to delete poll", status=401)
  if poll_instance.get_deleted():
    return response.Response("Poll already deleted", status=204)
  poll_instance.deleted = True
  poll_instance.deleted_by_creator = True
  poll_instance.save()
  serializer = PollInstanceSerializer(poll_instance, context=context)
  return response.Response(serializer.data, status=200)

@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([ResponseCreationThrottle])
def create_response(request, pk):
  context = { 'request': request }
  data = request.data.copy()
  data['poll_instance'] = pk
  serializer = ResponseSerializer(data=data, context=context)
  if serializer.is_valid(raise_exception=True):
    serializer.save(user=request.user)
    user_serializer = UserSerializer(request.user)
    return response.Response(user_serializer.data, status=200)
  else:
    return response.Response(serializer.errors, status=400)

@api_view(['POST', 'DELETE'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([FavoriteThrottle])
def toggle_poll_favorite(request, pk):
  user = request.user
  if request.method == 'DELETE':
    favorite = get_object_or_404(Favorite, poll_instance_id=pk, user=user)
    favorite.delete()
    return response.Response(status=204)

  context = { 'request': request }
  data = request.data.copy()
  data['poll_instance'] = pk
  serializer = FavoriteSerializer(data=data, context=context)
  if serializer.is_valid(raise_exception=True):
    serializer.save(user=user)
    return response.Response(serializer.data, status=200)
  return response.Response(serializer.errors, status=400)

@api_view(['PATCH'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([SubscriptionThrottle])
def update_poll_subscription(request, pk):
  user = request.user
  sub, created = PushSubscription.objects.get_or_create(poll_instance_id=pk, user=user)
  serializer = PushSubscriptionSerializer(sub, data=request.data, partial=True)
  if serializer.is_valid(raise_exception=True):
    serializer.save()
    return response.Response(serializer.data, status=200)
  return response.Response(serializer.errors, status=403)

@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([PollInstanceRemovalThrottle])
def remove_poll(request, pk):
  context = { 'request': request }
  data = request.data.copy()
  data['poll_instance'] = pk
  serializer = PollInstanceRemovalSerializer(data=data, context=context)
  if serializer.is_valid(raise_exception=True):
    serializer.save(user=request.user)
    return response.Response(serializer.data, status=200)
  return response.Response(serializer.errors, status=400)

@api_view(['DELETE'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([PollInstanceRemovalThrottle])
def undo_remove_poll(request):
  context = { 'request': request }
  removal = PollInstanceRemoval.objects.filter(user=request.user).order_by('-id').first()
  if removal:
    removal.delete()
    return response.Response({"id": removal.poll_instance_id}, status=200)
  else:
    return response.Response("Never removed a poll", status=204)

@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([PollInstanceVoteCreationThrottle])
def create_poll_vote(request, pk):
  context = { 'request': request }
  data = request.data.copy()
  data['poll_instance'] = pk
  if data['vote'] == 0:
    existing_vote = PollInstanceRemoval.objects.filter(
      user=request.user,
      poll_instance_id=pk,
      is_downvote=True
    )
    if existing_vote.exists():
      raise Exception("Data problem: Duplicate poll downvote")
    serializer = PollInstanceRemovalSerializer(data=data, context=context)
  else:
    serializer = FavoriteSerializer(data=data, context=context)

  if serializer.is_valid(raise_exception=True):
    serializer.save(user=request.user)
    return response.Response(serializer.data, status=200)
  return response.Response(serializer.errors, status=403)

@api_view(['POST'])
@permission_classes((IsAuthenticated, UserCanPost))
@throttle_classes([TaggingThrottle])
def create_poll_tags(request, pk):
  context = { 'request': request }
  data = request.data.copy()
  tag_ids = []
  errors = []

  for tag_data in data['contacts']:
    # TODO use serializer somehow?
    try:
      number = phone_number_formatter(tag_data.get('phone_number'))
      friendship = Friendship.objects.update_or_create(
          user=request.user, friend_phone_number=number,
          defaults={'friend_name': tag_data.get('name')}
        )[0]
    except:
      error = "%s is an invalid phone number" % tag_data.get('phone_number')
      errors.append({'phone_number': error})
      continue

    tag_data['poll_instance'] = pk
    tag_data['friendship'] = friendship.id

    serializer = TagCreateSerializer(data=tag_data, context=context)
    if serializer.is_valid():
      tag = serializer.save()
      tag_ids.append(tag.id)
    else:
      errors.append(serializer.errors)

  # TODO use post_save callbacks, store deeplink in Tag?
  if tag_ids:
    tasks.send_tags.delay(tag_ids, deep_link=data['message'])
  elif errors:
    return response.Response(errors, status=400)

  # TODO return UserSerializer and handle in app
  return response.Response(status=200)

@api_view(['PATCH'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([TaggingThrottle])
def update_tag(request, pk):
  context = { 'request': request }
  tag = get_object_or_404(Tag, pk=pk)
  if not request.user.can_modify_tag(tag, data=request.data):
    return response.Response("Can't modify that tag", status=401)

  tag_serializer = TagSerializer(tag, data=request.data, partial=True, context=context)
  if tag_serializer.is_valid(raise_exception=True):
    tag_serializer.save()
    return response.Response(tag_serializer.data, status=200)
  return response.Response(tag_serializer.errors, status=403)

@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([ReportCreationThrottle])
def report_poll(request, pk):
  context = { 'request' : request }
  user = request.user
  data = request.data.copy()
  data['poll_instance'] = pk
  serializer = ReportSerializer(data=data, context=context)
  if serializer.is_valid(raise_exception=True):
    report = serializer.save(user=request.user)
    # log_content_reported('poll',
    #   PollInstanceSerializer(poll_instance, context=context).data,
    #   report.get_report_type_display(), request)
    return response.Response(serializer.data, status=201)
  return response.Response(serializer.errors, status=403)

@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([ReportCreationThrottle])
def report_comment(request, pk):
  context = { 'request' : request }
  user = request.user
  data = request.data.copy()
  data['comment'] = pk
  serializer = ReportSerializer(data=data, context=context)
  if serializer.is_valid(raise_exception=True):
    report = serializer.save(user=request.user)
    # log_content_reported('comment',
    #   CommentSerializer(comment, context=context).data,
    #   report.get_report_type_display(), request)
    return response.Response(serializer.data, status=201)
  return response.Response(serializer.errors, status=403)

@api_view(['POST'])
@permission_classes((IsAuthenticated, UserCanPost))
@throttle_classes([CommentCreationThrottle])
def create_comment(request, pk):
  context = { 'request': request }
  user = request.user
  data = request.data.copy()
  data['poll_instance'] = pk
  comment_serializer = CommentCreateSerializer(data=data, context=context)
  if comment_serializer.is_valid(raise_exception=True):
    if comment_serializer.validated_data['poll_instance'].get_deleted():
      return response.Response("Poll does not exist", status=404)
    ip_address = get_ip_address(request)
    comment_serializer.save(user=user, ip_address=ip_address)
    log_content_created('comment', comment_serializer.data, request)
    return response.Response(comment_serializer.data, status=201)
  return response.Response(comment_serializer.errors, status=400)

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_comments_from_poll(request, pk):
  context = { 'request': request }
  poll_instance = get_object_or_404(PollInstance, pk=pk)
  comments = querysets.comments(request.user, poll_instance)
  serializer = CommentSerializer(comments, context=context, many=True)
  return response.Response(serializer.data, status=200)

@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([CommentVoteCreationThrottle])
def create_comment_vote(request, pk):
  context = { 'request': request }
  data = request.data.copy()
  data['comment'] = pk
  serializer = CommentVoteSerializer(data=data, context=context)
  if serializer.is_valid(raise_exception=True):
    serializer.save(user=request.user)
    return response.Response(serializer.data, status=200)
  else:
    return response.Response(serializer.errors, status=400)

@api_view(['POST', 'DELETE'])
@permission_classes((IsAuthenticated, ))
def delete_comment(request, pk):
  user = request.user
  context = { 'request': request }
  comment = get_object_or_404(Comment, pk=pk)
  if user != comment.user:
    return response.Response("Not authorized to delete comment", status=401)
  elif comment.deleted:
    return response.Response("Comment already deleted", status=204)
  else:
    comment.deleted=True
    comment.deleted_by_creator=True
    comment.save()
    serializer = CommentSerializer(comment, context=context)
    return response.Response(serializer.data, status=200)

@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([ContactFormCreationThrottle])
def contact(request):
  name = request.data.get('name', None)
  email = request.data.get('email', None)
  message = request.data.get('message', None)
  user_id = request.user.id
  if name and email:
    email_body = 'User ID: %d; Name: %s; Message: %s' % (user_id, name, message)
  else:
    search = re.search(r'[\w\.-]+@[\w\.-]+', message)
    email = search.group(0) if search else "noreply@whatsgoodly.com"
    email_body = 'User ID: %d; Message: %s' % (user_id, message)
  send_mail('Contact Form', email_body, email,
    ['support@whatsgoodly.zendesk.com'], fail_silently=False)
  return response.Response({ 'message': message }, status=200)

@api_view(['POST'])
def handle_branch_install(request):
  user_id = request.data.get('session_referring_identity', None)
  if user_id:
    try:
      user = User.objects.get(pk=int(user_id))
      branch_install_notification(user)
    except:
      pass
  return response.Response({}, status=200)

@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
def sms_invite(request):
  numbers = request.data.get('numbers', [])
  message = request.data.get('message', None)

  tasks.send_sms.delay(numbers, message)

  return response.Response({ 'message': message }, status=200)

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_universities(request):
  lat = request.query_params.get('latitude', None)
  lon = request.query_params.get('longitude', None)
  try:
    location = convert_to_point(lat, lon)
    queryset = University.objects.all().distance(location)\
      .order_by('distance')
  except:
    queryset = University.objects.all().order_by('name')
  serializer = UniversitySerializer(queryset, many=True)
  return response.Response(serializer.data, status=200)

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_notifications(request):
  params = request.query_params
  page = params.get('page', None)

  queryset = querysets.notifications(user=request.user)
  per_page = 20
  if page is None:
    per_page = 40

  page = int(page) if page else 1
  notifications = queryset[per_page*(page-1):per_page*page]
  serializer = NotificationSerializer(notifications, many=True)

  if page is None:
    return response.Response(serializer.data, status=200)
  else:
    response_dict = { 'user_notifications': serializer.data }
    return response.Response(response_dict, status=200)

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_announcements(request):
  queryset = Announcement.objects.filter(
      active=True, location=None
    ).filter(
      Q(university=None) | Q(university=request.user.university)
    ).order_by('-id')[:10]

  # FOR WHEN WE DO LOCATION-BASED ANNOUNCEMENTS
  # params = request.query_params
  # lat = params.get('latitude', None)
  # lon = params.get('longitude', None)
  # if lat is None or lon is None:
  #   queryset = Announcement.objects.filter(active=True, location=None).order_by('-id')[:10]
  # else:
  #   location = convert_to_point(lat, lon)
  #   queryset = Announcement.objects.filter(
  #       Q(active=True) &
  #       ( Q(location=None) | Q(location__distance_lte=(location, D(km=9))))
  #   ).order_by('-id')[:10]
  serializer = AnnouncementSerializer(queryset, many=True)
  return response.Response(serializer.data, status=200)

@api_view(['PATCH'])
@permission_classes((IsAuthenticated, ))
def update_notification(request, pk):
  notif = get_object_or_404(Notification, pk=pk)
  notif_serializer = NotificationSerializer(notif, data=request.data, partial=True)
  if notif_serializer.is_valid(raise_exception=True):
    notif_serializer.save()
    return response.Response(notif_serializer.data, status=200)
  return response.Response(notif_serializer.errors, status=403)

@api_view(['PATCH'])
@permission_classes((IsAuthenticated, ))
def update_user_university(request):
  context = { 'request' : request }
  user = request.user
  email = request.data.get('email', None)
  lat = request.data.get('latitude', None)
  lon = request.data.get('longitude', None)
  verification_token = request.data.get('verification_token', None)
  serializer = UserUniversityUpdateSerializer(data=request.data, context=context)
  if serializer.is_valid(raise_exception=True):
    if verification_token or (lat and lon):
      # Did verification in serializer validation
      user.university = serializer.validated_data['university']
      user.verified_university = True
      slack_message = "User {0} at *{1}* verified {2} school!".format(
        "{0} [{1} pts]".format(user.id, user.karma),
        user.university.name,
        user.possessive_pronoun())
      send_slack_message(slack_message, event_name="School Connection", emoji=":school:")
    elif email:
      # Send email for verification
      token = get_random_string(length=4, allowed_chars="0123456789")
      user.verification_token = token
      send_email_verification(token, email);
    else:
      # Not verified, but let them through
      user.university = serializer.validated_data['university']
      user.verified_university = False
    user.save()
    return response.Response(serializer.data, status=200)
  return response.Response(serializer.errors, status=403)

@api_view(['PATCH'])
@permission_classes((IsAuthenticated, ))
def update_user(request):
  user = request.user
  user_serializer = UserUpdateSerializer(user, data=request.data, partial=True, context={'request': request})
  if user_serializer.is_valid(raise_exception=True):
    user = user_serializer.save()
    return response.Response(user_serializer.data, status=200)
  return response.Response(user_serializer.errors, status=403)

@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
def update_user_friends(request):
  context = { 'request': request }
  user = request.user
  phone_numbers = request.data.get('phone_numbers', []) # TODO: deprecate
  dirty_contacts = request.data.get('contacts', [])
  if phone_numbers:
    dirty_contacts = [{'phone_number': number} for number in phone_numbers]
  poll_instance_id = request.data.get('poll_instance_id', None)
  
  unique_phone_numbers = set()
  contacts = []

  for contact in dirty_contacts:
    try:
      number = phone_number_formatter(contact.get('phone_number'))
    except:
      continue
    if not number or number in unique_phone_numbers:
      continue
    unique_phone_numbers.add(number)
    contact['phone_number'] = number
    contacts.append(contact)
  
  tasks.import_friends.delay(user_id=user.id, contacts=contacts)

  if poll_instance_id:
    return get_voters_and_tags(poll_instance_id, cached_phone_numbers=list(unique_phone_numbers), context=context)

  return response.Response(status=200)

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_peek_feeds(request):
  active_peek_feeds = PeekFeed.objects.filter(active=True).order_by('-id')
  serializer = PeekFeedSerializer(active_peek_feeds, many=True)
  return response.Response(serializer.data, status=200)

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def get_feeds(request):
  context = { 'request': request }
  user = request.user
  params = request.query_params
  level = int(params.get('level', user.get_age()))

  feed_queryset = querysets.feeds(user=request.user, order=FEED_ORDER.FEATURED_FEEDS, level=level, exclude_peek=True)
  serializer = FeedSerializer(feed_queryset, many=True, context=context)
  return response.Response(serializer.data, status=200)

@api_view(['PATCH'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([FeedPreferenceThrottle])
def update_feed_prefs(request, pk):
  user = request.user
  pref, created = FeedPreference.objects.get_or_create(feed_id=pk, user=user)
  serializer = FeedPreferenceSerializer(pref, data=request.data, partial=True)
  if serializer.is_valid(raise_exception=True):
    serializer.save()
    return response.Response(serializer.data, status=200)
  return response.Response(serializer.errors, status=403)

@api_view(['PATCH'])
@permission_classes((IsAuthenticated, ))
@throttle_classes([FeedPreferenceThrottle])
def update_feed_prefs_bulk(request):
  user = request.user
  updates = request.data.get("updates", [])
  try:
    for update in updates:
      pref, created = FeedPreference.objects.get_or_create(
          feed_id=update["feed_id"], user=user)
      pref.rank = update.get("rank", pref.rank)
      pref.disabled = update.get("disabled", pref.disabled)
      pref.save()
    return response.Response(len(updates), status=200)
  except KeyError, e:
    return response.Response("Invalid request", status=403)

@api_view(['POST'])
@permission_classes((IsAuthenticated, UserCanPost))
def recycle_poll(request, pk):
  context = { 'request': request }
  user = request.user
  data = request.data.copy()
  data['origin_poll_instance'] = pk
  data['banner'] = request.data.get('banner', None)
  if user.verified_university:
    uni = user.university
    data['latitude'] = uni.get_latitude()
    data['longitude'] = uni.get_longitude()
    data['community'] = uni.id
  serializer = PollInstanceRecycleSerializer(data=data, context=context)
  if serializer.is_valid(raise_exception=True):
    serializer.save(ip_address=get_ip_address(request))
    return response.Response(serializer.data, status=201)
  return response.Response(serializer.errors, status=403)

@api_view(['POST', 'DELETE'])
@permission_classes((IsAuthenticated, ))
def delete_user(request):
  user = request.user
  user.is_active = False
  user.save()
  slack_message = "User {0}{1} deactivated :(".format(
      "{0} [{1} pts]".format(user.id, user.karma),
      " at {0}".format(user.university.name) if user.university_id else ""
    )
  send_slack_message(slack_message, event_name="Deactivation", emoji=":broken_heart:")
  return response.Response(status=204)



# HELPERS

def get_ordered_polls(request, feed, order, page, lat=None, lon=None, filtering=None):
  if order == None:
    return get_recent_top_polls(request=request, feed=feed, lat=lat, lon=lon)

  user = request.user
  context = { 'request' : request }
  poll_queryset = querysets.poll_instances_paginated(page=page, user=user, order=order,
      feed_category=feed.category, feed=feed, lat=lat, lon=lon, filtering=filtering)
  poll_data = PollInstanceSerializer(poll_queryset, many=True, context=context).data

  if len(poll_data) > 0 and not filtering and \
      order in (POLL_FEED_ORDER.UNVOTED, POLL_FEED_ORDER.RECENT):
    # TODO batch these three querysets!
    fire_rand = random_object(querysets.fire_poll_instances_queryset(user=user, feed=feed, lat=lat, lon=lon))
    fires = [fire_rand] if fire_rand else []
    pinned = querysets.pinned_poll_instances_queryset(user=user, feed=feed)
    segmenters_rand = random_object(querysets.segmentation_instances_queryset(user=user, feed=feed))
    segmenters = [segmenters_rand] if segmenters_rand else []

    fire_data = PollInstanceSerializer(fires, many=True, context=context).data
    pinned_data = PollInstanceSerializer(pinned, many=True, context=context).data
    seg_data = PollInstanceSerializer(segmenters, many=True, context=context).data

    raised_polls = fire_data + pinned_data + seg_data
    poll_data = unique(raised_polls + poll_data, key='poll')
    
  return response.Response(poll_data, status=200)

def get_voters_and_tags(poll_instance_id, cached_phone_numbers=[], context={}):
  user = context['request'].user

  # phone_numbers = cached_phone_numbers or Friendship.objects.filter(user=user)\
  #   .values_list('friend_phone_number', flat=True)

  # If we want to send down voters
  # known_voter_ids = Response.objects.filter(
  #     poll_instance_id=poll_instance_id,
  #     user__phone_number__in=phone_numbers
  #   ).values_list('user_id', flat=True)
  # known_voters = User.objects.filter(pk__in=known_voter_ids)
  # voters_serializer = KnownUserSerializer(known_voters, many=True, context=context)

  # tags
  previous_tags = Tag.objects.filter(
    friendship__user=user,
    poll_instance_id=poll_instance_id
  )
  tag_serializer = TagSerializer(previous_tags, many=True, context=context)

  response_dict = {'voters': [], # voters_serializer.data,
                   'tags': tag_serializer.data}
  return response.Response(response_dict, status=200)

def log_user(event_name, user_data, request):
  pass
  # user_data.pop('token', None)
  # send_smyte_message({'user': user_data}, event_name, request)

def log_content_created(content_type, content_data, request):
  pass
  # user_data = UserSerializer(request.user).data
  # user_data.pop('token', None)
  # data = {'user': user_data}
  # data[content_type] = content_data
  # send_smyte_message(data, 'create_{0}'.format(content_type), request)
  
def log_content_reported(content_type, content_data, reason, request):
  pass
  # user_data = UserSerializer(request.user).data
  # user_data.pop('token', None)
  # data = {'actor': user_data, 'reason': reason}
  # data[content_type] = content_data
  # send_smyte_message(data, 'report_{0}'.format(content_type), request)
