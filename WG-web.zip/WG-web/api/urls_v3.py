from api.views_v3 import *
from api.querysets import POLL_FEED_ORDER
from django.conf.urls import url

urlpatterns = [

    url(r'^admin/polls/(?P<pk>[0-9]+)/delete/$', admin_delete_poll),
    url(r'^admin/polls/(?P<pk>[0-9]+)/favorite/$', admin_favorite_poll),

    url(r'^feed/(?P<feed_identifier>[0-9]+|local|global|campus|personal)/$', get_polls_from_feed),
    url(r'^feed/(?P<feed_identifier>[0-9]+|local|global|campus|personal)/top/$', get_polls_from_feed, {'order': POLL_FEED_ORDER.TOP}),
    url(r'^feed/(?P<feed_identifier>[0-9]+|local|global|campus|personal)/recent/$', get_polls_from_feed, {'order': POLL_FEED_ORDER.RECENT}),
    url(r'^feed/(?P<feed_identifier>[0-9]+|local|global|campus|personal)/recent/top/$', get_polls_from_feed, {'order': POLL_FEED_ORDER.RECENT_TOP}),
    url(r'^feed/(?P<feed_identifier>[0-9]+|local|global|campus|personal)/recent/(?P<filter_type>favorited)/$', get_polls_from_feed, {'order': POLL_FEED_ORDER.RECENT}),
    url(r'^feed/(?P<feed_identifier>[0-9]+|local|global|campus|personal)/unvoted/(?P<filter_type>all|guys|girls)/$', get_polls_from_feed, {'order': POLL_FEED_ORDER.UNVOTED}),
    url(r'^feed/(?P<feed_identifier>[0-9]+|local|global|campus|personal)/voted/$', get_polls_from_feed, {'order': POLL_FEED_ORDER.VOTED}),

    url(r'^feed/(?P<pk>[0-9]+)/search/$', search_polls_from_feed),

    url(r'^local_channel/$', get_local_channel),
    url(r'^gender_ratio/$', get_gender_ratio),

    # TODO deprecate all
    url(r'^polls/local/new/$', create_local_poll),
    url(r'^polls/campus/new/$', create_campus_poll),
    url(r'^polls/personal/new/$', create_personal_poll),
    
    url(r'^polls/feed/(?P<pk>[0-9]+)/new/$', create_poll),
    url(r'^polls/suggested/$', get_suggested_poll),
    url(r'^polls/(?P<pk>[0-9]+)/$', get_poll),
    url(r'^polls/(?P<pk>[0-9]+)/delete/$', delete_poll),
    url(r'^polls/(?P<pk>[0-9]+)/report/$', report_poll),
    url(r'^polls/(?P<pk>[0-9]+)/favorite/$', toggle_poll_favorite),
    url(r'^polls/(?P<pk>[0-9]+)/subscription/$', update_poll_subscription),
    url(r'^polls/(?P<pk>[0-9]+)/remove/$', remove_poll),
    url(r'^polls/undo_remove/$', undo_remove_poll),
    url(r'^polls/(?P<pk>[0-9]+)/recycle/$', recycle_poll),
    url(r'^polls/(?P<pk>[0-9]+)/tag/$', create_poll_tags),
    url(r'^polls/(?P<pk>[0-9]+)/response/new/$', create_response),

    url(r'^tags/(?P<pk>[0-9]+)/update/$', update_tag),

    url(r'^polls/(?P<pk>[0-9]+)/comments/$', get_comments_for_poll),
    url(r'^polls/(?P<pk>[0-9]+)/comments/new/$', create_comment),
    url(r'^polls/(?P<pk>[0-9]+)/breakdowns/(?P<breakdown_type_label>all|friends)/$', get_breakdown_for_poll),
    url(r'^comments/(?P<pk>[0-9]+)/delete/$', delete_comment),
    url(r'^comments/(?P<pk>[0-9]+)/vote/$', create_comment_vote),
    url(r'^comments/(?P<pk>[0-9]+)/report/$', report_comment),
    url(r'^poll_breakdowns/(?P<pk>[0-9]+)/unlock/$', unlock_poll_breakdown),

    url(r'^users/new/$', create_user),
    url(r'^users/auth/$', auth_user),
    url(r'^users/auth/digits/$', auth_with_digits),
    url(r'^users/merge/$', merge_user),
    url(r'^users/profile/$', get_user_profile),
    url(r'^users/info/$', get_user_info),
    url(r'^users/notifications/$', get_notifications),
    url(r'^users/notifications/(?P<pk>[0-9]+)/update/$', update_notification),
    url(r'^users/polls/favorites/$', get_user_favorites),
    url(r'^users/polls/comments/$', get_user_comment_polls),
    url(r'^users/polls/$', get_user_polls),
    url(r'^users/delete/$', delete_user),

    url(r'^users/update/campus/$', update_user_campus),
    url(r'^users/update/$', update_user),
    url(r'^users/friends/update/$', update_user_friends),

    url(r'^invite/$', sms_invite),
    url(r'^contact/$', contact),
    url(r'^campuses/$', get_campuses),
    url(r'^campuses/current/$', get_current_campus),
    url(r'^announcements/$', get_announcements),

    url(r'^peek/$', get_peek_feeds),
    url(r'^peek/(?P<pk>[0-9]+)/$', get_peek_polls),
    url(r'^peek/(?P<pk>[0-9]+)/top/$', get_peek_polls, {'order': POLL_FEED_ORDER.TOP}),
    url(r'^peek/(?P<pk>[0-9]+)/recent/$', get_peek_polls, {'order': POLL_FEED_ORDER.RECENT}),
    url(r'^peek/(?P<pk>[0-9]+)/recent/top/$', get_peek_polls, {'order': POLL_FEED_ORDER.RECENT_TOP}),
    url(r'^peek/(?P<pk>[0-9]+)/recent/(?P<filter_type>favorited)/$', get_peek_polls, {'order': POLL_FEED_ORDER.RECENT}),
    url(r'^peek/(?P<pk>[0-9]+)/unvoted/(?P<filter_type>all|guys|girls)/$', get_peek_polls, {'order': POLL_FEED_ORDER.UNVOTED}),
    url(r'^peek/(?P<pk>[0-9]+)/unvoted/$', get_peek_polls, {'order': POLL_FEED_ORDER.UNVOTED}),
    url(r'^peek/(?P<pk>[0-9]+)/voted/$', get_peek_polls, {'order': POLL_FEED_ORDER.VOTED}),

    url(r'^feeds/$', get_feeds),
    url(r'^feeds/(?P<pk>[0-9]+)/prefs/$', update_feed_prefs),
    url(r'^feeds/prefs/$', update_feed_prefs_bulk)
]
