### WG-web

##### Setup instructions:
1. Install VirtualBox: https://www.virtualbox.org/
2. Install Vagrant: https://www.vagrantup.com/
3. Start the VM by running: ```vagrant up```
4. SSH into the VM by running: ```vagrant ssh```
5. Go to source code by running: ```cd /opt/app/web/current``` (You can put this in Vagrant's `~/.profile` for convenience. Also recommend putting `export env=vagrant` on another line there too.)
6. Install dependencies and migrate the database by running: ```./bin/dev_setup.sh```
7. Run the server by running: ```env=vagrant python manage.py runserver 0.0.0.0:8080```, or equivalently ```./bin/dev_server.sh```
8. Access web pages at ```192.168.33.10:8080```, Django admin at ```192.168.33.10:8080/esuohgod/```, or the dashboard app at ```192.168.33.10:8080/dashboard/```
9. Some tasks, like making new polls, depend on redis. to install it, run ```sudo apt-get install redis-server```

**Note: to shutdown the server run ```vagrant halt```. To re-run the server, repeat steps 3, 4, 5, and 7.**

**You can edit files locally and they will sync with the VM.**

**Note: the admin username is ```whatsgoodly@whatsgoodly.com``` and the password is ```a```**

#### Graphing the database, models and relationships
This is a feature of django extensions: https://github.com/django-extensions/django-extensions. You should only use it locally, e.g. in your vagrant environment.

1. Install Graphviz: ```sudo apt-get install graphviz```
2. Install Python bridge:
```sudo pip install pyparsing==1.5.7```
```pip install pydot==1.1.0```
3. Graph the models in the whatsgoodly app: ```python manage.py graph_models whatsgoodly -o whatsgoodly/models_graph.png```
3. Graph all models, grouped by app: ```python manage.py graph_models -a -g -o models_graph.png```
