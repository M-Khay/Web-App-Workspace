from django.conf.urls import include, url
from webhooks.pusher.views import *

urlpatterns = [
    url(r'^channel_existence$', channel_existence, name='channel_existence'),
    url(r'^client_event$', client_event, name='client_event'),
    url(r'^presence$', presence, name='presence')
]
