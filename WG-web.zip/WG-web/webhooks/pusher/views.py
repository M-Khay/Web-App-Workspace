from rest_framework import response
from rest_framework.permissions import AllowAny
from rest_framework.decorators import permission_classes, api_view
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
import pusher
from whatsgoodly.models import LocalChannel

@api_view(['POST'])
@permission_classes((AllowAny, ))
@csrf_exempt
def channel_existence(request):
    webhook = verified_webhook(request)
    if webhook != None:
        handle_local_channel_events(webhook)
    return response.Response({}, status=200)

@api_view(['POST'])
@permission_classes((AllowAny, ))
@csrf_exempt
def client_event(request):
    # TODO client events
    # webhook = verified_webhook(request)
    # handle_local_channel_events(webhook)
    return response.Response({}, status=404)

@api_view(['POST'])
@permission_classes((AllowAny, ))
@csrf_exempt
def presence(request):
    # TODO: presence handlers
    # webhook = verified_webhook(request)
    # handle_local_channel_events(webhook)
    return response.Response({}, status=404)

def verified_webhook(request):
    wg_pusher = pusher.pusher.Pusher(
        app_id=settings.PUSHER_APP_ID,
        key=settings.PUSHER_KEY,
        secret=settings.PUSHER_SECRET
    )

    x_pusher_key = request.META.get('HTTP_X_PUSHER_KEY')
    x_pusher_signature = request.META.get('HTTP_X_PUSHER_SIGNATURE')
    return wg_pusher.validate_webhook(
        key=x_pusher_key,
        signature=x_pusher_signature,
        body=request.body
    )

def handle_local_channel_events(webhook):
    local_events = [
        event for event in webhook['events']
        if event['channel'].startswith('local')
    ]
    
    for event in local_events:
        channel_details = parse_channel(event['channel'])
        if event['name'] == 'channel_occupied':
            activate_local_channel(channel_details)
        elif event['name'] == 'channel_vacated':
            deactivate_local_channel(channel_details)

def parse_channel(channel):
    local_channel_components = channel.split(';')
    user_id = local_channel_components[0].split('-')[1]
    lat, lon = local_channel_components[1].split('_')

    return dict(
        channel=channel,
        user_id=int(user_id),
        lat=float(lat),
        lon=float(lon)
    )

def activate_local_channel(details):
    # This handles multiple user locations
    # Reuses rows for efficiency / to avoid race conditions
    user_channel = LocalChannel.objects\
        .filter(user_id=details['user_id'])\
        .order_by('-id').first()

    if not user_channel:
        user_channel = LocalChannel(user_id=details['user_id'])

    user_channel.name = details['channel']
    user_channel.location = "POINT ({0} {1})".format(details['lon'], details['lat'])
    user_channel.active = True
    user_channel.save()

def deactivate_local_channel(details):
    LocalChannel.objects.filter(
            user_id=details['user_id'],
            location="POINT ({0} {1})".format(details['lon'], details['lat']),
            active=True
        ).update(active=False)
