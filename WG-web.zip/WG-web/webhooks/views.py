from rest_framework import response
from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view, permission_classes, parser_classes
from rest_framework.parsers import JSONParser, FormParser
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
from whatsgoodly.models import *
from api.notifications import branch_install_notification
from api.slackbots import *
import json
from StringIO import StringIO

from raven import Client
client = Client(settings.RAVEN_CONFIG['dsn'])

WINSTON_SLACK_TOKEN = "5WL0DUSyl3HatU4WqLKtg2K1"
GUPTA_SLACK_TOKEN = "sYbcCXAQngsJmFdyOoeYGDNq"
CABO_SLACK_TOKEN = "jwYUGEHdbjkdMveqcDcmxdaI"
SHASTA_SLACK_TOKEN = "5kKhUMRwZ18oo5z9V5Pe3IjA"

@api_view(['POST'])
@permission_classes((AllowAny, ))
@csrf_exempt
def handle_branch_install(request):
  try:
    user_id = request.data.get('session_referring_identity', None)
    if user_id:
      try:
        user = User.objects.get(pk=int(user_id))
        branch_install_notification(user)
      except:
        pass
    return response.Response({}, status=200)
  except:
    client.captureException()

# EXAMPLE PAYLOAD:  "actions": [
#     {
#       "name": "decision",
#       "value": "verify"
#     }
#   ],
#   "callback_id": "poll_234233",
#   "user": {
#     "id": "U045VRZFT",
#     "name": "brautigan"
#   },
@api_view(['POST'])
@permission_classes((AllowAny, ))
@parser_classes((FormParser, ))
@csrf_exempt
def handle_winston_action(request):
  try:
    payload_string = request.data.get('payload')
    payload = json.loads(payload_string)
    token = payload.get('token', None)
    if token != WINSTON_SLACK_TOKEN:
      raise Exception("Wrong Slack token received")

    parts = payload.get('callback_id', '').split('_')
    if parts[0] == 'poll' and len(parts) == 2:
      obj = Poll.objects.get(id=parts[-1])
      message = Winston(poll=obj).respond(payload)
    elif parts[0] == 'comment':
      obj = Comment.objects.get(id=parts[-1])
      message = Winston(comment=obj).respond(payload)
    else:
      raise Exception("Unknown callback prefix")

    attachment = payload.get('original_message')['attachments'][0]
    attachment.pop('actions', None)
    attachment['text'] = u"{}\n{}".format(attachment['text'], message)
    payload = {
      'replace_original': True,
      'attachments': [attachment]
    }

    return response.Response(payload, status=200)
  except:
    client.captureException()

@api_view(['POST'])
@permission_classes((AllowAny, ))
@parser_classes((FormParser, ))
@csrf_exempt
def handle_gupta_action(request):
  try:
    payload_string = request.data.get('payload')
    payload = json.loads(payload_string)
    token = payload.get('token', None)
    if token != GUPTA_SLACK_TOKEN:
      raise Exception("Wrong Slack token received")

    parts = payload.get('callback_id', '').split('_')
    if parts[0] == 'poll' and parts[1] == 'instance':
      obj = PollInstance.objects.get(id=parts[-1])
      message = Gupta(poll_instance=obj).respond(payload)
    elif parts[0] == 'poll':
      obj = Poll.objects.get(id=parts[-1])
      message = Gupta(poll=obj).respond(payload)
    else:
      raise Exception("Unknown callback prefix")

    attachment = payload.get('original_message')['attachments'][0]
    attachment.pop('actions', None)
    attachment['text'] = u"{}\n{}".format(attachment['text'], message)
    payload = {
      'replace_original': True,
      'attachments': [attachment]
    }

    return response.Response(payload, status=200)
  except:
    client.captureException()

@api_view(['POST'])
@permission_classes((AllowAny, ))
@parser_classes((FormParser, ))
@csrf_exempt
def handle_cabo_action(request):
  try:
    payload_string = request.data.get('payload')
    payload = json.loads(payload_string)
    token = payload.get('token', None)
    if token != CABO_SLACK_TOKEN:
      raise Exception("Wrong Slack token received")

    parts = payload.get('callback_id', '').split('_')
    if parts[0] == 'poll' and parts[1] == 'instance':
      obj = PollInstance.objects.get(id=parts[-1])
      message, remove_actions = Cabo(poll_instance=obj).respond(payload)
    # elif obj_type == 'comment':
    #   obj = Comment.objects.get(id=obj_id)
    #   message = Gupta(comment=obj).respond(payload)
    else:
      raise Exception("Unknown callback prefix")

    attachment = payload.get('original_message')['attachments'][0]
    if remove_actions:
      attachment.pop('actions', None)
      attachment['text'] = u"{}\n{}".format(attachment['text'], message)
    payload = {
      'replace_original': True,
      'attachments': [attachment]
    }

    return response.Response(payload, status=200)
  except:
    client.captureException()

@api_view(['POST'])
@permission_classes((AllowAny, ))
@parser_classes((FormParser, ))
@csrf_exempt
def handle_shasta_action(request):
  try:
    payload_string = request.data.get('payload')
    payload = json.loads(payload_string)
    token = payload.get('token', None)
    if token != SHASTA_SLACK_TOKEN:
      raise Exception("Wrong Slack token received")

    parts = payload.get('callback_id', '').split('_')
    if parts[0] == 'poll' and parts[1] == 'instance':
      obj = PollInstance.objects.get(id=parts[-1])
      message, remove_actions = Shasta(poll_instance=obj).respond(payload)
    elif parts[0] == 'comment':
      obj = Comment.objects.get(id=parts[-1])
      message = Shasta(comment=obj).respond(payload)
    else:
      raise Exception("Unknown callback prefix")

    attachment = payload.get('original_message')['attachments'][0]
    attachment.pop('actions', None)
    attachment['text'] = u"{}\n{}".format(attachment['text'], message)
    payload = {
      'replace_original': True,
      'attachments': [attachment]
    }

    return response.Response(payload, status=200)
  except:
    client.captureException()
