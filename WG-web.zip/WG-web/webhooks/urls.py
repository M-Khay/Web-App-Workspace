from django.conf.urls import url, include
from webhooks.views import *

urlpatterns = [
    url(r'^pusher/', include('webhooks.pusher.urls')),
    url(r'^branch/install/$', handle_branch_install),
    url(r'^slack/action-endpoint/$', handle_winston_action),
    url(r'^slack/winston/$', handle_winston_action),
    url(r'^slack/gupta/$', handle_gupta_action),
    url(r'^slack/cabo/$', handle_cabo_action),
    url(r'^slack/shasta/$', handle_shasta_action),
]
