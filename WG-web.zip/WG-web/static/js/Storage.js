(function() {

  var shouldWarnIncognito = true;

  function Storage(key) {
    if (!key) {
      throw new Error("No key provided");
    }
    
    this._storageKey = key;
    this.load();

    PubSub.subscribe("Storage.STORE." + key, function(topic, data) {
      this.set(data);
      PubSub.publish("Storage.STORED." + key, this.get());
    }.bind(this));

    return this;
  }

  // Use get when cache is trusted
  Storage.prototype.get = function() {
    return this._data;
  }

  // Use load when cache isn't trusted
  Storage.prototype.load = function() {
    var serializedData = localStorage.getItem(this._storageKey);

    if (serializedData) {
      try {
        this._data = JSON.parse(serializedData);
      } catch (e) {
        destroy();
      }
    } else {
      this._data = null;
    }
    
    return this._data;
  }

  Storage.prototype.set = function(data, tries) {
    tries = tries || 0;
    this._data = $.extend({}, this._data, data);

    try {

      localStorage.setItem(this._storageKey, JSON.stringify(this._data));
      return true;

    } catch (e) {
      // might be incognito! or something dumb
      console.warn(e);

      if (tries < 1) {
        // localStorage might be filled up
        Storage.destroyAll();
        return this.set(data, tries + 1);

      } else if (shouldWarnIncognito) {
        alert("Looks like you're browsing privately 👀\n" +
          ["This app is much more useful if it can remember you.", 
          "Open a normal window on your browser, use Chrome, or allow",
          "local storage."].join(' ')
        );
        shouldWarnIncognito = false;
      }
      return false;
    }
  }

  Storage.prototype.destroy = function() {
    this._data = null;
    localStorage.removeItem(this._storageKey);
  }

  Storage.destroyAll = function() {
    localStorage.clear();
  };

  WG.Storage = Storage;
})();
