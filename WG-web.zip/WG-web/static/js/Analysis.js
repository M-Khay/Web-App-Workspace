(function() {

var D = React.DOM,
    R = window.Recharts;

var MIN_RESULTS_FOR_HEATMAP = 5,
    MAX_BARS = 4,
    // Chrome bug needs delay before rechart data is fetched
    RECHART_CHROME_INITAL_RENDER_DELAY = 200,
    BAR_COLORS = ["#5DA5DA", "#FAA43A", "#60BD68", "#F17CB0", "#B2912F", "#F15854", "#4D4D4D"],
    AREA_COLORS = ["#5DA5DA", "#F15854", "#FAA43A", "#60BD68", "#B2912F", "#F17CB0", "#4D4D4D"],
    BREAKDOWN_LABELS = {
      COMBINED: 'Combined',
      MOBILE: 'Mobile',
      WEB: 'Web',
      GENDER: 'Gender',
      UNIVERSITY: 'University',
      SEGMENT: 'Custom'
    };

var pollType = React.PropTypes.shape({
  id: React.PropTypes.number.isRequired,
  question: React.PropTypes.string.isRequired,
  options: React.PropTypes.arrayOf(React.PropTypes.string.isRequired).isRequired,
  option_counts: React.PropTypes.arrayOf(React.PropTypes.number.isRequired).isRequired
});

WG.Analysis = React.createFactory(React.createClass({

  propTypes: {
    poll: pollType.isRequired,
    breakdowns: React.PropTypes.arrayOf(
      React.PropTypes.shape({
        id: React.PropTypes.number.isRequired
      }).isRequired
    ),
    timelineSettings: React.PropTypes.object,
    surveyID: React.PropTypes.number,
    loading: React.PropTypes.bool,
    showHeader: React.PropTypes.bool,
  },

  getDefaultProps: function() {
    return {
      breakdowns: [],
      loading: false,
      showHeader: false
    }
  },

  // NOTE: updating state causes all charts to rerender and animate
  getInitialState: function() {
    return {
      disabledBreakdowns: {}
    }
  },

  componentDidUpdate: function(prevProps, prevState) {
    if (prevProps.breakdowns.length != this.props.breakdowns.length) {
      if (window.location.hash) {
        this.scrollTo(window.location.hash);
      }
    }
  },

  makeCombinedBreakdown: function() {
    var combinedCount = WG.utils.getResponseCount(this.props.poll);
    return {
      breakdown_type_label: BREAKDOWN_LABELS.COMBINED,
      percentages: this.props.poll.option_counts.map(function(optCount) {
        return optCount / combinedCount;
      }),
      total: combinedCount
    };
  },

  getGraphData: function(breakdowns, keyFunc) {
    var poll = this.props.poll;
    var data = [];

    poll.options.forEach(function(opt, i) {
      var datum = {option: opt};
      breakdowns.forEach(function(breakdown) {
        var value = breakdown.percentages[i];
        var key = keyFunc(breakdown);
        datum[key] = value;
      });
      data.push(datum);
    });

    return data;
  },

  scrollTo: function(href) {
    $('html, body').animate({
      scrollTop: $(href).offset().top - 140
    }, 500, function () {
      window.location.hash = href;
    });
  },

  onTOCRender: function(root) {
    if (!root) return;
    $(root).off('click.tocHash').on('click.tocHash', 'a', function(e) {
      e.preventDefault();
      $(root).removeClass('open');
      var href = $.attr(e.target, 'href');
      this.scrollTo(href);
    }.bind(this));
  },

  onBreakdownCheck: function(breakdownID, isChecked) {
    if (isChecked) {
      var disabledBreakdowns = this.state.disabledBreakdowns;
      delete disabledBreakdowns[breakdownID];
      this.setState({disabledBreakdowns:disabledBreakdowns});
    } else {
      var disabledBreakdowns = this.state.disabledBreakdowns;
      disabledBreakdowns[breakdownID] = true;
      this.setState({disabledBreakdowns:disabledBreakdowns});
    }
  },

  renderCustomSegment: function(breakdowns, key) {
    var poll = this.props.poll;
    var segmenter = breakdowns[0].segmenter;

    var maxSignificance = Math.max.apply( Math, breakdowns.map(function(b) {
      return b.significance;
    }) );

    var sortedBreakdowns = breakdowns.sort(function(a, b) {
      return a.segment_option - b.segment_option;
    });

    return (
      D.div({key: key, className: "row Analysis--segment"},
        D.h4({ className: "col-xs-12"},
          segmenter.question,
          D.small({style: {marginLeft: 15}}, "Significance: " + Math.round(maxSignificance*100) + "/100")
        ),
        D.div({ className: "col-sm-5 col-xs-12"},
          this.renderChart(sortedBreakdowns, getBreakdownLabel)
        ),
        D.table({ className: "Breakdowns col-sm-7 col-xs-12", id: "Breakdowns--seg-" + segmenter.id },
          D.tbody({className: "Breakdowns-tbody"},
            WG.AnalysisTableRow({ data: {poll: poll }}),
            sortedBreakdowns.map(function(breakdown, i) {
              var fallback = BAR_COLORS[i % BAR_COLORS.length];
              return WG.AnalysisTableRow({
                disabled: breakdown.id in this.state.disabledBreakdowns,
                data: breakdown, key: breakdown.id, fallbackColor: fallback,
                onCheck: this.onBreakdownCheck
              });
            }.bind(this))
          )
        )
      )
    )
  },
  
  renderTOC: function(bdownGroups, segmentGroups) {
    var disableGender = !bdownGroups[BREAKDOWN_LABELS.GENDER];
    var disableSegs = !bdownGroups[BREAKDOWN_LABELS.SEGMENT];
    var disableSchools = !bdownGroups[BREAKDOWN_LABELS.UNIVERSITY];

    return (
      D.div({className: "btn-group", role: "group",
          ref: this.onTOCRender},
        D.button({className: "btn btn-default dropdown-toggle",
          'data-toggle': "dropdown"},
          D.span({className: "toc-name"}, "Segment"),
          D.span({className: "caret", style: {marginLeft: 10}})
        ),
        D.ul({className: "dropdown-menu"},
          D.li({}, D.a({href: "#Breakdowns--overall"}, 
            "Overall"
          )),
          D.li({className: disableGender ? "disabled" : ""},
            D.a({href: "#Breakdowns--gender"}, "Genders")
          ),

          disableSegs
            ? null
            : [ D.li({key: "divider", role: "separator", className: "divider"}),
                Object.keys(segmentGroups).map(function(segId) {
                  var seg = segmentGroups[segId][0].segmenter;
                  return D.li({key: segId},
                    D.a({href: "#Breakdowns--seg-" + seg.id}, seg.question)
                  )
                })
              ],

          D.li({role: "separator", className: "divider"}),

          D.li({className: disableSchools ? "disabled" : ""},
            D.a({href: "#Breakdowns--schools"}, "Schools")
          )
        )
      )
    )
  },

  renderChart: function(breakdowns, dataKeyFn, defaultColor) {
    var toPercent = function(percent) {
      return percent ? Math.round(percent*100) : "0%";
    };

    var data = this.getGraphData(breakdowns, dataKeyFn);

    var filteredBreakdowns = breakdowns.filter(function(b) {

      return !(b.id in this.state.disabledBreakdowns);

    }.bind(this)).sort(function(a, b) {
      // Descending by total votes
      return b.total - a.total;
    }).slice(
      0, MAX_BARS
    );

    var isSkinny = WG.utils.isMobile();

    return React.createElement(R.ResponsiveContainer, {aspect: isSkinny ? 1.7 : 2},
      React.createElement(R.BarChart, {data: data, margin: isSkinny
          ? { top: 10, right: 0, left: -30, bottom: 0 }
          : { top: 10, right: 30, left: -30, bottom: 0 }
        },
        React.createElement(R.XAxis, {dataKey: "option", type: "category"}),
        React.createElement(R.YAxis, {tickFormatter: toPercent, type: "number"}),
        React.createElement(R.CartesianGrid, {strokeDasharray: "3 3"}),
        React.createElement(R.Tooltip),
        // React.createElement(R.Legend),
        filteredBreakdowns.map(function(bdown) {
          var i = breakdowns.indexOf(bdown);
          var formatter = function(val) {
            var suffix = " (" + Math.round(val * 100) + "%";
            if (bdown.breakdown_type_label != BREAKDOWN_LABELS.COMBINED) {
              suffix += " of segment";
            }
            suffix += ")";
            return Math.round(val * bdown.total) + suffix;
          };
          var color = bdown.color || defaultColor || BAR_COLORS[i % BAR_COLORS.length];
          return React.createElement(R.Bar, {
            key: i, dataKey: dataKeyFn(bdown), fill: color,
            formatter: formatter
          });
        })
      )
    )
  },
  
  render: function() {

    if (!this.props.breakdowns.length) {
      return null;
    }

    var exportURL = this.props.surveyID ?
        "/survey/" + this.props.surveyID + "/export/"
      : "export/";

    var poll = this.props.poll;

    var groups = WG.utils.groupBy(this.props.breakdowns, 'breakdown_type_label');
    
    var segmentGroups = WG.utils.groupBy(groups[BREAKDOWN_LABELS.SEGMENT] || [], function(bdown){
      return bdown.segmenter.question
    });

    (groups[BREAKDOWN_LABELS.GENDER] || []).sort(function(a, b) {
      return a.gender - b.gender;
    });

    (groups[BREAKDOWN_LABELS.UNIVERSITY] || []).sort(function(a, b) {
      return b.total - a.total;
    });

    var deviceBreakdowns = groups[BREAKDOWN_LABELS.MOBILE].concat(groups[BREAKDOWN_LABELS.WEB]);
    var combinedBreakdown = this.makeCombinedBreakdown();

    return (
      D.div({className: "Analysis"},
        D.div({className: "btn-group pull-right", role: "group"},
          this.renderTOC(groups, segmentGroups),
          D.a({className: "btn btn-default", href: exportURL},
            D.span({className: "glyphicon glyphicon-download-alt left"}),
            "Export"
          )
        ),

        this.props.showHeader ?
          D.div({className: "clearfix"},
            D.header({className: "row"},
              WG.Spinner({
                className: "pull-left", scale: 0.2,
                spinning: this.props.loading
              }),
              D.h2({className: "question", style: {margin: 5}},
                poll.question
              )
            ),
            WG.Methodology({poll: poll}),
            WG.ResponseTimeline({
              currentPoll: poll,
              timelineSettings: this.props.timelineSettings
            })
          )
          : null,


        D.div({style: this.props.style},

          D.section({},
            D.h3({}, "Overall"),
            D.div({className: "row"},
              D.div({ className: "col-sm-5 col-xs-12"},
                this.renderChart([combinedBreakdown], getBreakdownLabel, "#8A14CC")
              ),
              D.table({ className: "Breakdowns col-sm-7 col-xs-12", id: "Breakdowns--overall" },
                D.tbody({className: "Breakdowns-tbody"},
                  WG.AnalysisTableRow({ data: {poll: poll} }),
                  deviceBreakdowns.map(function(breakdown) {
                    return WG.AnalysisTableRow({
                      disabled: breakdown.id in this.state.disabledBreakdowns,
                      data: breakdown, key: breakdown.id,
                      onCheck: this.onBreakdownCheck
                    });
                  }.bind(this))
                )
              )
            )
          ),

          groups[BREAKDOWN_LABELS.GENDER] ?
            D.section({},
              D.h3({}, "Genders"),
              D.div({className: "row"},
                D.div({ className: "col-sm-5 col-xs-12"},
                  this.renderChart(groups[BREAKDOWN_LABELS.GENDER] || [], getBreakdownLabel)
                ),
                D.table({ className: "Breakdowns col-sm-7 col-xs-12", id: "Breakdowns--gender" },
                  D.tbody({className: "Breakdowns-tbody"},
                    WG.AnalysisTableRow({ data: {poll: poll} }),
                    groups[BREAKDOWN_LABELS.GENDER].map(function(breakdown) {
                      return WG.AnalysisTableRow({
                        disabled: breakdown.id in this.state.disabledBreakdowns,
                        data: breakdown, key: breakdown.id,
                        onCheck: this.onBreakdownCheck
                      });
                    }.bind(this))
                  )
                )
              )
            )
            : null,

          D.section({},
            D.h3({}, "Custom Segments"),
            Object.keys(segmentGroups).map(function(key) {
              return this.renderCustomSegment(segmentGroups[key], key)
            }.bind(this))
          ),

          D.section({},
            D.h3({}, "Schools"),
            groups[BREAKDOWN_LABELS.UNIVERSITY]
              ? D.table({ className: "Breakdowns", id: "Breakdowns--schools" },
                  D.tbody({className: "Breakdowns-tbody"},
                    WG.AnalysisTableRow({ data: {poll: poll} }),
                    groups[BREAKDOWN_LABELS.UNIVERSITY].map(function(breakdown) {
                      return WG.AnalysisTableRow({
                        disabled: breakdown.id in this.state.disabledBreakdowns,
                        data: breakdown, key: breakdown.id,
                        onCheck: this.onBreakdownCheck
                      });
                    }.bind(this))
                  )
                )
              : "None"
          )
        )
      )
    )
  }
}));

/**
 * PollResponseList class (each row)
 */

WG.AnalysisTableRow = React.createFactory(React.createClass({

  propTypes: {
    data: React.PropTypes.shape({
      id: React.PropTypes.number,
      poll: React.PropTypes.shape({
        question: React.PropTypes.string.isRequired,
        options: React.PropTypes.arrayOf(React.PropTypes.string.isRequired).isRequired
      }),
      percentages: React.PropTypes.arrayOf(React.PropTypes.number),
      breakdown_type_label: React.PropTypes.oneOf(WG.utils.values(BREAKDOWN_LABELS)),
      color: React.PropTypes.string,
      label_short: React.PropTypes.string
    }),
    fallbackColor: React.PropTypes.string,
    onCheck: React.PropTypes.func,
    disabled: React.PropTypes.bool
  },

  renderPollOptions: function() {
    var opts = this.props.data.poll.options;

    return D.table({className: "sub-table"},
      D.tbody({},
        D.tr({},
          opts.map(function(opt, i) {
            return D.th({key: i}, opt);
          })
        )
      )
    );
  },

  renderPercentages: function() {
    var colorRed = function(opacity) {
      if (this.props.data.total < MIN_RESULTS_FOR_HEATMAP) {
        return "white";
      }
      return "rgba(255, 160, 160, " + Math.pow(opacity, 2.5) + ")";
    }.bind(this);
    return D.table({className: "sub-table"},
      D.tbody({},
        D.tr({},
          this.props.data.percentages.map(function(num, i) {
            var style = {backgroundColor: colorRed(num)};
            return D.td({key: i, style: style},
              Math.round(num*100) + "%"
            );
          })
        )
      )
    );
  },

  render: function() {
    var color = this.props.data.color || this.props.fallbackColor;
    var checkbox = D.input({type: "checkbox", className: "left", checked: !this.props.disabled, onChange: function(e) {
      if (this.props.onCheck) {
        this.props.onCheck(this.props.data.id, e.target.checked);
      }
    }.bind(this)});

    var label = getBreakdownLabel(this.props.data);
    var style = color ? {color: color} : null;

    return D.tr({ className: "Breakdown" },
      D.th({style: style},
        this.props.data.breakdown_type_label == BREAKDOWN_LABELS.SEGMENT ?
            checkbox
          : null,
        label
      ),
      D.td({className: "text-center no-pad"},
        this.props.data.percentages
          ? this.renderPercentages()
          : this.renderPollOptions()
      ),
      this.props.data.total
        ? D.td({className: "fixed-width text-right"}, this.props.data.total + " total")
        : D.td()
    )
  }

}));





/*

  SURVEY TIMELINE

*/

WG.ResponseTimeline = React.createFactory(React.createClass({

  propTypes: {
    currentPoll: pollType,
    survey: React.PropTypes.shape({
      id: React.PropTypes.number.isRequired,
      name: React.PropTypes.string.isRequired,
      is_public: React.PropTypes.bool.isRequired,
      timeline_setting: React.PropTypes.number.isRequired,
      // map_setting: React.PropTypes.number.isRequired
    }),
    timelineSettings: React.PropTypes.object.isRequired
  },

  getInitialState: function() {
    var initialSetting = this.props.survey
      ? this.props.survey.timeline_setting
      : 1; // The first time-based setting
    return {
      loading: false,
      timelineSetting: initialSetting,
      timeGroups: []
    }
  },

  componentWillMount: function() {
    this.spinner = new Spinner(WG.constants.SPINNER_SETUP);
  },

  componentDidMount: function() {
    this.spinnerNode = ReactDOM.findDOMNode(this);
    if (this.state.loading) {
      this.spinner.spin(this.spinnerNode);
    }
    setTimeout(this.fetchTimelineData, RECHART_CHROME_INITAL_RENDER_DELAY);
  },

  componentDidUpdate: function(prevProps, prevState) {
    if (this.state.loading && !prevState.loading) {
      this.spinner.spin(this.spinnerNode);
    }
    if (!this.state.loading) {
      this.spinner.stop();
    }
    if (this.props.survey != prevProps.survey ||
        this.props.currentPoll != prevProps.currentPoll) {
      this.setState(this.getInitialState(), function() {
        this.fetchTimelineData();
      }.bind(this));
    }
  },

  getTimelineURL: function() {
    var url;
    if (this.props.survey) {
      url = "/survey/" + this.props.survey.id + "/timeline/";
    } else if (this.props.currentPoll) {
      url = "/poll/" + this.props.currentPoll.id + "/timeline/";
    } else {
      throw new Error("Need a poll or a survey for timeline");
    }
    return url;
  },

  fetchTimelineData: function(poll) {
    this.setState({
      loading: true
    });

    if (this.xhr) {
      this.xhr.abort();
    }

    var data = {timeline_setting: this.state.timelineSetting};

    this.xhr = $.getJSON(this.getTimelineURL(), data)
      .done(function(data) {
          this.setState({
            timeGroups: data.time_groups
          });
        }.bind(this))
      .fail(function(data) {
          PubSub.publish(WG.actions.SHOW_ERROR, "Failed to load timeline: " + data.responseText);
        }.bind(this))
      .always(function(data) {
          this.setState({
            loading: false
          });
        }.bind(this));
  },

  handleTimelineSettingChange: function(e) {
    var value = e.target.value;
    this.setState({loading: true, timelineSetting: value}, function() {

      if (this.props.currentPoll || this.props.survey.is_public) {
        this.fetchTimelineData();
        return;
      }

      var url = "/survey/" + this.props.survey.id + "/update/";

      $.ajax({
        url: url,
        data: {timeline_setting: this.state.timelineSetting},
        type: 'PUT',
        success: function(data) {
          this.fetchTimelineData();
        }.bind(this),
        error: function(data) {
          PubSub.publish(WG.actions.SHOW_ERROR, "Failed to adjust timeline: " + data.responseText);
          this.setState({loading: false});
        }.bind(this)
      });
    });
  },

  renderTicker: function(option, finishPercent, startPercent, style) {
    // console.log(finishPercent, startPercent, finishPercent - startPercent);
    var change = finishPercent - startPercent,
        arrowClass = change < 0 ? "glyphicon-arrow-down" : "glyphicon-arrow-up";

    return (
      D.span({style: style},
        Math.round(finishPercent) + "% " + option,
        D.small({className: "right"},
          D.span({className: "glyphicon left " + arrowClass}),
          Math.round(change) + "%"
        )
      )
    )
  },

  render: function() {
    var isSkinny = WG.utils.isMobile();

    var style = {
      padding: isSkinny ? 0 : 15,
      minHeight: 200,
      position: 'relative'
    };

    var selectorStyle = {
      position: 'absolute',
      top: 10,
      right: 10,
      zIndex: 2
    };

    var headingStyle = {
      width: isSkinny ? "50%" : "80%",
      margin: 0,
      paddingTop: isSkinny ? 15 : 0
    };
    // var maxRespondents = Math.max.apply(null, this.props.survey.polls.map(getResponseCount));
    // var maxPoll = this.props.survey.polls.filter(function(p){
    //   return getResponseCount(p) == maxRespondents;
    // })[0];

    var latest = this.state.timeGroups[this.state.timeGroups.length - 1],
        latestTotal,
        latestMax,
        latestMaxIndex,
        earliestTotal,
        earliestPercent,
        latestResults = [];

    if (latest) {
      latestTotal = latest.totals.reduce(WG.utils.add, 0);
      latestPercents = latest.totals.map(function(count) {
        return count*100/(latestTotal || 1);
      });
      latestMax = Math.max.apply(null, latestPercents);
      latestMaxIndex = latestPercents.indexOf(latestMax);
      earliestTotal = this.state.timeGroups[0].totals.reduce(WG.utils.add, 0) || 1;
      earliestPercent = this.state.timeGroups[0].totals[latestMaxIndex]*100/earliestTotal;
    }

    return D.div({className: "Timeline", style: style},
      latest ?
        D.h5({className: "text-left", style: headingStyle},
            "Latest " + (latestMax >= 50 ? "Majority: " : "Plurality: "),
            this.renderTicker(
              latest.options[latestMaxIndex],
              latestMax,
              earliestPercent,
              {color: getColor(latestMaxIndex)}
            )
        )
        : null,

      D.div({style: selectorStyle},
        D.select({
            className: "form-control",
            style: {width: 150},
            value: this.state.timelineSetting,
            onChange: this.handleTimelineSettingChange
          },
          Object.keys(this.props.timelineSettings).sort().map(function(key) {
            return (
              D.option({key: key, value: key}, this.props.timelineSettings[key])
            )
          }.bind(this))
        )
      ),
      this.state.timeGroups.length
        ? ResponseTimelineGraph({
            timeGroups: this.state.timeGroups
          })
        : null
    )
  }

}));


var ResponseTimelineGraph = React.createFactory(React.createClass({
  propTypes: {
    // When this changes, component will update
    timeGroups: React.PropTypes.arrayOf(React.PropTypes.shape({
      date: React.PropTypes.string.isRequired,
      totals: React.PropTypes.arrayOf(React.PropTypes.number.isRequired).isRequired,
      options: React.PropTypes.arrayOf(React.PropTypes.string.isRequired).isRequired
    })).isRequired
  },

  getGraphData: function(options) {
    return this.props.timeGroups.map(function(group) {
      var labeledGroup = {
        counts: group.totals,
        date: moment(group.date).format("YYYY-MM-DD")
      };
      options.forEach(function(opt, i) {
        labeledGroup[opt] = group.totals[i];
      });
      return labeledGroup;
    });
  },

  shouldComponentUpdate: function(nextProps, nextState) {
    return nextProps.timeGroups != this.props.timeGroups;
  },

  render: function() {
    var toPercent = function(decimal, fixed) {
      return (decimal*100).toFixed(fixed || 0) + "%";
    };

    var options = (this.props.timeGroups[0] || {}).options || [];
    var data = this.getGraphData(options);

    var optionValueFormatter = function(val, dataKey, wrapper) {
      var datum = wrapper.payload;
      var total = datum.counts.reduce(WG.utils.add, 0);
      return val + " (" + Math.round(val / total * 100) + "%)";
    };

    var isSkinny = WG.utils.isMobile();
    var aspectRatio = isSkinny ? 1 : 3;

    return React.createElement(R.ResponsiveContainer, {aspect: aspectRatio},
      React.createElement(R.AreaChart, {
          data: data, stackOffset: "expand",
          margin: isSkinny
            ? {top: 30, right: 0, left: -20, bottom: 0}
            : {top: 12, right: 30, left: 0, bottom: 0}
        },
        React.createElement(R.XAxis, {dataKey: "date", type: "category"}),
        React.createElement(R.YAxis, {tickFormatter: toPercent, type: "number"}),
        React.createElement(R.CartesianGrid, {strokeDasharray: "3 3"}),
        React.createElement(R.Tooltip),
        React.createElement(R.Legend, {
          verticalAlign: "top", align: "left",
          height: 45
        }),
        options.map(function(opt, i) {
          var color = getColor(i);
          return React.createElement(R.Area, {
            key: i, type: 'monotone', stackId: "1", dataKey: opt,
            stroke: color, fill: color,
            formatter: optionValueFormatter
          });
        })
      )
    )
  }
}));

function getColor(index, label, isBarGraph) {
  var colors = isBarGraph ? BAR_COLORS : AREA_COLORS;
  return colors[index % colors.length];
}

function getBreakdownLabel(breakdown) {
  switch (breakdown.breakdown_type_label) {
    case BREAKDOWN_LABELS.GENDER:
      // Label_short is "Guys" and "Girls"
      return ["Male", "Female"][breakdown.gender];
    case BREAKDOWN_LABELS.UNIVERSITY:
      return breakdown.university.name;
    case BREAKDOWN_LABELS.SEGMENT:
      return breakdown.label_short;
    case BREAKDOWN_LABELS.MOBILE:
      return "Mobile";
    case BREAKDOWN_LABELS.WEB:
      return "Web";
    case BREAKDOWN_LABELS.COMBINED:
      return "Total"
    default:
      return "";
  }
}

})();

